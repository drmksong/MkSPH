//--------------------------------------------------------------------
// MkMori.h
// 
// Last Revised. 2004. April. 13
//--------------------------------------------------------------------

#pragma hdrstop
#include "stdafx.h"
#include "MkMori.h"

//--------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#pragma package(smart_init)
#endif
//--------------------------------------------------------------------
bool MkMori::Setup()
{
  int size;

  Elements.SetupStiff();

  Stiff.SetupMatrix(*NodeRef);
  Stiff.Assemble(Elements);

  size=Stiff.GetStiffMatrix().GetFI();
  if(Var.GetSize()!=size) Var.Initialize(size);
  if(RHS.GetSize()!=size) RHS.Initialize(size);

  return true;
}

void MkMori::CalcNodalLen() // nodal length
{
  static bool flag=true; 
  int i,nnode,nelem;
  float len;

  nnode = NodeRef->GetSize();
  nelem = Elements.GetSize();

  if(flag) for (i=0;i<nnode;i++) NodalLen(i) = 0;

  for(i=0;i<nelem;i++) {
    int nd[2];
    MkBeamElement *beam;
    beam = dynamic_cast<MkBeamElement*>(&Elements[i]);
    if(!beam) continue;
    len = beam->GetLength();
    nd[0] = beam->GetNodeNumber(0);
    nd[1] = beam->GetNodeNumber(1);
    if(flag) {
      NodalLen(nd[0]) += len/2;
      NodalLen(nd[1]) += len/2;
    }
  }
  //flag = false;  // hate this but...temporary!!!!
}

void MkMori::CorrectNodalLoad2()   // correct nodal load due to displacement
{
  float dis;
  int side;
  int nnode = NodeRef->GetSize();

  for(int i=0;i<nnode;i++) {
//    dis = ((*NodeRef)[i].PrimaryVar(0)+NodalDis(i))/2;
//    NodalLoad(i,0) -= NodalKh(i,0)*dis;
//    NodalLoad(i,1) -= NodalKh(i,1)*dis;
    dis = NodalDis(i,0);
    side = dis>0?1:0;
    NodalLoad(i,0) -= NodalKh(i,side)*dis;
    NodalLoad(i,1) -= NodalKh(i,side)*dis;
  }
}

void MkMori::CalcNodalPress()
{
  MkVector press;
  MkMatrix mat;
  int nnode,nelem,i,j;
  int nd[2];
  float len;
  MkBeamElement *beam;

  nnode = NodeRef->GetSize();
  nelem = Elements.GetSize();

  press.Initialize(nnode);
  mat.Initialize(nnode,nnode);

  for (i=0;i<nnode;i++) {
    press[i] = 0;
    for (j=0;j<nnode;j++) mat(i,j) = 0;
  }

  for (i=0;i<nnode;i++)
    press[i] = 8*NodalLoad(i,0);

  for(i=0;i<nelem;i++) {
    beam = dynamic_cast<MkBeamElement*>(&Elements[i]);
    if(!beam) continue;
    len = beam->GetLength();
    nd[0] = beam->GetNodeNumber(0);
    nd[1] = beam->GetNodeNumber(1);
    mat(nd[0],nd[0]) += 3*len;
    mat(nd[0],nd[1]) += len;
    mat(nd[1],nd[0]) += len;
    mat(nd[1],nd[1]) += 3*len;
  }

  mat.Solve(press,stHybrid);

  for (i=0;i<nnode;i++)
    NodalPress(i,0)=press[i];

  for (i=0;i<nnode;i++) {
    press[i] = 0;
    for (j=0;j<nnode;j++) mat(i,j) = 0;
  }

  for (i=0;i<nnode;i++)
    press[i] = 8*NodalLoad(i,1);

  for(i=0;i<nelem;i++) {
    beam = dynamic_cast<MkBeamElement*>(&Elements[i]);
    if(!beam) continue;
    len = beam->GetLength();
    nd[0] = beam->GetNodeNumber(0);
    nd[1] = beam->GetNodeNumber(1);
    mat(nd[0],nd[0]) += 3*len;
    mat(nd[0],nd[1]) += len;
    mat(nd[1],nd[0]) += len;
    mat(nd[1],nd[1]) += 3*len;
  }

  mat.Solve(press,stHybrid);

  for (i=0;i<nnode;i++)
    NodalPress(i,1)=press[i];
}

void MkMori::UpdateNodalDis()
{
  int i,j,k,size=Var.GetSize();
  for (i=0;i<size;i++) {
    j=Stiff.GetSteer().Node(i);
    k=Stiff.GetSteer().NDof(i);
    if((*NodeRef)[j].GetDOFs()[k].GetDOFType()==doftXDis) {
      NodalDis(j,0) = Var(i);
      (*NodeRef)[j].SetXDis(Var(i));
    }
    else if((*NodeRef)[j].GetDOFs()[k].GetDOFType()==doftZAng) {
      NodalDis(j,1) = Var(i);
      (*NodeRef)[j].SetZAng(Var(i));
    }
  }
}

void MkMori::UpdateNodalPress()
{
  int i,size=NodeRef->GetSize();
  for (i=0;i<size;i++) {
//    (*NodeRef)[i].SecondVar(0) = NodalPress(i,0);
//    (*NodeRef)[i].SecondVar(1) = NodalPress(i,1);
  }
}

bool MkMori::CheckTol(MkVector &f, MkVector &b)
{
  bool flag;
  float q,w;
  int size=f.GetSize();
  if(size!=b.GetSize()) return false;
  flag = true;
  for (int i=0;i<size;i++) {
    q = f(i);
    w = b(i);
    if(fabs(q-w)>TOL) flag = false;
  }
  return flag;
}

void MkMori::TrimNodalLoad()
{
  int i,size=NodeRef->GetSize();
  for (i=0;i<size;i++) {
    NodalLoad(i,0) = NodalLoad(i,0)<NodalLd(i,0)?NodalLoad(i,0):NodalLd(i,0);
    NodalLoad(i,0) = NodalLoad(i,0)>NodalLu(i,0)?NodalLoad(i,0):NodalLu(i,0);

    NodalLoad(i,1) = NodalLoad(i,1)>NodalLd(i,1)?NodalLoad(i,1):NodalLd(i,1);
    NodalLoad(i,1) = NodalLoad(i,1)<NodalLu(i,1)?NodalLoad(i,1):NodalLu(i,1);
  }
}

bool MkMori::Post()
{
  UpdateNodalDis();
  CorrectNodalLoad2();
  TrimNodalLoad();
  CalcNodalPress();
  UpdateNodalPress();

  int i,j,k,ndata=0,cnt=0;
  float t[]={0.0,0.25,0.5,0.75,1.0};
  float loc[2]={1e4,-1e4};
  for (i=0;i<Elements.GetSize();i++) {
    Elements[i].Post();
    if(Elements[i].isBeamElement()) {
      MkBeamElement *beam = dynamic_cast<MkBeamElement*>(&Elements[i]);
      if(!beam) continue;
      MkLine &l = beam->GetLine();
      if(l[0].X<loc[0]) loc[0] = l[0].X;
      if(l[0].X>loc[1]) loc[1] = l[0].X;
      ndata+=2;
    }
  }

  WallResult.Clear();
  WallResult.Initialize(6,ndata);

  cnt=0;
  for (i=0;i<Elements.GetSize();i++) {
    if(Elements[i].isBeamElement()) {
      MkBeamElement *beam = dynamic_cast<MkBeamElement*>(&Elements[i]);
      if(!beam) continue;
      MkLine &l = beam->GetLine();
      for(j=0;j<2;j++,cnt++) {
        WallResult(0,cnt) = fabs(loc[0]-l[0].X)<EPS?0:1; // wall
        WallResult(1,cnt) = l.GetDivision(j).Y+((j==0)?+EPS:-EPS); // y-coord
        WallResult(2,cnt) = beam->GetDisp(j); // dis
        WallResult(3,cnt) = 0; // press
        WallResult(4,cnt) = ((j==0)?1:-1)*beam->GetShearForce(j); // shear
        WallResult(5,cnt) = ((j==0)?1:-1)*beam->GetMoment(j); // mom
      }
    }
  }

  for (i=0;i<ndata-1;i++) {
    for (j=i+1;j<ndata;j++) {
      if(fabs(WallResult(0,i)-WallResult(0,j))<EPS && WallResult(1,i)<WallResult(1,j)) {
        for (k=0;k<WallResult.getSzX();k++) {
//          swap(WallResult(k,i),WallResult(k,j));
        }
      }
    }
  }

  for (i=0;i<Elements.GetSize();i++) {
    if(Elements[i].isTrussElement()) {
      MkTrussElement *truss = dynamic_cast<MkTrussElement*>(&Elements[i]);
      if(!truss) continue;
      MkLine &l = truss->GetLine();
      ndata++;
    }
  }

  AxialResult.Initialize(3,ndata);
  cnt=0;
  for (i=0;i<Elements.GetSize();i++) {
    if(Elements[i].isTrussElement()) {
      MkTrussElement *truss = dynamic_cast<MkTrussElement*>(&Elements[i]);
      if(!truss) continue;
      MkLine &l = truss->GetLine();
      AxialResult(0,cnt) = l.GetDivision(0.5).X; // x-coord
      AxialResult(1,cnt) = l.GetDivision(0.5).Y; // y-coord
      AxialResult(2,cnt) = truss->GetAxialForce(0.5) ; //   axial force
    }
  }

  return true;
}

bool MkMori::Out()
{
  FILE *fp;
  char str[256];
  static bool flag=false;
  int nnode,nelem,i;
  memset(str,'\0',255);
  nnode = NodeRef->GetSize();
  nelem = Elements.GetSize();

  MkDebug("MkMori::Start function Out()\n");

  MkDebug("FileName is ");MkDebug(FileName);MkDebug("\n");

  if(strlen(FileName)) {
    fp = fopen(FileName,"a");

    if(!fp) {
      MkDebug(FileName);MkDebug(" is not found...fp is null so return false\n");
      return false;
    }

    if(!flag) {
      sprintf(str,"--------------BASIC OUTPUT-------------------\n");
      fputs(str,fp);
      sprintf(str,"- This is tempory outfile format to verify  -\n");
      fputs(str,fp);
      sprintf(str,"- the program logic and the results.        -\n");
      fputs(str,fp);
      sprintf(str,"- ESCOT(c)Copyright 2004, ESCO Eng. & Cons. -\n");
      fputs(str,fp);
      sprintf(str,"---------------------------------------------\n\n");
      fputs(str,fp);
    }

    sprintf(str,"STEP : %d\n\n",Step);
    fputs(str,fp);

    sprintf(str,"Node coordinate : number of node is %d\n", nnode);
    fputs(str,fp);
//               12345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890
    sprintf(str,"node      x       y    disp        ld     lload        lu        rd     rload        ru    lstiff    rstiff\n");
    fputs(str,fp);

    for(i=0;i<nnode;i++) {
      float load;
      load = NodalLoad(i,0);
      load = NodalLoad(i,1);

      sprintf(str,"%3d %7.1f %7.1f %7.3f %9.3f %9.3f %9.3f %9.3f %9.3f %9.3f %9.3f %9.3f\n",
        i, (*NodeRef)[i].GetPoint().X, (*NodeRef)[i].GetPoint().Y,
        (*NodeRef)[i].GetXDis()*1000,NodalLd(i,0),NodalLoad(i,0),NodalLu(i,0),NodalLd(i,1),NodalLoad(i,1),NodalLu(i,1)
        ,NodalKh(i,0),NodalKh(i,1));
      fputs(str,fp);
    }

    sprintf(str,"\nElement : number of element is %d\n", nelem);
    fputs(str,fp);

//                 12345678901234567890123456789012345678901234567890
    sprintf(str,"   element    node0     node1 \n");
    fputs(str,fp);

    for(i=0;i<nelem;i++) {
      sprintf(str,"%10d %10d %10d\n", i, Elements[i].GetNodeNumber(0),Elements[i].GetNodeNumber(1));
      fputs(str,fp);
    }
    fclose(fp);
  }

#ifdef __BCPLUSPLUS__
  if(Memo) {
    sprintf(str,"STEP : %d\n\n",Step);
    Memo->Lines->Add(str);

//               123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890
    sprintf(str,"     node         x         y         z      disp    lpress    rpress     lload    rload\n");
    Memo->Lines->Add(str);

    for(int i=0;i<nnode;i++) {
      sprintf(str,"%3d %7.1f %7.1f %7.3f %9.3f %9.3f %9.3f %9.3f %9.3f %9.3f %9.3f %9.3f\n",
        i, (*NodeRef)[i].GetPoint().X, (*NodeRef)[i].GetPoint().Y,
        (*NodeRef)[i].GetXDis()*1000,NodalLd(i,0),NodalLoad(i,0),NodalLu(i,0),NodalLd(i,1),NodalLoad(i,1),NodalLu(i,1)
        ,NodalKh(i,0),NodalKh(i,1));
      Memo->Lines->Add(str);
    }

    sprintf(str,"\nElement : number of element is %d\n", nelem);
//    Memo->Lines->Add(str);
//               12345678901234567890123456789012345678901234567890
    sprintf(str,"   element    node0     node1 \n");
//    Memo->Lines->Add(str);

    for(int i=0;i<nelem;i++) {
      sprintf(str,"%10d %10d %10d\n", i, Elements[i].GetNodeNumber(0),Elements[i].GetNodeNumber(1));
//      Memo->Lines->Add(str);
    }
  }
#endif

  flag = true;
  return flag;
}

bool MkMori::Out(char *fname)
{
  FILE *fp;
  char str[256];
  static bool flag=false;
  int nnode,nelem,i;

  SetFileName(fname);
  memset(str,'\0',255);
  nnode = NodeRef->GetSize();
  nelem = Elements.GetSize();

  MkDebug("MkMori::Start function Out()\n");

  MkDebug("FileName is ");MkDebug(FileName);MkDebug("\n");

  if(strlen(FileName)) {
    if(!flag) fp = fopen(FileName,"w");
    else fp = fopen(FileName,"a");

    if(!fp) {
      MkDebug(FileName);MkDebug(" is not found...fp is null so return false\n");
      return false;
    }

    if(!flag) {
      sprintf(str,"--------------BASIC OUTPUT-------------------\n");
      fputs(str,fp);
      sprintf(str,"- This is tempory outfile format to verify  -\n");
      fputs(str,fp);
      sprintf(str,"- the program logic and the results.        -\n");
      fputs(str,fp);
      sprintf(str,"- ESCOT(c)Copyright 2004, ESCO Eng. & Cons. -\n");
      fputs(str,fp);
      sprintf(str,"---------------------------------------------\n\n");
      fputs(str,fp);
    }

    sprintf(str,"STEP : %d\n\n",Step);
    fputs(str,fp);

    sprintf(str,"Node coordinate : number of node is %d\n", nnode);
    fputs(str,fp);
//               12345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890
    sprintf(str,"     node         x         y         z      disp    lpress    rpress     lload     rload    lstiff    rstiff\n");
    fputs(str,fp);

    for(i=0;i<nnode;i++) {
      sprintf(str,"%9d %9.3f %9.3f %9.3f %9.6f %9.6f %9.6f %9.6f %9.6f %9.3f %9.3f\n",
        i, (*NodeRef)[i].GetPoint().X, (*NodeRef)[i].GetPoint().Y,(*NodeRef)[i].GetPoint().Z,
        (*NodeRef)[i].GetXDis()*1000,NodalPress(i,0),NodalPress(i,1),
        NodalLoad(i,0),NodalLoad(i,1),NodalSubreact(i,0),NodalSubreact(i,1));
      fputs(str,fp);
    }

    sprintf(str,"\nElement : number of element is %d\n", nelem);
    fputs(str,fp);

//               12345678901234567890123456789012345678901234567890
    sprintf(str,"   element    node0     node1 \n");
    fputs(str,fp);

    for(i=0;i<nelem;i++) {
      sprintf(str,"%10d %10d %10d\n", i, Elements[i].GetNodeNumber(0),Elements[i].GetNodeNumber(1));
      fputs(str,fp);
    }
    fclose(fp);
  }
  flag = true;
  return flag;
}

bool MkMori::CalcNodalLoad(MkLoad *load, MkFloat &Nodal)
{
  int j,k,l;
  bool flag;
  MkPolygon poly;
  MkPolygon press;
  MkPoint pnt[2];
  MkPoint isp[2];
  MkLine line,tl;
  MkPoints pnts;
  MkElements telem;
  char str[256];
  int side;

  flag = true;
  flag = flag && load->GetLoadType() != ltRankine;
  flag = flag && load->GetLoadType() != ltPointBackLoad;
  flag = flag && load->GetLoadType() != ltLineBackLoad;
  flag = flag && load->GetLoadType() != ltStaticHydLoad;
  flag = flag && load->GetLoadType() != ltArbtrHydLoad;
  if (flag) return true;
  if (load->GetLoadType() == ltRankine) press = load->GetStaticPress();
  else if (load->GetLoadType() != ltPointBackLoad) press = load->GetBackLoad();
  else if (load->GetLoadType() != ltLineBackLoad) press = load->GetBackLoad();
  else if (load->GetLoadType() != ltStaticHydLoad) press = load->GetWatPress();
  else if (load->GetLoadType() != ltArbtrHydLoad) press = load->GetWatPress();
  
  side = load->GetDirection()[0] > 0 ? 0 : 1;

  for(j=0;j<NodeRef->GetSize();j++) {
    pnts.Clear();
    if(load->isIn((*NodeRef)[j].GetPoint())) {
      telem.Clear();
      for(k=0;k<Elements.GetSize();k++) {
	flag = true;
	for(l=0;l<Elements[k].GetElemNode().getSzX();l++)
	  flag = flag && load->isIn(Elements[k].GetElemNode(l).GetPoint());
	for(l=0;l<Elements[k].GetElemNode().getSzX();l++)
	  if(flag && Elements[k].GetElemNode(l)==(*NodeRef)[j])
	    telem.Add(&Elements[k]);
      }

      poly.Clear();
      if (telem.GetSize()==1) {
	pnt[0] = (*NodeRef)[j].GetPoint();
	pnt[1] = telem[0].GetCenter();
        pnt[0].X = 0;
        pnt[1].X = 0;
	isp[0] = NullPoint;
	isp[1] = NullPoint;
	if(pnt[0].Y < pnt[1].Y) Swap(pnt[0],pnt[1]);

	for(k=0;k<press.GetSize();k++) {
	  if(pnt[1].Y < press[k].Y && press[k].Y < pnt[0].Y)
	    pnts.Add(press[k]);
	}
	for(k=0;k<pnts.GetSize()-1;k++)  // sort
	  for(l=k+1;l<pnts.GetSize();l++)
	    if(pnts[k].Y < pnts[l].Y) Swap(pnts[k],pnts[l]);

	line.SetLine(MkPoint(-1.0e3,pnt[0].Y,0),MkPoint(1.0e3,pnt[0].Y,0));
	line.SetFiniteness(true);
	for(k=0;k<press.GetSize()-1;k++) {
	  tl = press(k);
	  tl.SetFiniteness(true);
	  if(line && tl) isp[0] = line.GetIntPoint(tl);
	}
	if(isp[0]==NullPoint) isp[0] = pnt[0];

	line.SetLine(MkPoint(-1.0e3,pnt[1].Y,0),MkPoint(1.0e3,pnt[1].Y,0));
	line.SetFiniteness(true);
	for(k=0;k<press.GetSize()-1;k++) {
	  tl = press(k);
	  tl.SetFiniteness(true);
	  if(line && tl) isp[1] = line.GetIntPoint(tl);
	}
	if(isp[1]==NullPoint) isp[1] = pnt[1];

	poly.Add(pnt[0]);
	if(pnt[0]!=isp[0]) poly.Add(isp[0]);
	for(k=0;k<pnts.GetSize();k++) poly.Add(pnts[k]);
	if(pnt[1]!=isp[1]) poly.Add(isp[1]);
	poly.Add(pnt[1]);

	sprintf(str,"%d-th node \n",j);
	MkDebug(str);
	for (k=0;k<poly.GetSize();k++) {
	  sprintf(str,"%d-th point of polyline is (%f, %f, %f)\n",k,poly[k].X,poly[k].Y,poly[k].Z);
	  MkDebug(str);
	}
      }
      else if (telem.GetSize()==2) {
	pnt[0] = NullPoint;
	pnt[1] = NullPoint;
	for(l=0;l<telem.GetSize()&&l<2;l++)
	  pnt[l] = telem[l].GetCenter();
	if(pnt[0].Y < pnt[1].Y) Swap(pnt[0],pnt[1]);
        pnt[0].X = 0;
        pnt[1].X = 0;


	for(k=0;k<press.GetSize();k++) {
	  if(pnt[1].Y < press[k].Y && press[k].Y < pnt[0].Y)
	    pnts.Add(press[k]);
	}
        for(k=0;k<pnts.GetSize()-1;k++)  // sort
	  for(l=k+1;l<pnts.GetSize();l++)
	    if(pnts[k].Y < pnts[l].Y) Swap(pnts[k],pnts[l]);

	line.SetLine(MkPoint(-1.0e3,pnt[0].Y,0),MkPoint(1.0e3,pnt[0].Y,0));
	line.SetFiniteness(true);
	for(k=0;k<press.GetSize()-1;k++) {
	  tl = press(k);
	  tl.SetFiniteness(true);
	  if(line && tl) isp[0] = line.GetIntPoint(tl);
	}

	line.SetLine(MkPoint(-1.0e3,pnt[1].Y,0),MkPoint(1.0e3,pnt[1].Y,0));
	line.SetFiniteness(true);
	for(k=0;k<press.GetSize()-1;k++) {
	  tl = press(k);
	  tl.SetFiniteness(true);
	  if(line && tl) isp[1] = line.GetIntPoint(tl);
	}

	poly.Add(pnt[0]);
	poly.Add(isp[0]);
	for(k=0;k<pnts.GetSize();k++) poly.Add(pnts[k]);
	poly.Add(isp[1]);
	poly.Add(pnt[1]);

	sprintf(str,"%d-th node \n",j);
	MkDebug(str);
	for (k=0;k<poly.GetSize();k++) {
	  sprintf(str,"%d-th point of polyline is (%f, %f, %f)\n",k,poly[k].X,poly[k].Y,poly[k].Z);
	  MkDebug(str);
	}
      }
      else
	MkDebug("Error in MkMori::CalcNodalLoad(load) telem.GetSize is neither 1 nor 2\n");
	  float area;
	  area = poly.GetArea();
      Nodal(j,side) += poly.GetArea();
    }
  }
  return true;
}

bool MkMori::CalcNodalLoad(MkLoad *load)
{
  int j,k,l;
  bool flag;
  MkPolygon poly;
  MkPolygon press;
  MkPoint pnt[2];
  MkPoint isp[2];
  MkLine line,tl;
  MkPoints pnts;
  MkElements telem;
  char str[256];
  int side;

  flag = true;
  flag = flag && load->GetLoadType() != ltRankine;
  flag = flag && load->GetLoadType() != ltPointBackLoad;
  flag = flag && load->GetLoadType() != ltLineBackLoad;
  flag = flag && load->GetLoadType() != ltStaticHydLoad;
  flag = flag && load->GetLoadType() != ltArbtrHydLoad;
  if (flag) return true;
  if (load->GetLoadType() == ltRankine) press = load->GetStaticPress();
  else if (load->GetLoadType() != ltPointBackLoad) press = load->GetBackLoad();
  else if (load->GetLoadType() != ltLineBackLoad) press = load->GetBackLoad();
  else if (load->GetLoadType() != ltStaticHydLoad) press = load->GetWatPress();
  else if (load->GetLoadType() != ltArbtrHydLoad) press = load->GetWatPress();
  
  side = load->GetDirection()[0] > 0 ? 0 : 1;

  for(j=0;j<NodeRef->GetSize();j++) {
    pnts.Clear();
    if(load->isIn((*NodeRef)[j].GetPoint())) {
      telem.Clear();
      for(k=0;k<Elements.GetSize();k++) {
	flag = true;
	for(l=0;l<Elements[k].GetElemNode().getSzX();l++)
	  flag = flag && load->isIn(Elements[k].GetElemNode(l).GetPoint());
	for(l=0;l<Elements[k].GetElemNode().getSzX();l++)
	  if(flag && Elements[k].GetElemNode(l)==(*NodeRef)[j])
	    telem.Add(&Elements[k]);
      }

      poly.Clear();
      if (telem.GetSize()==1) {
	pnt[0] = (*NodeRef)[j].GetPoint();
	pnt[1] = telem[0].GetCenter();
        pnt[0].X = 0;
        pnt[1].X = 0;
	isp[0] = NullPoint;
	isp[1] = NullPoint;
	if(pnt[0].Y < pnt[1].Y) Swap(pnt[0],pnt[1]);

	for(k=0;k<press.GetSize();k++) {
	  if(pnt[1].Y < press[k].Y && press[k].Y < pnt[0].Y)
	    pnts.Add(press[k]);
	}
	for(k=0;k<pnts.GetSize()-1;k++)  // sort
	  for(l=k+1;l<pnts.GetSize();l++)
	    if(pnts[k].Y < pnts[l].Y) Swap(pnts[k],pnts[l]);

	line.SetLine(MkPoint(-1.0e3,pnt[0].Y,0),MkPoint(1.0e3,pnt[0].Y,0));
	line.SetFiniteness(true);
	for(k=0;k<press.GetSize()-1;k++) {
	  tl = press(k);
	  tl.SetFiniteness(true);
	  if(line && tl) isp[0] = line.GetIntPoint(tl);
	}
	if(isp[0]==NullPoint) isp[0] = pnt[0];

	line.SetLine(MkPoint(-1.0e3,pnt[1].Y,0),MkPoint(1.0e3,pnt[1].Y,0));
	line.SetFiniteness(true);
	for(k=0;k<press.GetSize()-1;k++) {
	  tl = press(k);
	  tl.SetFiniteness(true);
	  if(line && tl) isp[1] = line.GetIntPoint(tl);
	}
	if(isp[1]==NullPoint) isp[1] = pnt[1];

	poly.Add(pnt[0]);
	if(pnt[0]!=isp[0]) poly.Add(isp[0]);
	for(k=0;k<pnts.GetSize();k++) poly.Add(pnts[k]);
	if(pnt[1]!=isp[1]) poly.Add(isp[1]);
	poly.Add(pnt[1]);

	sprintf(str,"%d-th node \n",j);
	MkDebug(str);
	for (k=0;k<poly.GetSize();k++) {
	  sprintf(str,"%d-th point of polyline is (%f, %f, %f)\n",k,poly[k].X,poly[k].Y,poly[k].Z);
	  MkDebug(str);
	}
      }
      else if (telem.GetSize()==2) {
	pnt[0] = NullPoint;
	pnt[1] = NullPoint;
	for(l=0;l<telem.GetSize()&&l<2;l++)
	  pnt[l] = telem[l].GetCenter();
	if(pnt[0].Y < pnt[1].Y) Swap(pnt[0],pnt[1]);
        pnt[0].X = 0;
        pnt[1].X = 0;


	for(k=0;k<press.GetSize();k++) {
	  if(pnt[1].Y < press[k].Y && press[k].Y < pnt[0].Y)
	    pnts.Add(press[k]);
	}
        for(k=0;k<pnts.GetSize()-1;k++)  // sort
	  for(l=k+1;l<pnts.GetSize();l++)
	    if(pnts[k].Y < pnts[l].Y) Swap(pnts[k],pnts[l]);

	line.SetLine(MkPoint(-1.0e3,pnt[0].Y,0),MkPoint(1.0e3,pnt[0].Y,0));
	line.SetFiniteness(true);
	for(k=0;k<press.GetSize()-1;k++) {
	  tl = press(k);
	  tl.SetFiniteness(true);
	  if(line && tl) isp[0] = line.GetIntPoint(tl);
	}

	line.SetLine(MkPoint(-1.0e3,pnt[1].Y,0),MkPoint(1.0e3,pnt[1].Y,0));
	line.SetFiniteness(true);
	for(k=0;k<press.GetSize()-1;k++) {
	  tl = press(k);
	  tl.SetFiniteness(true);
	  if(line && tl) isp[1] = line.GetIntPoint(tl);
	}

	poly.Add(pnt[0]);
	poly.Add(isp[0]);
	for(k=0;k<pnts.GetSize();k++) poly.Add(pnts[k]);
	poly.Add(isp[1]);
	poly.Add(pnt[1]);

	sprintf(str,"%d-th node \n",j);
	MkDebug(str);
	for (k=0;k<poly.GetSize();k++) {
	  sprintf(str,"%d-th point of polyline is (%f, %f, %f)\n",k,poly[k].X,poly[k].Y,poly[k].Z);
	  MkDebug(str);
	}
      }
      else
	MkDebug("Error in MkMori::CalcNodalLoad(load) telem.GetSize is neither 1 nor 2\n");
	  float area;
	  area = poly.GetArea();
      NodalLoad(j,side) += poly.GetArea();
    }
  }
  return true;
}

bool MkMori::CalcNodalLu(MkLoad *load)
{
  int j,k,l;
  bool flag;
  MkPolygon poly;
  MkPolygon press;
  MkPoint pnt[2];
  MkPoint isp[2];
  MkLine line,tl;
  MkPoints pnts;
  MkElements telem;
  char str[256];
  int side;

  flag = true;
  flag = flag && load->GetLoadType() != ltRankine;
  flag = flag && load->GetLoadType() != ltPointBackLoad;
  flag = flag && load->GetLoadType() != ltLineBackLoad;
  if (flag) return true;
  if (load->GetLoadType() == ltRankine) press = load->GetPassivPress();
  else if (load->GetLoadType() != ltPointBackLoad) press = load->GetBackLoad();
  else if (load->GetLoadType() != ltLineBackLoad) press = load->GetBackLoad();
  
  side = load->GetDirection()[0] > 0 ? 0 : 1;

  for(j=0;j<NodeRef->GetSize();j++) {
    pnts.Clear();
    if(load->isIn((*NodeRef)[j].GetPoint())) {
      telem.Clear();
      for(k=0;k<Elements.GetSize();k++) {
	flag = true;
	for(l=0;l<Elements[k].GetElemNode().getSzX();l++)
	  flag = flag && load->isIn(Elements[k].GetElemNode(l).GetPoint());
	for(l=0;l<Elements[k].GetElemNode().getSzX();l++)
	  if(flag && Elements[k].GetElemNode(l)==(*NodeRef)[j])
	    telem.Add(&Elements[k]);
      }

      poly.Clear();
      if (telem.GetSize()==1) {
	pnt[0] = (*NodeRef)[j].GetPoint();
	pnt[1] = telem[0].GetCenter();
        pnt[0].X = 0;
        pnt[1].X = 0;
	isp[0] = NullPoint;
	isp[1] = NullPoint;

	if(pnt[0].Y < pnt[1].Y) Swap(pnt[0],pnt[1]);

	for(k=0;k<press.GetSize();k++) {
	  if(pnt[1].Y < press[k].Y && press[k].Y < pnt[0].Y)
	    pnts.Add(press[k]);
	}
	for(k=0;k<pnts.GetSize()-1;k++)  // sort
	  for(l=k+1;l<pnts.GetSize();l++)
	    if(pnts[k].Y < pnts[l].Y) Swap(pnts[k],pnts[l]);

	line.SetLine(MkPoint(-1.0e3,pnt[0].Y,0),MkPoint(1.0e3,pnt[0].Y,0));
	line.SetFiniteness(true);
	for(k=0;k<press.GetSize()-1;k++) {
	  tl = press(k);
	  tl.SetFiniteness(true);
	  if(line && tl) isp[0] = line.GetIntPoint(tl);
	}
	if(isp[0]==NullPoint) isp[0] = pnt[0];

	line.SetLine(MkPoint(-1.0e3,pnt[1].Y,0),MkPoint(1.0e3,pnt[1].Y,0));
	line.SetFiniteness(true);
	for(k=0;k<press.GetSize()-1;k++) {
	  tl = press(k);
	  tl.SetFiniteness(true);
	  if(line && tl) isp[1] = line.GetIntPoint(tl);
	}
	if(isp[1]==NullPoint) isp[1] = pnt[1];

	poly.Add(pnt[0]);
	if(pnt[0]!=isp[0]) poly.Add(isp[0]);
	for(k=0;k<pnts.GetSize();k++) poly.Add(pnts[k]);
	if(pnt[1]!=isp[1]) poly.Add(isp[1]);
	poly.Add(pnt[1]);

	sprintf(str,"%d-th node \n",j);
	MkDebug(str);
	for (k=0;k<poly.GetSize();k++) {
	  sprintf(str,"%d-th point of polyline is (%f, %f, %f)\n",k,poly[k].X,poly[k].Y,poly[k].Z);
	  MkDebug(str);
	}
      }
      else if (telem.GetSize()==2) {
	pnt[0] = NullPoint;
	pnt[1] = NullPoint;
	for(l=0;l<telem.GetSize()&&l<2;l++)
	  pnt[l] = telem[l].GetCenter();
	if(pnt[0].Y < pnt[1].Y) Swap(pnt[0],pnt[1]);
        pnt[0].X = 0;
        pnt[1].X = 0;

	for(k=0;k<press.GetSize();k++) {
	  if(pnt[1].Y < press[k].Y && press[k].Y < pnt[0].Y)
	    pnts.Add(press[k]);
	}
        for(k=0;k<pnts.GetSize()-1;k++)  // sort
	  for(l=k+1;l<pnts.GetSize();l++)
	    if(pnts[k].Y < pnts[l].Y) Swap(pnts[k],pnts[l]);

	line.SetLine(MkPoint(-1.0e3,pnt[0].Y,0),MkPoint(1.0e3,pnt[0].Y,0));
	line.SetFiniteness(true);
	for(k=0;k<press.GetSize()-1;k++) {
	  tl = press(k);
	  tl.SetFiniteness(true);
	  if(line && tl) isp[0] = line.GetIntPoint(tl);
	}

	line.SetLine(MkPoint(-1.0e3,pnt[1].Y,0),MkPoint(1.0e3,pnt[1].Y,0));
	line.SetFiniteness(true);
	for(k=0;k<press.GetSize()-1;k++) {
	  tl = press(k);
	  tl.SetFiniteness(true);
	  if(line && tl) isp[1] = line.GetIntPoint(tl);
	}

	poly.Add(pnt[0]);
	poly.Add(isp[0]);
	for(k=0;k<pnts.GetSize();k++) poly.Add(pnts[k]);
	poly.Add(isp[1]);
	poly.Add(pnt[1]);

	sprintf(str,"%d-th node \n",j);
	MkDebug(str);
	for (k=0;k<poly.GetSize();k++) {
	  sprintf(str,"%d-th point of polyline is (%f, %f, %f)\n",k,poly[k].X,poly[k].Y,poly[k].Z);
	  MkDebug(str);
	}
      }
      else
	MkDebug("Error in MkMori::CalcNodalLu(load) telem.GetSize is neither 1 nor 2\n");
      NodalLu(j,side) += poly.GetArea();
    }
  }
  return true;
}

bool MkMori::CalcNodalLd(MkLoad *load)
{
  int j,k,l;
  bool flag;
  MkPolygon poly;
  MkPolygon press;
  MkPoint pnt[2];
  MkPoint isp[2];
  MkLine line,tl;
  MkPoints pnts;
  MkElements telem;
  char str[256];
  int side;

  flag = true;
  flag = flag && load->GetLoadType() != ltRankine;
  flag = flag && load->GetLoadType() != ltPointBackLoad;
  flag = flag && load->GetLoadType() != ltLineBackLoad;
  if (flag) return true;
  if (load->GetLoadType() == ltRankine) press = load->GetActivPress();
  else if (load->GetLoadType() != ltPointBackLoad) press = load->GetBackLoad();
  else if (load->GetLoadType() != ltLineBackLoad) press = load->GetBackLoad();
  
  side = load->GetDirection()[0] > 0 ? 0 : 1;

  for(j=0;j<NodeRef->GetSize();j++) {
    pnts.Clear();
    if(load->isIn((*NodeRef)[j].GetPoint())) {
      telem.Clear();
      for(k=0;k<Elements.GetSize();k++) {
	flag = true;
	for(l=0;l<Elements[k].GetElemNode().getSzX();l++)
	  flag = flag && load->isIn(Elements[k].GetElemNode(l).GetPoint());
	for(l=0;l<Elements[k].GetElemNode().getSzX();l++)
	  if(flag && Elements[k].GetElemNode(l)==(*NodeRef)[j])
	    telem.Add(&Elements[k]);
      }

      poly.Clear();
      if (telem.GetSize()==1) {
	pnt[0] = (*NodeRef)[j].GetPoint();
	pnt[1] = telem[0].GetCenter();
        pnt[0].X = 0;
        pnt[1].X = 0;
	isp[0] = NullPoint;
	isp[1] = NullPoint;
	if(pnt[0].Y < pnt[1].Y) Swap(pnt[0],pnt[1]);

	for(k=0;k<press.GetSize();k++) {
	  if(pnt[1].Y < press[k].Y && press[k].Y < pnt[0].Y)
	    pnts.Add(press[k]);
	}
	for(k=0;k<pnts.GetSize()-1;k++)  // sort
	  for(l=k+1;l<pnts.GetSize();l++)
	    if(pnts[k].Y < pnts[l].Y) Swap(pnts[k],pnts[l]);

	line.SetLine(MkPoint(-1.0e3,pnt[0].Y,0),MkPoint(1.0e3,pnt[0].Y,0));
	line.SetFiniteness(true);
	for(k=0;k<press.GetSize()-1;k++) {
	  tl = press(k);
	  tl.SetFiniteness(true);
	  if(line && tl) isp[0] = line.GetIntPoint(tl);
	}
	if(isp[0]==NullPoint) isp[0] = pnt[0];

	line.SetLine(MkPoint(-1.0e3,pnt[1].Y,0),MkPoint(1.0e3,pnt[1].Y,0));
	line.SetFiniteness(true);
	for(k=0;k<press.GetSize()-1;k++) {
	  tl = press(k);
	  tl.SetFiniteness(true);
	  if(line && tl) isp[1] = line.GetIntPoint(tl);
	}
	if(isp[1]==NullPoint) isp[1] = pnt[1];

	poly.Add(pnt[0]);
	if(pnt[0]!=isp[0]) poly.Add(isp[0]);
	for(k=0;k<pnts.GetSize();k++) poly.Add(pnts[k]);
	if(pnt[1]!=isp[1]) poly.Add(isp[1]);
	poly.Add(pnt[1]);

	sprintf(str,"%d-th node \n",j);
	MkDebug(str);
	for (k=0;k<poly.GetSize();k++) {
	  sprintf(str,"%d-th point of polyline is (%f, %f, %f)\n",k,poly[k].X,poly[k].Y,poly[k].Z);
	  MkDebug(str);
	}
      }
      else if (telem.GetSize()==2) {
	pnt[0] = NullPoint;
	pnt[1] = NullPoint;
	for(l=0;l<telem.GetSize()&&l<2;l++)
	  pnt[l] = telem[l].GetCenter();
	if(pnt[0].Y < pnt[1].Y) Swap(pnt[0],pnt[1]);
        pnt[0].X = 0;
        pnt[1].X = 0;

	for(k=0;k<press.GetSize();k++) {
	  if(pnt[1].Y < press[k].Y && press[k].Y < pnt[0].Y)
	    pnts.Add(press[k]);
	}
        for(k=0;k<pnts.GetSize()-1;k++)  // sort
	  for(l=k+1;l<pnts.GetSize();l++)
	    if(pnts[k].Y < pnts[l].Y) Swap(pnts[k],pnts[l]);

	line.SetLine(MkPoint(-1.0e3,pnt[0].Y,0),MkPoint(1.0e3,pnt[0].Y,0));
	line.SetFiniteness(true);
	for(k=0;k<press.GetSize()-1;k++) {
	  tl = press(k);
	  tl.SetFiniteness(true);
	  if(line && tl) isp[0] = line.GetIntPoint(tl);
	}

	line.SetLine(MkPoint(-1.0e3,pnt[1].Y,0),MkPoint(1.0e3,pnt[1].Y,0));
	line.SetFiniteness(true);
	for(k=0;k<press.GetSize()-1;k++) {
	  tl = press(k);
	  tl.SetFiniteness(true);
	  if(line && tl) isp[1] = line.GetIntPoint(tl);
	}

	poly.Add(pnt[0]);
	poly.Add(isp[0]);
	for(k=0;k<pnts.GetSize();k++) poly.Add(pnts[k]);
	poly.Add(isp[1]);
	poly.Add(pnt[1]);

	sprintf(str,"%d-th node \n",j);
	MkDebug(str);
	for (k=0;k<poly.GetSize();k++) {
	  sprintf(str,"%d-th point of polyline is (%f, %f, %f)\n",k,poly[k].X,poly[k].Y,poly[k].Z);
	  MkDebug(str);
	}
      }
      else
	MkDebug("Error in MkMori::CalcNodalLd(load) telem.GetSize is neither 1 nor 2\n");
      NodalLd(j,side) += poly.GetArea();
    }
  }
  return true;
}

bool MkMori::CalcNodalHydLoad(MkLoad *load)
{
  int j,k,l;
  bool flag;
  MkPolygon poly;
  MkPolygon press;
  MkPoint pnt[2];
  MkPoint isp[2];
  MkLine line,tl;
  MkPoints pnts;
  MkElements telem;
  char str[256];
  int side;

  flag = true;
  flag = flag && load->GetLoadType() != ltStaticHydLoad;
  flag = flag && load->GetLoadType() != ltArbtrHydLoad;
  if (flag) return true;
  if (load->GetLoadType() != ltStaticHydLoad) press = load->GetWatPress();
  else if (load->GetLoadType() != ltArbtrHydLoad) press = load->GetWatPress();
  
  side = load->GetDirection()[0] > 0 ? 0 : 1;

  for(j=0;j<NodeRef->GetSize();j++) {
    pnts.Clear();
    if(load->isIn((*NodeRef)[j].GetPoint())) {
      telem.Clear();
      for(k=0;k<Elements.GetSize();k++) {
	flag = true;
	for(l=0;l<Elements[k].GetElemNode().getSzX();l++)
	  flag = flag && load->isIn(Elements[k].GetElemNode(l).GetPoint());
	for(l=0;l<Elements[k].GetElemNode().getSzX();l++)
	  if(flag && Elements[k].GetElemNode(l)==(*NodeRef)[j])
	    telem.Add(&Elements[k]);
      }

      poly.Clear();
      if (telem.GetSize()==1) {
	pnt[0] = (*NodeRef)[j].GetPoint();
	pnt[1] = telem[0].GetCenter();
        pnt[0].X = 0;
        pnt[1].X = 0;
	isp[0] = NullPoint;
	isp[1] = NullPoint;
	if(pnt[0].Y < pnt[1].Y) Swap(pnt[0],pnt[1]);

	for(k=0;k<press.GetSize();k++) {
	  if(pnt[1].Y < press[k].Y && press[k].Y < pnt[0].Y)
	    pnts.Add(press[k]);
	}
	for(k=0;k<pnts.GetSize()-1;k++)  // sort
	  for(l=k+1;l<pnts.GetSize();l++)
	    if(pnts[k].Y < pnts[l].Y) Swap(pnts[k],pnts[l]);

	line.SetLine(MkPoint(-1.0e3,pnt[0].Y,0),MkPoint(1.0e3,pnt[0].Y,0));
	line.SetFiniteness(true);
	for(k=0;k<press.GetSize()-1;k++) {
	  tl = press(k);
	  tl.SetFiniteness(true);
	  if(line && tl) isp[0] = line.GetIntPoint(tl);
	}
	if(isp[0]==NullPoint) isp[0] = pnt[0];

	line.SetLine(MkPoint(-1.0e3,pnt[1].Y,0),MkPoint(1.0e3,pnt[1].Y,0));
	line.SetFiniteness(true);
	for(k=0;k<press.GetSize()-1;k++) {
	  tl = press(k);
	  tl.SetFiniteness(true);
	  if(line && tl) isp[1] = line.GetIntPoint(tl);
	}
	if(isp[1]==NullPoint) isp[1] = pnt[1];

	poly.Add(pnt[0]);
	if(pnt[0]!=isp[0]) poly.Add(isp[0]);
	for(k=0;k<pnts.GetSize();k++) poly.Add(pnts[k]);
	if(pnt[1]!=isp[1]) poly.Add(isp[1]);
	poly.Add(pnt[1]);

	sprintf(str,"%d-th node \n",j);
	MkDebug(str);
	for (k=0;k<poly.GetSize();k++) {
	  sprintf(str,"%d-th point of polyline is (%f, %f, %f)\n",k,poly[k].X,poly[k].Y,poly[k].Z);
	  MkDebug(str);
	}
      }
      else if (telem.GetSize()==2) {
	pnt[0] = NullPoint;
	pnt[1] = NullPoint;
	for(l=0;l<telem.GetSize()&&l<2;l++)
	  pnt[l] = telem[l].GetCenter();
	if(pnt[0].Y < pnt[1].Y) Swap(pnt[0],pnt[1]);
        pnt[0].X = 0;
        pnt[1].X = 0;

	for(k=0;k<press.GetSize();k++) {
	  if(pnt[1].Y < press[k].Y && press[k].Y < pnt[0].Y)
	    pnts.Add(press[k]);
	}
        for(k=0;k<pnts.GetSize()-1;k++)  // sort
	  for(l=k+1;l<pnts.GetSize();l++)
	    if(pnts[k].Y < pnts[l].Y) Swap(pnts[k],pnts[l]);

	line.SetLine(MkPoint(-1.0e3,pnt[0].Y,0),MkPoint(1.0e3,pnt[0].Y,0));
	line.SetFiniteness(true);
	for(k=0;k<press.GetSize()-1;k++) {
	  tl = press(k);
	  tl.SetFiniteness(true);
	  if(line && tl) isp[0] = line.GetIntPoint(tl);
	}

	line.SetLine(MkPoint(-1.0e3,pnt[1].Y,0),MkPoint(1.0e3,pnt[1].Y,0));
	line.SetFiniteness(true);
	for(k=0;k<press.GetSize()-1;k++) {
	  tl = press(k);
	  tl.SetFiniteness(true);
	  if(line && tl) isp[1] = line.GetIntPoint(tl);
	}

	poly.Add(pnt[0]);
	poly.Add(isp[0]);
	for(k=0;k<pnts.GetSize();k++) poly.Add(pnts[k]);
	poly.Add(isp[1]);
	poly.Add(pnt[1]);

	sprintf(str,"%d-th node \n",j);
	MkDebug(str);
	for (k=0;k<poly.GetSize();k++) {
	  sprintf(str,"%d-th point of polyline is (%f, %f, %f)\n",k,poly[k].X,poly[k].Y,poly[k].Z);
	  MkDebug(str);
	}
      }
      else
	MkDebug("Error in MkMori::CalcNodalHydLoad(load) telem.GetSize is neither 1 nor 2\n");
      NodalHydLoad(j,side) += poly.GetArea();
    }
  }
  return true;
}

bool MkMori::CalcNodalLu(MkLayers &lay)
{
  int i,j;
  int size;
  float ph,wp,kp;
  MkPoint p;
  size = NodalLu.getSzX();
  if(size!=NodalHydLoad.getSzX()) return false;

  for(i=0;i<size;i++) {
    for (j=0;j<2;j++) {
      p = (*NodeRef)[i].GetPoint();
      ph = NodalLu(i,j);
      wp = NodalHydLoad(i,j);
      kp = lay.GetKp(p);
      ph = ph-wp;
      ph = ph*kp+wp;
      NodalLu(i) = ph;
    }
  }
  return true;
}

bool MkMori::CalcNodalLd(MkLayers &lay)
{
  int i,j;
  int size;
  float ph,wp,ka;
  MkPoint p;
  size = NodalLd.getSzX();
  if(size!=NodalHydLoad.getSzX()) return false;

  for(i=0;i<size;i++) {
    for (j=0;j<2;j++) {
      p = (*NodeRef)[i].GetPoint();
      ph = NodalLd(i,j);
      wp = NodalHydLoad(i,j);
      ka = lay.GetKa(p);
      ph = ph-wp;
      ph = ph*ka+wp;
      NodalLd(i) = ph;
    }
  }
  return true;
}

bool MkMori::Apply(MkLoads &load,MkLayers &lay)
{
  // set NodalLoad, NodalLu, NodalLd
  int i,j;
  bool flag=true;
  float temp;
  MkNode node[2];
  int nodenum[2];

  for(i=0;i<NodeRef->GetSize();i++) {
    NodalLoad(i,0) = 0;
    NodalLoad(i,1) = 0;
    NodalLu(i,0) = 0;
    NodalLu(i,1) = 0;
    NodalLd(i,0) = 0;
    NodalLd(i,1) = 0;
  }

  for(i=0;i<load.GetSize();i++) {
    flag = CalcNodalLoad(&load[i]) && flag;
    flag = CalcNodalLu(&load[i]) && flag;
    flag = CalcNodalLd(&load[i]) && flag;
    flag = CalcNodalHydLoad(&load[i]) && flag;
  }
  flag = CalcNodalLu(lay) && flag;
  flag = CalcNodalLd(lay) && flag;

  for(i=0;i<NodeRef->GetSize();i++) {
    temp = NodalLoad(i,0);
    temp = NodalLoad(i,1);
    temp = NodalLu(i,0);
    temp = NodalLu(i,1);
    temp = NodalLd(i,0);
    temp = NodalLd(i,1);
  }

  return flag;
}

bool MkMori::Apply(MkSubreact &sub)
{
  int j,k,l;
  bool flag;
  MkPolygon poly;
  MkPolygon subreact;
  MkPoint pnt[2];
  MkPoint isp[2];
  MkLine line,tl;
  MkPoints pnts;
  MkElements telem;
  char str[256];
  int side;

  CalcNodalLen();  // absolutely!!!

  side = sub.GetDirection()[0]>0?0:1;
  subreact = sub.GetSubreact();

  for(j=0;j<NodeRef->GetSize();j++) {
    pnts.Clear();
    if(sub.isIn((*NodeRef)[j].GetPoint())) {
      telem.Clear();
      for(k=0;k<Elements.GetSize();k++) {
	flag = true;
	for(l=0;l<Elements[k].GetElemNode().getSzX();l++)
	  flag = flag && sub.isIn(Elements[k].GetElemNode(l).GetPoint());
	for(l=0;l<Elements[k].GetElemNode().getSzX();l++)
	  if(flag && Elements[k].GetElemNode(l)==(*NodeRef)[j])
	    telem.Add(&Elements[k]);
      }

      poly.Clear();
      if (telem.GetSize()==1) {
	pnt[0] = (*NodeRef)[j].GetPoint();
	pnt[1] = telem[0].GetCenter();
        pnt[0].X = 0;
        pnt[1].X = 0;

	isp[0] = NullPoint;
	isp[1] = NullPoint;
	if(pnt[0].Y < pnt[1].Y) Swap(pnt[0],pnt[1]);

	for(k=0;k<subreact.GetSize();k++) {
	  if(pnt[1].Y < subreact[k].Y && subreact[k].Y < pnt[0].Y)
	    pnts.Add(subreact[k]);
	}
	for(k=0;k<pnts.GetSize()-1;k++)  // sort
	  for(l=k+1;l<pnts.GetSize();l++)
	    if(pnts[k].Y < pnts[l].Y) Swap(pnts[k],pnts[l]);

	line.SetLine(MkPoint(-1.0e5,pnt[0].Y,0),MkPoint(1.0e5,pnt[0].Y,0));
	line.SetFiniteness(true);
	for(k=0;k<subreact.GetSize()-1;k++) {
	  tl = subreact(k);
	  tl.SetFiniteness(true);
	  if(line && tl) isp[0] = line.GetIntPoint(tl);
	}
	if(isp[0]==NullPoint) isp[0] = pnt[0];

	line.SetLine(MkPoint(-1.0e5,pnt[1].Y,0),MkPoint(1.0e5,pnt[1].Y,0));
	line.SetFiniteness(true);
	for(k=0;k<subreact.GetSize()-1;k++) {
	  tl = subreact(k);
	  tl.SetFiniteness(true);
	  if(line && tl) isp[1] = line.GetIntPoint(tl);
	}
	if(isp[1]==NullPoint) isp[1] = pnt[1];

	poly.Add(pnt[0]);
	if(pnt[0]!=isp[0]) poly.Add(isp[0]);
	for(k=0;k<pnts.GetSize();k++) poly.Add(pnts[k]);
	if(pnt[1]!=isp[1]) poly.Add(isp[1]);
	poly.Add(pnt[1]);

	sprintf(str,"%d-th node \n",j);
	MkDebug(str);
	for (k=0;k<poly.GetSize();k++) {
	  sprintf(str,"%d-th point of polyline is (%f, %f, %f)\n",k,poly[k].X,poly[k].Y,poly[k].Z);
	  MkDebug(str);
	}
      }
      else if (telem.GetSize()==2) {
	pnt[0] = NullPoint;
	pnt[1] = NullPoint;
	for(l=0;l<telem.GetSize()&&l<2;l++)
	  pnt[l] = telem[l].GetCenter();
	if(pnt[0].Y < pnt[1].Y) Swap(pnt[0],pnt[1]);
        pnt[0].X = 0;
        pnt[1].X = 0;

	for(k=0;k<subreact.GetSize();k++) {
	  if(pnt[1].Y < subreact[k].Y && subreact[k].Y < pnt[0].Y)
	    pnts.Add(subreact[k]);
	}
        for(k=0;k<pnts.GetSize()-1;k++)  // sort
	  for(l=k+1;l<pnts.GetSize();l++)
	    if(pnts[k].Y < pnts[l].Y) Swap(pnts[k],pnts[l]);

	line.SetLine(MkPoint(-1.0e5,pnt[0].Y,0),MkPoint(1.0e5,pnt[0].Y,0));
	line.SetFiniteness(true);
	for(k=0;k<subreact.GetSize()-1;k++) {
	  tl = subreact(k);
	  tl.SetFiniteness(true);
	  if(line && tl) isp[0] = line.GetIntPoint(tl);
	}

	line.SetLine(MkPoint(-1.0e5,pnt[1].Y,0),MkPoint(1.0e5,pnt[1].Y,0));
	line.SetFiniteness(true);
	for(k=0;k<subreact.GetSize()-1;k++) {
	  tl = subreact(k);
	  tl.SetFiniteness(true);
	  if(line && tl) isp[1] = line.GetIntPoint(tl);
	}

	poly.Add(pnt[0]);
	poly.Add(isp[0]);
	for(k=0;k<pnts.GetSize();k++) poly.Add(pnts[k]);
	poly.Add(isp[1]);
	poly.Add(pnt[1]);

	sprintf(str,"%d-th node \n",j);
	MkDebug(str);
	for (k=0;k<poly.GetSize();k++) {
	  sprintf(str,"%d-th point of polyline is (%f, %f, %f)\n",k,poly[k].X,poly[k].Y,poly[k].Z);
	  MkDebug(str);
	}
      }
      else
	MkDebug("Error in MkMori::Apply(subreact) telem.GetSize is neither 1 nor 2\n");
	  float area;
	  area = fabs(poly.GetArea()); // check needed because it is negative
      if(NodalLen(j)>EPS) NodalKh(j,side) += area;// fabs(poly.GetArea())/NodalLen(j);
    }
  }

  int nnode = NodeRef->GetSize();
  return true;
}

void MkMori::ApplySubreact(MkMatrix &mat)
{
  int i,j,k,size;
  size=RHS.GetSize();

  for (i=0;i<size;i++) {
    j=Stiff.GetSteer().Node(i);
    k=Stiff.GetSteer().NDof(i);
    if((*NodeRef)[j].GetDOFs()[k].GetDOFType()==doftXDis) {
      mat(i,i) += NodalDis(j,0)>0?2*NodalKh(j,1):2*NodalKh(j,0);
    }
  }
}

bool MkMori::Solve()
{
  static MkVector var,post;
  int i,j,k,size;
  bool flag=true, isfirst=true;
  int nnode = NodeRef->GetSize();
  char str[256];
  MkMatrix stiff;

  Step=0;

  UpdateNodalPress();

  do {
    flag=Setup() && flag;
    size=RHS.GetSize();

    for (i=0;i<JackingForce.GetSize();i++) {
      NodalLoad(JackingForce.GetNode(i),0) += JackingForce.GetForce(i);
    }
    for (i=0;i<IniForceCorrect.GetSize();i++) {
      NodalLoad(IniForceCorrect.GetNode(i),0) += IniForceCorrect.GetForce(i);
    }

    for (i=0;i<size;i++) {
      j=Stiff.GetSteer().Node(i);
      k=Stiff.GetSteer().NDof(i);
      if((*NodeRef)[j].GetDOFs()[k].GetDOFType()==doftXDis) {
		float nl,nr,r;
		nl = NodalLoad(j,0);
		nr = NodalLoad(j,1);
		r = NodalLoad(j,0)+NodalLoad(j,1);
		RHS(i) = NodalLoad(j,0)+NodalLoad(j,1);
	  }
    }

    for (i=0;i<JackingForce.GetSize();i++) {
      NodalLoad(JackingForce.GetNode(i),0) -= JackingForce.GetForce(i);
    }
    for (i=0;i<IniForceCorrect.GetSize();i++) {
      NodalLoad(IniForceCorrect.GetNode(i),0) -= IniForceCorrect.GetForce(i);
    }

    var = Var;
    Var = RHS;

    if(!(Step%PrintStep)) flag=Out() && flag;

    stiff = Stiff.GetStiffMatrix();
    ApplySubreact(stiff);

    stiff.Solve(Var,stHybrid);

    post = Var;

    for (i=0;i<size && isfirst;i++) {
      j=Stiff.GetSteer().Node(i);
      k=Stiff.GetSteer().NDof(i);
      if((*NodeRef)[j].GetDOFs()[k].GetDOFType()==doftXDis) {
        float dis;
        dis = Var(i);
        NodalDis(j,0) = Var(i);
      }
      else if((*NodeRef)[j].GetDOFs()[k].GetDOFType()==doftZAng) {
        float dis;
        dis = Var(i);
        NodalDis(j,1) = Var(i);
      }
    }
    Post();
    Step++;

    sprintf(str,"Current step is %d\n",Step);
    MkDebug(str);

    isfirst = false;
  } while(!CheckTol(post,var) && Step < 1/*MaxStep*/);

  flag=Out() && flag;

  return flag;
}
