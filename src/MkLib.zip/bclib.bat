bcc32 -c MkFloat.cpp
bcc32 -c MkInt.cpp
bcc32 -c MkPoint.cpp
bcc32 -c MkMatrix.cpp
bcc32 -c MkSparseMatrix.cpp 
bcc32 -c MkMisc.cpp 
bcc32 -c MkLine.cpp 
bcc32 -c MkPolygon.cpp 
bcc32 -c MkPlane.cpp 
bcc32 -c MkRect.cpp 
bcc32 -c MkCube.cpp 
bcc32 -c MkSphere.cpp 
bcc32 -c MkCylinder.cpp 
bcc32 -c MkShape.cpp 
bcc32 -c MkEntity.cpp 
bcc32 -c MkBndCon.cpp 
bcc32 -c MkRange.cpp 
bcc32 -c MkLoad.cpp 
bcc32 -c MkSteer.cpp 
bcc32 -c MkStiff.cpp 
bcc32 -c MkMesh.cpp 
bcc32 -c MkAnalysis.cpp 
bcc32 -c MkFEA.cpp 
bcc32 -c MkBeamSpring.cpp 
bcc32 -c MkExcavStep.cpp

tlib /u MkBClib.lib -+ MkFloat.obj MkInt.obj MkPoint.obj MkMatrix.obj MkNurbs.obj MkSparseMatrix.obj MkMisc.obj MkLine.obj MkPolygon.obj MkPlane.obj MkRect.obj MkCube.obj MkSphere.obj MkCylinder.obj MkShape.obj MkEntity.obj MkBndCon.obj MkRange.obj MkLoad.obj MkSteer.obj MkStiff.obj MkMesh.obj MkAnalysis.obj MkFEA.obj MkBeamSpring.obj MkExcavStep.obj c:\nurbs\lib\nurb.lib