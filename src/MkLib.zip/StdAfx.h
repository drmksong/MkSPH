// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//
#if defined(_MSC_VER)
#if !defined(AFX_STDAFX_H__6E4F3CD5_F04E_472F_ABA5_BD4A3498BBD3__INCLUDED_)
#define AFX_STDAFX_H__6E4F3CD5_F04E_472F_ABA5_BD4A3498BBD3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


// TODO: reference additional headers your program requires here

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__6E4F3CD5_F04E_472F_ABA5_BD4A3498BBD3__INCLUDED_)
#endif

