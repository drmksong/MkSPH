//---------------------------------------------------------------------------
// This module is general purposed simple graphic class to store, draw,
// manipulate object. It is well suited to VCL component, but not restricted.
// It forms the base for the higher level class, such as tunnel component.
//
// Copyright (c) 1999-2000 Myung Kyu Song, ESCO Consultant Co., Ltd.
			  
#include "MkPointData.h"
#include "WorldPaintBox.hpp"
#include <Math.hpp>
#include <Extctrls.hpp>
#include <Comctrls.hpp>

MkDataPoint NullDataPoint(0,0,0);
MkDataPoints NullDataPoints(0);

__fastcall MkDataPoint::MkDataPoint()
: MkPoint()
{
   Data = 0;
};

__fastcall MkDataPoint::MkDataPoint(float x,float y)
: MkPoint(x,y)
{
   Data = 0;
};

__fastcall MkDataPoint::MkDataPoint(float x,float y,float z)
:MkPoint(x,y,z)
{
   Data = 0;
};

MkDataPoint & __fastcall MkDataPoint::operator=(MkPoint rp)
{
   X = rp.X;
   Y = rp.Y;
   Z = rp.Z;
   Data = 0;
   return (*this);
}

MkDataPoint & __fastcall MkDataPoint::operator=(MkDataPoint rp)
{
   X = rp.X;
   Y = rp.Y;
   Z = rp.Z;
   Data = rp.Data;
   return (*this);
}

bool __fastcall MkDataPoint::operator==(MkDataPoint rp)
{
   return (fabs(X - rp.X)<FTOL) &&
          (fabs(Y - rp.Y)<FTOL) &&
          (fabs(Z - rp.Z)<FTOL) &&
          (fabs(Data-rp.Data) < FTOL);
}

bool __fastcall MkDataPoint::operator!=(MkDataPoint rp)
{
   return (fabs(X - rp.X)>FTOL)||
          (fabs(Y - rp.Y)>FTOL)||
          (fabs(Z - rp.Z)>FTOL)||
          (fabs(Data-rp.Data) > FTOL);
}

MkDataPoint __fastcall MkDataPoint::operator*(MkMatrix4 &rm)
{
   MkDataPoint rp;

   rp.X = X*rm[0][0]+Y*rm[0][1]+Z*rm[0][2];
   rp.Y = X*rm[1][0]+Y*rm[1][1]+Z*rm[1][2];
   rp.Z = X*rm[2][0]+Y*rm[2][1]+Z*rm[2][2];
   return rp;
}


__fastcall MkDataPoints::MkDataPoints(int size,MkDataPoint *rps)
{

    if (size < 0) {
      ShowMessage("::MkDataPoints - MkDataPoints(int size)");;
      return;
    }

    FSize = size;
    if (FSize == 0) {
       FPoint = NULL;
       return;
    }

    FPoint = new MkDataPoint[FSize];
    for (int i=0;i<FSize;i++) FPoint[i] = rps[i];
}

__fastcall MkDataPoints::MkDataPoints(int size)
{
    if (size < 0) {
      ShowMessage("::MkDataPoints - MkDataPoints(int size)");;
      return;
    }

    FSize = size;
    if (FSize == 0) {
       FPoint = NULL;
       return;
    }

    FPoint = new MkDataPoint[FSize];
}

__fastcall MkDataPoints::~MkDataPoints()
{
   FSize = 0;
   if (FPoint) {
      delete[] (MkDataPoint*)FPoint;
      FPoint = NULL;
   }
}

void __fastcall MkDataPoints::Initialize(int size)
{

    if (size < 0) {
      ShowMessage("::MkDataPoints - Initialize(int size)");;
      return;
    }
    if (FSize == size) return;

    FSize = size;
    if (FSize == 0) {
       if (FPoint!=NULL) delete[] (MkDataPoint*)FPoint;
       FPoint = NULL;
       return;
    }

    if (FPoint!=NULL) delete[] (MkDataPoint*)FPoint;
    FPoint = new MkDataPoint[FSize];
}

void __fastcall MkDataPoints::Initialize(int size,MkDataPoint *rps)
{

    if (size < 0 || rps == NULL) {
      ShowMessage("::MkDataPoints - Initialize(int size)");;
      return;
    }
    if (FSize == size) return;
    FSize = size;
    if (FSize == 0) {
       if (FPoint!=NULL) delete[] (MkDataPoint*)FPoint;
       FPoint = NULL;
       return;
    }

    if (FPoint!=NULL) delete[] (MkDataPoint*)FPoint;
    FPoint = new MkDataPoint[FSize];
    for (int i=0;i<FSize;i++) (*this)[i] = rps[i];
}

void __fastcall MkDataPoints::Grow(int Delta)
{
    int i;
    MkDataPoint *rp=NULL;

    rp = new MkDataPoint[FSize+Delta];
    for (i = 0; i < FSize;i++)
        rp[i] = FPoint[i];
    for (i=FSize; i<FSize+Delta;i++)
        rp[i] = NullDataPoint;
    if (FPoint) {
       delete[] (MkDataPoint*)FPoint;
       FPoint = NULL;
    }
    FPoint = rp;
    FSize = FSize+Delta;
}

bool __fastcall MkDataPoints::Add(MkDataPoint point)
{
    Grow(1);
    FPoint[FSize-1] = point;
    return true;
}

bool __fastcall MkDataPoints::Clear()
{

   FSize = 0;
   if (FPoint) {
      delete[] (MkDataPoint*)FPoint;
      FPoint = NULL;
   }
   return true;
}

MkDataPoint & __fastcall MkDataPoints::operator[](int i)
{
    if (FSize == 0) return NullDataPoint;
    else if (i >=0 && i < FSize) return FPoint[i];
    else return NullDataPoint;
}

MkDataPoints & __fastcall MkDataPoints::operator=(MkDataPoints &points)
{
    int i;

    Clear();
    FSize = points.FSize;
    if (FSize == 0) {
       this->FPoint = NULL;
       return *this;
    }
    this->FPoint = new MkDataPoint[FSize];

    for (i=0;i<FSize;i++)
      this->FPoint[i] = points.FPoint[i];

    return *this;
}

bool __fastcall MkDataPoints::operator==(MkDataPoints &points)
{
    int i;

    if (FSize != points.FSize) return false;
    for (i=0;i<FSize;i++)
      if (this->FPoint[i] != points.FPoint[i]) return false;

    return true;
}

MkDataPoints & __fastcall MkDataPoints::operator*(MkMatrix4 &rm)
{
    for (int i=0;i<FSize;i++)
        this->FPoint[i] = this->FPoint[i]*rm;
    return *this;
}

MkDataPoints & __fastcall MkDataPoints::Translate(MkPoint rp)
{
    for (int i=0;i<FSize;i++)
        this->FPoint[i].Translate(rp);
    return *this;
}

MkDataPoints & __fastcall MkDataPoints::Translate(MkDataPoint rp)
{
    for (int i=0;i<FSize;i++)
        this->FPoint[i].Translate(rp);
    return *this;
}

MkDataPoints & __fastcall MkDataPoints::Translate(float x,float y,float z)
{
    for (int i=0;i<FSize;i++)
        this->FPoint[i].Translate(x,y,z);
    return *this;
}

MkDataPoints & __fastcall MkDataPoints::Rotate(float alpha, float beta, float gamma)
{
    for (int i=0;i<FSize;i++)
        this->FPoint[i].Rotate(alpha,beta,gamma);
    return *this;
}

MkDataPoints & __fastcall MkDataPoints::Scale(float sx,float sy, float sz)
{
    for (int i=0;i<FSize;i++)
        this->FPoint[i].Scale(sx,sy,sz);
    return *this;
}


void __fastcall MkDataPoints::Draw(TObject *Sender)
{
    TColor C;
    float Offset;
    if (FSize == 0) return;
    if (String(Sender->ClassName()) == String("TWorldPaintBox")) {
       TWorldPaintBox *pb=(TWorldPaintBox*)Sender;
       C = pb->Canvas->Pen->Color;
       pb->Canvas->Pen->Color = Color;
       for (int i = 0; i < FSize;i++) {
           Offset = pb->Offset(3);
//           pb->Cube( (*this)[i].X-Offset,(*this)[i].Y-Offset,(*this)[i].Z-Offset,
//                            (*this)[i].X+Offset,(*this)[i].Y+Offset,(*this)[i].Z+Offset);
//           pb->Cube( (*this)[i].X-Offset,(*this)[i].Y-Offset,0,
//                            (*this)[i].X+Offset,(*this)[i].Y+Offset,0);
       }
       pb->Canvas->Pen->Color = C;
    }
}
//---------------------------------------------------------------------------
