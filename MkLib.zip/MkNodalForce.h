//---------------------------------------------------------------------------
#ifndef MkNodalForceH
#define MkNodalForceH
#include "MkInt.h"
#include "MkFloat.h"

class MkNodalForce {
private:
  int FSize;
  MkInt Node;
  MkFloat Force;
public:
  MkNodalForce(){FSize = 0;}
  ~MkNodalForce(){}
  void Add(int node,float f);
  void Del(int node,float f);
  int GetNode(int n){return Node(n);}
  float GetForce(int n){return Force(n);}
  int GetSize(){return FSize;}
  MkNodalForce &operator=(MkNodalForce &nf);
};
//---------------------------------------------------------------------------
#endif

