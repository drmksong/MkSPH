//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include "MkPrjReader.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)

MkPrjReader::MkPrjReader()
{
  memset(PrjFolder,'\0',255);
  LeftStartPoint=NullPoint;
  RightStartPoint=NullPoint;
  GroundDiff=0;

  Grounds=NULL;
  Layers=NULL;
  Wales=NULL;
  Struts=NULL;
  Piles=NULL;
  Bolts=NULL;
  Anchors=NULL;
  Memo = NULL;
}

MkPrjReader::MkPrjReader(char *fname)
{
  Read(fname);
}

MkPrjReader::~MkPrjReader()
{
  Clear();
}

bool MkPrjReader::Read(char *fname)
{
  bool flag;
  Clear();
  if(!strcmp(fname,PrjFolder)) return false;
  SetPrjName(fname);
  if(!ReadLayerName()) return false;
  if(!ReadCenterLine()) return false;
  if(!ReadSideLine()) return false;
  if(!ReadStartPosition()) return false;
  if(!ReadSectPoint()) return false;
  if(!ReadLayer()) return false;
  if(!ReadSectWidth()) return false;
  if(!ReadRSM()) return false;
  if(!ReadSupport()) return false;
  return true;
}

bool MkPrjReader::ReadLayerName()
{
  FILE *fp=NULL;
  char fname[256];
  char str[256];
  char title[256];
  strcpy(fname,PrjFolder);
  strcat(fname,"\\stratum.bda");
  fp = fopen(fname,"r");
  assert(fp);
  if(!fp) return false;
  memset(str,'\0',255);
  fgets(str,255,fp);
  sscanf(str,"%d",&NumOfLayer);
  assert(NumOfLayer);
  LayerNames = new AnsiString[NumOfLayer];
  sprintf(str,"< %d Layer(s) is(are) loaded. >",NumOfLayer);
  if(Memo) Memo->Lines->Add(str);
  for(int i=0;i<NumOfLayer;i++) {
    fgets(str,255,fp);
    sscanf(str,"%s",title);
    LayerNames[i] = title;
    if(Memo) Memo->Lines->Add(LayerNames[i]);
  }

  if(Memo) Memo->Lines->Add(" ");
  fclose(fp);
  return true;
}

bool MkPrjReader::ReadCenterLine()
{
  FILE *fp=NULL;
  int npnt;
  char fname[256];
  char str[256];
  char *pstr;
  float x,y,z;
  strcpy(fname,PrjFolder);
  strcat(fname,"\\centerline.bda");
  fp = fopen(fname,"r");
  assert(fp);
  if(!fp) return false;
  memset(str,'\0',255);
  fgets(str,255,fp);
  sscanf(str,"%d",&npnt);
  sprintf(str,"< Center Line %d point(s) is(are) loaded. >",npnt);
  if(Memo) Memo->Lines->Add(str);

  CenterLine.Initialize(npnt);

  for(int i=0;i<npnt;i++) {
    fgets(str,255,fp);
    pstr = str;
    while(*pstr) {if(*pstr==',') *pstr = ' ';pstr++;}
    x=y=z=0;
    sscanf(str,"%f %f %f",&x,&y,&z);
    CenterLine[i] = MkPoint(x,y,z);

    sprintf(str,"%d-th point (%f,%f,%f)",i,x,y,z);
    if(Memo) Memo->Lines->Add(str);
  }

  if(Memo) Memo->Lines->Add(" ");
  fclose(fp);
  return true;
}

bool MkPrjReader::ReadSideLine()
{
  FILE *fp=NULL;
  int npnt;
  char fname[256];
  char str[256];
  char *pstr;
  float x,y,z;
  strcpy(fname,PrjFolder);
  strcat(fname,"\\leftpileline.bda");
  fp = fopen(fname,"r");
  assert(fp);
  if(!fp) return false;
  memset(str,'\0',255);
  fgets(str,255,fp);
  sscanf(str,"%d",&npnt);
  sprintf(str,"< Left Pile Line %d point(s) is(are) loaded. >",npnt);
  if(Memo) Memo->Lines->Add(str);

  LeftLine.Initialize(npnt);

  for(int i=0;i<npnt;i++) {
    fgets(str,255,fp);
    pstr = str;
    while(*pstr) {if(*pstr==',') *pstr = ' ';pstr++;}
    x=y=z=0;
    sscanf(str,"%f %f %f",&x,&y,&z);
    LeftLine[i] = MkPoint(x,y,z);

    sprintf(str,"%d-th point (%f,%f,%f)",i,x,y,z);
    if(Memo) Memo->Lines->Add(str);
  }

  if(Memo) Memo->Lines->Add(" ");
  fclose(fp);

  strcpy(fname,PrjFolder);
  strcat(fname,"\\rightpileline.bda");
  fp = fopen(fname,"r");
  assert(fp);
  if(!fp) return false;
  memset(str,'\0',255);
  fgets(str,255,fp);
  sscanf(str,"%d",&npnt);
  sprintf(str,"< Right Pile Line %d point(s) is(are) loaded. >",npnt);
  if(Memo) Memo->Lines->Add(str);

  RightLine.Initialize(npnt);

  for(int i=0;i<npnt;i++) {
    fgets(str,255,fp);
    pstr = str;
    while(*pstr) {if(*pstr==',') *pstr = ' ';pstr++;}
    x=y=z=0;
    sscanf(str,"%f %f %f",&x,&y,&z);
    RightLine[i] = MkPoint(x,y,z);

    sprintf(str,"%d-th point (%f,%f,%f)",i,x,y,z);
    if(Memo) Memo->Lines->Add(str);
  }

  if(Memo) Memo->Lines->Add(" ");
  fclose(fp);
  return true;
}

bool MkPrjReader::ReadStartPosition()
{
  FILE *fp=NULL;
  char fname[256];
  char str[256];
  char *pstr;
  float x,y,z;
  strcpy(fname,PrjFolder);
  strcat(fname,"\\startposition.bda");
  fp = fopen(fname,"r");
  assert(fp);
  if(!fp) return false;
  memset(str,'\0',255);

  sprintf(str,"< Start Positions are loaded. >");
  if(Memo) Memo->Lines->Add(str);

  fgets(str,255,fp);
  pstr = str;
  while(*pstr) {if(*pstr==',') *pstr = ' ';pstr++;}
  sscanf(str,"%f %f %f",&x,&y,&z);
  LeftStartPoint = MkPoint(x,y,z);

  sprintf(str,"left start point (%f,%f,%f)",x,y,z);
  if(Memo) Memo->Lines->Add(str);

  fgets(str,255,fp);
  pstr = str;
  while(*pstr) {if(*pstr==',') *pstr = ' ';pstr++;}
  sscanf(str,"%f %f %f",&x,&y,&z);
  RightStartPoint = MkPoint(x,y,z);

  sprintf(str,"right start point (%f,%f,%f)",x,y,z);
  if(Memo) Memo->Lines->Add(str);

  if(Memo) Memo->Lines->Add(" ");
  fclose(fp);
  return true;
}

bool MkPrjReader::ReadSectPoint()
{
  FILE *fp=NULL;
  char fname[256];
  char str[256];
  char *pstr;
  int npnt;
  float x,y,z;
  strcpy(fname,PrjFolder);
  strcat(fname,"\\sectionpoint.bda");
  fp = fopen(fname,"r");
  assert(fp);
  if(!fp) return false;
  memset(str,'\0',255);

  sprintf(str,"< %d Center Section(s) is(are) loaded. >",npnt);
  if(Memo) Memo->Lines->Add(str);

  fgets(str,255,fp);
  sscanf(str,"%d",&npnt);
  CentSectPoint.Initialize(npnt);

  for(int i=0;i<npnt;i++) {
    fgets(str,255,fp);
    pstr = str;    
    while(*pstr) {if(*pstr==',') *pstr = ' ';pstr++;}
    x=y=z=0;
    sscanf(str,"%f %f %f",&x,&y,&z);
    CentSectPoint[i] = MkPoint(x,y,z);

    sprintf(str,"%d-th point (%f,%f,%f)",i,x,y,z);
    if(Memo) Memo->Lines->Add(str);
  }

  if(Memo) Memo->Lines->Add(" ");
  fclose(fp);

  strcpy(fname,PrjFolder);
  strcat(fname,"\\inter_L.bda");
  fp = fopen(fname,"r");
  assert(fp);
  if(!fp) return false;
  memset(str,'\0',255);

  sprintf(str,"< %d Left Section(s) is(are) loaded. >",npnt);
  if(Memo) Memo->Lines->Add(str);

  fgets(str,255,fp);
  sscanf(str,"%d",&npnt);
  LeftSectPoint.Initialize(npnt);

  for(int i=0;i<npnt;i++) {
    fgets(str,255,fp);
    pstr = str;
    while(*pstr) {if(*pstr==',') *pstr = ' ';pstr++;}
    x=y=z=0;
    sscanf(str,"%f %f %f",&x,&y,&z);
    LeftSectPoint[i] = MkPoint(x,y,z);

    sprintf(str,"%d-th point (%f,%f,%f)",i,x,y,z);
    if(Memo) Memo->Lines->Add(str);
  }

  if(Memo) Memo->Lines->Add(" ");
  fclose(fp);

  return true;
}

bool MkPrjReader::ReadLayer()
{
  FILE *fp=NULL;
  char fname[256];
  char str[256];
  char *pstr;
  char title[256];
  int cnt;
  int npnt;
  float depth;

  strcpy(fname,PrjFolder);
  strcat(fname,"\\layer_L.bda");
  fp = fopen(fname,"r");
  assert(fp);

  if(!fp) return false;
  memset(str,'\0',255);

  sprintf(str,"< Left Layer Data(s) is(are) loaded. >");
  if(Memo) Memo->Lines->Add(str);

  do {fgets(str,255,fp);} while(!strlen(str));
  sscanf(str,"%s %d",title,&npnt);

  LeftExcavDepth.Initialize(npnt);
  LeftLayerDepth.Initialize(npnt,NumOfLayer-1);

  for(int i=0;i<npnt;i++) {
    do {fgets(str,255,fp);} while(strlen(str)<2);
    sscanf(str,"%s %d",title,&cnt);
    do {fgets(str,255,fp);} while(strlen(str)<2);
    sscanf(str,"%s %f",title,&depth);
    LeftExcavDepth(i) = depth;
    do {fgets(str,255,fp);} while(strlen(str)<2);
    pstr = str;
    for(int j=0;j<NumOfLayer-1;j++) {
      char *qstr;
      if(j) {
        qstr = strchr(pstr,' ');
        while(*qstr==' ') qstr++;
        qstr = strchr(qstr,' ');
        while(*qstr==' ') qstr++;
        pstr = qstr;
      }

      sscanf(pstr,"%s %f",title,&depth);
      LeftLayerDepth(i,j) = depth;
    }
  }

  do {fgets(str,255,fp);} while(!strlen(str));
  sscanf(str,"%s %f",title,&GroundDiff);

  for(int i=0;i<npnt;i++) {
    sprintf(str,"%d-th Section excavation depth is %f",i, LeftExcavDepth(i));
    if(Memo) Memo->Lines->Add(str);
    for(int j=0;j<NumOfLayer-1;j++) {
      sprintf(str,"%d-th section, %d-th layer depth is %f",i,j, LeftLayerDepth(i,j));
      if(Memo) Memo->Lines->Add(str);
    }
  }
  sprintf(str,"ground level diffrence between left and right is %f",GroundDiff);
  if(Memo) Memo->Lines->Add(str);

  if(Memo) Memo->Lines->Add(" ");
  fclose(fp);

  strcpy(fname,PrjFolder);
  strcat(fname,"\\layer_R.bda");
  fp = fopen(fname,"r");
  assert(fp);
  if(!fp) return false;
  memset(str,'\0',255);
  sprintf(str,"< Right Layer Data(s) is(are) loaded. >");
  if(Memo) Memo->Lines->Add(str);

  do {fgets(str,255,fp);} while(!strlen(str));
  sscanf(str,"%s %d",title,&npnt);

  RightExcavDepth.Initialize(npnt);
  RightLayerDepth.Initialize(npnt,NumOfLayer-1);

  for(int i=0;i<npnt;i++) {
    do {fgets(str,255,fp);} while(strlen(str)<2);
    sscanf(str,"%s %d",title,&cnt);
    do {fgets(str,255,fp);} while(strlen(str)<2);
    sscanf(str,"%s %f",title,&depth);
    RightExcavDepth(i) = depth;
    do {fgets(str,255,fp);} while(strlen(str)<2);
    pstr = str;
    for(int j=0;j<NumOfLayer-1;j++) {
      char *qstr;
      if(j) {
        qstr = strchr(pstr,' ');
        while(*qstr==' ') qstr++;
        qstr = strchr(qstr,' ');
        while(*qstr==' ') qstr++;
        pstr = qstr;
      }

      sscanf(pstr,"%s %f",title,&depth);
      RightLayerDepth(i,j) = depth;
    }
  }

  for(int i=0;i<npnt;i++) {
    sprintf(str,"%d-th Section excavation depth is %f",i, RightExcavDepth(i));
    if(Memo) Memo->Lines->Add(str);
    for(int j=0;j<NumOfLayer-1;j++) {
      sprintf(str,"%d-th section, %d-th layer depth is %f",i,j, RightLayerDepth(i,j));
      if(Memo) Memo->Lines->Add(str);
    }
  }

  if(Memo) Memo->Lines->Add(" ");
  fclose(fp);

  return true;
}

bool MkPrjReader::ReadSectWidth()
{
  FILE *fp=NULL;
  char fname[256];
  char str[256];
  char title[256];
  char *pstr;
  int cnt;
  int npnt;
  
  strcpy(fname,PrjFolder);
  strcat(fname,"\\sectionwidth.bda");
  fp = fopen(fname,"r");
  assert(fp);

  if(!fp) return false;
  memset(str,'\0',255);
  sprintf(str,"< Section width(s) is(are) loaded. >");
  if(Memo) Memo->Lines->Add(str);

  do {fgets(str,255,fp);} while(!strlen(str));
  sscanf(str,"%s %d",title,&npnt);

  cnt = 0;
  
  SectNum.Initialize(npnt);
  for (int i=0;i<npnt;i++) {
    int n=0;
    do {fgets(str,255,fp);memset(title,'\0',255);sscanf(str,"%s",title);} while(strcmp(title,"[��]"));
    pstr = str;

    while(pstr) {
      char *qstr;
      if(!(qstr = strchr(pstr,' '))) break;
      while(qstr&&*qstr==' ') qstr++;
      pstr = qstr;
      cnt++;n++;
    }
    SectNum(i) = n;
  }

  SectWidth.Initialize(cnt);

  cnt=0;
  rewind(fp);
  for (int i=0;i<npnt;i++) {
    float v;
    do {fgets(str,255,fp);memset(title,'\0',255);sscanf(str,"%s",title);} while(strcmp(title,"[��]"));
    pstr = str;

    while(pstr) {
      char *qstr;
      if(!(qstr = strchr(pstr,' '))) break;
      while(*qstr==' ') qstr++;
      pstr = qstr;
      sscanf(pstr,"%f",&v);
      SectWidth(cnt) = v;
      cnt++;
    }
  }

  assert(SectWidth.getSzX()==cnt);
  cnt=0;
  for (int i=0;i<npnt;i++) {
    char t[256];

    sprintf(str,"%d-th section width",i);
    if(Memo) Memo->Lines->Add(str);

    memset(str,'\0',255);
    memset(t,'\0',255);

    for (int j=0;j<SectNum(i);j++) {
      sprintf(t,"%f ",SectWidth(cnt));
      strcat(str,t);
      cnt++;
    }
    if(Memo) Memo->Lines->Add(str);
  }

  if(Memo) Memo->Lines->Add(" ");
  fclose(fp);
  return true;
}

bool MkPrjReader::ReadRSM()
{
  FILE *fp=NULL;
  char fname[256];
  char str[256];
  char title[256];
  char *pstr;
  int cnt;
  int npnt;
  
  strcpy(fname,PrjFolder);
  strcat(fname,"\\RSM.bda");
  fp = fopen(fname,"r");
  assert(fp);

  if(!fp) return false;
  memset(str,'\0',255);
  sprintf(str,"< RSM data are loaded. >");
  if(Memo) Memo->Lines->Add(str);

  do {fgets(str,255,fp);} while(!strlen(str));
  sscanf(str,"%s %d",title,&npnt);

  cnt = 0;
  
  RsmNum.Initialize(npnt);
  for (int i=0;i<npnt;i++) {
    int n=0,n1;
    do {fgets(str,255,fp);memset(title,'\0',255);sscanf(str,"%s",title);} while(strcmp(title,"��ġ"));
    fgets(str,255,fp);
    sscanf(str,"%d",&n1);
    fgets(str,255,fp);

    pstr = str;
    while(pstr) {
      char *qstr;
      if(!(qstr = strchr(pstr,' '))) break;
      while(qstr&&*qstr==' ') qstr++;
      pstr = qstr;
      cnt++;n++;
    }
    if(n!=n1) ShowMessage("Mismatch");
    RsmNum(i) = n;
  }

  RsmData.Initialize(cnt);

  cnt=0;
  rewind(fp);
  for (int i=0;i<npnt;i++) {
    float v;
    do {fgets(str,255,fp);memset(title,'\0',255);sscanf(str,"%s",title);} while(strcmp(title,"��ġ"));
    fgets(str,255,fp);
    fgets(str,255,fp);

    pstr = strchr(str,'\0');
    pstr--;
    while(pstr&&(*pstr==' '||*pstr=='\n')) {*pstr='\0';pstr--;}
    
    pstr = str;

    while(pstr) {
      char *qstr;

      sscanf(pstr,"%f",&v);
      RsmData(cnt) = v;
      cnt++;

      if(!(qstr = strchr(pstr,' '))) break;
      while(*qstr==' ') qstr++;
      pstr = qstr;

    }
  }

  assert(RsmData.getSzX()==cnt);
  cnt=0;
  for (int i=0;i<npnt;i++) {
    char t[256];

    sprintf(str,"%d-th section RSM",i);
    if(Memo) Memo->Lines->Add(str);

    memset(str,'\0',255);
    memset(t,'\0',255);

    for (int j=0;j<RsmNum(i);j++) {
      sprintf(t,"%f ",RsmData(cnt));
      strcat(str,t);
      cnt++;
    }
    if(Memo) Memo->Lines->Add(str);
  }

  if(Memo) Memo->Lines->Add(" ");
  fclose(fp);
  return true;

}

bool MkPrjReader::ReadSupport()
{
  FILE *fp=NULL;
  char fname[256];
  char str[256];
  strcpy(fname,PrjFolder);
  strcat(fname,"\\support_L.bda");
  fp = fopen(fname,"r");
  assert(fp);
  if(!fp) return false;
  memset(str,'\0',255);
  sprintf(str,"< Support Data(s) is(are) loaded. >");
  if(Memo) Memo->Lines->Add(str);

  fgets(str,255,fp);


  if(Memo) Memo->Lines->Add(" ");
  fclose(fp);
  return true;
}

bool MkPrjReader::Clear()
{
  CenterLine.Clear();
  LeftLine.Clear();
  RightLine.Clear();
  LeftStartPoint = NullPoint;
  RightStartPoint = NullPoint;
  GroundDiff = 0;
  LeftExcavDepth.Clear();
  LeftLayerDepth.Clear();
  RightExcavDepth.Clear();
  RightLayerDepth.Clear();
  CentSectPoint.Clear();
  LeftSectPoint.Clear();  
  SectWidth.Clear();
  SectNum.Clear();
  RsmData.Clear();
  RsmNum.Clear();
  NumOfLayer = 0;
  if(LayerNames) {delete[] LayerNames;LayerNames=NULL;}
  if(Grounds) {delete[] Grounds;Grounds =NULL;}
  if(Layers) {delete[] Layers;Layers =NULL;}
  if(Wales) {delete[] Wales;Wales =NULL;}
  if(Struts) {delete[] Struts;Struts =NULL;}
  if(Piles) {delete[] Piles;Piles =NULL;}
  if(Bolts) {delete[] Bolts;Bolts =NULL;}
  if(Anchors) {delete[] Anchors;Anchors =NULL;}
}

