//---------------------------------------------------------------------------
#ifndef MkKeyWordH
#define MkKeyWordH

#include "MkMisc.h"
//---------------------------------------------------------------------------
enum MkKeyKind {kkProject, kkLayer, kkProfile, kkWall, kkStrut, kkAnchor,
                kkRockbolt, kkSlab, kkSlabWall, kkDivision, kkSolution,
                kkPoint, kkNoEcho, kkOutput, kkStep, kkBottom, kkRankine,
                kkPeck, kkPeck1, kkEarthPress, kkSlope, kkProfileChange, kkGWL,
                kkWaterPress, kkSurcharge, kkLoad, kkPress, kkMinAcive,
                kkExcav, kkConst, kkRemove, kkInsertCheck, kkIteration,
                kkGroundSettle, kkSlip, kkEnd, kkNone};
//---------------------------------------------------------------------------
class MkKeyWord {
protected:
  int Size,NumOfKeyWord;
  char **KeyWord;
  MkKeyKind *KeyKind;
  char *CurKeyWord;
  MkKeyKind CurKeyKind;

public:
  MkKeyWord();
  ~MkKeyWord();

  virtual void Setup(){};
  bool Initialize(int size);
  bool Clear();
  bool Grow(int );
  bool Shrink(int );

  bool Add(char *kw, MkKeyKind kk);
  bool Del(char *kw, MkKeyKind kk);

  int GetSize(){return Size;}
  int GetNumberOfKeyWord(){return NumOfKeyWord;}

  virtual bool IsKeyWord(char *){return false;}
  virtual MkKeyKind GetKeyKind(char *){return kkNone;}
};
//---------------------------------------------------------------------------
class MkEscotKeyWord : public MkKeyWord {
public:
  MkEscotKeyWord();
  ~MkEscotKeyWord();

  void Setup();
  bool IsKeyWord(char *);
  MkKeyKind GetKeyKind(char *);
};
//---------------------------------------------------------------------------
class MkSunexKeyWord : public MkKeyWord {
public:
  MkSunexKeyWord();
  ~MkSunexKeyWord();

  void Setup();
  bool IsKeyWord(char *);
  MkKeyKind GetKeyKind(char *);
};
//---------------------------------------------------------------------------
class MkExcadKeyWord : public MkKeyWord {
public:
  MkExcadKeyWord();
  ~MkExcadKeyWord();

  void Setup();
  bool IsKeyWord(char *);
  MkKeyKind GetKeyKind(char *);
};
//---------------------------------------------------------------------------
class MkExcavKeyWord : public MkKeyWord {
public:
  MkExcavKeyWord();
  ~MkExcavKeyWord();

  void Setup();
  bool IsKeyWord(char *);
  MkKeyKind GetKeyKind(char *);
};
//---------------------------------------------------------------------------
class MkSimpKeyWord : public MkKeyWord {
public:
  MkSimpKeyWord();
  ~MkSimpKeyWord();

  void Setup();
  bool IsKeyWord(char *);
  MkKeyKind GetKeyKind(char *);
};
//---------------------------------------------------------------------------
#endif

