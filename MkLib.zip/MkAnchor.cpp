//---------------------------------------------------------------------------
#include "MkAnchor.h"
#ifdef __BCPLUSPLUS__
#include <vcl.h>
#endif
#pragma hdrstop
//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#pragma package(smart_init)
#endif
//---------------------------------------------------------------------------
MkAnchor NullAnchor(0);
MkAnchor::MkAnchor()
{
  Clear();
}
MkAnchor::MkAnchor(int n)
{
  Clear();
}

#ifdef __BCPLUSPLUS__
bool MkAnchor::UpdateFrom()
{
  if(!Grid) return false;

  Number  =Grid->Cells[1][0].ToInt();
  Depth   =Grid->Cells[1][1].ToDouble();
  Area    =Grid->Cells[1][2].ToDouble();
  Angle   =Grid->Cells[1][3].ToDouble();
  Length  =Grid->Cells[1][4].ToDouble();
  JackingForce  =Grid->Cells[1][5].ToDouble();
  TenLoss =Grid->Cells[1][6].ToDouble();
  IniDis  =Grid->Cells[1][7].ToDouble();

  return true;
}
bool MkAnchor::UpdateTo()
{
  if(!Grid) return false;

  for(int i=0;i<20;i++) {Grid->Cells[0][i] = "";Grid->Cells[1][i]="";}

  Grid->Cells[0][0] = "Number";
  Grid->Cells[0][1] = "Depth";
  Grid->Cells[0][2] = "Area";
  Grid->Cells[0][3] = "Angle";
  Grid->Cells[0][4] = "Length";
  Grid->Cells[0][5] = "JackingForce";
  Grid->Cells[0][6] = "TenLoss";
  Grid->Cells[0][7] = "IniDis";

  Grid->Cells[1][0] = Number;
  Grid->Cells[1][1] = Depth ;
  Grid->Cells[1][2] = Area  ;
  Grid->Cells[1][3] = Angle ;
  Grid->Cells[1][4] = Length;
  Grid->Cells[1][5] = JackingForce;
  Grid->Cells[1][6] = TenLoss;
  Grid->Cells[1][7] = IniDis;
  return true;
}

void MkAnchor::Out(TObject *Sender)
{

}
#endif
void MkAnchor::Out(char *fname)
{
  FILE *fp;
  fp = fopen(fname,"a");
  if(!fp) {
    MkDebug(fname); MkDebug(" is not found, so fp is null and return false\n");
    return;
  }
            //12345678901234567890123456789012345678901234567890123456789012345678901234567890
//fprintf(fp," Anchor Depth   Length  Area  Angle   Spacing  Pini  Loss\n");
//fprintf(fp,"   No.   (m)    (m)    (m2)   (deg)    (m)    (t/m)  (%)\n");
  fprintf(fp,"  %3d   %5.2f   %5.2f  %5.2f   %5.2f   %5.2f  %5.2f  %5.2f\n",Number,Depth,Length,Area,Angle,Spacing,JackingForce*MPa2Tonf, TenLoss);
  fprintf(fp,"                      (%5.2f)                (%5.2f) \n",Area/(Spacing>EPS?Spacing:1),JackingForce*MPa2Tonf/(Spacing>EPS?Spacing:1));
  fprintf(fp,"\n");
  fclose(fp);
}

void MkAnchor::Clear()
{
  MkEntity::Clear();

  Side=mkLeft;
  Wale.Clear();

#ifdef __BCPLUSPLUS__
  MajorWale="";
#else
  memset(MajorWale,'\0',255);
#endif

  Tan = SupportTan = 0;

  Area=0;
  Angle=0;
  Spacing=0;
  JackingForce=0;
  TenLoss=0;
  IniDis=0;
  WireNum=0;
  FreeLength=0;
  StickLength=0;

  YoungMod=0;
  ShearTor=0;
  SecMomentY=0;
  SecMomentZ=0;  // second moment of inertial

  AnchorLine.Clear();
}

#ifdef __BCPLUSPLUS__
void MkAnchor::Import(MkGlobalVar &globalvar, int sec, MkSide side, int tan)
{
  Tan=((side==mkLeft)?globalvar.support_tan_L[sec+1][SupportTan+1]:globalvar.support_tan_R[sec+1][SupportTan+1]);
  WireNum=((side==mkLeft)?globalvar.support_tendonEA_L[sec+1][SupportTan+1]:globalvar.support_tendonEA_R[sec+1][SupportTan+1]);
  Depth=((side==mkLeft)?globalvar.support_depth_L[sec+1][SupportTan+1]:globalvar.support_depth_R[sec+1][SupportTan+1]);
  Angle=((side==mkLeft)?globalvar.support_var_L[sec+1][SupportTan+1]:globalvar.support_var_R[sec+1][SupportTan+1]);
  FreeLength=((side==mkLeft)?globalvar.support_freelen_L[sec+1][SupportTan+1]:globalvar.support_freelen_R[sec+1][SupportTan+1]);
  StickLength=((side==mkLeft)?globalvar.support_sticklen_L[sec+1][SupportTan+1]:globalvar.support_sticklen_R[sec+1][SupportTan+1]);
  JackingForce=((side==mkLeft)?globalvar.support_jackingforce_L[sec+1][SupportTan+1]:globalvar.support_jackingforce_R[sec+1][SupportTan+1]);
  Wale.SetMajorWale(MajorWale);
  Wale.Import(globalvar,sec,Tan);
}

void MkAnchor::Export(MkGlobalVar &globalvar, int sec, MkSide side, int tan)
{
  ((side==mkLeft)?globalvar.support_tan_L[sec+1][SupportTan+1]:globalvar.support_tan_R[sec+1][SupportTan+1])=Tan;
  ((side==mkLeft)?globalvar.support_type_L[sec+1][SupportTan+1]:globalvar.support_type_R[sec+1][SupportTan+1])="��Ŀ";
  ((side==mkLeft)?globalvar.support_tendonEA_L[sec+1][SupportTan+1]:globalvar.support_tendonEA_R[sec+1][SupportTan+1])=WireNum;
  ((side==mkLeft)?globalvar.support_depth_L[sec+1][SupportTan+1]:globalvar.support_depth_R[sec+1][SupportTan+1])=Depth;
  ((side==mkLeft)?globalvar.support_var_L[sec+1][SupportTan+1]:globalvar.support_var_R[sec+1][SupportTan+1])=Angle;
  ((side==mkLeft)?globalvar.support_freelen_L[sec+1][SupportTan+1]:globalvar.support_freelen_R[sec+1][SupportTan+1])=FreeLength;
  ((side==mkLeft)?globalvar.support_sticklen_L[sec+1][SupportTan+1]:globalvar.support_sticklen_R[sec+1][SupportTan+1])=StickLength;
  ((side==mkLeft)?globalvar.support_jackingforce_L[sec+1][SupportTan+1]:globalvar.support_jackingforce_R[sec+1][SupportTan+1])=JackingForce;
  Wale.Export(globalvar, sec, Tan);
}
#endif

#ifdef __BCPLUSPLUS__
void MkAnchor::Draw(TObject *Sender)
{
  AnchorLine.Draw(Sender);
}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void MkAnchor::Draw(MkPaint *pb)
{

}
#endif

bool MkAnchor::operator==(MkAnchor &anchor)
{
  bool flag = true;
  flag = flag && MkEntity::operator==((MkEntity&)anchor);
  flag = flag && Number==anchor.Number;
  flag = flag && Depth==anchor.Depth;
  flag = flag && Area==anchor.Area;
  flag = flag && Angle==anchor.Angle;
  flag = flag && Spacing==anchor.Spacing;
  flag = flag && Length==anchor.Length;
  flag = flag && JackingForce==anchor.JackingForce;
  flag = flag && TenLoss==anchor.TenLoss;
  flag = flag && IniDis==anchor.IniDis;
  flag = flag && WireNum==anchor.WireNum;
  flag = flag && FreeLength==anchor.FreeLength;
  flag = flag && StickLength==anchor.StickLength;
  flag = flag && YoungMod==anchor.YoungMod;
  flag = flag && ShearTor==anchor.ShearTor;
  flag = flag && SecMomentY==anchor.SecMomentY,
  flag = flag && SecMomentZ==anchor.SecMomentZ;  // second moment of inertial
  flag = flag && Side==anchor.Side;

  return flag;
}

bool MkAnchor::operator!=(MkAnchor &anchor)
{
  return !operator==(anchor);
}

MkAnchor& MkAnchor::operator=(MkAnchor& anchor)
{
  MkEntity::operator=((MkEntity&)anchor);
  AnchorLine=anchor.AnchorLine;
  Number=anchor.Number;
  Depth=anchor.Depth;
  Area=anchor.Area;
  Angle=anchor.Angle;
  Spacing=anchor.Spacing;
  Length=anchor.Length;
  JackingForce=anchor.JackingForce;            
  TenLoss=anchor.TenLoss;           
  IniDis=anchor.IniDis;
  WireNum=anchor.WireNum;
  FreeLength=anchor.FreeLength;
  StickLength=anchor.StickLength;
  YoungMod=anchor.YoungMod;
  ShearTor=anchor.ShearTor;
  SecMomentY=anchor.SecMomentY,
  SecMomentZ=anchor.SecMomentZ;  // second moment of inertial
  Side=anchor.Side;

  return *this;
}

MkAnchors::MkAnchors(int size,MkAnchor *anchors)
{
    if (size < 0) {
      MkDebug("::MkAnchors - MkAnchors(int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSize == 0) {
       FAnchor = NULL;
       return;
    }

    FAnchor = new MkAnchor[FSize];
    for (int i=0;i<FSize;i++) (*this)[i] = anchors[i];
}

MkAnchors::MkAnchors(int size)
{
    if (size < 0) {
      MkDebug("::MkAnchors - MkAnchors(int size)");;
      return;
    }

    FSizeOfArray = size;
    FSize = 0;
    if (FSizeOfArray == 0) {
       FAnchor = NULL;
       return;
    }

    FAnchor = new MkAnchor[FSizeOfArray];
}

MkAnchors::~MkAnchors()
{
   FSizeOfArray = FSize = 0;
   if (FAnchor) {
      delete[] FAnchor;
      FAnchor = NULL;
   }
}

void MkAnchors::Initialize(int size)
{
    int i;
    if (size < 0) {
      MkDebug("::MkAnchors - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;

    FSizeOfArray = FSize = size;

    if (FSizeOfArray == 0) {
       if (FAnchor!=NULL) delete[] (MkAnchor*)FAnchor;
       FAnchor = NULL;
       return;
    }

    if (FAnchor!=NULL) delete[] (MkAnchor*)FAnchor;
    FAnchor = new MkAnchor[FSizeOfArray];
    for (i=0;i<FSize;i++) FAnchor[i].Number = i;
}

void MkAnchors::Initialize(int size,MkAnchor *anchors)
{
    int i;
    if (size < 0 || anchors == NULL) {
      MkDebug("::MkAnchors - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSize = FSizeOfArray = size;
    if (FSizeOfArray == 0) {
       if (FAnchor!=NULL) delete[] (MkAnchor*)FAnchor;
       FAnchor = NULL;
       return;
    }

    if (FAnchor!=NULL) delete[] (MkAnchor*)FAnchor;
    FAnchor = new MkAnchor[FSizeOfArray];
    for (i=0;i<FSizeOfArray;i++) FAnchor[i] = anchors[i];
    for (i=0;i<FSize;i++) FAnchor[i].Number = i;
}

int MkAnchors::Grow(int delta)
{
    int i;
    MkAnchor *anchor=NULL;

    if (!(anchor = new MkAnchor[FSizeOfArray+delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        anchor[i] = FAnchor[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        anchor[i] = NullAnchor;
    if (FAnchor) {
       delete[] (MkAnchor*)FAnchor;
       FAnchor = NULL;
    }
    FAnchor = anchor;
    FSizeOfArray = FSizeOfArray+delta;
    return FSizeOfArray;
}

int MkAnchors::Shrink(int delta)
{
    int i;
    MkAnchor *anchor=NULL;

    if (!(anchor = new MkAnchor[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        anchor[i] = FAnchor[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        anchor[i] = NullAnchor;
    if (FAnchor) {
       delete[] (MkAnchor*)FAnchor;
       FAnchor = NULL;
    }
    FAnchor = anchor;
    FSizeOfArray = FSizeOfArray-delta;
    return FSizeOfArray;
}

bool MkAnchors::Add(MkAnchor &anchor)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    FSize++;
    FAnchor[FSize-1] = anchor;
    return true;
}

bool MkAnchors::Add(int index, MkAnchor &anchor)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    for (int i=FSize-1;i>=index;i--)
      FAnchor[i+1] = FAnchor[i];
    FSize++;
    FAnchor[index] = anchor;
    return true;
}

bool MkAnchors::Delete(MkAnchor &anchor)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FAnchor[i] == anchor) break;
    }
    if(i==FSize) return false;
    if(FAnchor[i] == anchor) {
      for (int j=i;j<FSize-1;j++)
        FAnchor[j] = FAnchor[j+1];
    }
    FSize--;
    FAnchor[FSize] = NullAnchor;
    return true;
}

bool MkAnchors::Delete(int index)
{
    for (int j=index;j<FSize-1;j++)
        FAnchor[j] = FAnchor[j+1];

    FSize--;
    FAnchor[FSize] = NullAnchor;
    return true;
}

bool MkAnchors::Clear()
{
   FSizeOfArray = FSize = 0;
   if (FAnchor) {
      delete[] FAnchor;
      FAnchor = NULL;
   }
   return true;
}

MkAnchor & MkAnchors::operator[](int i)
{
    if (0<=i && i<FSize) return FAnchor[i];
    else if(FSize<=i && i<FSizeOfArray) {
      FSize=i+1;
      return FAnchor[i];
    }
    else if (FSizeOfArray <= i) {
      Grow(i-FSizeOfArray+5);
      return NullAnchor;
    }
    else return NullAnchor;
}

MkAnchors & MkAnchors::operator=(MkAnchors &anchors)
{
    int i;

    Clear();
    FSize = anchors.FSize;
    FSizeOfArray = anchors.FSizeOfArray;
    if (FSizeOfArray == 0) {
       FAnchor = NULL;
       return *this;
    }
    this->FAnchor = new MkAnchor[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FAnchor[i] = anchors.FAnchor[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FAnchor[i] = NullAnchor;

    return *this;
}

bool MkAnchors::operator==(MkAnchors &anchors)
{
    int i;

    if (FSize != anchors.FSize) return false;
    for (i=0;i<FSize;i++)
      if (this->FAnchor[i] != anchors.FAnchor[i]) return false;

    return true;
}

#ifdef __BCPLUSPLUS__
void MkAnchors::Out(TObject *Sender)
{

}

#endif
void MkAnchors::Out(char *fname)
{
  FILE *fp;
  fp = fopen(fname,"a");
  if(!fp) {
    return;
  }

  if(FSize==0) return;
    
            //12345678901234567890123456789012345678901234567890123456789012345678901234567890
  fprintf(fp,"\n");
  fprintf(fp,"                           <Information of Anchorss>\n");
  fprintf(fp,"\n");
  fprintf(fp," Anchor Depth   Length  Area  Angle   Spacing  Pini  Loss\n");
  fprintf(fp,"   No.   (m)    (m)    (m2)   (deg)    (m)    (t/m)  (%)\n");
  fclose(fp);

  for(int i=0;i<FSize;i++) 
    FAnchor[i].Out(fname);
}

#ifdef __BCPLUSPLUS__
void MkAnchors::Import(MkGlobalVar &globalvar, int sec)
{
  int i;
  for(i=0;i<FSize;i++)
    FAnchor[i].Import(globalvar,sec,mkLeft, i);
}

void MkAnchors::Export(MkGlobalVar &globalvar, int sec)
{
  int i;
  for(i=0;i<FSize;i++)
    FAnchor[i].Export(globalvar,sec, mkLeft, i);
}
#endif

#ifdef __BCPLUSPLUS__
void MkAnchors::Draw(TObject *Sender)
{
    TColor C;
    float Offset;
    if (FSize == 0) return;
    if (String(Sender->ClassName()) == String("MkPaintBox")) {
       MkPaintBox *pb=(MkPaintBox*)Sender;
       C = pb->Canvas->Pen->Color;
       pb->Canvas->Pen->Color = Color;
       for (int i = 0; i < FSize;i++) {
           Offset = pb->Offset(3);
           FAnchor[i].Draw(pb);
       }
       pb->Canvas->Pen->Color = C;
    }
}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void MkAnchors::Draw(MkPaint *pb)
{

}
#endif



//---------------------------------------------------------------------------

