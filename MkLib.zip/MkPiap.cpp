#include "stdafx.h"
#include "MkPiap.h"

MkPiap::MkPiap()
{
  Gamma1 = Gamma2 = H = D = Hw = 0;
}

float MkPiap::GetFS()
{
  if(Hw < EPS) return 0;
  return (Gamma1*H+Gamma2*(D-H))/Hw;
}
