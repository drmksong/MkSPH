//---------------------------------------------------------------------------

#ifndef MkBEAH
#define MkBEAH
#include "MkAnalysis.h"
//---------------------------------------------------------------------------

class MkBEA : public MkAnalysis {

};

#endif
