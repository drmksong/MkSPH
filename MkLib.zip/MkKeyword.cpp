//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#include <vcl.h>
#pragma hdrstop
#endif
#include "MkKeyWord.h"
//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#pragma package(smart_init)
#endif

MkKeyWord::MkKeyWord()
{
  Size=0;
  NumOfKeyWord = 0;
  KeyWord=NULL;
  KeyKind=NULL;
}

MkKeyWord::~MkKeyWord()
{
  Clear();
}

bool MkKeyWord::Initialize(int size)
{
  int i, nofkw;
  bool flag=true;

  if(Size==size) return true;

  char **keyword;
  MkKeyKind *keykind;

  keyword = new char*[size];
  if(!keyword) return false;

  keykind = new MkKeyKind[size];
  if(!keykind) {
    delete[] keyword;
    return false;
  }

  for(i=0;i<size;i++) {
    keyword[i]=NULL;
    keykind[i]=kkNone;
  }

  nofkw = min(Size,size);
  for(i=0;i<nofkw;i++) {
    keyword[i] = new char[strlen(KeyWord[i])+1];
    if(!keyword[i]) {
      flag=false;
      break;
    }
    strcpy(keyword[i],KeyWord[i]);
    keykind[i] = KeyKind[i];
  }

  if(!flag) {
    for(i=0;i<size;i++)
      if(keyword[i]) {
        delete[] keyword[i];
        keyword[i] = NULL;
      }
    if(keyword) {
      delete[] keyword;
      keyword = NULL;
    }
    if(keykind) {
      delete[] keykind;
      keykind = NULL;
    }
    return false;
  }

  Clear();
  Size = size;
  NumOfKeyWord = nofkw;
  KeyWord = keyword;
  KeyKind = keykind;
  return true;
}

bool MkKeyWord::Clear()
{
  int i;
  for(i=0;i<Size;i++) {
    if(KeyWord[i]) delete[] KeyWord[i];
    KeyWord[i] = NULL;
  }
  if(KeyWord) {
    delete[] KeyWord;
    KeyWord = NULL;
  }
  if(KeyKind) {
    delete[] KeyKind;
    KeyKind = NULL;
  }
  NumOfKeyWord = 0;
  Size = 0;
  return true;
}

bool MkKeyWord::Grow(int sz)
{
  int i, size, nofkw;
  bool flag=true;

  if(sz<=0) return false;

  size = Size+sz;
  char **keyword;
  MkKeyKind *keykind;

  keyword = new char*[size];
  if(!keyword) return false;

  keykind = new MkKeyKind[size];
  if(!keykind) {
    delete[] keyword;
    return false;
  }

  for(i=0;i<size;i++) {
    keyword[i]=NULL;
    keykind[i]=kkNone;
  }

  nofkw = min(Size,size);
  for(i=0;i<nofkw;i++) {
    keyword[i] = new char[strlen(KeyWord[i])+1];
    if(!keyword[i]) {
      flag=false;
      break;
    }
    strcpy(keyword[i],KeyWord[i]);
    keykind[i] = KeyKind[i];
  }

  if(!flag) {
    for(i=0;i<size;i++)
      if(keyword[i]) {
        delete[] keyword[i];
        keyword[i] = NULL;
      }
    if(keyword) {
      delete[] keyword;
      keyword = NULL;
    }
    if(keykind) {
      delete[] keykind;
      keykind = NULL;
    }
    return false;
  }

  Clear();
  Size = size;
  NumOfKeyWord = nofkw;
  KeyWord = keyword;
  KeyKind = keykind;
  return true;
}

bool MkKeyWord::Shrink(int sz)
{
  int i, size, nofkw;
  bool flag=true;

  if(sz<=0) return false;

  size = Size-sz;
  char **keyword=NULL;
  MkKeyKind *keykind=NULL;

  keyword = new char*[size];
  if(!keyword) return false;

  keykind = new MkKeyKind[size];
  if(!keykind) {
    delete[] keyword;
    return false;
  }

  for(i=0;i<size;i++) {
    keyword[i]=NULL;
    keykind[i]=kkNone;
  }

  nofkw = min(Size,size);
  for(i=0;i<nofkw;i++) {
    keyword[i] = new char[strlen(KeyWord[i])+1];
    if(!keyword[i]) {
      flag=false;
      break;
    }
    strcpy(keyword[i],KeyWord[i]);
    keykind[i] = KeyKind[i];
  }

  if(!flag) {
    for(i=0;i<size;i++)
      if(keyword[i]) {
        delete[] keyword[i];
        keyword[i] = NULL;
      }
    if(keyword) {
      delete[] keyword;
      keyword = NULL;
    }
    if(keykind) {
      delete[] keykind;
      keykind = NULL;
    }
    return false;
  }

  Clear();
  Size = size;
  NumOfKeyWord = nofkw;
  KeyWord = keyword;
  KeyKind = keykind;
  return true;
}

bool MkKeyWord::Add(char *kw,MkKeyKind kk)
{
  bool flag;
  if(Size-NumOfKeyWord<1) flag = Grow(10-Size+NumOfKeyWord);
  if(!flag) return false;
  KeyWord[NumOfKeyWord] = new char[strlen(kw)+1];
  strcpy(KeyWord[NumOfKeyWord],kw);
  KeyKind[NumOfKeyWord] = kk;
  NumOfKeyWord++;
  return true;
}

bool MkKeyWord::Del(char *kw, MkKeyKind kk)
{
  int i,index=-1;
  for(i=0;i<NumOfKeyWord;i++) {
    if(!strcmp(KeyWord[i],kw)) {
      index = i;
      break;
    }
  }
  if(index==-1) return false;

  if(KeyWord[index]) {
    delete KeyWord[index];
    KeyWord[index] = NULL;
  }
  for(i=index;i<NumOfKeyWord-1;i++) {
    KeyWord[i] = KeyWord[i+1];
    KeyKind[i] = KeyKind[i+1];
  }
  KeyWord[NumOfKeyWord-1] = NULL;
  KeyKind[NumOfKeyWord-1] = kkNone;
  NumOfKeyWord--;
  return true;
}

//---------------------------------------------------------------------------
MkEscotKeyWord::MkEscotKeyWord()
{

}

MkEscotKeyWord::~MkEscotKeyWord()
{

}

void MkEscotKeyWord::Setup()
{

}

bool MkEscotKeyWord::IsKeyWord(char *kw)
{

}

MkKeyKind MkEscotKeyWord::GetKeyKind(char *kw)
{

}
//---------------------------------------------------------------------------
MkSunexKeyWord::MkSunexKeyWord()
{

}

MkSunexKeyWord::~MkSunexKeyWord()
{

}

void MkSunexKeyWord::Setup()
{
  Initialize(40);
  Add("Project",kkProject);
  Add("Soil", kkLayer);
  Add("Profile", kkProfile);
  Add("VWall", kkWall);
  Add("Strut", kkStrut);
  Add("Anchor", kkAnchor);
  Add("Slab", kkSlab);
  Add("Wall", kkSlabWall);
  Add("Division", kkDivision);
  Add("Solution", kkSolution);
  Add("Point", kkPoint);
  Add("No-Echo", kkNoEcho);
  Add("Output", kkOutput);
  Add("Step", kkStep);
  Add("Bottom", kkBottom);
  Add("Rankine", kkRankine);
  Add("Peck", kkPeck);
  Add("Peck1", kkPeck1);
  Add("Earth-Pressure", kkEarthPress);
  Add("Slope", kkSlope);
  Add("Profile-Change", kkProfileChange);
  Add("GWL", kkGWL);
  Add("Water-Pressure", kkWaterPress);
  Add("Surcharge", kkSurcharge);
  Add("Load", kkLoad);
  Add("Press", kkPress);
  Add("MinAcive", kkMinAcive);
  Add("Excav", kkExcav);
  Add("Const", kkConst);
  Add("Remove", kkRemove);
  Add("InsertCheck", kkInsertCheck);
  Add("Iteration", kkIteration);
  Add("GroundSettle", kkGroundSettle);
  Add("Slip", kkSlip);
  Add("End", kkEnd);
}

bool MkSunexKeyWord::IsKeyWord(char *kw)
{
  int i;
  MkKeyKind ck;
  if(strlen(kw)<=2) return false;
  for (i=0;i<NumOfKeyWord;i++) {
    if(strlen(KeyWord[i])>=4 && strlen(kw)<4) continue;
    else if(CompSub(KeyWord[i],kw)) {
      CurKeyWord = KeyWord[i];
      CurKeyKind = KeyKind[i];
      return true;
    }
  }
  return false;
}

MkKeyKind MkSunexKeyWord::GetKeyKind(char *kw)
{
  int i;
  if(strlen(kw)<=2) return kkNone;
  if(CompSub(CurKeyWord,kw)) return CurKeyKind;
  for (i=0;i<NumOfKeyWord;i++) {
    if(strlen(KeyWord[i])>=4 && strlen(kw)<4) continue;
    else if(CompSub(KeyWord[i],kw)) {
      CurKeyWord = KeyWord[i];
      CurKeyKind = KeyKind[i];
      return CurKeyKind;
    }
  }
  return kkNone;
}
//---------------------------------------------------------------------------
MkExcadKeyWord::MkExcadKeyWord()
{

}

MkExcadKeyWord::~MkExcadKeyWord()
{

}

void MkExcadKeyWord::Setup()
{

}

bool MkExcadKeyWord::IsKeyWord(char *kw)
{

}

MkKeyKind MkExcadKeyWord::GetKeyKind(char *kw)
{

}
//---------------------------------------------------------------------------
MkExcavKeyWord::MkExcavKeyWord()
{

}

MkExcavKeyWord::~MkExcavKeyWord()
{

}

void MkExcavKeyWord::Setup()
{

}

bool MkExcavKeyWord::IsKeyWord(char *kw)
{

}

MkKeyKind MkExcavKeyWord::GetKeyKind(char *kw)
{

}
//---------------------------------------------------------------------------

MkSimpKeyWord::MkSimpKeyWord()
{

}

MkSimpKeyWord::~MkSimpKeyWord()
{

}

void MkSimpKeyWord::Setup()
{
  Initialize(7);
  Add("Project",kkProject);
  Add("Layer", kkLayer);
  Add("VWall", kkWall);
  Add("Anchor", kkAnchor);
  Add("Division", kkDivision);
  Add("Step", kkStep);
  Add("End", kkEnd);
}

bool MkSimpKeyWord::IsKeyWord(char *kw)
{
  int i;
  MkKeyKind ck;
  if(strlen(kw)<=2) return false;
  for (i=0;i<NumOfKeyWord;i++) {
    if(strlen(KeyWord[i])>=4 && strlen(kw)<4) continue;
    else if(CompSub(KeyWord[i],kw)) {
      CurKeyWord = KeyWord[i];
      CurKeyKind = KeyKind[i];
      return true;
    }
  }
  return false;
}

MkKeyKind MkSimpKeyWord::GetKeyKind(char *kw)
{
  int i;
  if(strlen(kw)<=2) return kkNone;
  if(CompSub(CurKeyWord,kw)) return CurKeyKind;
  for (i=0;i<NumOfKeyWord;i++) {
    if(strlen(KeyWord[i])>=4 && strlen(kw)<4) continue;
    else if(CompSub(KeyWord[i],kw)) {
      CurKeyWord = KeyWord[i];
      CurKeyKind = KeyKind[i];
      return CurKeyKind;
    }
  }
  return kkNone;
}
//---------------------------------------------------------------------------

