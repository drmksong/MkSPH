//---------------------------------------------------------------------------
#pragma hdrstop
//#include "stdafx.h"
#include "MkAnalysis.h"

#ifdef __BCPLUSPLUS__
#include <vcl.h>
#endif

MkAnalysis NullAnalysis(0);
//--------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#pragma package(smart_init)
#endif
//--------------------------------------------------------------------

MkAnalysis::MkAnalysis()
{
#ifdef __BCPLUSPLUS__
  Memo = NULL;
#endif
  memset(FileName,'\0',255);;
  PrintStep=20;
  MaxStep = 100;
  AnalysisType = atBase;
}

MkAnalysis::MkAnalysis(int n)
{
#ifdef __BCPLUSPLUS__
  Memo = NULL;
#endif
  memset(FileName,'\0',255);;
  PrintStep=20;
  MaxStep = 100;
  AnalysisType = atBase;
}

bool MkAnalysis::Add(MkElements &elems)
{
  int i,j,k,l;
  bool flag,isa;

  for (i=0;i<elems.GetSize();i++) {
    flag = true;
    for (j=0;j<Elements.GetSize();j++) {
      if (elems[i] == Elements[j]) flag = false;
    }
    if(flag) {
      MkNodes &node=elems[i].GetNodes();
      MkInt &elemnode=elems[i].GetElemNode();
      NodeRef->Add(node);

      //MkDebug("After Add elems :: Nodes changed like this\n");
      //NodeRef->Out();
      //MkDebug("After Add elems :: when node is like this\n");
      //node.Out();

      for (k=0;k<elemnode.getSzX();k++) {
        isa = false;
        for (l=0;l<NodeRef->GetSize();l++) {
          if(node[elemnode[k]] == (*NodeRef)[l]) {
            isa = true;
            elemnode[k] = l;
            break;
          }
        }
        if(!isa) {
          MkDebug("Error in MkAnalysis::Add, return false\n");
          return false;
        }
      }
      elems[i].SetNodes(*NodeRef);
      Elements.Add(&elems[i]);
    }
  }
  return true;
}

bool MkAnalysis::AddNew(MkElements &elems) 
{
  int i,j,k,l;
  bool flag,isa;

  for(i=0;i<elems.GetSize();i++) {
    if(NodeRef!=&elems[i].GetNodes())  
      return false;
  }

  for (i=0;i<elems.GetSize();i++) {
    flag = true;
    for (j=0;j<Elements.GetSize();j++) {
      if (elems[i] == Elements[j]) flag = false;
    }
    if(flag) {
      Elements.AddNew(&elems[i]);
    }
  }
  return true;
}

bool MkAnalysis::Delete(MkElements &elems)
{
  int i;
  for (i=0;i<elems.GetSize();i++) {
    Elements.Delete(&elems[i]); 
  }
  return true;
}

bool MkAnalysis::CheckElements()
{
  int i,j;
  bool flag;
  char str[256];
  for (i=0;i<Elements.GetSize()-1;i++)
    for (j=i+1;j<Elements.GetSize();j++)
      if(Elements[i]==Elements[j]) return false;

  for (i=0;i<Elements.GetSize()-1;i++)
    flag = true;
    for (j=i+1;j<Elements.GetSize();j++) {
      MkNode &na=Elements[i].GetElemNode(0);
      MkNode &nb=Elements[i].GetElemNode(1);
      MkNode &nc=Elements[j].GetElemNode(0);
      MkNode &nd=Elements[j].GetElemNode(1);

      if(na!=nc&&nb!=nc&&Elements[i].IsIn(nc)) flag = false;
      else if(na!=nd&&nb!=nd&&Elements[i].IsIn(nd)) flag = false;

      if(!flag) {
        sprintf(str,"%d-th and %d-th element has an intersection\n",i,j);
        MkDebug(str);
        return false;
      }
    }

  for (i=0;i<Elements.GetSize();i++) {
   MkNode &na=Elements[i].GetElemNode(0);
   MkNode &nb=Elements[i].GetElemNode(1);
   flag = false;
   for(j=0;j<CheckLines.GetSize();j++) {
     if(CheckLines[j].IsInLine(na.GetPoint())&&CheckLines[j].IsInLine(nb.GetPoint())) flag=true;
   }
   if(!flag) {
     sprintf(str,"%d-th element is not on the entities\n",i);
     MkDebug(str);
     return false;
   }
  }
  
  return true;
}

bool MkAnalysis::operator==(MkAnalysis &a)
{
  bool flag=true;
  flag = flag && !strcmp(FileName,a.FileName);
  flag = flag && NodeRef == a.NodeRef;
  flag = flag && Elements == a.Elements;
  return flag;
}

bool MkAnalysis::operator!=(MkAnalysis &a)
{
  return !(*this==a);
}

#ifdef __BCPLUSPLUS__
void MkAnalysis::Draw(TObject *Sender)
{
  NodeRef->Draw(Sender);
  Elements.Draw(Sender);
}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void MkAnalysis::Draw(MkPaint *pb)
{
  NodeRef->Draw(pb);
  Elements.Draw(pb);
}
#endif
//--------------------------------------------------------------------
MkAnalyses::MkAnalyses(int size,MkAnalysis **ana)
{
  MkContBeam *cbeam;
  MkBeamSpring *beam;
  MkMori *mori;
  if (size < 0) {
    MkDebug("::MkAnalyses - MkAnalyses(int size)");
    return;
  }

  FSize = size;
  if (FSize == 0) {
     FAnalysis = NULL;
     return;
  }

  FAnalysis = new MkAnalysis*[FSize];
  assert(FAnalysis);

  for (int i=0;i<FSize;i++) {
    if(beam = dynamic_cast<MkBeamSpring*>(FAnalysis[i])) {
      assert(beam);
      MkBeamSpring *b = new MkBeamSpring();
      *b = *beam;
      ana[i] = b;
    }
    else if(mori = dynamic_cast<MkMori*>(FAnalysis[i])) {
      assert(mori);
      MkMori *m = new MkMori();
      *m = *mori;
      ana[i] = m;
    }
    else if(cbeam = dynamic_cast<MkContBeam*>(FAnalysis[i])) {
      assert(cbeam);
      MkContBeam *cb = new MkContBeam();
      *cb = *cbeam;
      ana[i] = cb;
    }
  }
}

MkAnalyses::~MkAnalyses()
{
  Clear();
}

void MkAnalyses::Initialize(int size)
{
  Clear();

  if (size < 0) {
    MkDebug("::MkAnalyses - MkAnalyses(int size)");
    return;
  }

  FSize = size;
  if (FSize == 0) {
     FAnalysis = NULL;
     return;
  }

  FAnalysis = new MkAnalysis*[FSize];
  assert(FAnalysis);

  for (int i=0;i<FSize;i++)
    FAnalysis[i] = NULL;
}

void MkAnalyses::Initialize(int size,MkAnalysis **ana)
{
  MkContBeam *cbeam;
  MkBeamSpring *beam;
  MkMori *mori;

  Clear();

  if (size < 0) {
    MkDebug("::MkAnalyses - MkAnalyses(int size)");
    return;
  }

  FSize = size;
  if (FSize == 0) {
     FAnalysis = NULL;
     return;
  }

  FAnalysis = new MkAnalysis*[FSize];
  assert(FAnalysis);

  for (int i=0;i<FSize;i++) {
    if(beam = dynamic_cast<MkBeamSpring*>(FAnalysis[i])) {
      assert(beam);
      MkBeamSpring *b = new MkBeamSpring();
      *b = *beam;
      ana[i] = b;
    }
    else if(mori = dynamic_cast<MkMori*>(FAnalysis[i])) {
      assert(mori);
      MkMori *m = new MkMori();
      *m = *mori;
      ana[i] = m;
    }
    else if(cbeam = dynamic_cast<MkContBeam*>(FAnalysis[i])) {
      assert(cbeam);
      MkContBeam *cb = new MkContBeam();
      *cb = *cbeam;
      ana[i] = cb;
    }
  }
}

bool MkAnalyses::Add(MkAnalysis *ana)
{
  int size,i;
  MkAnalysis **anas;
  MkBeamSpring *beam;
  MkMori *mori;
  MkContBeam *cbeam;

  size = FSize+1;
  anas = new MkAnalysis*[size];
  assert(anas);

  for (i=0;i<size-1;i++) {
    if(beam = dynamic_cast<MkBeamSpring*>(FAnalysis[i])) {
      assert(beam);
      MkBeamSpring *b = new MkBeamSpring();
      *b = *beam;
      anas[i] = b;
    }
    else if(mori = dynamic_cast<MkMori*>(FAnalysis[i])) {
      assert(mori);
      MkMori *m = new MkMori();
      *m = *mori;
      anas[i] = m;
    }
    else if(cbeam = dynamic_cast<MkContBeam*>(FAnalysis[i])) {
      assert(cbeam);
      MkContBeam *cb = new MkContBeam();
      *cb = *cbeam;
      anas[i] = cb;
    }
  }

  i = size-1;
  if(beam = dynamic_cast<MkBeamSpring*>(ana)) {
    assert(beam);
    MkBeamSpring *b = new MkBeamSpring();
    *b = *beam;
    anas[i] = b;
  }
  else if(mori = dynamic_cast<MkMori*>(ana)) {
    assert(mori);
    MkMori *m = new MkMori();
    *m = *mori;
    anas[i] = m;
  }
  else if(cbeam = dynamic_cast<MkContBeam*>(ana)) {
    assert(cbeam);
    MkContBeam *cb = new MkContBeam();
    *cb = *cbeam;
    anas[i] = cb;
  }
  
  Clear();
  FSize = size;
  FAnalysis = anas;
  return true;
}

bool MkAnalyses::Del(MkAnalysis *ana)
{
  int size,i,j;
  MkAnalysis **anas;
  MkBeamSpring *beam;
  MkMori *mori;
  MkContBeam *cbeam;

  size = FSize-1;
  anas = new MkAnalysis*[size];
  assert(anas);

  for (i=0;i<FSize;i++) {
    if(beam = dynamic_cast<MkBeamSpring*>(FAnalysis[i])) {
      MkBeamSpring *b = dynamic_cast<MkBeamSpring*>(ana);
      if(*b == *beam) break;
    }
    else if(mori = dynamic_cast<MkMori*>(FAnalysis[i])) {
      MkMori *f = dynamic_cast<MkMori*>(ana);
      if(*f == *mori) break;
    }
    else if(cbeam = dynamic_cast<MkContBeam*>(FAnalysis[i])) {
      MkContBeam *cb = dynamic_cast<MkContBeam*>(ana);
      if(*cb == *cbeam) break;
    }
  }

  for (j=0;j<i;j++) {
    if(beam = dynamic_cast<MkBeamSpring*>(FAnalysis[j])) {
      assert(beam);
      MkBeamSpring *b = new MkBeamSpring();
      *b = *beam;
      anas[j] = b;
    }
    else if(mori = dynamic_cast<MkMori*>(FAnalysis[j])) {
      assert(mori);
      MkMori *m = new MkMori();
      *m = *mori;
      anas[j] = m;
    }
    else if(cbeam = dynamic_cast<MkContBeam*>(FAnalysis[j])) {
      assert(cbeam);
      MkContBeam *cb = new MkContBeam();
      *cb = *cbeam;
      anas[j] = cb;
    }
  }
  for (j=i+1;j<FSize;j++) {
    if(beam = dynamic_cast<MkBeamSpring*>(FAnalysis[j])) {
      assert(beam);
      MkBeamSpring *b = new MkBeamSpring();
      *b = *beam;
      anas[j-1] = b;
    }
    else if(mori = dynamic_cast<MkMori*>(FAnalysis[j])) {
      assert(mori);
      MkMori *m = new MkMori();
      *m = *mori;
      anas[j-1] = m;
    }
    else if(cbeam = dynamic_cast<MkContBeam*>(FAnalysis[j])) {
      assert(cbeam);
      MkContBeam *cb = new MkContBeam();
      *cb = *cbeam;
      anas[j-1] = cb;
    }
  }

  Clear();
  FSize = size;
  FAnalysis = anas;
  return true;
}

bool MkAnalyses::Clear()
{
 if (FAnalysis) {
   for(int i=0;i<FSize;i++) {
     if(FAnalysis[i]) {
       if(FAnalysis[i]->GetAnalysisType()==atBeamSpring) {
         MkBeamSpring *a = (MkBeamSpring*)FAnalysis[i];
         delete a;
       }
       else if(FAnalysis[i]->GetAnalysisType()==atMori) {
         MkMori *a = (MkMori*)FAnalysis[i];
         delete a;
       }
       else if(FAnalysis[i]->GetAnalysisType()==atContBeam) {
         MkContBeam *a = (MkContBeam*)FAnalysis[i];
         delete a;
       }
       else
         delete FAnalysis[i];
       FAnalysis[i] = NULL;
     }
   }
   delete[] FAnalysis;
   FAnalysis = NULL;
   FSize = 0;
   return true;
 }
 else return false;
}

MkAnalyses & MkAnalyses::operator=(MkAnalyses &ana)
{
    MkContBeam *cbeam;
    MkBeamSpring *beam;
    MkMori *mori;
    int i;

    Clear();
    FSize = ana.FSize;
    if (FSize == 0) {
       FAnalysis = NULL;
       return *this;
    }
    FAnalysis = new MkAnalysis*[FSize];
    assert(FAnalysis);

    for (i=0;i<FSize;i++) {
      if(beam = dynamic_cast<MkBeamSpring*>(ana[i])) {
        assert(beam);
        MkBeamSpring *b = new MkBeamSpring();
        *b = *beam;
        FAnalysis[i] = b;
      }
      else if(mori = dynamic_cast<MkMori*>(ana[i])) {
        assert(mori);
        MkMori *m = new MkMori();
        *m = *mori;
        FAnalysis[i] = m;
      }
      else if(cbeam = dynamic_cast<MkContBeam*>(ana[i])) {
        assert(cbeam);
        MkContBeam *cb = new MkContBeam();
        *cb = *cbeam;
        FAnalysis[i] = cb;
      }
    }
    return *this;
}

MkAnalysis * MkAnalyses::operator[](int i)
{
    if (FSize == 0) return &NullAnalysis;
    else if (i >=0 && i < FSize) return FAnalysis[i];
    else return &NullAnalysis;
}

bool MkAnalyses::operator==(MkAnalyses &a)
{
  int i;
  bool flag=true;
  if (FSize!=a.FSize) return false;
  for (i=0;i<FSize;i++) {
    flag = flag && *FAnalysis[i]==*a[i];
  }
  return flag;
}

bool MkAnalyses::operator!=(MkAnalyses &a)
{
  return !(*this==a);
}

#ifdef __BCPLUSPLUS__
void MkAnalyses::Draw(TObject *Sender)
{ 
    TColor C;
    float Offset;
    if (FSize == 0) return;
    if (String(Sender->ClassName()) == String("MkPaintBox")) {
       MkPaintBox *pb=(MkPaintBox*)Sender;
       C = pb->Canvas->Pen->Color;
       pb->Canvas->Pen->Color = Color;
       for (int i = 0; i < FSize;i++) {
           Offset = pb->Offset(3);
           (*FAnalysis)[i].Draw(pb);
       }
       pb->Canvas->Pen->Color = C;
    }
}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void MkAnalyses::Draw(MkPaint *pb)
{
  for (int i=0;i<FSize;i++) {
    (*FAnalysis)[i].Draw(pb);
  }
}
#endif
//---------------------------------------------------------------------------
