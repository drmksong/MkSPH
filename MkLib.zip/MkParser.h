//---------------------------------------------------------------------------
#ifndef MkParserH
#define MkParserH

#include <stdio.h>
#include <string.h>
//---------------------------------------------------------------------------
class MkParser {
protected:
  FILE *FP;
  char FileName[256];
public:
  MkParser();
  MkParser(char *fname);
  ~MkParser();

  void SetFileName(char *fname){strncpy(FileName,fname,255);}
  char *GetFileName(){return FileName;}

  bool Create();
  bool Delete();
  bool Open();
  bool Close();
  bool Eof(){return feof(FP);}

  bool Create(char *fname){SetFileName(fname);return Create();}
  bool Delete(char *fname){SetFileName(fname);return Delete();}
  bool Open(char *fname){SetFileName(fname);return Open();}
  bool Close(char *fname){SetFileName(fname);return Close();}

  virtual bool Parse();
};
#endif

