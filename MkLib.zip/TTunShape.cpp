//---------------------------------------------------------------------------
// It is part of OPTIFACE program which is to be designed to get
// the best parameter using Genetic alogrithm which is one of optimization
// algorithm.
// The work of this project was started by T.H. Ahn, and handed to M.K. Song.
// Copyright (c) 1999 ESCO Consultant Co., Ltd.
#include <vcl.h>
#pragma hdrstop

#include "TTunShape.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)

