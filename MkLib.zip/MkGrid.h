//---------------------------------------------------------------------------
#ifndef MkGridH
#define MkGridH

#include "MkMisc.h"
#include "MkPoint.h"
#include "MkFloat.h"
#include "MkCube.h"
#include "MkRailWay.h"
#include "MkFault.h"
#include "MkPlane.h"
#include "MkKrig.h"

class MkTopoGrid {
private:
    MkFloat X,Y,Elev;
    float XMin,XMax,YMin,YMax,ElevMin,ElevMax;//Z mean value.
    int NX,NY;
    bool Assigned;
public:
    MkTopoGrid();
    MkTopoGrid(MkFloat &x,MkFloat &y,MkFloat &elev);
    void SetX(MkFloat &x){X.CopyFrom(x);}
    void SetY(MkFloat &y){Y.CopyFrom(y);}
    void SetElev(MkFloat &elev){Elev.CopyFrom(elev);}
    void SetTopoGrid(MkFloat &x,MkFloat &y,MkFloat &elev);
    float operator()(float x,float y);
    float operator()(int i,int j){return Elev(i,j);}
    float GetX(int i){return X(i);}
    float GetY(int i){return Y(i);}
    MkTopoGrid & operator=(MkTopoGrid &tg);
    bool isAssigned(){return Assigned;}
};

class MkGrid2D { // plane ��ü�� �����󿡼� ������ ���⼺, ������ ��ġ�� �����ϵ��� �Ѵ�.
private:
    MkDataPoints FGrid; // Mesh
    MkDataPoints FPoints;  // Value at point for interpolation
    int NAxis1,NAxis2;
    MkPoint Boundary[2]; //Boundary[0]�� ����ü�� ���� ���� ��ǥ�� �ǹ��ϰ�,
                            //Boundary[1]�� ����ü�� ���� ���� ��ǥ�� �ǹ��Ѵ�.
    float Axis1Min,Axis1Max,Axis2Min,Axis2Max;
    float Axis1Dif,Axis2Dif;
    char GridFileName[256];
    char FieldFileName[256];
    char UCDFileName[256];
public:
    __fastcall MkGrid2D();
    __fastcall MkGrid2D(int nx,int ny,int nz);
    void __fastcall SetFieldFileName(char *file_name){strcpy(FieldFileName,file_name);};
    void __fastcall SetUCDFileName(char *file_name){strcpy(UCDFileName,file_name);};
    void __fastcall SetGridFileName(char *file_name){strcpy(GridFileName,file_name);;}
    bool __fastcall SaveFieldFile(char *file_name);
    bool __fastcall SaveUCDFileName(char *file_name);
    bool __fastcall SaveFieldFile();
    bool __fastcall ReadFieldFile();
    bool __fastcall ReadGridFile();
    bool __fastcall ReadGridFile(char *file_name);
    bool __fastcall SaveUCDFile();
    void SetMemo(TObject *);
    void SetProgBar(TObject *);

    void __fastcall SetGrid(int nx,int ny,int nz);

    void __fastcall Setup();
    void __fastcall SetDataPoints(MkDataPoints & points){FPoints = points;};
    MkDataPoints & GetPoints(){return FGrid;};
    void __fastcall InverseDistance();
    void __fastcall Krig3D();
    void __fastcall Krig2D();

    MkDataPoint & __fastcall operator()(int i,int j);
    MkGrid2D & __fastcall operator=(MkGrid2D &);
    bool __fastcall operator==(MkGrid2D &);
public:
    float FXMin,FXMax,FYMin,FYMax;
    TMemo *memo;
    TProgressBar *prog_bar;
};

class MkGrid {
private:
    int Dimension;  // 2D or 3D
    MkDataPoints FGrid;  // Mesh
    MkDataPoints FPoints;  // Value at point for interpolation
    int NX,NY,NZ;
    MkPoint Boundary[2]; // Boundary[0]�� ����ü�� ���� ���� ��ǥ�� �ǹ��ϰ�,
                            // Boundary[1]�� ����ü�� ���� ���� ��ǥ�� �ǹ��Ѵ�.
    MkRailWay FRailWay;
    float XMin,XMax,YMin,YMax,ZMin,ZMax;
    float XDif,YDif,ZDif;
    float StartStation, EndStation;
    MkTopoGrid FTopoGrid;
    MkFloat Tunnel;
    char FieldFileName[256];
    char UCDFileName[256];
public:
    __fastcall MkGrid();
    __fastcall MkGrid(int nx,int ny,int nz);
    void __fastcall SetFieldFileName(char *file_name){strcpy(FieldFileName,file_name);};
    void __fastcall SetUCDFileName(char *file_name){strcpy(UCDFileName,file_name);};
    bool __fastcall SaveFieldFile(char *file_name);
    bool __fastcall SaveUCDFileName(char *file_name);
    bool __fastcall SaveFieldFile();
    bool __fastcall ReadFieldFile();
    bool __fastcall SaveUCDFile();
    void SetMemo(TObject *);
    void SetProgBar(TObject *);

    void __fastcall SetStation(float start_sta,float end_sta){
                    StartStation = start_sta;EndStation = end_sta;};
    void __fastcall SetGrid(int nx,int ny,int nz);
    void __fastcall SetBoundary(MkPoint lb,MkPoint ub)
         {Boundary[0] = lb;
          Boundary[1] = ub;
          XMin = Boundary[0].X;YMin = Boundary[0].Y;ZMin = Boundary[0].Z;
          XMax = Boundary[0].X;YMax = Boundary[0].Y;ZMax = Boundary[0].Z;};
    void __fastcall SetRailWay(MkRailWay &rail_way) {FRailWay = rail_way;
                                                    FXMin = rail_way[0].X;
                                                    FYMin = rail_way[0].Y;}
    void __fastcall SetTopoGrid(MkTopoGrid & tg){FTopoGrid = tg;};
    void __fastcall Setup();
    void __fastcall SetupTunnel();
    void __fastcall SetDataPoints(MkDataPoints & points){FPoints = points;};
    MkDataPoints & GetPoints(){return FGrid;};
    void __fastcall InverseDistance();
    void __fastcall Krig3D();
    void __fastcall Krig2D();

    MkDataPoint & __fastcall operator()(int i,int j,int k);
    MkGrid & __fastcall operator=(MkGrid &);
    bool __fastcall operator==(MkGrid &);
public:
    float FXMin,FXMax,FYMin,FYMax;
    TMemo *memo;
    TProgressBar *prog_bar;
};

class MkLayerGrid {
private:

    MkDataPoints FGrid;  // Mesh
    MkDataPoints FResist; // Resistivity
    MkTopoGrid FTopoGrid;
    MkTopoGrid FirstLayerGrid;
    MkTopoGrid SecondLayerGrid;
    MkTopoGrid ThirdLayerGrid;
    MkTopoGrid FourthLayerGrid;
    MkTopoGrid FifthLayerGrid;
    MkRailWay      FRailWay,FRailWay2;
    MkCubes    FCubes;
    MkFaults       FFaults;           // �ļ�� �ڷ�
    MkCube     FCutBlock;
    MkPointsPlanes FPointsPlanes;     // ���� �� ����� �ڷ�
    float StartStation, EndStation;
    float FDepth;
    int NX,NY,NZ;                    // �׸��� ��
    bool  isLayer,isResist,isSide,isInFault,isCutBlock,isTunnel;
    MkFloat Layer,Resist,Side,InFault,CutBlock,Tunnel;   // Each node has these values.
    // Layer : ������踦 ����� 0-1, ǳȭ���� 1-2, ����� 2-3
    // Resist : ���������� ��ġ�� ���������ġ
    // Side : �ͳ��� ������ ���� ���ؼ� �ͳ��߽ɼ����κ��� �¿���� �Ÿ�
    // InFault : �ļ���� �Ȱ� ���� ��Ÿ���� ��.
    // CutBlock : ���θ� �Ⱦ�� ���� ���� ���
    // Tunnel : �ͳ��� ������ ���
    char FieldFileName[256];
    float FXMin,FYMin;
    MkKrig FKrig;
    int NumOfLine;

public:
    __fastcall MkLayerGrid();
    __fastcall MkLayerGrid(int nx,int ny,int nz);

    void __fastcall SetFieldFileName(char *file_name){strcpy(FieldFileName,file_name);};
    bool __fastcall SaveFieldFile(char *file_name);
    bool __fastcall SaveFieldFile();
    bool __fastcall SaveSimpleFieldFile(char *file_name);
    bool __fastcall SaveSimpleFieldFile();
    bool __fastcall SaveResistFieldFile();

    void SetMemo(TObject *);
    void SetProgBar(TObject *);

    void __fastcall Setup();// grid�� �� ��ǥ���� �̵�
    void __fastcall SetupCNP(); // Setup�� ��ü�ϴ� ������ ��������並 ǥ���Ҷ� ���
    void __fastcall SetStation(float start_sta,float end_sta){
                    StartStation = start_sta;EndStation = end_sta;};
    void __fastcall SetGrid(int nx,int ny,int nz);
    void __fastcall SetupLayer();
    void __fastcall SetupDefaultLayer();
    void __fastcall SetupLayerCNP();
    void __fastcall SetupLayer2();// ��������ö�� ���ؼ� �ӽ÷� �����.
    void __fastcall SetupResist();
    void __fastcall SetupKrigResist();
    void __fastcall SetupSide();
    void __fastcall SetupInFault();
    void __fastcall SetupCutBlock();
    void __fastcall SetupTunnel();
    void __fastcall SetupTunnelBK() ;    
    void __fastcall SetTopography(MkTopoGrid &topo_grid){FTopoGrid = topo_grid;}
    void __fastcall SetFirstLayer(MkTopoGrid &first_grid){FirstLayerGrid = first_grid;}
    void __fastcall SetSecondLayer(MkTopoGrid &second_grid){SecondLayerGrid = second_grid;}
    void __fastcall SetThirdLayer(MkTopoGrid &third_grid){ThirdLayerGrid = third_grid;}
    void __fastcall SetFourthLayer(MkTopoGrid &fourth_grid){FourthLayerGrid = fourth_grid;}
    void __fastcall SetFifthLayer(MkTopoGrid &fifth_grid){FifthLayerGrid = fifth_grid;}
    void __fastcall SetRailWay(MkRailWay & rail_way){FRailWay = rail_way;}
    void __fastcall SetRailWay(MkRailWay & rail_way, MkRailWay rail_way2){FRailWay = rail_way;FRailWay2 = rail_way2;NumOfLine=2;}
    void __fastcall SetFaults(MkFaults &faults);
    void __fastcall SetCutBlock(MkCube cube);
    void __fastcall SetPointsPlanes(MkPointsPlanes & pp);
    void __fastcall SetResistivity(MkDataPoints &resist);
    void __fastcall InverseDistance();
    void __fastcall Krig3D();

    bool __fastcall IsLayer(){return isLayer;}
    bool __fastcall IsResist(){return isResist;}
    bool __fastcall IsSide(){return isSide;}
    bool __fastcall IsInFault(){return isInFault;}
    bool __fastcall IsCutBlock(){return isCutBlock;}
    bool __fastcall IsTunnel(){return isTunnel;}

    void __fastcall SetLayer(bool b){isLayer = b;}
    void __fastcall SetResist(bool b){isResist = b;}
    void __fastcall SetSide(bool b){isSide = b;}
    void __fastcall SetInFault(bool b){isInFault = b;}
    void __fastcall SetCutBlock(bool b){isCutBlock = b;}
    void __fastcall SetTunnel(bool b){isTunnel = b;}
    void __fastcall SetDepth(float d){FDepth = d;}

    void __fastcall ScaleAxis(float xs, float ys, float zs);

    MkDataPoint & __fastcall operator()(int i,int j,int k);
public:
    TMemo *memo;
    TProgressBar *prog_bar;
    float XMin,XMax,YMin,YMax,ZMin,ZMax;
    float XDif,YDif,ZDif;
};

//---------------------------------------------------------------------------
#endif
