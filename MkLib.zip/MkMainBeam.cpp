//---------------------------------------------------------------------------
#include "MkMainBeam.h"
#ifdef __BCPLUSPLUS__
#include <vcl.h>
#endif
#pragma hdrstop
//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#pragma package(smart_init)
#endif

void MkMainBeam::Clear()
{
  Height=0;
  Width=0;
  T1=0;
  T2=0;         // tt1, tt2
  Area=0;
  AreaWeb=0; // AA, Aw

  Weight=0;
  SecCoeffY=0;
  SecCoeffZ=0;    // Section coefficient Zx, Zy
  SecMomentY=0;
  SecMomentZ=0;
  SecRadiusY=0;
  SecRadiusZ=0;  // second radius of inertia rx, ry
}

#ifdef __BCPLUSPLUS__
void MkMainBeam::Import(MkGlobalVar &globalvar, int sec)
{
  Width=globalvar.mainbeam_BB[sec+1];
  Height=globalvar.mainbeam_HH[sec+1];
  T1=globalvar.mainbeam_tt1[sec+1];
  T2=globalvar.mainbeam_tt2[sec+1];
  Area=globalvar.mainbeam_AA[sec+1];
  AreaWeb=globalvar.mainbeam_Aw[sec+1];
  Weight=globalvar.mainbeam_W[sec+1];
  SecCoeffY=globalvar.mainbeam_Zx[sec+1];
  SecMomentY=globalvar.mainbeam_Ix[sec+1];
  SecRadiusY=globalvar.mainbeam_rx[sec+1];
  SecRadiusZ=globalvar.mainbeam_ry[sec+1];
}

void MkMainBeam::Export(MkGlobalVar &globalvar, int sec)
{
  globalvar.mainbeam_BB[sec+1]=Width;
  globalvar.mainbeam_HH[sec+1]=Height;
  globalvar.mainbeam_tt1[sec+1]=T1;
  globalvar.mainbeam_tt2[sec+1]=T2;
  globalvar.mainbeam_AA[sec+1]=Area;
  globalvar.mainbeam_Aw[sec+1]=AreaWeb;
  globalvar.mainbeam_W[sec+1]=Weight;
  globalvar.mainbeam_Zx[sec+1]=SecCoeffY;
  globalvar.mainbeam_Ix[sec+1]=SecMomentY;
  globalvar.mainbeam_rx[sec+1]=SecRadiusY;
  globalvar.mainbeam_ry[sec+1]=SecRadiusZ;
}
#endif

void MkMainBeam::SetBeam(MkBeam beam)
{
  SetSteelType(beam.SteelType);
  SetHeight(beam.HH);
  SetWidth(beam.BB);
  SetT1(beam.tt1);
  SetT2(beam.tt2);
  SetArea(beam.AA);
  SetAreaWeb(beam.Aw);
  SetWeight(beam.W);
  SetSecCoeffY(beam.Zx);
  SetSecCoeffZ(beam.Zx);
  SetSecMomentY(beam.Ix);
  SetSecMomentZ(beam.Ix);
  SetSecRadiusY(beam.rx);
  SetSecRadiusZ(beam.ry);
}
