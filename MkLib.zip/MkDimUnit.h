//---------------------------------------------------------------------------
#ifndef MkDimUnitH
#define MkDimUnitH
//---------------------------------------------------------------------------
// Apply conversion with respect to Meter, Sec, Tonf, Tonf/m2
//---------------------------------------------------------------------------
enum MkLenUnitType {utMeter, utCentimeter, utMilimeter, utKilometer};
enum MkAreaUnitType {utMeter2, utCenti2, utMili2, utKilo2};
enum MkVolumeUnitType {utMeter3, utCenti3, utMili3, utKilo3};
enum MkTimeUnitType {utSec, utMinute, utHour, utDay, utMonth, utYear};
enum MkPressUnitType {utTPM2, utKPC2, utMPa, utKPa};
enum MkMassUnitType {utTon, utKilogram, utGram};
enum MkForceUnitType {utTONF, utKGF, utN, utKN, utMN};

class MkDimUnit {
protected:
  MkLenUnitType LenType;
  MkTimeUnitType TimeType;
  MkPressUnitType PressType;
  MkForceUnitType ForceType;

public:
  MkDimUnit();

  void SetLenType(MkLenUnitType ut){LenType = ut;}
  void SetTimeType(MkTimeUnitType ut){TimeType = ut;}
  void SetPressType(MkPressUnitType ut){PressType = ut;}
  void SetForceType(MkForceUnitType ut){ForceType = ut;}

  MkLenUnitType GetLenType(){return LenType;}
  MkTimeUnitType GetTimeType(){return TimeType;}
  MkPressUnitType GetPressType(){return PressType;}
  MkForceUnitType GetForceType(){return ForceType;}

  float len();
  float area();
  float volume();
  float mass();
  float time();
  float press();
  float stress();
  float force();
  float weight();
};
#endif
