//---------------------------------------------------------------------------
#include "MkGrid.h"
//---------------------------------------------------------------------------

MkTopoGrid::MkTopoGrid()
{
    XMin = 0;
    XMax = 0;
    YMin = 0;
    YMax = 0;
    ElevMin = 0;
    ElevMax = 0;
    Assigned = false;
}

MkTopoGrid::MkTopoGrid(MkFloat &x,MkFloat &y,MkFloat &elev)
{
    X.CopyFrom(x);
    NX = X.getSzX();
    Y.CopyFrom(y);
    NY = Y.getSzX();
    Elev.CopyFrom(elev);
    XMin = X(0);XMax = X(X.getSzX());
    YMin = Y(0);YMax = Y(Y.getSzX());
    ElevMin = Elev(0);ElevMax = Elev(Elev.getSzX());
    Assigned = true;
}

void MkTopoGrid::SetTopoGrid(MkFloat &x,MkFloat &y,MkFloat &elev)
{
    X.CopyFrom(x);
    NX = X.getSzX();
    Y.CopyFrom(y);
    NY = Y.getSzX();
    Elev.CopyFrom(elev);
    XMin = X(0);XMax = X(X.getSzX()-1);
    YMin = Y(0);YMax = Y(Y.getSzX()-1);
    ElevMin = Elev(0);ElevMax = Elev(Elev.getSzX()-1);
    Assigned = true;
}

float MkTopoGrid::operator()(float x,float y)
{
  MkPoint rp[4];
  MkTriangle rt[2];
  MkLine rl[2];
  float elev[4];
  long I,J;
  long i,j;

  if (x < XMin || x > XMax || y < YMin || y > YMax) return 0;

  for (i = 0 ; i < NX-1 ; i++) {
    if (x >= X[i] && x <= X[i+1]) {
       I = i;
       break;
    }
  }
  for (j = 0; j < NY-1 ; j++ ) {
    if (y >= Y[j] && y <= Y[j+1]) {
       J = j;
       break;
    }
  }
  if (i == NX-1 || j == NY-1) return 0;

  rp[0] = MkPoint(X[I  ],Y[J  ],Elev[(int)I][J]);
  rp[1] = MkPoint(X[I+1],Y[J  ],Elev[(int)(I+1)][J]);
  rp[2] = MkPoint(X[I+1],Y[J+1],Elev[(int)(I+1)][J+1]);
  rp[3] = MkPoint(X[I  ],Y[J+1],Elev[(int)I][J+1]);

  rt[0].Reset(rp[0],rp[1],rp[3]);
  rt[1].Reset(rp[1],rp[2],rp[3]);

  if (rt[0].isIn(x,y)) {
     return rt[0](x,y);
  }

  else if (rt[1].isIn(x,y)) {
     return rt[1](x,y);
  }
  else return 0;
}

MkTopoGrid & MkTopoGrid::operator=(MkTopoGrid &tg)
{
     X.CopyFrom(tg.X);
     Y.CopyFrom(tg.Y);
     Elev.CopyFrom(tg.Elev);
     XMin     =  tg.XMin;
     XMax     =  tg.XMax;
     YMin     =  tg.YMin;
     YMax     =  tg.YMax;
     ElevMin  =  tg.ElevMin;
     ElevMax  =  tg.ElevMax;
     NX       =  tg.NX;
     NY       =  tg.NY;
     Assigned =  true;
}

//---------------------------------------------------------------------------

__fastcall MkGrid::MkGrid()
{
    FGrid.Initialize(0);
    FPoints.Initialize(0);
    NX=NY=NZ=0;

    Boundary[0] = Boundary[1] = NullPoint;

    strcpy(FieldFileName,"\0");
    strcpy(UCDFileName,"\0");
}

__fastcall MkGrid::MkGrid(int nx,int ny,int nz)
{
    NX = nx;
    NY = ny;
    NZ = nz;
    FGrid.Initialize(nx*ny*nz);
}

void MkGrid::SetMemo(TObject *Sender)
{
    memo = dynamic_cast<TMemo *>(Sender);
    if (!memo) memo->Lines->Add("Memo is assigned to GeomReader!");
}

void MkGrid::SetProgBar(TObject *Sender)
{
    prog_bar = dynamic_cast<TProgressBar *>(Sender);
    if (!memo) memo->Lines->Add("Memo is assigned to GeomReader!");
}

bool __fastcall MkGrid::SaveFieldFile(char *file_name)
{
    SetFieldFileName(file_name);
    SaveFieldFile();
}

bool __fastcall MkGrid::SaveUCDFileName(char *file_name)
{
    SetUCDFileName(file_name);
    SaveUCDFile();
}

bool __fastcall MkGrid::SaveFieldFile()
{
    FILE *fp;
    char str[256];

    XDif = XMax - XMin;
    YDif = YMax - YMin;
    ZDif = ZMax - ZMin;

    fp = fopen(FieldFileName,"wb");
    fprintf(fp,"# AVS field file %s\n",FieldFileName);
    fprintf(fp,"ndim = %d\n",3);
    fprintf(fp,"dim1 = %d\n",NX);
    fprintf(fp,"dim2 = %d\n",NY);
    fprintf(fp,"dim3 = %d\n",NZ);
    fprintf(fp,"nspace = %d\n",3);
    fprintf(fp,"veclen = %d\n",3);
    fprintf(fp,"data = float\n");
    fprintf(fp,"field = irregular\n");
    fprintf(fp,"label = Resistivity Tunnel Depth\n");

    fprintf(fp,"variable 1 filetype=ascii skip= 0 offset=0 stride=6\n");
    fprintf(fp,"variable 2 filetype=ascii skip= 0 offset=1 stride=6\n");
    fprintf(fp,"variable 3 filetype=ascii skip= 0 offset=2 stride=6\n");
    fprintf(fp,"coord    1 filetype=ascii skip= 0 offset=3 stride=6\n");
    fprintf(fp,"coord    2 filetype=ascii skip= 0 offset=4 stride=6\n");
    fprintf(fp,"coord    3 filetype=ascii skip= 0 offset=5 stride=6\n");

    strcpy(str,"\f\f\n");
    fprintf(fp,"%s",str);
    //fwrite(&str,sizeof(str[0]),2,fp);

    for (int k=0;k<NZ;k++)
        for (int j=0;j<NY;j++)
            for (int i=0;i<NX;i++) {
                float depth;
                float x,y,elev;
                x = (XMax-XMin)/(NX+1)*i+XMin;
                y = (YMax-YMin)/(NY+1)*j+YMin;
                elev = FTopoGrid(x,y)+100;
                depth = elev - (*this)(i,j,k).Z;

/*
                if ((*this)(i,j,k).Z < ZDif/2 - 2) {
                   if (dist < 5)
                      inout = ZDif/2-(*this)(i,j,k).Z;
                   else inout = dist-5;
                }
                else {
                   if ( dist < 5 ) {
                      inout = dist-5;
                   }
                   else inout = dist-5;
                }
*/

                sprintf(str,"%f %f %f %f %f %f",
                (*this)(i,j,k).Data,Tunnel(i,j,k),depth,
                (*this)(i,j,k).X, (*this)(i,j,k).Y,(*this)(i,j,k).Z );
                fprintf(fp,"%s\n",str);
            }
/*
    for (int k=0;k<NZ;k++)
        for (int j=0;j<NY;j++)
            for (int i=0;i<NX;i++) {
                int data = (*this)(i,j,k).Data;
                fwrite(&data,sizeof(data),1,fp);
                fwrite(&data,sizeof(data),1,fp);
                fwrite(&data,sizeof(data),1,fp);
            }

    for (int k=0;k<NZ;k++)
        for (int j=0;j<NY;j++)
            for (int i=0;i<NX;i++) {
                int x = (*this)(i,j,k).X;
                fwrite(&x,sizeof(x),1,fp);
            }
    for (int k=0;k<NZ;k++)
        for (int j=0;j<NY;j++)
            for (int i=0;i<NX;i++){
                int y = (*this)(i,j,k).Y;
                fwrite(&y,sizeof(y),1,fp);
            }
    for (int k=0;k<NZ;k++)
        for (int j=0;j<NY;j++)
            for (int i=0;i<NX;i++){
                int z = (*this)(i,j,k).Z;
                fwrite(&z,sizeof(z),1,fp);
            }

    for (int k=0;k<NZ;k++)
        for (int j=0;j<NY;j++)
            for (int i=0;i<NX;i++) {
                sprintf(str,"%d %d %d %d %d %d",
                (int)(*this)(i,j,k).Data,(int)(*this)(i,j,k).Data,(int)(*this)(i,j,k).Data,
                (int)(*this)(i,j,k).X, (int)(*this)(i,j,k).Y,(int)(*this)(i,j,k).Z );
                fprintf(fp,"%s\n",str);
            }
*/

    fclose(fp);
    return true;
}

bool __fastcall MkGrid::ReadFieldFile()
{
    FILE *fp;
    char str[256];
    int i,j,k,n;
//    MkFloat X(NX,NY,NZ),Y(NX,NY,NZ),Z(NX,NY,NZ),Data(NX,NY,NZ);
    int x[10][10][10],y[10][10][10],z[10][10][10],data[10][10][10];

    fp = fopen(FieldFileName,"r");

    fgets(str,255,fp);//fprintf(fp,"# AVS field file %s\n",FieldFileName);
    fgets(str,255,fp);//fprintf(fp,"ndim = %d\n",3);
    fgets(str,255,fp);//fprintf(fp,"dim1 = %d\n",NX);
    fgets(str,255,fp);//fprintf(fp,"dim2 = %d\n",NY);
    fgets(str,255,fp);//fprintf(fp,"dim3 = %d\n",NZ);
    fgets(str,255,fp);//fprintf(fp,"nspace = %d\n",3);
    fgets(str,255,fp);//fprintf(fp,"veclen = %d\n",1);
    fgets(str,255,fp);//fprintf(fp,"data = byte\n");
    fgets(str,255,fp);//fprintf(fp,"field = irregular\n");
    fgets(str,255,fp);//fprintf(fp,"label = Resistivity \n");

    fgets(str,255,fp);//fprintf(fp,"variable 1 filetype=binary skip= 0 stride=6\n");
    fgets(str,255,fp);//fprintf(fp,"variable 2 filetype=binary skip= 0 stride=6\n");
    fgets(str,255,fp);//fprintf(fp,"variable 3 filetype=binary skip= 0 stride=6\n");
    fgets(str,255,fp);//fprintf(fp,"coord    1 filetype=binary skip= 0 stride=6\n");
    fgets(str,255,fp);//fprintf(fp,"coord    2 filetype=binary skip= 0 stride=6\n");
    fgets(str,255,fp);//fprintf(fp,"coord    3 filetype=binary skip= 0 stride=6\n");

    fread(&str,sizeof(str[0]),2,fp);//fprintf(fp,"%s","");

//    fprintf(fp,"%c%c",VK_CONTROL || 'L',VK_CONTROL|| 'L');
    for ( k=0;k<NZ;k++)
        for ( j=0;j<NY;j++)
            for ( i=0;i<NX;i++) {
                n = fread(&data[i][j][k],sizeof(data[i][j][k]),1,fp);
                n = fread(&data[i][j][k],sizeof(data[i][j][k]),1,fp);
                n = fread(&data[i][j][k],sizeof(data[i][j][k]),1,fp);
                sprintf(str,"data[i][j][k] = %d",data[i][j][k]);
                memo->Lines->Add(str);
            }

    for ( k=0;k<NZ;k++)
        for ( j=0;j<NY;j++)
            for ( i=0;i<NX;i++) {
                n = fread(&x[i][j][k],sizeof(x[i][j][k]),1,fp);
                sprintf(str,"x[i][j][k] = %d",x[i][j][k]);
                memo->Lines->Add(str);
            }
    for ( k=0;k<NZ;k++)
        for ( j=0;j<NY;j++)
            for ( i=0;i<NX;i++) {
                n = fread(&y[i][j][k],sizeof(y[i][j][k]),1,fp);
                sprintf(str,"y[i][j][k] = %d",y[i][j][k]);
                memo->Lines->Add(str);
            }
    for ( k=0;k<NZ;k++)
        for ( j=0;j<NY;j++)
            for ( i=0;i<NX;i++) {
                n = fread(&z[i][j][k],sizeof(z[i][j][k]),1,fp);
                sprintf(str,"z[i][j][k] = %d",z[i][j][k]);
                memo->Lines->Add(str);
            }

    fclose(fp);
    return true;
}

bool __fastcall MkGrid::SaveUCDFile()
{

}

void __fastcall MkGrid::SetGrid(int nx,int ny,int nz)
{
    if (nx == NX && ny == NY && nz == NZ) return;
    FGrid.Clear();
    NX = nx;
    NY = ny;
    NZ = nz;
    FGrid.Initialize(nx*ny*nz);
    Tunnel.Initialize(nx,ny,nz);
}

void __fastcall MkGrid::Setup()
{

    XMin = Boundary[0].X;
    YMin = Boundary[0].Y;
    ZMin = Boundary[0].Z;
    XMax = Boundary[1].X;
    YMax = Boundary[1].Y;
    ZMax = Boundary[1].Z;

    for (int i = 0 ; i < NX;i++) {
        for (int j = 0 ; j < NY ; j++) {
            float x,y,elev;
            x = (XMax-XMin)/(NX+1)*i+XMin;
            y = (YMax-YMin)/(NY+1)*j+YMin;
            elev = FTopoGrid(x,y);
//            elev = FTopoGrid(x,y)-100;
            if (elev > ZMax) ZMax = elev;
        }
    }

    XDif = XMax - XMin;
    YDif = YMax - YMin;
    ZDif = ZMax - ZMin;

    for (int i=0;i<NX;i++) {
        for (int j=0;j<NY;j++) {
/*            float x,y,elev;
            x = (XMax-XMin)/(NX+1)*i+XMin;
            y = (YMax-YMin)/(NY+1)*j+YMin;
            ZMax = elev = FTopoGrid(x,y)+100;
            if (ZMin > ZMax) ZMax = Boundary[1].Z;
*/
            for (int k=0;k<NZ;k++) {
                (*this)(i,j,k) = MkDataPoint((XMax-XMin)/(NX+1)*i+XMin,(YMax-YMin)/(NY+1)*j+YMin,(ZMax-ZMin)/NZ*k+ZMin);
                (*this)(i,j,k).Data = 0;
                Tunnel(i,j,k) = 0;
            }
        }
    }
}

void __fastcall MkGrid::SetupTunnel()
{
    int I;float J;
    float msta;
    float Phi,theta;
    MkPoint cp,dir;
    MkDataPoint rp;

    msta = (StartStation+EndStation)/2;
    I = int(msta/1000);
    J = msta - I*1000;

    cp =  FRailWay(I,J);
    cp.Z = cp.Z + 100;
    dir = FRailWay.FowardDir(I,J);
    dir.Normalize();

    Phi = acos(dir.X);
    if (fabs(cos(Phi) - dir.X) < 0.001) Phi = Phi *180/M_PI;
    else Phi = (Phi+M_PI)*180/M_PI;

    for (int i=0;i<NX;i++) {
        for (int j=0;j<NY;j++) {
            for (int k=0;k<NZ;k++) {
                rp = (*this)(i,j,k);
                rp.Translate(-cp.X,-cp.Y,-cp.Z);
                rp.Rotate(-Phi,0,0);  // �޼� ��ǥ��
                rp.Translate(0,-2.900,-2.047);

                float dist;
                float depth;
                dist = rp.Z*rp.Z;
                dist += rp.Y*rp.Y;
                dist = sqrt(dist);

                float theta;
                MkPoint cp(rp.Y,rp.Z);
                theta = cp.GetAng();
                if (theta > 210 && theta <330) {
                   Tunnel(i,j,k) = dist/sin(30*M_PI/180) - 5;
                }
                else {
                   Tunnel(i,j,k) = dist-5;
                }
            }
        }
    }

}

void __fastcall MkGrid::InverseDistance()
{
    float Domain;

    Domain = XDif < YDif ?  (XDif < ZDif ? XDif : ZDif ) : ( YDif < ZDif ?  YDif : ZDif);
    prog_bar->Position = 0;
    for (int i=0;i<NX;i++) {
        for (int j=0;j<NY;j++) {
            for (int k=0;k<NZ;k++) {
                prog_bar->Position = (i*NY*NZ  + j*NZ + k)*100/(NX*NY*NZ);
                Application->ProcessMessages();
                float dist=0,bunja=0,bunmo=0;
                MkDataPoint cur_pnt, mun_pnt;
                cur_pnt = (*this)(i,j,k);
                bunmo = bunja = 0;
                for (int l = 0 ; l < FPoints.GetSize();l++) {
                    mun_pnt = FPoints[l];
//                    mun_pnt.X -= XMin;
//                    mun_pnt.Y -= YMin;
//                    mun_pnt.Z -= ZMin;

                    dist = CalDist(cur_pnt,mun_pnt);
                    if (dist < 0.0001) {
                       bunja += FPoints[l].Data*10000;
                       bunmo += 10000;
                    }
                    else if (dist < Domain) {
                       bunja += FPoints[l].Data/dist;
                       bunmo += 1/dist;
                    }
                }

                if (bunmo>0.0001) (*this)(i,j,k).Data = RandG(bunja/bunmo,bunja*0.005/bunmo);//(*this)(i,j,k).Data = bunja/bunmo
                else {
                    (*this)(i,j,k).Data = 0;
                    bunmo = bunja = 0;
                    for (int l = 0 ; l < FPoints.GetSize();l++) {
                        mun_pnt = FPoints[l];
//                        mun_pnt.X -= XMin;
//                        mun_pnt.Y -= YMin;
//                        mun_pnt.Z -= ZMin;

                        dist = CalDist(cur_pnt,mun_pnt);
                        if (dist < 0.0001) {
                           bunja += FPoints[l].Data*10000;
                           bunmo += 10000;
                        }
                        else if (dist < Domain*5) {
                           bunja += FPoints[l].Data/dist;
                           bunmo += 1/dist;
                        }
                    }
                    if (bunmo>0.0001) (*this)(i,j,k).Data = RandG(bunja/bunmo,bunja*0.005/bunmo);//(*this)(i,j,k).Data = bunja/bunmo
                }
            }
        }
    }

    float DMax=-10000000,DMin=10000000;
    for (int l = 0 ; l < FPoints.GetSize();l++) {
        if (FPoints[l].Data > DMax) DMax = FPoints[l].Data;
        if (FPoints[l].Data < DMin) DMin = FPoints[l].Data;
    }

    float datamax=-1000000,datamin=1000000;

    for (int i=0;i<NX;i++) {
        for (int j=0;j<NY;j++) {
            for (int k=0;k<NZ;k++) {
                if ((*this)(i,j,k).Data > datamax) datamax =(*this)(i,j,k).Data;
                if ((*this)(i,j,k).Data < datamin) datamin =(*this)(i,j,k).Data;
            }
        }
    }

    for (int i=0;i<NX;i++) {
        for (int j=0;j<NY;j++) {
            for (int k=0;k<NZ;k++) {
               float data;
               data = (*this)(i,j,k).Data;
               (*this)(i,j,k).Data = DMin + (DMax-DMin)*(data-datamin)/(datamax-datamin);
            }
        }
    }

}

void __fastcall MkGrid::Krig3D()
{

}

void __fastcall MkGrid::Krig2D()
{

}

MkDataPoint & __fastcall MkGrid::operator()(int i,int j,int k)
{
/*    if (i<0 || NX<=i) {
       ShowMessage("MkGrid index out of range\n");
       return NullDataPoint;
    }
    if (j<0 || NY<=j) {
       ShowMessage("MkGrid index out of range\n");
       return NullDataPoint;
    }
    if (k<0 || NZ<=k) {
       ShowMessage("MkGrid index out of range\n");
       return NullDataPoint;
    }
*/
    return FGrid[i+j*NX+k*NX*NY];
}

MkGrid & __fastcall MkGrid::operator=(MkGrid &rg)
{
    FGrid = rg.FGrid;
    FPoints = rg.FPoints;
    NX = rg.NX;
    NY = rg.NY;
    NZ = rg.NZ;
    Boundary[0] = rg.Boundary[0];
    Boundary[1] = rg.Boundary[1];

    strcpy(FieldFileName,rg.FieldFileName);
    strcpy(UCDFileName,rg.UCDFileName);
    return *this;
}

bool __fastcall MkGrid::operator==(MkGrid &rg)
{

}
//---------------------------------------------------------------------------
__fastcall MkLayerGrid::MkLayerGrid()
{
   memo = (TMemo*)NULL;
   prog_bar = (TProgressBar*)NULL;

   NX = NY = NZ = 0;
   FDepth = 30;
}

__fastcall MkLayerGrid::MkLayerGrid(int nx,int ny,int nz)
{
   memo = (TMemo*)NULL;
   prog_bar = (TProgressBar*)NULL;

   NX = nx;
   NY = ny;
   NZ = nz;
   FDepth = 30;
   FGrid.Initialize(nx*ny*nz);
   Layer.Initialize(nx,ny,nz);
   Resist.Initialize(nx,ny,nz);
   Side.Initialize(nx,ny,nz);
   InFault.Initialize(nx,ny,nz);
   CutBlock.Initialize(nx,ny,nz);
   Tunnel.Initialize(nx,ny,nz);
}

void __fastcall MkLayerGrid::SetGrid(int nx,int ny,int nz)
{
    if (nx == NX && ny == NY && nz == NZ) return;
    FGrid.Clear();
    NX = nx;
    NY = ny;
    NZ = nz;
    FGrid.Initialize(nx*ny*nz);
    Layer.Initialize(nx,ny,nz);
    Resist.Initialize(nx,ny,nz);
    Side.Initialize(nx,ny,nz);
    InFault.Initialize(nx,ny,nz);
    CutBlock.Initialize(nx,ny,nz);
    Tunnel.Initialize(nx,ny,nz);
}

void __fastcall MkLayerGrid::Setup()
{

    ZMin=100000000;
    float x,y,elev;
    for (int i=0;i<NX;i++) {
        for (int j=0;j<NY;j++) {
            elev = FTopoGrid(i,j);
            if (ZMin > elev) ZMin = elev;
        }
    }

  ZMin = ZMin-FDepth;
/*
    for (int i=0;i<FRailWay.GetSize();i++) {
        x = FRailWay[i].X;
        y = FRailWay[i].Y;
        elev = FTopoGrid(x,y);
        if (ZMin > elev) ZMin = elev;
    }
    ZMin = ZMin-30;
*/

    FXMin = FRailWay.GetXMin();
    FYMin = FRailWay.GetYMin();

    for (int i=0;i<NX;i++) {
        Application->ProcessMessages();
        for (int j=0;j<NY;j++) {
            float x,y,elev;
            x = FTopoGrid.GetX(i)-FXMin;
            y = FTopoGrid.GetY(j)-FYMin;
            elev = FTopoGrid(i,j);

            for (int k=0;k<NZ;k++) {
                float p;
//                p = 3*k/(2*(NZ-1)) - k*k*k/(2*(NZ-1)*(NZ-1)*(NZ-1));
//                (*this)(i,j,k) = MkDataPoint(x,y,(elev-ZMin)*p);
                (*this)(i,j,k) = MkDataPoint(x,y,(elev-ZMin)*k/(NZ-1));
                  // ȸ���� ȸ������ �𵨾ȿ� �־� �����ϴ�.
//                (*this)(i,j,k) = MkDataPoint(x,y,(elev-ZMin)*k/(NZ-1)+ZMin);
                // z��ǥ�� ����ǥ�� �ϸ� ������ �������� �Ʒ����� �̵���ų �ʿ�
                // �� ����. 
            }
        }
    }

    XMin = (*this)(0,0,0).X;
    YMin = (*this)(0,0,0).Y;
    XMax = (*this)(NX-1,NY-1,0).X;
    YMax = (*this)(NX-1,NY-1,0).Y;
}

void __fastcall MkLayerGrid::SetupCNP()
{

    ZMin=100000000;
    ZMax = -ZMin;
    float x,y,elev;
    for (int i=0;i<NX;i++) {
        for (int j=0;j<NY;j++) {
            elev = FTopoGrid(i,j);
            if (ZMin > elev) ZMin = elev;
            if (ZMax < elev) ZMax = elev;
        }
    }

    ZMin = ZMin-30;
    ZMax = ZMax + 0.1;

    FXMin = FRailWay[0].X;
    FYMin = FRailWay[0].Y;

    for (int i=0;i<NX;i++) {
        for (int j=0;j<NY;j++) {
            float x,y,elev,elev2;
            x = FTopoGrid.GetX(i)-FXMin;
            y = FTopoGrid.GetY(j)-FYMin;
            elev = FTopoGrid(i,j);
            MkPoint rp(x+FXMin,y+FYMin,0);

            for (int k=0;k < FPointsPlanes.GetSize();k++) {
                if (FPointsPlanes[k].IsIn(rp)) {
                   elev2 = FPointsPlanes[k].CalcHeight(rp);
                   if (FPointsPlanes[k].GetHeightMode() == hmAbs) elev = elev2;
                   else if (FPointsPlanes[k].GetHeightMode() == hmCut) elev = min(elev,elev2);
                   else if (FPointsPlanes[k].GetHeightMode() == hmPaste) elev = max(elev,elev2);
                }
            }

            for (int k=0;k < NZ;k++) {
                float p;
//                p = 3*k/(2*(NZ-1)) - k*k*k/(2*(NZ-1)*(NZ-1)*(NZ-1));
//                (*this)(i,j,k) = MkDataPoint(x,y,(elev-ZMin)*p);
                (*this)(i,j,k) = MkDataPoint(x,y,(elev-ZMin)*k/(NZ-1));
            }
        }
    }

    XMin = (*this)(0,0,0).X;
    YMin = (*this)(0,0,0).Y;
    XMax = (*this)(NX-1,NY-1,0).X;
    YMax = (*this)(NX-1,NY-1,0).Y;
}


void __fastcall MkLayerGrid::SetupLayer()
{
    for (int i=0;i<NX;i++) {
        Application->ProcessMessages();
        for (int j=0;j<NY;j++) {
            float x,y,z,elev[4];
            x = FTopoGrid.GetX(i);
            y = FTopoGrid.GetY(j);
            elev[0] = FTopoGrid(i,j);
            elev[1] = FirstLayerGrid(i,j);
            elev[2] = SecondLayerGrid(i,j);
//            elev[3] = ThirdLayerGrid(i,j);  // COMMENT THIS IF THERE IS TWO LAYER

            for (int k=0;k<NZ;k++) {
                z = (*this)(i,j,k).Z + ZMin;
                if (z < elev[0]+0.001 && z > elev[1])
                   Layer(i,j,k) = (z - elev[1])/(elev[0] - elev[1]);
                else if (z < elev[1] && z > elev[2])
                   Layer(i,j,k) = (z - elev[2])/(elev[1] - elev[2])+1;
//              else if (z < elev[2] && z > ZMin - 0.001)         // comment this if there is three layer
//                 Layer(i,j,k) = (z - ZMin)/(elev[2] - ZMin)+2;  // comment this if there is three layer

              else if (z < elev[2] && z > elev[3])
                 Layer(i,j,k) = (z - elev[3])/(elev[2] - elev[3])+2;
              else if (z < elev[3] && z > ZMin-0.001)          // COMMENT THIS IF THERE IS TOW LAYER
                 Layer(i,j,k) = (z - ZMin)/(elev[3] - ZMin)+3; // COMMENT THIS IF THERE IS TOW LAYER
            }
        }
    }
}

void __fastcall MkLayerGrid::SetupDefaultLayer()
{
    for (int i=0;i<NX;i++) {
        Application->ProcessMessages();
        for (int j=0;j<NY;j++) {
            float x,y,z,elev[4];
            x = FTopoGrid.GetX(i);
            y = FTopoGrid.GetY(j);
            elev[0] = FTopoGrid(i,j);

            for (int k=0;k<NZ;k++) {
                z = (*this)(i,j,k).Z + ZMin;
                if (z < elev[0]+0.001 && z > ZMin-0.001)
                   Layer(i,j,k) = (z-ZMin)/(elev[0] - ZMin);
            }
        }
    }
}

void __fastcall MkLayerGrid::SetupLayerCNP()
{
    for (int i=0;i<NX;i++) {
        Application->ProcessMessages();
        for (int j=0;j<NY;j++) {
            float x,y,z,elev[4];
            x = FTopoGrid.GetX(i);
            y = FTopoGrid.GetY(j);
            elev[0] = FTopoGrid(i,j);
            elev[1] = FirstLayerGrid(i,j);
            elev[2] = SecondLayerGrid(i,j);
            elev[3] = ThirdLayerGrid(i,j);  // COMMENT THIS IF THERE IS TWO LAYER

            for (int k=0;k<NZ;k++) {
                z = (*this)(i,j,k).Z + ZMin;
                if (z > elev[0]) Layer(i,j,k) = Layer(i,j,k) = 1;//(z - elev[0])/(ZMax - elev[0])-1;
                else if (z < elev[0]+0.001 && z > elev[1])
                   Layer(i,j,k) = (z - elev[1])/(elev[0] - elev[1]);
                else if (z < elev[1] && z > elev[2])
                   Layer(i,j,k) = (z - elev[2])/(elev[1] - elev[2])+1;
//              else if (z < elev[2] && z > ZMin - 0.001)         // comment this if there is three layer
//                 Layer(i,j,k) = (z - ZMin)/(elev[2] - ZMin)+2;  // comment this if there is three layer

              else if (z < elev[2] && z > elev[3])
                 Layer(i,j,k) = (z - elev[3])/(elev[2] - elev[3])+2;
              else if (z < elev[3] && z > ZMin-0.001)          // COMMENT THIS IF THERE IS TOW LAYER
                 Layer(i,j,k) = (z - ZMin)/(elev[3] - ZMin)+3; // COMMENT THIS IF THERE IS TOW LAYER
            }
        }
    }
}

void __fastcall MkLayerGrid::SetupLayer2() // remove this routine
{

    float ZMax=-100000;

//    for (int i=0;i<NX;i++)                      // delete from
//        for (int j=0;j<NY;j++)
//            ZMax = ZMax < FTopoGrid(i,j) ? FTopoGrid(i,j) : ZMax;;  // to here for general case

    for (int i=0;i<NX;i++) {
        Application->ProcessMessages();
        for (int j=0;j<NY;j++) {
            float z,elev[6];
//            elev[0] = ZMax; //FTopoGrid(i,j); remove comment for general case
            elev[0] = FTopoGrid(i,j);
            elev[1] = FirstLayerGrid(i,j);//+(ZMax-FTopoGrid(i,j));
            elev[2] = SecondLayerGrid(i,j);//+(ZMax-FTopoGrid(i,j));
            elev[3] = ThirdLayerGrid(i,j);//+(ZMax-FTopoGrid(i,j));;  // COMMENT THIS IF THERE IS TWO LAYER
            elev[4] = FourthLayerGrid(i,j);//+(ZMax-FTopoGrid(i,j));;  // COMMENT THIS IF THERE IS TWO LAYER
            elev[5] = FifthLayerGrid(i,j);//+(ZMax-FTopoGrid(i,j));;

            for (int k=0;k<NZ;k++) {
                z = (*this)(i,j,k).Z + ZMin;
                if (z < elev[0]+0.001 && z > elev[1])
                   Layer(i,j,k) = (z - elev[1])/(elev[0] - elev[1]);
                else if (z < elev[1] && z > elev[2])
                   Layer(i,j,k) = (z - elev[2])/(elev[1] - elev[2])+1;
//              else if (z < elev[2] && z > ZMin - 0.001)  // COMMENT THIS IF THERE IS Three LAYER
//                 Layer(i,j,k) = (z - ZMin)/(elev[2] - ZMin)+2;  // COMMENT THIS IF THERE IS Three LAYER
                else if (z < elev[2] && z > elev[3])            // COMMENT THIS IF THERE IS TWo LAYER
                   Layer(i,j,k) = (z - elev[3])/(elev[2] - elev[3])+2; // COMMENT THIS IF THERE IS TWo LAYER
                else if (z < elev[3] && z > elev[4])            // COMMENT THIS IF THERE IS TWo LAYER
                   Layer(i,j,k) = (z - elev[4])/(elev[3] - elev[4])+3; // COMMENT THIS IF THERE IS TWo LAYER
                else if (z < elev[4] && z > elev[5])            // COMMENT THIS IF THERE IS TWo LAYER
                   Layer(i,j,k) = (z - elev[5])/(elev[4] - elev[5])+4; // COMMENT THIS IF THERE IS TWo LAYER
                else if (z < elev[5] && z > ZMin-0.001)          // COMMENT THIS IF THERE IS TWo LAYER
                   Layer(i,j,k) = (z - ZMin)/(elev[5] - ZMin)+5; // COMMENT THIS IF THERE IS TWo LAYER
            }
        }
    }
}

void __fastcall MkLayerGrid::SetupResist()
{
    float Domain;
    float dist=0,bunja=0,bunmo=0;
    MkDataPoint cur_pnt, mun_pnt;

    XDif = XMax - XMin;
    YDif = YMax - YMin;

    Domain = XDif < YDif ?  XDif :  YDif;
    prog_bar->Position = 0;
    for (int i=0;i<NX;i++) {
        for (int j=0;j<NY;j++) {
            for (int k=0;k<NZ;k++) {
                prog_bar->Position = (i*NY*NZ  + j*NZ + k)*100/(NX*NY*NZ);
                Application->ProcessMessages();

                dist=bunja=bunmo=0;
                cur_pnt = (*this)(i,j,k);

                for (long l = 0 ; l < FResist.GetSize();l++) {
                    mun_pnt = FResist[l];
                    mun_pnt.X -= FXMin;
                    mun_pnt.Y -= FYMin;
                    mun_pnt.Z -= ZMin;

                    dist = CalDist(cur_pnt,mun_pnt);
                    if (dist < 0.0001) {
                       bunja += FResist[l].Data*10000;
                       bunmo += 10000;
                    }
                    else if (dist < Domain) {
                       bunja += FResist[l].Data/dist;
                       bunmo += 1/dist;
                    }
                }

                if (bunmo>0.0001) Resist(i,j,k) = (*this)(i,j,k).Data = RandG(bunja/bunmo,bunja*0.005/bunmo);//(*this)(i,j,k).Data = bunja/bunmo
                else {
                    (*this)(i,j,k).Data = 0;
                    bunmo = bunja = 0;
                    for (long l = 0 ; l < FResist.GetSize();l++) {
                        mun_pnt = FResist[l];

                        dist = CalDist(cur_pnt,mun_pnt);
                        if (dist < 0.0001) {
                           bunja += FResist[l].Data*10000;
                           bunmo += 10000;
                        }
                        else if (dist < Domain*5) {
                           bunja += FResist[l].Data/dist;
                           bunmo += 1/dist;
                        }
                    }
                    if (bunmo>0.0001) Resist(i,j,k) = (*this)(i,j,k).Data = RandG(bunja/bunmo,bunja*0.005/bunmo);//(*this)(i,j,k).Data = bunja/bunmo
                }
            }
        }
    }
}

void __fastcall MkLayerGrid::SetupKrigResist()
{
    float Domain;
    float a;
    MkDataPoint cur_pnt, mun_pnt,sft;

    XDif = XMax - XMin;
    YDif = YMax - YMin;

    sft.X = -FXMin;
    sft.Y = -FYMin;
    sft.Z = -ZMin;

    FResist.Translate(sft);
    FKrig.SetDataPoints(FResist);

    Domain = XDif < YDif ?  XDif :  YDif;
    prog_bar->Position = 0;
    for (int i=0;i<NX;i++) {
        for (int j=0;j<NY;j++) {
            for (int k=0;k<NZ;k++) {
                prog_bar->Position = (i*NY*NZ  + j*NZ + k)*100/(NX*NY*NZ);
                Application->ProcessMessages();

                cur_pnt = (*this)(i,j,k);
                a = FKrig(cur_pnt.X,cur_pnt.Y,cur_pnt.Z);

                Resist(i,j,k) = a;
            }
        }
    }
}

void __fastcall MkLayerGrid::SetupSide()
{
    MkPoint rp,sp,ep;
    MkLine rl;
    float x,y;
    float cross=1;
    float side=1;
    float min_dist;
    int   Nearest;
    float dist[3],d;

    for (int i=0;i<NX;i++) {
        Application->ProcessMessages();
        for (int j=0;j<NY;j++) {
            float x,y,z,elev[3];
            x = FTopoGrid.GetX(i);
            y = FTopoGrid.GetY(j);
            rp.X = x;
            rp.Y = y;
            rp.Z = 0;
            min_dist = 10000000000;
            for (int l=0;l<FRailWay.GetSize()-1;l++) {
                sp.X = FRailWay[l].X;
                sp.Y = FRailWay[l].Y;
                sp.Z = 0;
                dist[0] = CalDist(sp,rp);
                ep.X = FRailWay[l+1].X;
                ep.Y = FRailWay[l+1].Y;
                ep.Z = 0;
                dist[1] = CalDist(ep,rp);
                dist[2] = (dist[0] + dist[1])/2;
                if (min_dist > dist[2]) {
                   Nearest = l;
                   min_dist = dist[2];
                }
            }
            sp.X = FRailWay[Nearest].X;
            sp.Y = FRailWay[Nearest].Y;
            sp.Z = 0;
            ep.X = FRailWay[Nearest+1].X;
            ep.Y = FRailWay[Nearest+1].Y;
            ep.Z = 0;

            rl.SetLine(sp,ep);
            cross = rl * rp;

            d = rl.CalDist(rp);
            if (cross < 0) {
               side = -d;
            }
            else if (cross > 0) {
               side = d;
            }
            else if (fabs(cross) <0.1) {
               side = 0;
            }

            for (int k=0;k<NZ;k++) {
                Side(i,j,k) = side;
            }
        }
    }
}

void __fastcall MkLayerGrid::SetupInFault()
{
    MkPoint rp,sp,ep;
    MkLine rl;
    int NC; // Number of Cube
    float x,y;
    float cross=1;
    float side=1;
    float norm,normin;

    NC = FCubes.GetSize();

    for (int i=0;i<NX;i++) {
        Application->ProcessMessages();
        for (int j=0;j<NY;j++) {
            for (int k=0;k<NZ;k++) {

                rp.X = (*this)(i,j,k).X + FXMin;
                rp.Y = (*this)(i,j,k).Y + FYMin;
                rp.Z = (*this)(i,j,k).Z + ZMin;

                normin = 10000;

                for (int l=0;l<NC;l++) {
                    norm = FCubes[l].GetNorm(rp);
                    normin = norm < normin ? norm : normin;
                }

                InFault(i,j,k) = normin;
            }
        }
    }
}

void __fastcall MkLayerGrid::SetupCutBlock()
{
    MkPoint rp,sp,ep;
    MkLine rl;

    float x,y;
    float cross=1;
    float side=1;
    float norm,normin;


    for (int i=0;i<NX;i++) {
        for (int j=0;j<NY;j++) {
            for (int k=0;k<NZ;k++) {
                rp.X = (*this)(i,j,k).X + FXMin;
                rp.Y = (*this)(i,j,k).Y + FYMin;
                rp.Z = (*this)(i,j,k).Z + ZMin;
                normin = 10000;
                norm = FCutBlock.GetNorm(rp);
                normin = norm < normin ? norm : normin;

                CutBlock(i,j,k) = normin;
            }
        }
    }
}

void __fastcall MkLayerGrid::SetupTunnel()
{
    int I;float J;
    float msta;
    float Phi,theta;
    MkLine rl;

    MkPoint cp,dir;
    MkPoint fp,mp;
    MkDataPoint rp,sp,ep;
    float min_dist;
    int Nearest, WhichOne;
    float dist[3],d;
    float ZMax=-100000,ZMin=100000;

    for (int i=0;i<NX;i++)                      // delete from
        for (int j=0;j<NY;j++)
            ZMax = ZMax < FTopoGrid(i,j) ? FTopoGrid(i,j) : ZMax;  // to here for general case

    for (int i=0;i<NX;i++)                      // delete from
        for (int j=0;j<NY;j++)
            ZMin = ZMin > FTopoGrid(i,j) ? FTopoGrid(i,j) : ZMin;  // to here for general case

    for (int i=0;i<NX;i++) {
        Application->ProcessMessages();
        for (int j=0;j<NY;j++) {
            for (int k=0;k<NZ;k++) {
                rp = (*this)(i,j,k);
                rp.Translate(0,0,ZMin-FDepth);
                min_dist = 10000000;
                for (int l=0;l<FRailWay.GetSize()-1;l++) {
                    sp.X = FRailWay[l].X;
                    sp.Y = FRailWay[l].Y;
                    sp.Z = FRailWay[l].Z;
                    dist[0] = CalDist(sp,rp);
                    ep.X = FRailWay[l+1].X;
                    ep.Y = FRailWay[l+1].Y;
                    ep.Z = FRailWay[l+1].Z;
                    dist[1] = CalDist(ep,rp);
                    dist[2] = (dist[0]+dist[1])/2;
                    if (min_dist > dist[2]) {
                      Nearest = l;
                      WhichOne = 0;
                      min_dist = dist[2];
                    }
                }

                for (int l=0;l<FRailWay2.GetSize()-1;l++) {
                    sp.X = FRailWay2[l].X;
                    sp.Y = FRailWay2[l].Y;
                    sp.Z = FRailWay2[l].Z;
                    dist[0] = CalDist(sp,rp);
                    ep.X = FRailWay2[l+1].X;
                    ep.Y = FRailWay2[l+1].Y;
                    ep.Z = FRailWay2[l+1].Z;
                    dist[1] = CalDist(ep,rp);
                    dist[2] = (dist[0]+dist[1])/2;
                    if (min_dist > dist[2]) {
                      Nearest = l;
                      WhichOne = 1;
                      min_dist = dist[2];
                    }
                }

                sp = WhichOne == 0 ? FRailWay[Nearest]:FRailWay2[Nearest];
                ep = WhichOne == 0 ? FRailWay[Nearest+1]:FRailWay2[Nearest+1];
                mp = ep-sp;
                mp.Normalize();

                float atheta;
                atheta = asin(mp.X);
                atheta = fabs(sin(atheta)-mp.X) < 0.001 ? atheta*180/M_PI : (atheta+M_PI)*180/M_PI;

                mp.X = rp.X;
                mp.Y = rp.Y;
                mp.Z = rp.Z;

                rl.SetLine(sp,ep);
                rl.Translate(-sp.X,-sp.Y,-sp.Z);
                mp.Translate(-sp.X,-sp.Y,-sp.Z);

                rl.Rotate((90-atheta),0,0);
                mp.Rotate((90-atheta),0,0);

                min_dist = sqrt(mp.Y*mp.Y+mp.Z*mp.Z);

                int Sta;
                Sta = WhichOne == 0 ? FRailWay.Station(Nearest) : FRailWay2.Station(Nearest);
                I = int(Sta/1000);
                J = Sta - I*1000;

                dir = WhichOne == 0 ? FRailWay.FowardDir(I,J) : FRailWay2.FowardDir(I,J);
                dir.Z = 0;
                dir.Normalize();

                Phi = acos(dir.X);
                if (fabs(cos(Phi) - dir.X) < 0.001) Phi = Phi*180/M_PI;
                else Phi = (Phi+M_PI)*180/M_PI;

                if (WhichOne == 0) fp.Set(FRailWay[Nearest]);
                else if (WhichOne == 1) fp.Set(FRailWay2[Nearest]);

                cp.Set(rp);
                cp.Translate(-sp.X,-sp.Y,-sp.Z);

                cp.Rotate(Phi,0,0);

                float theta;
                if (fabs(cos(Phi*M_PI/180.0))>0.001) mp.SetPoint(cp.Y/cos(Phi*M_PI/180.0),cp.Z);
                else mp.SetPoint(rp.X,rp.Z);
                theta = mp.GetAng();
                if (theta<0) theta += 360;
                if (theta>360) theta -= 360;

                if (theta > 259 && theta <319) {
                   Tunnel(i,j,k) = fabs(cp.Z)/sin(49*M_PI/180)-4; // 4.669
                }
                else {
                   Tunnel(i,j,k) = min_dist - 4;
                }
            }
        }
    }
}

void __fastcall MkLayerGrid::SetupTunnelBK()
{
    int I;float J;
    float msta;
    float Phi,theta;
    MkPoint cp,dir;
    MkDataPoint rp;

    msta = (StartStation+EndStation)/2;
    I = int(msta/1000);
    J = msta - I*1000;

    cp =  FRailWay(I,J);
    cp.Z = cp.Z + 100;
    dir = FRailWay.FowardDir(I,J);
    dir.Normalize();
    cp.X = 0;
    cp.Y = 0;
    cp.Z = 17.5;

    Phi = acos(dir.X);
    if (fabs(cos(Phi) - dir.X) < 0.001) Phi = Phi*180/M_PI;
    else Phi = (Phi+M_PI)*180/M_PI;

    for (int i=0;i<NX;i++) {
        Application->ProcessMessages();
        for (int j=0;j<NY;j++) {
            for (int k=0;k<NZ;k++) {
                rp = (*this)(i,j,k);
                rp.Translate(-cp.X,-cp.Y,-cp.Z);
                //rp.Rotate(-Phi,0,0);  // �޼� ��ǥ��
                //rp.Translate(0,-2.900,-2.047);

                float dist;
                float depth;

                dist = sqrt(rp.Z*rp.Z + rp.Y*rp.Y);

                float theta;
                MkPoint cp(rp.Y,rp.Z);
                theta = cp.GetAng();
                if (theta > 210 && theta <330) {
                   Tunnel(i,j,k) = fabs(rp.Z)/sin(30*M_PI/180) - 5;
                }
                else {
                   Tunnel(i,j,k) = dist-5;
                }
            }
        }
    }
}

void __fastcall MkLayerGrid::InverseDistance()
{
    float Domain;

    Domain = XDif < YDif ?  (XDif < ZDif ? XDif : ZDif ) : ( YDif < ZDif ?  YDif : ZDif);
    prog_bar->Position = 0;
    for (int i=0;i<NX;i++) {
        for (int j=0;j<NY;j++) {
            for (int k=0;k<NZ;k++) {
                prog_bar->Position = (i*NY*NZ  + j*NZ + k)*100/(NX*NY*NZ);
                Application->ProcessMessages();
                float dist=0,bunja=0,bunmo=0;
                MkDataPoint cur_pnt, mun_pnt;
                cur_pnt = (*this)(i,j,k);
                bunmo = bunja = 0;
                for (int l = 0 ; l < FResist.GetSize();l++) {
                    mun_pnt = FResist[l];
//                    mun_pnt.X -= XMin;
//                    mun_pnt.Y -= YMin;
//                    mun_pnt.Z -= ZMin;

                    dist = CalDist(cur_pnt,mun_pnt);
                    if (dist < 0.0001) {
                       bunja += FResist[l].Data*10000;
                       bunmo += 10000;
                    }
                    else if (dist < Domain) {
                       bunja += FResist[l].Data/dist;
                       bunmo += 1/dist;
                    }
                }

                if (bunmo>0.0001) (*this)(i,j,k).Data = RandG(bunja/bunmo,bunja*0.005/bunmo);//(*this)(i,j,k).Data = bunja/bunmo
                else {
                    (*this)(i,j,k).Data = 0;
                    bunmo = bunja = 0;
                    for (int l = 0 ; l < FResist.GetSize();l++) {
                        mun_pnt = FResist[l];
//                        mun_pnt.X -= XMin;
//                        mun_pnt.Y -= YMin;
//                        mun_pnt.Z -= ZMin;

                        dist = CalDist(cur_pnt,mun_pnt);
                        if (dist < 0.0001) {
                           bunja += FResist[l].Data*10000;
                           bunmo += 10000;
                        }
                        else if (dist < Domain*5) {
                           bunja += FResist[l].Data/dist;
                           bunmo += 1/dist;
                        }
                    }
                    if (bunmo>0.0001) (*this)(i,j,k).Data = RandG(bunja/bunmo,bunja*0.005/bunmo);//(*this)(i,j,k).Data = bunja/bunmo
                }
            }
        }
    }

    float DMax=-10000000,DMin=10000000;
    for (int l = 0 ; l < FResist.GetSize();l++) {
        if (FResist[l].Data > DMax) DMax = FResist[l].Data;
        if (FResist[l].Data < DMin) DMin = FResist[l].Data;
    }

    float datamax=-1000000,datamin=1000000;

    for (int i=0;i<NX;i++) {
        for (int j=0;j<NY;j++) {
            for (int k=0;k<NZ;k++) {
                if ((*this)(i,j,k).Data > datamax) datamax =(*this)(i,j,k).Data;
                if ((*this)(i,j,k).Data < datamin) datamin =(*this)(i,j,k).Data;
            }
        }
    }

    for (int i=0;i<NX;i++) {
        for (int j=0;j<NY;j++) {
            for (int k=0;k<NZ;k++) {
               float data;
               data = (*this)(i,j,k).Data;
               (*this)(i,j,k).Data = DMin + (DMax-DMin)*(data-datamin)/(datamax-datamin);
            }
        }
    }

}

void __fastcall MkLayerGrid::Krig3D()
{

}


void MkLayerGrid::SetMemo(TObject *Sender)
{
    memo = dynamic_cast<TMemo *>(Sender);
    if (!memo) memo->Lines->Add("Memo is assigned to MkLayerGrid!");
}

void MkLayerGrid::SetProgBar(TObject *Sender)
{
    prog_bar = dynamic_cast<TProgressBar *>(Sender);
    if (!memo) memo->Lines->Add("ProgressBar is assigned to MkLayerGrid!");
}

void __fastcall MkLayerGrid::SetFaults(TFaults &faults)
{
    FFaults = faults;
    int I;float J;
    float station;
    MkPoint center;
    float psi,theta;
    float xl,yl,zl;

    FCubes.Initialize(FFaults.GetSize());
    for (int i=0;i<FFaults.GetSize();i++) {
        center = FFaults[i].GetCenter();
        psi = 90 - FFaults[i].GetDip();
        theta =  90 - FFaults[i].GetDipDir();
        xl = FFaults[i].GetThickness();  // �β�
        yl = FFaults[i].GetLength();     // ��
        zl = 5000;
        FCubes[i].SetCenter(center);
        FCubes[i].SetRotation(psi,theta); // psi first
        FCubes[i].SetLength(xl,yl,zl);
    }
}

void __fastcall MkLayerGrid::SetCutBlock(MkCube cube)
{
    FCutBlock = cube;
}

void __fastcall MkLayerGrid::SetPointsPlanes(TPointsPlanes &pp)
{
    FPointsPlanes = pp;
}

void __fastcall MkLayerGrid::SetResistivity(MkDataPoints &resist)
{
   FResist = resist;
}

bool __fastcall MkLayerGrid::SaveFieldFile(char *file_name)
{
    SetFieldFileName(file_name);
    SaveFieldFile();
}

bool __fastcall MkLayerGrid::SaveFieldFile()
{
    FILE *fp;
    char str[256];

    fp = fopen(FieldFileName,"w");
    fprintf(fp,"# AVS field file %s\n",FieldFileName);
    fprintf(fp,"ndim = %d\n",3);
    fprintf(fp,"dim1 = %d\n",NX);
    fprintf(fp,"dim2 = %d\n",NY);
    fprintf(fp,"dim3 = %d\n",NZ);
    fprintf(fp,"nspace = %d\n",3);
    fprintf(fp,"veclen = %d\n",5);
    fprintf(fp,"data = float\n");
    fprintf(fp,"field = irregular\n");
    fprintf(fp,"label = Layer Side Fault CutBlock Tunnel\n");

    fprintf(fp,"variable 1 filetype=ascii skip= 0 offset=0 stride=8\n");
    fprintf(fp,"variable 2 filetype=ascii skip= 0 offset=1 stride=8\n");
    fprintf(fp,"variable 3 filetype=ascii skip= 0 offset=2 stride=8\n");
    fprintf(fp,"variable 4 filetype=ascii skip= 0 offset=3 stride=8\n");
    fprintf(fp,"variable 5 filetype=ascii skip= 0 offset=4 stride=8\n");
    fprintf(fp,"coord    1 filetype=ascii skip= 0 offset=5 stride=8\n");
    fprintf(fp,"coord    2 filetype=ascii skip= 0 offset=6 stride=8\n");
    fprintf(fp,"coord    3 filetype=ascii skip= 0 offset=7 stride=8\n");

    strcpy(str,"\f\f\n");
    fprintf(fp,"%s",str);

    for (int k=0;k<NZ;k++)
        for (int j=0;j<NY;j++)
            for (int i=0;i<NX;i++) {
                sprintf(str,"%f %f %f %f %f %f %f %f",
                Layer(i,j,k),Side(i,j,k),InFault(i,j,k),CutBlock(i,j,k),Tunnel(i,j,k),
                (*this)(i,j,k).X, (*this)(i,j,k).Y,(*this)(i,j,k).Z);
                fprintf(fp,"%s\n",str);
            }

    fclose(fp);
    return true;
}

bool __fastcall MkLayerGrid::SaveSimpleFieldFile(char *file_name)
{
    SetFieldFileName(file_name);
    SaveSimpleFieldFile();
}

bool __fastcall MkLayerGrid::SaveSimpleFieldFile()
{
    FILE *fp;
    char str[256];

    fp = fopen(FieldFileName,"w");
    fprintf(fp,"# AVS field file %s\n",FieldFileName);
    fprintf(fp,"ndim = %d\n",3);
    fprintf(fp,"dim1 = %d\n",NX);
    fprintf(fp,"dim2 = %d\n",NY);
    fprintf(fp,"dim3 = %d\n",NZ);
    fprintf(fp,"nspace = %d\n",3);
    fprintf(fp,"veclen = %d\n",2);
    fprintf(fp,"data = float\n");
    fprintf(fp,"field = irregular\n");
    fprintf(fp,"label = Layer CutBlock\n");

    fprintf(fp,"variable 1 filetype=ascii skip= 0 offset=0 stride=5\n");
    fprintf(fp,"variable 2 filetype=ascii skip= 0 offset=1 stride=5\n");
    fprintf(fp,"coord    1 filetype=ascii skip= 0 offset=2 stride=5\n");
    fprintf(fp,"coord    2 filetype=ascii skip= 0 offset=3 stride=5\n");
    fprintf(fp,"coord    3 filetype=ascii skip= 0 offset=4 stride=5\n");

    strcpy(str,"\f\f\n");
    fprintf(fp,"%s",str);

    for (int k=0;k<NZ;k++)
        for (int j=0;j<NY;j++)
            for (int i=0;i<NX;i++) {
                sprintf(str,"%f %f %f %f %f",
                Layer(i,j,k),CutBlock(i,j,k),
                (*this)(i,j,k).X, (*this)(i,j,k).Y,(*this)(i,j,k).Z);
                fprintf(fp,"%s\n",str);
            }

    fclose(fp);
    return true;
}

bool __fastcall MkLayerGrid::SaveResistFieldFile()
{
    FILE *fp;
    char str[256];

    fp = fopen(FieldFileName,"w");
    fprintf(fp,"# AVS field file %s\n",FieldFileName);
    fprintf(fp,"ndim = %d\n",3);
    fprintf(fp,"dim1 = %d\n",NX);
    fprintf(fp,"dim2 = %d\n",NY);
    fprintf(fp,"dim3 = %d\n",NZ);
    fprintf(fp,"nspace = %d\n",3);
    fprintf(fp,"veclen = %d\n",3);
    fprintf(fp,"data = float\n");
    fprintf(fp,"field = irregular\n");
    fprintf(fp,"label = Resistivity Side CutBlock\n");

    fprintf(fp,"variable 1 filetype=ascii skip= 0 offset=0 stride=6\n");
    fprintf(fp,"variable 2 filetype=ascii skip= 0 offset=1 stride=6\n");
    fprintf(fp,"variable 3 filetype=ascii skip= 0 offset=2 stride=6\n");
    fprintf(fp,"coord    1 filetype=ascii skip= 0 offset=3 stride=6\n");
    fprintf(fp,"coord    2 filetype=ascii skip= 0 offset=4 stride=6\n");
    fprintf(fp,"coord    3 filetype=ascii skip= 0 offset=5 stride=6\n");

    strcpy(str,"\f\f\n");
    fprintf(fp,"%s",str);

    for (int k=0;k<NZ;k++)
        for (int j=0;j<NY;j++)
            for (int i=0;i<NX;i++) {
                sprintf(str,"%f %f %f %f %f %f",
                Resist(i,j,k),Side(i,j,k),CutBlock(i,j,k),
                (*this)(i,j,k).X, (*this)(i,j,k).Y,(*this)(i,j,k).Z);
                fprintf(fp,"%s\n",str);
            }

    fclose(fp);
    return true;
}

void __fastcall MkLayerGrid::ScaleAxis(float xs, float ys, float zs)
{
    for (int k=0;k<NZ;k++)
        for (int j=0;j<NY;j++)
            for (int i=0;i<NX;i++) {
                (*this)(i,j,k).X*=xs;
                (*this)(i,j,k).Y*=ys;
                (*this)(i,j,k).Z*=zs;
            }
}

MkDataPoint & __fastcall MkLayerGrid::operator()(int i,int j,int k)
{
    if (i<0 || NX<=i) {
       ShowMessage("MkLayerGrid index out of range\n");
       return NullDataPoint;
    }
    if (j<0 || NY<=j) {
       ShowMessage("MkLayerGrid index out of range\n");
       return NullDataPoint;
    }
    if (k<0 || NZ<=k) {
       ShowMessage("MkLayerGrid index out of range\n");
       return NullDataPoint;
    }

    return FGrid[i+j*NX+k*NX*NY];
}
//---------------------------------------------------------------------------
#pragma package(smart_init)
