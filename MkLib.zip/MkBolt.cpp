//---------------------------------------------------------------------------
#include "MkBolt.h"
#ifdef __BCPLUSPLUS__
#include <vcl.h>
#endif
#pragma hdrstop
//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#pragma package(smart_init)
#endif

MkBolt NullBolt(0);
MkBolt::MkBolt()
{
  Clear();
}

MkBolt::MkBolt(int n)
{
  Clear();
}

#ifdef __BCPLUSPLUS__
bool MkBolt::UpdateFrom()
{
  if(!Grid) return false;

  Number=Grid->Cells[1][0].ToInt();
  Depth =Grid->Cells[1][1].ToDouble();
  Area  =Grid->Cells[1][2].ToDouble();
  Angle =Grid->Cells[1][3].ToDouble();
  Length=Grid->Cells[1][4].ToDouble();

  return true;
}

bool MkBolt::UpdateTo()
{
  if(!Grid) return false;

  for(int i=0;i<20;i++) {Grid->Cells[0][i] = "";Grid->Cells[1][i]="";}

  Grid->Cells[0][0] = "Number";
  Grid->Cells[0][1] = "Depth";
  Grid->Cells[0][2] = "Area";
  Grid->Cells[0][3] = "Angle";
  Grid->Cells[0][4] = "Length";
  Grid->Cells[1][0] = Number;
  Grid->Cells[1][1] = Depth;
  Grid->Cells[1][2] = Area;
  Grid->Cells[1][3] = Angle;
  Grid->Cells[1][4] = Length;

  return true;
}

void MkBolt::Draw(TObject *Sender)
{
  BoltLine.Draw(Sender);
}

void MkBolt::Out(TObject *Sender)
{

}
#else
#endif

void MkBolt::Out(char *fname)
{
  FILE *fp;
  fp = fopen(fname,"a");
  if(!fp) {
    MkDebug(fname); MkDebug(" is not found, so fp is null and return false\n");
    return;
  }
            //12345678901234567890123456789012345678901234567890123456789012345678901234567890
//fprintf(fp,"  Bolt Depth    Length   Area  Spacing\n");
//fprintf(fp,"   No.   (m)     (m)     (m2)    (m)\n");
  fprintf(fp,"  %3d   %5.2f   %5.2f  %5.2f   %5.2f\n",Number,Depth,Length,Area,Spacing);
  fprintf(fp,"                      (%5.2f)\n",Area/(Spacing>EPS?Spacing:1));
  fprintf(fp,"\n");
  fclose(fp);
}

void MkBolt::Clear()
{
  Side = mkLeft;
  Tan = 0;
  SupportTan = 0;
#ifdef __BCPLUSPLUS__
  Spec = "";
#else
  memset(Spec,'\0',255);
#endif

  MkEntity::Clear();
  Area=0;
  Angle=0;
  Spacing=0;
  YoungMod=0;

  BoltLine.Clear();
}

#ifdef __BCPLUSPLUS__
void MkBolt::Import(MkGlobalVar &globalvar, int sec, MkSide side, int tan)
{
  Tan=((side==mkLeft)?globalvar.support_tan_L[sec+1][tan+1]:globalvar.support_tan_R[sec+1][tan+1]);
  Depth=((side==mkLeft)?globalvar.support_depth_L[sec+1][tan+1]:globalvar.support_depth_R[sec+1][tan+1]);
  Length=((side==mkLeft)?globalvar.support_var_L[sec+1][tan+1]:globalvar.support_var_R[sec+1][tan+1]);
}

void MkBolt::Export(MkGlobalVar &globalvar, int sec, MkSide side, int tan)
{
  ((side==mkLeft)?globalvar.support_tan_L[sec+1][tan+1]:globalvar.support_tan_R[sec+1][tan+1])=Tan;
  ((side==mkLeft)?globalvar.support_type_L[sec+1][tan+1]:globalvar.support_type_R[sec+1][tan+1])="�Ϻ�Ʈ";
  ((side==mkLeft)?globalvar.support_depth_L[sec+1][tan+1]:globalvar.support_depth_R[sec+1][tan+1])=Depth;
  ((side==mkLeft)?globalvar.support_var_L[sec+1][tan+1]:globalvar.support_var_R[sec+1][tan+1])=Length;
}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void MkBolt::Draw(MkPaint *pb)
{

}
#endif

bool MkBolt::operator==(MkBolt &bolt)
{
  bool flag = true;
  flag == flag && MkEntity::operator==((MkEntity&)bolt);
  flag == flag && Number==bolt.Number;
  flag == flag && Depth==bolt.Depth;
  flag == flag && Area==bolt.Area;
  flag == flag && Angle==bolt.Angle;
  flag == flag && Spacing==bolt.Spacing;  
  flag == flag && Length==bolt.Length;
  flag == flag && YoungMod==bolt.YoungMod;
  flag == flag && Side==bolt.Side;

  return flag;
}
bool MkBolt::operator!=(MkBolt &bolt)
{
  return !operator==(bolt);
}

MkBolt & MkBolt::operator=(MkBolt &bolt)
{
  MkEntity::operator=((MkEntity&)bolt);
  BoltLine=bolt.BoltLine;
  Number=bolt.Number;
  Depth=bolt.Depth;
  Area=bolt.Area;
  Angle=bolt.Angle;
  Spacing=bolt.Spacing;
  Length=bolt.Length;
  YoungMod=bolt.YoungMod;
  Side=bolt.Side;

  return *this;
}
//---------------------------------------------------------------------------
MkBolts::MkBolts(int size,MkBolt *bolts)
{

    if (size < 0) {
      MkDebug("::MkBolts - MkBolts(int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSize == 0) {
       FBolt = NULL;
       return;
    }

    FBolt = new MkBolt[FSize];
    for (int i=0;i<FSize;i++) (*this)[i] = bolts[i];
}

MkBolts::MkBolts(int size)
{
    if (size < 0) {
      MkDebug("::MkBolts - MkBolts(int size)");;
      return;
    }

    FSizeOfArray = size;
    FSize = 0;
    if (FSizeOfArray == 0) {
       FBolt = NULL;
       return;
    }

    FBolt = new MkBolt[FSizeOfArray];
}

MkBolts::~MkBolts()
{
   FSizeOfArray = FSize = 0;
   if (FBolt) {
      delete[] FBolt;
      FBolt = NULL;
   }
}

void MkBolts::Initialize(int size)
{
    int i;
    if (size < 0) {
      MkDebug("::MkBolts - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;

    FSizeOfArray = FSize = size;

    if (FSizeOfArray == 0) {
       if (FBolt!=NULL) delete[] (MkBolt*)FBolt;
       FBolt = NULL;
       return;
    }

    if (FBolt!=NULL) delete[] (MkBolt*)FBolt;
    FBolt = new MkBolt[FSizeOfArray];
    for (i=0;i<FSize;i++) FBolt[i].Number = i;
}

void MkBolts::Initialize(int size,MkBolt *bolts)
{
    int i;
    if (size < 0 || bolts == NULL) {
      MkDebug("::MkBolts - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSize = FSizeOfArray = size;
    if (FSizeOfArray == 0) {
       if (FBolt!=NULL) delete[] (MkBolt*)FBolt;
       FBolt = NULL;
       return;
    }

    if (FBolt!=NULL) delete[] (MkBolt*)FBolt;
    FBolt = new MkBolt[FSizeOfArray];
    for (i=0;i<FSizeOfArray;i++) FBolt[i] = bolts[i];
    for (i=0;i<FSize;i++) FBolt[i].Number = i;
}

int MkBolts::Grow(int delta)
{
    int i;
    MkBolt *bolt=NULL;

    if (!(bolt = new MkBolt[FSizeOfArray+delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        bolt[i] = FBolt[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        bolt[i] = NullBolt;
    if (FBolt) {
       delete[] (MkBolt*)FBolt;
       FBolt = NULL;
    }
    FBolt = bolt;
    FSizeOfArray = FSizeOfArray+delta;
    return FSizeOfArray;
}

int MkBolts::Shrink(int delta)
{
    int i;
    MkBolt *bolt=NULL;

    if (!(bolt = new MkBolt[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        bolt[i] = FBolt[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        bolt[i] = NullBolt;
    if (FBolt) {
       delete[] (MkBolt*)FBolt;
       FBolt = NULL;
    }
    FBolt = bolt;
    FSizeOfArray = FSizeOfArray-delta;
    return FSizeOfArray;
}

bool MkBolts::Add(MkBolt &bolt)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    FSize++;
    FBolt[FSize-1] = bolt;
    return true;
}

bool MkBolts::Add(int index, MkBolt &bolt)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    for (int i=FSize-1;i>=index;i--)
      FBolt[i+1] = FBolt[i];
    FSize++;
    FBolt[index] = bolt;
    return true;
}

bool MkBolts::Delete(MkBolt &bolt)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FBolt[i] == bolt) break;
    }
    if(i==FSize) return false;
    if(FBolt[i] == bolt) {
      for (int j=i;j<FSize-1;j++)
        FBolt[j] = FBolt[j+1];
    }
    FSize--;
    FBolt[FSize] = NullBolt;
    return true;
}

bool MkBolts::Delete(int index)
{
    for (int j=index;j<FSize-1;j++)
        FBolt[j] = FBolt[j+1];

    FSize--;
    FBolt[FSize] = NullBolt;
    return true;
}

bool MkBolts::Clear()
{
   FSizeOfArray = FSize = 0;
   if (FBolt) {
      delete[] FBolt;
      FBolt = NULL;
   }
   return true;
}

MkBolt & MkBolts::operator[](int i)
{
    if (0<=i && i<FSize) return FBolt[i];
    else if(FSize<=i && i<FSizeOfArray) {
      FSize=i+1;
      return FBolt[i];
    }
    else if (FSizeOfArray <= i) {
      Grow(i-FSizeOfArray+5);
      return NullBolt;
    }
    else return NullBolt;
}

MkBolts & MkBolts::operator=(MkBolts &bolts)
{
    int i;

    Clear();
    FSize = bolts.FSize;
    FSizeOfArray = bolts.FSizeOfArray;
    if (FSizeOfArray == 0) {
       FBolt = NULL;
       return *this;
    }
    this->FBolt = new MkBolt[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FBolt[i] = bolts.FBolt[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FBolt[i] = NullBolt;

    return *this;
}

bool MkBolts::operator==(MkBolts &bolts)
{
    int i;

    if (FSize != bolts.FSize) return false;
    for (i=0;i<FSize;i++)
      if (this->FBolt[i] != bolts.FBolt[i]) return false;

    return true;
}

#ifdef __BCPLUSPLUS__
void MkBolts::Out(TObject *Sender)
{

}
#endif

void MkBolts::Out(char *fname)
{
  FILE *fp;
  fp = fopen(fname,"a");
  if(!fp) {
    return;
  }

  if(FSize==0) return;
    
            //12345678901234567890123456789012345678901234567890123456789012345678901234567890
  fprintf(fp,"\n");
  fprintf(fp,"                           <Information of Rockbolts>\n");
  fprintf(fp,"\n");
  fprintf(fp,"  Bolt  Depth   Length  Area  Spacing\n");
  fprintf(fp,"   No.   (m)      (m)   (m2)    (m)\n");
  fclose(fp);

  for(int i=0;i<FSize;i++) 
    FBolt[i].Out(fname);
}

#ifdef __BCPLUSPLUS__
void MkBolts::Import(MkGlobalVar &globalvar, int sec)
{
  int i;
  for(i=0;i<FSize;i++)
    FBolt[i].Import(globalvar,sec,mkLeft, i);
}

void MkBolts::Export(MkGlobalVar &globalvar, int sec)
{
  int i;
  for(i=0;i<FSize;i++)
    FBolt[i].Export(globalvar,sec, mkLeft, i);
}
#endif

#ifdef __BCPLUSPLUS__
void MkBolts::Draw(TObject *Sender)
{
    TColor C;
    float Offset;
    if (FSize == 0) return;
    if (String(Sender->ClassName()) == String("MkPaintBox")) {
       MkPaintBox *pb=(MkPaintBox*)Sender;
       C = pb->Canvas->Pen->Color;
       pb->Canvas->Pen->Color = Color;
       for (int i = 0; i < FSize;i++) {
           Offset = pb->Offset(3);
           FBolt[i].Draw(pb);
       }
       pb->Canvas->Pen->Color = C;
    }
}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void MkBolts::Draw(MkPaint *pb)
{

}
#endif
//---------------------------------------------------------------------------

