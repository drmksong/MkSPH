//---------------------------------------------------------------------------
#include "MkRetainPanel.h"
#ifdef __BCPLUSPLUS__
#include <vcl.h>
#endif
#pragma hdrstop
//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#pragma package(smart_init)
#endif
//---------------------------------------------------------------------------
MkRetainPanel NullRetainPanel(0);
MkRetainPanel::MkRetainPanel()
{
  Number=0;
  Height=0;
  Width=0;
  Thick=0;
  Press=0;
  BendCompStressAllow=0;
  Moment=0;
}

MkRetainPanel::MkRetainPanel(int n)
{
  Number=0;
  Height=0;
  Width=0;
  Thick=0;
  Press=0;
  BendCompStressAllow=0;
  Moment=0;
}

#ifdef __BCPLUSPLUS__
bool MkRetainPanel::UpdateFrom()
{
  if(!Grid) return false;

  Number=Grid->Cells[1][0].ToInt();
  Thick=Grid->Cells[1][1].ToDouble();
  Press=Grid->Cells[1][2].ToDouble();
  Width =Grid->Cells[1][3].ToDouble();
  BendCompStressAllow=Grid->Cells[1][4].ToDouble();
  Moment=Grid->Cells[1][4].ToDouble();
  return true;
}

bool MkRetainPanel::UpdateTo()
{

  if(!Grid) return false;

  for(int i=0;i<20;i++) {Grid->Cells[0][i] = "";Grid->Cells[1][i]="";}

  Grid->Cells[0][0] = "Number";
  Grid->Cells[0][1] = "Thick";
  Grid->Cells[0][2] = "Press";
  Grid->Cells[0][3] = "Width";
  Grid->Cells[0][4] = "BendCompStressAllow";
  Grid->Cells[0][5] = "Moment";

  Grid->Cells[1][0] = Number;
  Grid->Cells[1][1] = Thick;
  Grid->Cells[1][2] = Press;
  Grid->Cells[1][3] = Width;
  Grid->Cells[1][4] = BendCompStressAllow;
  Grid->Cells[1][5] = Moment;

  return true;
}

void MkRetainPanel::Draw(TObject *Sender)
{

}
#endif

bool MkRetainPanel::operator==(MkRetainPanel &pan)
{
  bool flag = true;
  flag == flag && MkEntity::operator==((MkEntity&)pan);
  flag == flag && Number==pan.Number;
  flag == flag && Thick==pan.Thick;
  flag == flag && Press==pan.Press;
  flag == flag && Width==pan.Width;
  flag == flag && BendCompStressAllow==pan.BendCompStressAllow;
  flag == flag && Moment==pan.Moment;

  return flag;
}
bool MkRetainPanel::operator!=(MkRetainPanel &pan)
{
  return !operator==(pan);
}

MkRetainPanel & MkRetainPanel::operator=(MkRetainPanel &pan)
{
  MkEntity::operator=((MkEntity&)pan);
  Number=pan.Number;
  Thick=pan.Thick;
  Press=pan.Press;
  Width=pan.Width;
  BendCompStressAllow=pan.BendCompStressAllow;
  Moment=pan.Moment;
  return *this;
}

#if defined(_MSC_VER) && defined(_WINDOWS_)
void MkRetainPanel::Draw(MkPaint *Sender)
{
}
#endif

MkRetainPanels::MkRetainPanels(int size,MkRetainPanel *pans)
{

    if (size < 0) {
      MkDebug("::MkRetainPanels - MkRetainPanels(int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSize == 0) {
       FRetainPanel = NULL;
       return;
    }

    FRetainPanel = new MkRetainPanel[FSize];
    for (int i=0;i<FSize;i++) (*this)[i] = pans[i];
}

MkRetainPanels::MkRetainPanels(int size)
{
    if (size < 0) {
      MkDebug("::MkRetainPanels - MkRetainPanels(int size)");;
      return;
    }

    FSizeOfArray = size;
    FSize = 0;
    if (FSizeOfArray == 0) {
       FRetainPanel = NULL;
       return;
    }

    FRetainPanel = new MkRetainPanel[FSizeOfArray];
}

MkRetainPanels::~MkRetainPanels()
{
   FSizeOfArray = FSize = 0;
   if (FRetainPanel) {
      delete[] FRetainPanel;
      FRetainPanel = NULL;
   }
}

void MkRetainPanels::Initialize(int size)
{
    int i;
    if (size < 0) {
      MkDebug("::MkRetainPanels - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;

    FSizeOfArray = FSize = size;

    if (FSizeOfArray == 0) {
       if (FRetainPanel!=NULL) delete[] (MkRetainPanel*)FRetainPanel;
       FRetainPanel = NULL;
       return;
    }

    if (FRetainPanel!=NULL) delete[] (MkRetainPanel*)FRetainPanel;
    FRetainPanel = new MkRetainPanel[FSizeOfArray];
    for (i=0;i<FSize;i++) FRetainPanel[i].Number = i;    
}

void MkRetainPanels::Initialize(int size,MkRetainPanel *pans)
{
    int i;
    if (size < 0 || pans == NULL) {
      MkDebug("::MkRetainPanels - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSize = FSizeOfArray = size;
    if (FSizeOfArray == 0) {
       if (FRetainPanel!=NULL) delete[] (MkRetainPanel*)FRetainPanel;
       FRetainPanel = NULL;
       return;
    }

    if (FRetainPanel!=NULL) delete[] (MkRetainPanel*)FRetainPanel;
    FRetainPanel = new MkRetainPanel[FSizeOfArray];
    for (i=0;i<FSizeOfArray;i++) FRetainPanel[i] = pans[i];
    for (i=0;i<FSize;i++) FRetainPanel[i].Number = i;
}

int MkRetainPanels::Grow(int delta)
{
    int i;
    MkRetainPanel *pan=NULL;

    if (!(pan = new MkRetainPanel[FSizeOfArray+delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        pan[i] = FRetainPanel[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        pan[i] = NullRetainPanel;
    if (FRetainPanel) {
       delete[] (MkRetainPanel*)FRetainPanel;
       FRetainPanel = NULL;
    }
    FRetainPanel = pan;
    FSizeOfArray = FSizeOfArray+delta;
    return FSizeOfArray;
}

int MkRetainPanels::Shrink(int delta)
{
    int i;
    MkRetainPanel *pan=NULL;

    if (!(pan = new MkRetainPanel[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        pan[i] = FRetainPanel[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        pan[i] = NullRetainPanel;
    if (FRetainPanel) {
       delete[] (MkRetainPanel*)FRetainPanel;
       FRetainPanel = NULL;
    }
    FRetainPanel = pan;
    FSizeOfArray = FSizeOfArray-delta;
    return FSizeOfArray;
}

bool MkRetainPanels::Add(MkRetainPanel &pan)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    FSize++;
    FRetainPanel[FSize-1] = pan;
    return true;
}

bool MkRetainPanels::Add(int index, MkRetainPanel &pan)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    for (int i=FSize-1;i>=index;i--)
      FRetainPanel[i+1] = FRetainPanel[i];
    FSize++;
    FRetainPanel[index] = pan;
    return true;
}

bool MkRetainPanels::Delete(MkRetainPanel &pan)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FRetainPanel[i] == pan) break;
    }
    if(i==FSize) return false;
    if(FRetainPanel[i] == pan) {
      for (int j=i;j<FSize-1;j++)
        FRetainPanel[j] = FRetainPanel[j+1];
    }
    FSize--;
    FRetainPanel[FSize] = NullRetainPanel;
    return true;
}

bool MkRetainPanels::Delete(int index)
{
    for (int j=index;j<FSize-1;j++)
        FRetainPanel[j] = FRetainPanel[j+1];

    FSize--;
    FRetainPanel[FSize] = NullRetainPanel;
    return true;
}

bool MkRetainPanels::Clear()
{
   FSizeOfArray = FSize = 0;
   if (FRetainPanel) {
      delete[] FRetainPanel;
      FRetainPanel = NULL;
   }
   return true;
}

MkRetainPanel & MkRetainPanels::operator[](int i)
{
    if (0<=i && i<FSize) return FRetainPanel[i];
    else if(FSize<=i && i<FSizeOfArray) {
      FSize=i+1;
      return FRetainPanel[i];
    }
    else if (FSizeOfArray <= i) {
      Grow(i-FSizeOfArray+5);
      return NullRetainPanel;
    }
    else return NullRetainPanel;
}

MkRetainPanels & MkRetainPanels::operator=(MkRetainPanels &pans)
{
    int i;

    Clear();
    FSize = pans.FSize;
    FSizeOfArray = pans.FSizeOfArray;
    if (FSizeOfArray == 0) {
       FRetainPanel = NULL;
       return *this;
    }
    this->FRetainPanel = new MkRetainPanel[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FRetainPanel[i] = pans.FRetainPanel[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FRetainPanel[i] = NullRetainPanel;

    return *this;
}

bool MkRetainPanels::operator==(MkRetainPanels &pans)
{
    int i;

    if (FSize != pans.FSize) return false;
    for (i=0;i<FSize;i++)
      if (this->FRetainPanel[i] != pans.FRetainPanel[i]) return false;

    return true;
}

#ifdef __BCPLUSPLUS__
void MkRetainPanels::Draw(TObject *Sender)
{
    TColor C;
    float Offset;
    if (FSize == 0) return;
    if (String(Sender->ClassName()) == String("MkPaintBox")) {
       MkPaintBox *pb=(MkPaintBox*)Sender;
       C = pb->Canvas->Pen->Color;
       pb->Canvas->Pen->Color = Color;
       for (int i = 0; i < FSize;i++) {
           Offset = pb->Offset(3);
           FRetainPanel[i].Draw(pb);
       }
       pb->Canvas->Pen->Color = C;
    }
}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void MkRetainPanels::Draw(MkPaint *Sender)
{
}
#endif
//---------------------------------------------------------------------------
