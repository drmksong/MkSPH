//---------------------------------------------------------------------------
#ifndef MkSteerH
#define MkSteerH
#include "MkMesh.h"
#include "MkInt.h"
//--------------------------------------------------------------------
class MkSteer {
protected:
  MkInt Steer;
public:
  MkSteer(){}
  MkSteer(MkNodes &nodes){SetupSteer(nodes);}
  ~MkSteer(){}
  void Clear(){Steer.Clear();}
  void SetupSteer(MkNodes &nodes);
  void SetupSteerPost(MkNodes &nodes);
  int & Node(int i){return Steer(i,0);}
  int & NDof(int i){return Steer(i,1);}
  int GetSize(){return Steer.getSzX();}
#ifdef __BCPLUSPLUS__
  void Out(TMemo *);
#else
  void Out(char *);
#endif
};
//---------------------------------------------------------------------------
#endif
