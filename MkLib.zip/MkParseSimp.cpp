//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#include <vcl.h>
#pragma hdrstop
#endif
#include "MkParseSimp.h"
//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#pragma package(smart_init)
#endif
MkSimpParser::MkSimpParser()
{
  SectionRef = NULL;
  CurStep = 0;
}

MkSimpParser::~MkSimpParser()
{
  SectionRef = NULL;
}

bool MkSimpParser::Parse()
{
  int limit=1000;
  MkKeyKind key;
  MkSimpKeyWord keyword;
  char str[512];
  char *res;

  if (!Open()) return false;
  while (!Eof() && (key!=kkEnd) && (limit>0) && str && res) {
    res = fgets(str,511,FP);
    if(keyword.IsKeyWord(str)) {
      key = keyword.GetKeyKind(str);
    }
    if(!ParseLine(str,key)) break;
    limit--;
  }
  Close();

  if (limit>999) return false;
  return true;
}

bool MkSimpParser::ParseLine(char *str, MkKeyKind key)
{
  char buf[256], *s, *p;
  MkSimpKeyWord keyword;

  if(strlen(str)<1) return false;
  s = buf;
  TrimLeft(s,str);

  if(keyword.IsKeyWord(s)) p = strchr(s,' ');
  else p = s;

  if((p-s)>255) return false;

  switch(key) {
    case kkProject: return ParsePrj(p); 
    case kkLayer: return ParseLay(p); 
    case kkProfile: return ParsePrf(p); 
    case kkWall: return ParseWall(p); 
    case kkAnchor: return ParseAnchor(p); 
    case kkDivision: return ParseDiv(p); 
    case kkStep: return ParseStep(p);
    case kkEnd: return true;
  }
}

bool MkSimpParser::ParsePrj(char *str)
{

}

bool MkSimpParser::ParseLay(char *str)
{
  
}

bool MkSimpParser::ParsePrf(char *str)
{

}

bool MkSimpParser::ParseWall(char *str)
{

}

bool MkSimpParser::ParseStrut(char *str)
{

}
bool MkSimpParser::ParseAnchor(char *str)
{

}

bool MkSimpParser::ParseRockbolt(char *str)
{

}

bool MkSimpParser::ParseSlab(char *str)
{

}

bool MkSimpParser::ParseSlabWall(char *str)
{

}

bool MkSimpParser::ParseDiv(char *str)
{

}

bool MkSimpParser::ParseSol(char *str)
{

}

bool MkSimpParser::ParsePnt(char *str)
{

}

bool MkSimpParser::ParseNoEcho(char *str)
{

}

bool MkSimpParser::ParseOut(char *str)
{

}

bool MkSimpParser::ParseStep(char *str)
{

}

bool MkSimpParser::ParseBot(char *str)
{

}

bool MkSimpParser::ParseRankine(char *str)
{

}

bool MkSimpParser::ParsePeck(char *str)
{

}

bool MkSimpParser::ParsePeck1(char *str)
{

}

bool MkSimpParser::ParseEarthPress(char *str)
{

}

bool MkSimpParser::ParseSlope(char *str)
{

}

bool MkSimpParser::ParseProfile(char *str)
{

}

bool MkSimpParser::ParseGWL(char *str)
{

}

bool MkSimpParser::ParseWaterPress(char *str)
{

}

bool MkSimpParser::ParseSurcharge(char *str)
{

}

bool MkSimpParser::ParseLoad(char *str)
{

}

bool MkSimpParser::ParsePress(char *str)
{

}

bool MkSimpParser::ParseMinAct(char *str)
{

}

bool MkSimpParser::ParseExcav(char *str)
{

}

bool MkSimpParser::ParseConst(char *str)
{

}

bool MkSimpParser::ParseRemove(char *str)
{

}

bool MkSimpParser::ParseInsertCheck(char *str)
{

}

bool MkSimpParser::ParseInteration(char *str)
{

}

bool MkSimpParser::ParseGroundSettle(char *str)
{

}

bool MkSimpParser::ParseSlip(char *str)
{

}


