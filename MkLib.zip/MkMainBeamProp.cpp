//---------------------------------------------------------------------------
#include "MkMainBeamProp.h"
#ifdef __BCPLUSPLUS__
#include <vcl.h>
#endif
#pragma hdrstop
//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#pragma package(smart_init)
#endif

void MkMainBeamProp::Clear()
{
  BeamLoc = blSide;
  Height=0;
  Width=0;
  T1=0;
  T2=0;         // tt1, tt2
  Area=0;
  AreaWeb=0; // AA, Aw

  Weight=0;
  SecCoeffY=0;
  SecCoeffZ=0;    // Section coefficient Zx, Zy
  SecMomentY=0;
  SecMomentZ=0;
  SecRadiusY=0;
  SecRadiusZ=0;  // second radius of inertia rx, ry
}

#ifdef __BCPLUSPLUS__
void MkMainBeamProp::Import(MkGlobalVar &globalvar, int sec)
{
  if(BeamLoc==blSide) {
    Width=globalvar.supportbeam_BB[sec+1];
    Height=globalvar.supportbeam_HH[sec+1];
    T1=globalvar.supportbeam_tt1[sec+1];
    T2=globalvar.supportbeam_tt2[sec+1];
    Area=globalvar.supportbeam_AA[sec+1];
    AreaWeb=globalvar.supportbeam_Aw[sec+1];
    Weight=globalvar.supportbeam_W[sec+1];
    SecCoeffY=globalvar.supportbeam_Zx[sec+1];
    SecMomentY=globalvar.supportbeam_Ix[sec+1];
    SecRadiusY=globalvar.supportbeam_rx[sec+1];
    SecRadiusZ=globalvar.supportbeam_ry[sec+1];
  }
  else if(BeamLoc=blMid) {
    Width=globalvar.supportbeam_m_BB[sec+1];
    Height=globalvar.supportbeam_m_HH[sec+1];
    T1=globalvar.supportbeam_m_tt1[sec+1];
    T2=globalvar.supportbeam_m_tt2[sec+1];
    Area=globalvar.supportbeam_m_AA[sec+1];
    AreaWeb=globalvar.supportbeam_m_Aw[sec+1];
    Weight=globalvar.supportbeam_m_W[sec+1];
    SecCoeffY=globalvar.supportbeam_m_Zx[sec+1];
    SecMomentY=globalvar.supportbeam_m_Ix[sec+1];
    SecRadiusY=globalvar.supportbeam_m_rx[sec+1];
    SecRadiusZ=globalvar.supportbeam_m_ry[sec+1];
  }
}

void MkMainBeamProp::Export(MkGlobalVar &globalvar, int sec)
{
  if(BeamLoc==blSide) {
    globalvar.supportbeam_BB[sec+1]=Width;
    globalvar.supportbeam_HH[sec+1]=Height;
    globalvar.supportbeam_tt1[sec+1]=T1;
    globalvar.supportbeam_tt2[sec+1]=T2;
    globalvar.supportbeam_AA[sec+1]=Area;
    globalvar.supportbeam_Aw[sec+1]=AreaWeb;
    globalvar.supportbeam_W[sec+1]=Weight;
    globalvar.supportbeam_Zx[sec+1]=SecCoeffY;
    globalvar.supportbeam_Ix[sec+1]=SecMomentY;
    globalvar.supportbeam_rx[sec+1]=SecRadiusY;
    globalvar.supportbeam_ry[sec+1]=SecRadiusZ;
  }
  else if(BeamLoc=blMid) {
    globalvar.supportbeam_m_BB[sec+1]=Width;
    globalvar.supportbeam_m_HH[sec+1]=Height;
    globalvar.supportbeam_m_tt1[sec+1]=T1;
    globalvar.supportbeam_m_tt2[sec+1]=T2;
    globalvar.supportbeam_m_AA[sec+1]=Area;
    globalvar.supportbeam_m_Aw[sec+1]=AreaWeb;
    globalvar.supportbeam_m_W[sec+1]=Weight;
    globalvar.supportbeam_m_Zx[sec+1]=SecCoeffY;
    globalvar.supportbeam_m_Ix[sec+1]=SecMomentY;
    globalvar.supportbeam_m_rx[sec+1]=SecRadiusY;
    globalvar.supportbeam_m_ry[sec+1]=SecRadiusZ;
  }
}
#endif

void MkMainBeamProp::SetBeam(MkBeam beam)
{
  SetSteelType(beam.SteelType);
  SetHeight(beam.HH);
  SetWidth(beam.BB);
  SetT1(beam.tt1);
  SetT2(beam.tt2);
  SetArea(beam.AA);
  SetAreaWeb(beam.Aw);
  SetWeight(beam.W);
  SetSecCoeffY(beam.Zx);
  SetSecCoeffZ(beam.Zx);
  SetSecMomentY(beam.Ix);
  SetSecMomentZ(beam.Ix);
  SetSecRadiusY(beam.rx);
  SetSecRadiusZ(beam.ry);
}
