//---------------------------------------------------------------------------
#ifndef MkSlabH
#define MkSlabH
#include "MkEntity.h"
//---------------------------------------------------------------------------
class MkSlab : public MkEntity {
protected:
  MkLine SlabLine;
  float Thick;
  float Length;
  float IniDis;

//  float Area;
//  float Angle;
//  float YoungMod;
//  float ShearTor;
//  float SecMomentY, SecMomentZ;  // second moment of inertial
public:
  MkSlab();
  MkSlab(int n);
  ~MkSlab(){};

  void SetLine(MkLine &line){SlabLine = line;SlabLine.SetFiniteness(true);}
  void SetThick(float thick){Thick = thick;}
  void SetLength(float len){Length = len;}
  void SetIniDis(float dini){IniDis = dini;}

  MkLine &GetLine(){return SlabLine;}
  float GetThick(){return Thick;}
  float GetLength(){return Length;}
  float GetIniDis(){return IniDis;}

//  void SetYoungMod(float y){YoungMod = y;}
//  void SetShearTor(float s){ShearTor = s;}
//  void SetSecMomentY(float sm){SecMomentY=sm;}
//  void SetSecMomentZ(float sm){SecMomentZ=sm;}

#ifdef __BCPLUSPLUS__
  AnsiString ClassName(){return AnsiString("MkSlab");};
  bool UpdateFrom(TStringGrid *grid){Grid = grid;return UpdateFrom();};
  bool UpdateTo(TStringGrid *grid){Grid = grid;return UpdateTo();};
  bool UpdateFrom();
  bool UpdateTo();
  void Out(TObject *);
#else
  char* ClassName(){return "MkSlab";}
#endif

  void Out(char *fname);

  bool operator==(MkSlab&);
  bool operator!=(MkSlab&);
  MkSlab & operator=(MkSlab&);

#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif
  
#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif

};

class MkSlabs {
protected:
    MkSlab *FSlab;
    int FSize;//Actual size of entities
    int FSizeOfArray;
#ifdef __BCPLUSPLUS__
    TColor Color;
#endif
public:
    MkSlabs(int size,MkSlab *ent);
    MkSlabs(int size);
    MkSlabs(){FSizeOfArray = FSize = 0;FSlab = NULL;}
    ~MkSlabs();
    virtual void Initialize(int size);
    virtual void Initialize(int size,MkSlab *);
    int GetSize(){return FSize;};
    int GetNumber(){return FSize;};
    bool Add(MkSlab &slab);  // change of size of slab
    bool Add(int index,MkSlab &slab);
    bool Delete(MkSlab &slab);  // change of size of slab
    bool Delete(int index);
    int Grow(int Delta);            // change of size of array
    int Shrink(int Delta);          // change of size of array
    bool Clear();
#ifdef __BCPLUSPLUS__
    TColor GetColor(){return Color;};
    void SetColor(TColor c){Color = c;}
    void Out(TObject *);
#else
#endif

    void Out(char *fname);

#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif

  virtual MkSlab & operator[](int);
  MkSlabs & operator=(MkSlabs &slabs);
  bool operator==(MkSlabs &slabs);
};

//---------------------------------------------------------------------------
extern MkSlab NullSlab;
//---------------------------------------------------------------------------
#endif
