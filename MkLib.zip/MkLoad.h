//---------------------------------------------------------------------------
#ifndef MkLoadH
#define MkLoadH
#include "MkMesh.h"
#include "MkStrata.h"
#include "MkMatrix.h"
#include "MkPoint.h"
#include "MkRange.h"
#include "MkCut.h"
#include "MkFill.h"

#ifndef dyn_load_cp
#define dyn_load_cp(_destl_,_srcl_) {\
  MkEarthPress *_earthpress_,*_ep_;\
  MkRankine *_rankine_,*_rk_;\
  MkStaticHydLoad *_statichydload_,*_shl_;\
  MkArbtrHydLoad *_arbtrhydload_,*_ahl_;\
  MkPointBackLoad *_pointbackload_,*_pbl_;\
  MkLineBackLoad *_linebackload_,*_lbl_;\
  if(_rankine_ = dynamic_cast<MkRankine*>((_srcl_))) {\
    assert(_rankine_);\
    MkRankine *_rk_ = new MkRankine();\
    *_rk_ = *_rankine_;\
    (_destl_) = _rk_;\
  }\
  else if(_earthpress_ = dynamic_cast<MkEarthPress*>((_srcl_))) {\
    assert(_earthpress_);\
    MkEarthPress *_ep_ = new MkEarthPress();\
    *_ep_ = *_earthpress_;\
    (_destl_) = _ep_;\
  }\
  else if(_arbtrhydload_ = dynamic_cast<MkArbtrHydLoad*>((_srcl_))) {\
    assert(_arbtrhydload_);\
    MkArbtrHydLoad *_ahl_ = new MkArbtrHydLoad();\
    *_ahl_ = *_arbtrhydload_;\
    (_destl_) = _ahl_;\
  }\
  else if(_statichydload_ = dynamic_cast<MkStaticHydLoad*>((_srcl_))) {\
    assert(_statichydload_);\
    MkStaticHydLoad *_shl_ = new MkStaticHydLoad();\
    *_shl_ = *_statichydload_;\
    (_destl_) = _shl_;\
  }\
  else if(_linebackload_ = dynamic_cast<MkLineBackLoad*>((_srcl_))) {\
    assert(_linebackload_);\
    MkLineBackLoad *_lbl_ = new MkLineBackLoad();\
    *_lbl_ = *_linebackload_;\
    (_destl_) = _lbl_;\
  }\
  else if(_pointbackload_ = dynamic_cast<MkPointBackLoad*>((_srcl_))) {\
    assert(_pointbackload_);\
    MkPointBackLoad *_pbl_ = new MkPointBackLoad();\
    *_pbl_ = *_pointbackload_;\
    (_destl_) = _pbl_;\
  }\
}
#endif

//-------------------------------------------------------------
enum MkLoadType {ltNone, ltEarthPress, ltRankine, ltStaticHydLoad, ltArbtrHydLoad, ltPointBackLoad, ltLineBackLoad };
enum MkLoadApplyType {latNone, latNodal, latDistributal};

class MkLoad {
protected:
  MkLoadType LoadType;
  MkLoadApplyType LoadApplyType;
  MkVector Direction;
  MkPoint Origin;  // location of pile head
  float GroundWaterLevel;
  MkRangeTree Range;
#ifdef __BCPLUSPLUS__
  TColor Color;
#endif
public:
  MkLoad(){LoadType = ltNone; LoadApplyType = latDistributal; Direction.SetVector(1,0,0); Origin.SetPoint(0,0,0);}
  MkLoad(int n){LoadType = ltNone; LoadApplyType = latDistributal; Direction.SetVector(1,0,0); Origin.SetPoint(0,0,0);}
  ~MkLoad(){};
#ifdef __BCPLUSPLUS__
  AnsiString ClassName(){return AnsiString("MkLoad");}
#else
  char *ClassName(){return "MkLoad";}
#endif
public: //setting function
  void SetDirection(MkVector &dir){Direction = dir;}
  void SetOrigin(MkPoint &ori){Origin = ori;}
  void SetRangeTree(MkRangeTree &range){Range = range;}
  void SetGroundWaterLevel(float gl){GroundWaterLevel = gl;}
  void SetLoadApplyType(MkLoadApplyType lat){LoadApplyType=lat;}
  virtual void SetKa(float ka){}
  virtual void SetGamma(float g){}
  virtual void SetDepth(float h){}
  virtual void SetStaticPress(MkPolygon &stat){}
public: // getting function
  MkVector &GetDirection(){return Direction;}
  MkPoint &GetOrigin(){return Origin;}
  MkRangeTree &GetRange(){return Range;}
  MkLoadType GetLoadType(){return LoadType;}
  MkLoadApplyType GetLoadApplyType(){return LoadApplyType;}  
  float GetGroundWaterLevel(){return GroundWaterLevel;}
  bool isIn(MkPoint p){return Range.Operate(p);}

  virtual float GetKa(){MkDebug("Pure virtual function MkLoad::GetKa() is called\n");return 0;}
  virtual float GetGamma(){MkDebug("Pure virtual function MkLoad::GetGamma() is called\n");return 0;}
  virtual float GetDepth(){MkDebug("Pure virtual function MkLoad::GetDepth() is called\n");return 0;}

  virtual float GetStaticPress(MkPoint pnt){MkDebug("Pure virtual function MkLoad::GetStaticPress() is called\n");return 0;}
  virtual float GetActivPress(MkPoint pnt){MkDebug("Pure virtual function MkLoad::GetActivPress() is called\n");return 0;}
  virtual float GetPassivPress(MkPoint pnt){MkDebug("Pure virtual function MkLoad::GetPassivPress() is called\n");return 0;}
  virtual float GetVerticPress(MkPoint pnt){MkDebug("Pure virtual function MkLoad::GetVerticPress() is called\n");return 0;}

  virtual MkPolygon &GetStaticPress(){MkDebug("Pure virtual function MkLoad::GetStaticPress() is called\n");return NullPolygon;}
  virtual MkPolygon &GetActivPress(){MkDebug("Pure virtual function MkLoad::GetActivPress() is called\n");return NullPolygon;}
  virtual MkPolygon &GetPassivPress(){MkDebug("Pure virtual function MkLoad::GetPassivPress() is called\n");return NullPolygon;}
  virtual MkPolygon &GetVerticPress(){MkDebug("Pure virtual function MkLoad::GetVerticPress() is called\n");return NullPolygon;}

  virtual MkPolygon &GetBackLoad(){MkDebug("Pure virtual function MkLoad::GetBackLoad() is called\n");return NullPolygon;}
  virtual MkPolygon &GetVertLoad(){MkDebug("Pure virtual function MkLoad::GetBackLoad() is called\n");return NullPolygon;}
  virtual MkPolygon &GetWatPress(){MkDebug("Pure virtual function MkLoad::GetBackLoad() is called\n");return NullPolygon;}
public: // key function
  virtual bool BuildFrom(MkLayers &lay,MkCuts &cuts,MkFills &fills, MkWall &wall){MkDebug("Pure virtual function MkLoad::BuildFrom() is called.\n");return false;}
  virtual bool BuildFrom(MkStratum &str,MkCuts &cuts,MkFills &fills, MkWall &wall){MkDebug("Pure virtual function MkLoad::BuildFrom() is called.\n");return false;}
  virtual bool BuildFrom(MkLayers &lay){MkDebug("Pure virtual function MkLoad::BuildFrom() is called.\n");return false;}
  virtual bool Build(MkWall &wall){MkDebug("Pure virtual function MkLoad::Build() is called.\n");return false;}
  bool BuildRange(MkWall &wall);
  virtual bool Out(char *fname);

public: // who am I functions
  virtual bool isLoad(){return true;}
  virtual bool isEarthPress(){return false;}
  virtual bool isRankine(){return false;}
  virtual bool isStaticHydLoad(){return false;}
  virtual bool isArbtrHydLoad(){return false;}
  virtual bool isPointBackLoad(){return false;}
  virtual bool isLineBackLoad(){return false;}

public: // operator function
  virtual bool operator==(MkLoad &load);
  virtual bool operator!=(MkLoad &load);
  virtual MkLoad & operator=(MkLoad &load);

#ifdef __BCPLUSPLUS__
  virtual void Draw(TObject *){MkDebug("Pure virtual function MkLoad::Draw() is called.\n");}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  virtual void Draw(MkPaint *){MkDebug("Pure virtual function MkLoad::Draw() is called.\n");}
#endif
};
//-------------------------------------------------------------
class MkEarthPress : public MkLoad {
protected:
  float K0,Ka,Kp;
  float Gamma;
  float H;

  float HeightTop; // it is fraction [0..1]
  float HeightMid; // it is fraction [0..1]
  float HeightBot; // it is fraction [0..1] but the total should be exactly 1.0

  MkPolygon Static;
public:
  MkEarthPress();
  ~MkEarthPress(){}
#ifdef __BCPLUSPLUS__
  AnsiString ClassName(){return AnsiString("MkEarthPress");}
#else
  char *ClassName(){return "MkEarthPress";}
#endif
public: //setting function
  void SetK0(float k0){K0 = k0;}
  void SetKa(float ka){Ka = ka;}
  void SetKp(float kp){Kp = kp;}
  void SetGamma(float g){Gamma = g;}
  void SetDepth(float h){H = h;}

  void SetHeightTop(float h){HeightTop = h;}
  void SetHeightMid(float h){HeightMid = h;}
  void SetHeightBot(float h){HeightBot = h;}

  void SetStaticPress(MkPolygon &stat){Static=stat;}
public: //getting function
  float GetK0(){return K0;}
  float GetKa(){return Ka;}
  float GetKp(){return Kp;}
  float GetGamma(){return Gamma;}
  float GetDepth(){return H;}

  float GetHeightTop(){return HeightTop;}
  float GetHeightMid(){return HeightMid;}
  float GetHeightBot(){return HeightBot;}

  float GetStaticPress(MkPoint pnt);

  bool isEarthPress(){return true;}

  MkPolygon &GetStaticPress(){return Static;}
public:// key function
  bool Build(MkWall &wall);

public:
  bool operator==(MkEarthPress &ep);
  bool operator!=(MkEarthPress &ep);
  MkEarthPress &operator=(MkEarthPress & ep);

  bool Out(char *fname);

#ifdef __BCPLUSPLUS__
  void Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif

};
//-------------------------------------------------------------
class MkRankine : public MkEarthPress {
protected:
  MkPolygon Static;
  MkPolygon Activ;
  MkPolygon Passiv;
  MkPolygon Vertic;
public:
  MkRankine();
  ~MkRankine(){}
#ifdef __BCPLUSPLUS__
  AnsiString ClassName(){return AnsiString("MkRankine");}
#else
  char *ClassName(){return "MkRankine";}
#endif
public: // setting function
  void SetActivPress(MkPolygon &activ){Activ=activ;}
  void SetPassivPress(MkPolygon &passiv){Passiv=passiv;}
  void SetStaticPress(MkPolygon &stat){Static=stat;}
  void SetVerticPress(MkPolygon &stat){Static=stat;}
public: // getting function
  float GetActivPress(MkPoint pnt);
  float GetPassivPress(MkPoint pnt);
  float GetVerticPress(MkPoint pnt);
  MkPolygon &GetPassivPress(){return Passiv;}
  MkPolygon &GetActivPress(){return Activ;}
  MkPolygon &GetStaticPress(){return Static;}
  MkPolygon &GetVerticPress(){return Static;}

public: // key function
  bool BuildStatic(MkLayers &lay,MkCuts &cuts,MkFills &fills, MkWall &wall);
  bool BuildStatic(MkStratum &str,MkCuts &cuts,MkFills &fills, MkWall &wall);
  bool BuildActiv(MkLayers &lay,MkCuts &cuts,MkFills &fills, MkWall &wall);
  bool BuildActiv(MkStratum &str,MkCuts &cuts,MkFills &fills, MkWall &wall);
  bool BuildPassiv(MkLayers &lay,MkCuts &cuts,MkFills &fills, MkWall &wall);
  bool BuildPassiv(MkStratum &str,MkCuts &cuts,MkFills &fills, MkWall &wall);
  bool BuildVertic(MkLayers &lay,MkCuts &cuts,MkFills &fills, MkWall &wall);
  bool BuildVertic(MkStratum &str,MkCuts &cuts,MkFills &fills, MkWall &wall);
  bool BuildFrom(MkLayers &lay,MkCuts &cuts,MkFills &fills, MkWall &wall);
  bool BuildFrom(MkStratum &str,MkCuts &cuts,MkFills &fills, MkWall &wall);

  bool isRankine(){return true;}

public://operators
  bool operator==(MkRankine &);
  bool operator!=(MkRankine &);
  MkRankine &operator=(MkRankine &);

  bool Out(char *fname);

#ifdef __BCPLUSPLUS__
  void Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif
};
//-------------------------------------------------------------
class MkStaticHydLoad : public MkLoad {
protected:
  float HeightTop; // it is fraction [0..1] HeightTop+HeightBot = 1
  float HeightBot; // it is fraction [0..1]
  MkPolygon WatPress;
  float ExcavDepth;
public:
  MkStaticHydLoad();
  ~MkStaticHydLoad(){}
public:
  void SetWatPress(MkPolygon &p){WatPress = p;}
  void SetExcavDepth(float e){ExcavDepth = e;}
  void SetHeightTop(float h){HeightTop = h;}
  void SetHeightBot(float h){HeightBot = h;}
public:
  MkPolygon & GetWatPress(){return WatPress;}
  float GetExcavDepth(){return ExcavDepth;}
  float GetHeightTop(){return HeightTop;}
  float GetHeightBot(){return HeightBot;}
public:
  bool Build(MkWall &wall);
  bool Build(MkCuts &cuts, MkFills &fills, MkWall &wall);

  virtual bool isStaticHydLoad(){return true;}

  bool operator==(MkStaticHydLoad &r);
  bool operator!=(MkStaticHydLoad &r);
  MkStaticHydLoad & operator=(MkStaticHydLoad &r);

#ifdef __BCPLUSPLUS__
  AnsiString ClassName(){return AnsiString("MkStaticHydLoad");}
#else
  char *ClassName(){return "MkStaticHydLoad";}
#endif

#ifdef __BCPLUSPLUS__
  void Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif
};
//-------------------------------------------------------------
class MkArbtrHydLoad : public MkStaticHydLoad {
protected:
public:
  MkArbtrHydLoad();
  ~MkArbtrHydLoad(){}
 public:

#ifdef __BCPLUSPLUS__
  AnsiString ClassName(){return AnsiString("MkArbtrHydLoad");}
#else
  char *ClassName(){return "MkArbtrHydLoad";}
#endif
  bool Build(MkWall &wall);

  virtual bool isArbtrHydLoad(){return true;}

  bool operator==(MkArbtrHydLoad &r);
  bool operator!=(MkArbtrHydLoad &r);
  MkArbtrHydLoad & operator=(MkArbtrHydLoad &r);

#ifdef __BCPLUSPLUS__
  void Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif
};
//-------------------------------------------------------------
class MkPointBackLoad : public MkLoad {
protected:
  float Weight;
  MkPoint LoadPoint;
  MkPolygon BackLoad;
  MkPolygon VertLoad;
public:
  MkPointBackLoad();
  ~MkPointBackLoad(){}
 public:
  void SetPoint(MkPoint p){LoadPoint = p;}
  void SetWeight(float w){Weight = w;}
 public:
  MkPoint GetPoint(){return LoadPoint;}
  float GetWeight(){return Weight;}
  MkPolygon & GetBackLoad(){return BackLoad;}
  MkPolygon & GetVertLoad(){return VertLoad;}
 public:
  bool Build(MkWall &wall);
  bool BuildVert(MkLayers &lay);
  bool BuildVert(MkStratum &str);

  bool isPointBackLoad(){return true;}


  bool operator==(MkPointBackLoad &r);
  bool operator!=(MkPointBackLoad &r);
  MkPointBackLoad & operator=(MkPointBackLoad &r);

#ifdef __BCPLUSPLUS__
  AnsiString ClassName(){return AnsiString("MkPointBackLoad");}
#else
  char *ClassName(){return "MkPointBackLoad";}
#endif

#ifdef __BCPLUSPLUS__
  void Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif
};
//-------------------------------------------------------------
class MkLineBackLoad : public MkPointBackLoad {
protected:

public:
  MkLineBackLoad();
  ~MkLineBackLoad(){}
public:
  bool Build(MkWall &wall);

  bool isLineBackLoad(){return true;}

  bool operator==(MkLineBackLoad &r);
  bool operator!=(MkLineBackLoad &r);
  MkLineBackLoad & operator=(MkLineBackLoad &r);

#ifdef __BCPLUSPLUS__
  AnsiString ClassName(){return AnsiString("MkLineBackLoad");}  
#else
  char *ClassName(){return "MkLineBackLoad";}
#endif

#ifdef __BCPLUSPLUS__
  void Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif
};
//-------------------------------------------------------------
class MkLoads {
protected:
  MkLoad **FLoad;
  int FSize;//Actual size of loads
#ifdef __BCPLUSPLUS__
  TColor Color;
#endif
public:
  MkLoads(int size,MkLoad **load);
  MkLoads(){FSize = 0;FLoad = NULL;}
  ~MkLoads();
  virtual void Initialize(int size,MkLoad **);
  int GetSize(){return FSize;};
  int GetNumber(){return FSize;};
  bool Add(MkLoad *load);  // change of size of load
  bool Delete(MkLoad *load);  // change of size of load
  bool Clear();
 public:
  virtual MkLoad & operator[](int);

  MkLoads & operator=(MkLoads &loads);
  bool operator==(MkLoads &loads);
  bool operator!=(MkLoads &loads);

  bool Out(char *fname);
#ifdef __BCPLUSPLUS__
  void Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif
};
//---------------------------------------------------------------------------
extern MkLoad NullLoad;
#endif
