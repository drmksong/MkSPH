//---------------------------------------------------------------------------
#ifndef MkSphereH
#define MkSphereH
#include <math.h>
#include "MkShape.h"
#include "MkPoint.h"
#include "MkTriangle.h"

//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#endif
//---------------------------------------------------------------------------
class MkSphere : public MkShape {
private:
  MkTriangles Surf;
  int SurfDivision;
  bool needUpdate;
  bool UpdateSurf();
protected:
    MkPoint FCP;
    float FRadius;
    float FSphereVolume;
    MkPoints FRealPoints;
    virtual void  CalcVolume();
public:
     MkSphere();
     MkSphere(float cx,float cy,float cz,float radius);
     MkSphere(MkPoint cp,float radius);
#ifdef __BCPLUSPLUS__

     MkSphere(float cx,float cy,float cz,float radius,TColor C);
     MkSphere(MkPoint cp,float radius,TColor C);
     AnsiString ClassName(){return AnsiString("MkSphere");}
#else 
     char* ClassName(){return "MkSphere";}
#endif
    void  SetSphere(float cx,float cy,float cz,float radius);
    void  SetSphere(MkPoint cp,float radius);
#ifdef __BCPLUSPLUS__
    void  SetSphere(float cx,float cy,float cz,float radius,TColor C);
    void  SetSphere(MkPoint cp,float radius,TColor C);
    void SetSurfDivision(int n){SurfDivision = n;}
#endif
    virtual void  SetCenter(float cx,float cy,float cz);
    virtual void  SetCenter(MkPoint cp);
    virtual void  SetRadius(float radius);

    bool IsInSurface(MkPoint &pnt, float thick);
    bool IsInSpace(MkPoint &pnt);
    bool IsIntersect(MkLine &rl);
    bool isSphere(){return true;}

    MkPoints CalcIntPnts(MkLine &rl);
    void GetIntParam(MkLine &rl, float &t1,float &t2);

    MkPoint  GetCenter();
    float  GetRadius();
    float  GetVolume();
    MkPoint &  operator[](int);
    bool operator==(MkSphere &rs);
    bool operator!=(MkSphere &rs);
    MkSphere & operator=(MkSphere &rs);
    bool operator&&(MkLine &rl);
    MkPoints operator&(MkLine &rl);

#ifdef __BCPLUSPLUS__
  void Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif

};

class MkSpheres {
protected:
    MkSphere *FSphere;
    int FSize;
public:
    MkSpheres(int Size);
    MkSpheres(){FSize = 0; FSphere = NULL;}
    ~MkSpheres(){if (FSphere) {delete (MkSphere*)FSphere;FSphere = NULL;}}
    void Initialize(int Size);
    void Clear();
    int GetSize(){return FSize;}
    virtual MkSphere &  operator[](int);
    MkSpheres &  operator=(MkSpheres &spheres);

#ifdef __BCPLUSPLUS__
  void Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif
};

#endif
