//---------------------------------------------------------------------------
#ifndef MkPointH
#define MkPointH
#include <Math.h>

#if defined(_MSC_VER) && defined(_WINDOWS_)
class MkPaint;
//typedef MkColor;
#endif

#include "MkMisc.h"
#include "MkMatrix.h"

struct MkPoint;
class MkPoints;
extern MkPoint NullPoint;
extern MkPoints NullPoints;

class MkMatrix4;
struct MkPoint {
public:
    float X,Y,Z;
#ifdef __BCPLUSPLUS__
    TColor Color;
#endif
#if defined(_MSC_VER) && defined(_WINDOWS_)
	MkColor Color;
#endif
    MkPoint(){X=0;Y=0;Z=0;}
    MkPoint(float x,float y){X=x;Y=y;Z=0;}
    MkPoint(float x,float y,float z){X=x;Y=y;Z=z;}
    void SetPoint(float x,float y){X=x;Y=y;}
    void SetPoint(float x,float y,float z){X=x;Y=y;Z=z;}
    void Set(float x,float y,float z){X=x;Y=y;Z=z;}
    void Set(MkPoint rp){X = rp.X;Y = rp.Y;Z=rp.Z;}

#ifdef __BCPLUSPLUS__
    TColor GetColor(){return Color;};
    void SetColor(TColor c){Color = c;}
#endif

#if !defined(_MSC_VER) && !defined(_WINDOWS_) || defined(__BCPLUSPLUS__)
    MkPoint & operator=(const MkPoint &rp);
#endif
    MkPoint & operator=(MkPoint &rp);
    MkPoint & operator+=(MkPoint &rp){X += rp.X;Y += rp.Y;Z+=rp.Z;return *this;}
    friend MkPoint & operator+(MkPoint &a,MkPoint &b)
            {static MkPoint c;c.X = a.X + b.X;c.Y = a.Y + b.Y;c.Z = a.Z + b.Z;return c;}
    MkPoint & operator-=(MkPoint &rp){X -= rp.X;Y -= rp.Y;Z-=rp.Z;return *this;}
    friend MkPoint & operator-(MkPoint &a,MkPoint &b)
            {static MkPoint c;c.X = a.X - b.X;c.Y = a.Y - b.Y;c.Z = a.Z - b.Z;return c;}
    friend float CalDist(MkPoint sp, MkPoint ep)
           {return sqrt(pow(sp.X-ep.X,2)+pow(sp.Y-ep.Y,2)+pow(sp.Z-ep.Z,2)) ;}
    float GetAng();
    void  GetAng(float &alpha, float &beta, float &gamma);
    bool operator==(MkPoint&rp);
    bool operator!=(MkPoint&rp);

    friend MkPoint & operator*(MkPoint &rp,MkMatrix4 &rm);
    friend MkPoint & operator*(MkPoint &rp,float f);
    MkPoint & operator *= (MkMatrix4 &rm);
    MkPoint & operator *= (float f);
    MkPoint & operator/(float f){
      static MkPoint p;
      p = *this;
      if(fabs(f)<EPS) {
        MkDebug("MkPoint::operator/(float) Try to divide with too small float\n");
        return NullPoint;
      }
      p.X = p.X/f;
      p.Y = p.Y/f;
      p.Z = p.Z/f;
      return p;
    };
    MkPoint & operator/(int i){
      static MkPoint p;
      p = *this;
      if(i==0) {
        MkDebug("MkPoint::operator/(int) Try to divide with zero\n");
        return NullPoint;
      }
      p.X = p.X/i;
      p.Y = p.Y/i;
      p.Z = p.Z/i;
      return p;
    }

    void Unify();
    MkPoint & Translate(MkPoint &rp);
    MkPoint & Translate(float x,float y,float z);
    MkPoint & Rotate(float alpha, float beta, float gamma);
    MkPoint & RotateInX(float ang);
    MkPoint & RotateInY(float ang);
    MkPoint & RotateInZ(float ang);
    MkPoint & RotateInA(float ang,float l, float m, float n);
    MkPoint & Scale(float sx,float sy, float sz);
    void Normalize();
    bool IsNear(MkPoint &rp){return CalDist(*this,rp) < 0.001;}
    bool IsNear(float x,float y){static MkPoint rp;rp.SetPoint(x,y);
                                 return CalDist(*this,rp) < 0.001;}

#ifdef __BCPLUSPLUS__
  void Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif
};

void Swap(MkPoint &p1, MkPoint &p2);

class MkPoints {
protected:
    MkPoint *FPoint;
    MkPoint FCenter;
    int FSize;//Actual size of points
    int FSizeOfArray;
    void FindCenter();
#ifdef __BCPLUSPLUS__
    TColor Color;
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
    MkColor Color;
    float DotRadius;
#endif
public:
    MkPoints(int size,MkPoint *rps);
    MkPoints(int size);
    MkPoints(){FSizeOfArray = FSize = 0;FPoint = NULL;}
    ~MkPoints();
    virtual void Initialize(int size);
    virtual void Initialize(int size,MkPoint *);
    int GetSize(){return FSize;};
    int GetNumber(){return FSize;};
    MkPoint* GetPoints(){return FPoint;}
    MkPoint GetCenter(){FindCenter();return FCenter;};
    bool Add(MkPoint point);  // change of size of point
    bool Add(int index,MkPoint point);
    bool Add(MkPoints &p){for (int i=0;i<p.GetSize();i++) Add(p[i]);return true;}
    bool Delete(MkPoint point);  // change of size of point
    bool Delete(int index);
    int Grow(int Delta);            // change of size of array
    int Shrink(int Delta);          // change of size of array
    bool Swap(int i, int j);
    bool Clear();
#ifdef __BCPLUSPLUS__
    TColor GetColor(){return Color;};
    void SetColor(TColor c){Color = c;}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
    void SetColor(MkColor c){Color = c;}
    void SetDotRadius(float r){DotRadius = r;}
    MkColor GetColor(){return Color;}
    float GetDotRadius(){return DotRadius;}
#endif
    bool hasPoint(MkPoint &pnt){for(int i=0;i<FSize;i++) if(FPoint[i]==pnt) return true; return false;}
    int  numPoint(MkPoint &pnt){for(int i=0;i<FSize;i++) if(FPoint[i]==pnt) return i; return -1;}
    virtual MkPoint & operator[](int);
    MkPoints & operator*=(MkMatrix4 &rm);
    friend MkPoints & operator*(MkPoints &rps, MkMatrix4 &rm);

    MkPoints & Translate(MkPoint rp);
    MkPoints & Translate(float x,float y,float z);
    MkPoints & Rotate(float alpha, float beta, float gamma);
    MkPoints & RotateInX(float ang);
    MkPoints & RotateInY(float ang);
    MkPoints & RotateInZ(float ang);
    MkPoints & RotateInA(float ang,float l, float m, float n);
    MkPoints & Scale(float sx,float sy, float sz);

    MkPoints & operator=(MkPoints &points);
    bool operator==(MkPoints &points);
    bool operator!=(MkPoints &points){return !operator==(points);}

#ifdef __BCPLUSPLUS__
  void Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif
};
//---------------------------------------------------------------------------
#endif
