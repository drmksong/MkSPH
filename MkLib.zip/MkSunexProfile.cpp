//---------------------------------------------------------------------------
#include "MkSunexProfile.h"
#ifdef __BCPLUSPLUS__
#include <vcl.h>
#endif
#pragma hdrstop
//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#pragma package(smart_init)
#endif
//---------------------------------------------------------------------------
MkSunexProfile NullSunexProfile(0);
MkSunexProfiles::MkSunexProfiles(int size,MkSunexProfile *profs)
{
    if (size < 0) {
      MkDebug("::MkSunexProfiles - MkSunexProfiles(int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSize == 0) {
       FSunexProfile = NULL;
       return;
    }

    FSunexProfile = new MkSunexProfile[FSize];
    for (int i=0;i<FSize;i++) (*this)[i] = profs[i];
}

MkSunexProfiles::MkSunexProfiles(int size)
{
    if (size < 0) {
      MkDebug("::MkSunexProfiles - MkSunexProfiles(int size)");;
      return;
    }

    FSizeOfArray = size;
    FSize = 0;
    if (FSizeOfArray == 0) {
       FSunexProfile = NULL;
       return;
    }

    FSunexProfile = new MkSunexProfile[FSizeOfArray];
}

MkSunexProfiles::~MkSunexProfiles()
{
   FSizeOfArray = FSize = 0;
   if (FSunexProfile) {
      delete[] FSunexProfile;
      FSunexProfile = NULL;
   }
}

void MkSunexProfiles::Initialize(int size)
{
    int i;
    if (size < 0) {
      MkDebug("::MkSunexProfiles - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;

    FSizeOfArray = FSize =size;

    if (FSizeOfArray == 0) {
       if (FSunexProfile!=NULL) delete[] (MkSunexProfile*)FSunexProfile;
       FSunexProfile = NULL;
       return;
    }

    if (FSunexProfile!=NULL) delete[] (MkSunexProfile*)FSunexProfile;
    FSunexProfile = new MkSunexProfile[FSizeOfArray];
    for (i=0;i<FSize;i++) FSunexProfile[i].Number = i;
}

void MkSunexProfiles::Initialize(int size,MkSunexProfile *profs)
{
    int i;
    if (size < 0 || profs == NULL) {
      MkDebug("::MkSunexProfiles - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSize = FSizeOfArray = size;
    if (FSizeOfArray == 0) {
       if (FSunexProfile!=NULL) delete[] (MkSunexProfile*)FSunexProfile;
       FSunexProfile = NULL;
       return;
    }

    if (FSunexProfile!=NULL) delete[] (MkSunexProfile*)FSunexProfile;
    FSunexProfile = new MkSunexProfile[FSizeOfArray];
    for (i=0;i<FSizeOfArray;i++) FSunexProfile[i] = profs[i];
    for (i=0;i<FSize;i++) FSunexProfile[i].Number = i;
}

int MkSunexProfiles::Grow(int delta)
{
    int i;
    MkSunexProfile *prof=NULL;

	prof = new MkSunexProfile[FSizeOfArray+delta];
    if (!(prof)) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        prof[i] = FSunexProfile[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        prof[i] = NullSunexProfile;
    if (FSunexProfile) {
       delete[] (MkSunexProfile*)FSunexProfile;
       FSunexProfile = NULL;
    }
    FSunexProfile = prof;
    FSizeOfArray = FSizeOfArray+delta;
    return FSizeOfArray;
}

int MkSunexProfiles::Shrink(int delta)
{
    int i;
    MkSunexProfile *prof=NULL;

    if (!(prof = new MkSunexProfile[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        prof[i] = FSunexProfile[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        prof[i] = NullSunexProfile;
    if (FSunexProfile) {
       delete[] (MkSunexProfile*)FSunexProfile;
       FSunexProfile = NULL;
    }
    FSunexProfile = prof;
    FSizeOfArray = FSizeOfArray-delta;
    return FSizeOfArray;
}

bool MkSunexProfiles::Add(MkSunexProfile &prof)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    FSize++;
    FSunexProfile[FSize-1] = prof;
    return true;
}

bool MkSunexProfiles::Add(int index, MkSunexProfile &prof)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    for (int i=FSize-1;i>=index;i--)
      FSunexProfile[i+1] = FSunexProfile[i];
    FSize++;
    FSunexProfile[index] = prof;
    return true;
}

bool MkSunexProfiles::Delete(MkSunexProfile &prof)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FSunexProfile[i] == prof) break;
    }
    if(i==FSize) return false;
    if(FSunexProfile[i] == prof) {
      for (int j=i;j<FSize-1;j++)
        FSunexProfile[j] = FSunexProfile[j+1];
    }
    FSize--;
    FSunexProfile[FSize] = NullSunexProfile;
    return true;
}

bool MkSunexProfiles::Delete(int index)
{
    for (int j=index;j<FSize-1;j++)
        FSunexProfile[j] = FSunexProfile[j+1];

    FSize--;
    FSunexProfile[FSize] = NullSunexProfile;
    return true;
}

bool MkSunexProfiles::Clear()
{
   FSizeOfArray = FSize = 0;
   if (FSunexProfile) {
      delete[] FSunexProfile;
      FSunexProfile = NULL;
   }
   return true;
}

void MkSunexProfiles::Out(char *fname)
{
  FILE *fp;
  fp = fopen(fname,"a");
  if(!fp) {
    return;
  }

  if(FSize==0) return;
    
            //12345678901234567890123456789012345678901234567890123456789012345678901234567890
  fprintf(fp,"\n");
  fprintf(fp,"                           <Information of SunexProfile Stage>\n");
  fprintf(fp,"\n");
  fprintf(fp,"  SunexProfile     Dist       G.L.\n");
  fprintf(fp,"  No.     (m)        (m) \n");
  fclose(fp);

  for(int i=0;i<FSize;i++)
    FSunexProfile[i].Out(fname);
}

MkSunexProfile & MkSunexProfiles::operator[](int i)
{
    if (0<=i && i<FSize) return FSunexProfile[i];
    else if(FSize<=i && i<FSizeOfArray) {
      FSize=i+1;
      return FSunexProfile[i];
    }
    else if (FSizeOfArray <= i) {
      Grow(i-FSizeOfArray+5);
      return NullSunexProfile;
    }
    else return NullSunexProfile;
}

MkSunexProfiles & MkSunexProfiles::operator=(MkSunexProfiles &profs)
{
    int i;

    Clear();
    FSize = profs.FSize;
    FSizeOfArray = profs.FSizeOfArray;
    if (FSizeOfArray == 0) {
       FSunexProfile = NULL;
       return *this;
    }
    this->FSunexProfile = new MkSunexProfile[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FSunexProfile[i] = profs.FSunexProfile[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FSunexProfile[i] = NullSunexProfile;

    return *this;
}

bool MkSunexProfiles::operator==(MkSunexProfiles &profs)
{
    int i;

    if (FSize != profs.FSize) return false;
    for (i=0;i<FSize;i++)
      if (this->FSunexProfile[i] != profs.FSunexProfile[i]) return false;

    return true;
}

#ifdef __BCPLUSPLUS__
void MkSunexProfiles::Draw(TObject *Sender)
{
    TColor C;
    float Offset;
    if (FSize == 0) return;
    if (String(Sender->ClassName()) == String("MkPaintBox")) {
       MkPaintBox *pb=(MkPaintBox*)Sender;
       C = pb->Canvas->Pen->Color;
       pb->Canvas->Pen->Color = Color;
       for (int i = 0; i < FSize;i++) {
           Offset = pb->Offset(3);
           FSunexProfile[i].Draw(pb);
       }
       pb->Canvas->Pen->Color = C;
    }
}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void  MkSunexProfiles::Draw(MkPaint *pb)
{

}
#endif
//---------------------------------------------------------------------------
