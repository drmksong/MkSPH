//---------------------------------------------------------------------------
#ifndef MkEntityH
#define MkEntityH

#include "MkShape.h"
#include "MkPolygon.h"
#include "MkRect.h"
#include "MkLine.h"
#include "assert.h"
//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#define INC_VCLEXT_HEADERS
#include <Grids.hpp>
#include <ComCtrls.hpp>
#include <vcl.h>
#endif

class MkEntity : public MkShape {
protected:
#ifdef __BCPLUSPLUS__
  TStringGrid *Grid;
  TTabSheet *Sheet;
  AnsiString Name;
#else
  char Name[256];
#endif
  MkFloat Prop;
  int Division;
public:
  int Number;
  float Depth;
  float Length;
public:
  MkEntity()
    {
      Division = 1;
#ifdef __BCPLUSPLUS__
      Grid=NULL;
#endif
    };
  MkEntity(int n)
    {
      Division = 1;
#ifdef __BCPLUSPLUS__
      Grid=NULL;
#endif
    };
  ~MkEntity(){};
public: //setting function
#ifdef __BCPLUSPLUS__
  void SetGrid(TStringGrid* grid){Grid = grid;}
  void SetTabSheet(TTabSheet *sheet){Sheet = sheet;}
#endif
  void SetEntNum(int n){Number=n;}
  void SetDivision(int n){Division=n;}
  void SetDepth(float d){Depth=d;}
  void SetLength(float l){Length=l;}
public: //getting function
  int  GetEntNum(){return Number;}
  int  GetDivision(){return Division;}
  MkFloat &GetProp(){return Prop;}
  float GetDepth(){return Depth;}
  float GetLength(){return Length;}
#ifdef __BCPLUSPLUS__
  AnsiString ClassName(){return AnsiString("MkEntity");};
  virtual bool UpdateFrom(TStringGrid*){return false;}
  virtual bool UpdateTo(TStringGrid*){return false;}
  virtual bool UpdateFrom(){return false;}
  virtual bool UpdateTo(){return false;}
  virtual void Out(TObject *){};
#else
  char* ClassName(){return "MkEntity";}
#endif
  virtual void Out(char *fname){};

#ifdef __BCPLUSPLUS__
  virtual void Draw(TObject *){MkDebug("pure virtual function MkEntity::Draw() is called\n");}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  virtual void Draw(MkPaint *){MkDebug("pure virtual function MkEntity::Draw() is called\n");}
#endif
  virtual bool operator==(MkEntity &){return true;}
  virtual bool operator!=(MkEntity &){return false;}
};

class MkEntities {
protected:
    MkEntity *FEntity;
    int FSize;//Actual size of entities
    int FSizeOfArray;
#ifdef __BCPLUSPLUS__
    TColor Color;
#endif
public:
    MkEntities(int size,MkEntity *ent);
    MkEntities(int size);
    MkEntities(){FSizeOfArray = FSize = 0;FEntity = NULL;}
     ~MkEntities();
    virtual void Initialize(int size);
    virtual void Initialize(int size,MkEntity *);
    int GetSize(){return FSize;};
    int GetNumber(){return FSize;};
    bool Add(MkEntity &entity);  // change of size of entity
    bool Add(int index,MkEntity &entity);
    bool Delete(MkEntity &entity);  // change of size of entity
    bool Delete(int index);
    int Grow(int Delta);            // change of size of array
    int Shrink(int Delta);          // change of size of array
    bool Clear();
#ifdef __BCPLUSPLUS__
    TColor GetColor(){return Color;};
    void SetColor(TColor c){Color = c;}
    virtual void Out(TObject *){};
#else

#endif
    virtual void Out(char *fname){};

#ifdef __BCPLUSPLUS__
  void Draw(TObject *){MkDebug("pure virtual function MkEntities::Draw() is called\n");}
#endif
    
#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *){MkDebug("pure virtual function MkEntities::Draw() is called\n");}
#endif

    virtual MkEntity & operator[](int);
    MkEntities & operator=(MkEntities &entities);
    bool operator==(MkEntities &entities);
};
//---------------------------------------------------------------------------
class MkWall : public MkEntity {
protected:
  MkLine Wall;
public:
  MkWall(){}
  MkWall(int){}
  ~MkWall(){}
public:
  void SetLine(MkLine &w)
    {
      Wall=w;
      Wall.SetFiniteness(true);
      Depth = Wall[0].Y<Wall[1].Y?-Wall[0].Y:-Wall[1].Y;
      Length = Wall.GetLength();
    }
public:
  MkLine &GetLine(){return Wall;}
  bool operator==(MkWall &);
  bool operator!=(MkWall &);
  MkWall & operator=(MkWall &);

#ifdef __BCPLUSPLUS__
  AnsiString ClassName(){return AnsiString("MkWall");};
#else
  char * ClassName(){return "MkWall";}
#endif

#ifdef __BCPLUSPLUS__
  void  Draw(TObject *Sender){Wall.Draw(Sender);}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *pb){Wall.Draw(pb);}
#endif
};

class MkWalls {
protected:
    MkWall *FWall;
    int FSize;//Actual size of walls
    int FSizeOfArray;
#ifdef __BCPLUSPLUS__
    TColor Color;
#endif
public:
    MkWalls(int size,MkWall *wall);
    MkWalls(int size);
    MkWalls(){FSizeOfArray = FSize = 0;FWall = NULL;}
     ~MkWalls();
    virtual void Initialize(int size);
    virtual void Initialize(int size,MkWall *);
    int GetSize(){return FSize;};
    int GetNumber(){return FSize;};
    bool Add(MkWall &wall);  // change of size of wall
    bool Add(int index,MkWall &wall);
    bool Delete(MkWall &wall);  // change of size of wall
    bool Delete(int index);
    int Grow(int Delta);            // change of size of array
    int Shrink(int Delta);          // change of size of array
    bool Clear();
#ifdef __BCPLUSPLUS__
    TColor GetColor(){return Color;};
    void SetColor(TColor c){Color = c;}
#endif

#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif

    virtual MkWall & operator[](int);
    MkWalls & operator=(MkWalls &walls);
    bool operator==(MkWalls &walls);
};
//---------------------------------------------------------------------------
class MkCIP : public MkWall {
protected:

public:
  MkCIP(){}
  MkCIP(int ){}
  ~MkCIP();

#ifdef __BCPLUSPLUS__
  AnsiString ClassName(){return AnsiString("MkCIP");};
#else
  char* ClassName(){return "MkCIP";}
#endif

#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif
};

class MkCIPs {
protected:
    MkCIP *FCIP;
    int FSize;//Actual size of cips
    int FSizeOfArray;
#ifdef __BCPLUSPLUS__
    TColor Color;
#endif
public:
    MkCIPs(int size,MkCIP *cip);
    MkCIPs(int size);
    MkCIPs(){FSizeOfArray = FSize = 0;FCIP = NULL;}
     ~MkCIPs();
    virtual void Initialize(int size);
    virtual void Initialize(int size,MkCIP *);
    int GetSize(){return FSize;};
    int GetNumber(){return FSize;};
    bool Add(MkCIP &cip);  // change of size of cip
    bool Add(int index,MkCIP &cip);
    bool Delete(MkCIP &cip);  // change of size of cip
    bool Delete(int index);
    int Grow(int Delta);            // change of size of array
    int Shrink(int Delta);          // change of size of array
    bool Clear();
#ifdef __BCPLUSPLUS__
    TColor GetColor(){return Color;};
    void SetColor(TColor c){Color = c;}
#endif

#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif

    virtual MkCIP & operator[](int);
    MkCIPs & operator=(MkCIPs &cips);
    bool operator==(MkCIPs &cips);
};
//---------------------------------------------------------------------------
class MkSCW : public MkWall {
protected:

public:
  MkSCW(){}
  MkSCW(int){}
  ~MkSCW();
#ifdef __BCPLUSPLUS__
  AnsiString ClassName(){return AnsiString("MkSCW");};
#else
  char* ClassName(){return "MkSCW";}
#endif

};

class MkSCWs {
protected:
    MkSCW *FSCW;
    int FSize;//Actual size of scws
    int FSizeOfArray;
#ifdef __BCPLUSPLUS__
    TColor Color;
#endif
public:
    MkSCWs(int size,MkSCW *scw);
    MkSCWs(int size);
    MkSCWs(){FSizeOfArray = FSize = 0;FSCW = NULL;}
     ~MkSCWs();
    virtual void Initialize(int size);
    virtual void Initialize(int size,MkSCW *);
    int GetSize(){return FSize;};
    int GetNumber(){return FSize;};
    bool Add(MkSCW &scw);  // change of size of scw
    bool Add(int index,MkSCW &scw);
    bool Delete(MkSCW &scw);  // change of size of scw
    bool Delete(int index);
    int Grow(int Delta);            // change of size of array
    int Shrink(int Delta);          // change of size of array
    bool Clear();
#ifdef __BCPLUSPLUS__
    TColor GetColor(){return Color;};
    void SetColor(TColor c){Color = c;}
#endif

#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif

    virtual MkSCW & operator[](int);
    MkSCWs & operator=(MkSCWs &scws);
    bool operator==(MkSCWs &scws);
};

//---------------------------------------------------------------------------
class MkPile : public MkWall {
protected:
  float Area;
  float Spacing;
  float T1,T2;
  float Weight; 
  float Height; // H
  float Width;  // B
  float YoungMod;
  float ShearTor;
  float SecMomentY, SecMomentZ;  // second moment of inertial
  float YieldMom;

public:
  MkPile();
  MkPile(int n);
  ~MkPile(){};
public:
  void SetArea(float a){Area=a;}
  void SetSpacing(float s){Spacing=s;}
  void SetT1(float t){T1 = t;}
  void SetT2(float t){T2 = t;}
  void SetHeight(float h){Height=h;}
  void SetWidth(float w){Width=w;}
  void SetWeight(float w){Weight=w;}
  void SetYoungMod(float y){YoungMod = y;}
  void SetShearTor(float s){ShearTor = s;}
  void SetSecMomentY(float sm){SecMomentY=sm;}
  void SetSecMomentZ(float sm){SecMomentZ=sm;}
  void SetYieldMom(float ym){YieldMom=ym;}
public:
  float GetSpacing(){return Spacing;}
  float GetYoungMod(){return YoungMod;}
  float GetShearTor(){return ShearTor;}
  float GetSecMomentY(){return SecMomentY;}  // second moment of inertial
  float GetSecMomentZ(){return SecMomentZ;}  // second moment of inertial
public:
#ifdef __BCPLUSPLUS__
  AnsiString ClassName(){return AnsiString("MkPile");};
  bool UpdateFrom(TStringGrid *grid){Grid = grid;return UpdateFrom();}
  bool UpdateTo(TStringGrid *grid){Grid = grid;return UpdateTo();}
  bool UpdateFrom();
  bool UpdateTo();
  void Out(TObject *);
#else
  char* ClassName(){return "MkPile";}
#endif

  void Out(char *fname);

  MkLine &GetLine(){return Wall;}
  bool operator==(MkPile&);
  bool operator!=(MkPile&);
  MkPile &operator=(MkPile&);

#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
    void Draw(MkPaint *);
#endif
};

class MkPiles {
protected:
    MkPile *FPile;
    int FSize;//Actual size of entities
    int FSizeOfArray;
#ifdef __BCPLUSPLUS__
    TColor Color;
#endif
public:
    MkPiles(int size,MkPile *ent);
    MkPiles(int size);
    MkPiles(){FSizeOfArray = FSize = 0;FPile = NULL;}
     ~MkPiles();
    virtual void Initialize(int size);
    virtual void Initialize(int size,MkPile *);
    int GetSize(){return FSize;};
    int GetSizeOfArray(){return FSizeOfArray;}
    int GetNumber(){return FSize;};
    bool Add(MkPile &pile);  // change of size of pile
    bool Add(int index,MkPile &pile);
    bool Delete(MkPile &pile);  // change of size of pile
    bool Delete(int index);
    int Grow(int Delta);            // change of size of array
    int Shrink(int Delta);          // change of size of array
    bool Clear();
#ifdef __BCPLUSPLUS__
    TColor GetColor(){return Color;};
    void SetColor(TColor c){Color = c;}
    void Out(TObject *);
#else
#endif

    void Out(char *fname);
    
#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
    void Draw(MkPaint *);
#endif

    virtual MkPile & operator[](int);
    MkPiles & operator=(MkPiles &piles);
    bool operator==(MkPiles &piles);
};
//---------------------------------------------------------------------------
class MkStrata : public MkEntity {
protected:
  MkPolygon Strata;
  float WetUnitWeight[2];
  float SubUnitWeight[2];
  float Cohesion[2];
  float Friction[2];
  float HorSubReact[2]; // ���� ���ݹݷ°��(modulus of subgrade reaction
  float VerSubReact[2]; // ���� ���ݹݷ°��(modulus of subgrade reaction
  float Burden;
  float K0;
  float Ka;
  float Kp;
public:
  MkStrata();
  MkStrata(int n);
  ~MkStrata(){};
public: //setting function
  void SetStrata(MkPolygon &strata){Strata=strata;}
  void SetK0(float k0){K0 = k0;}
  void SetKa(float ka){Ka = ka;}
  void SetKp(float kp){Kp = kp;}
  void SetBurden(float burden){Burden=burden;}
  void SetWetUnitWeight(int n,float w){if(n>=0&&n<2) WetUnitWeight[n] = w;}
  void SetSubUnitWeight(int n,float w){if(n>=0&&n<2) SubUnitWeight[n] = w;}
  void SetCohesion(int n,float w){if(n>=0&&n<2) Cohesion[n] = w;}
  void SetFriction(int n,float w){if(n>=0&&n<2) Friction[n] = w;}
  void SetHorSubReact(int n,float w){if(n>=0&&n<2) HorSubReact[n] = w;}
  void SetVerSubReact(int n,float w){if(n>=0&&n<2) VerSubReact[n] = w;}
public:// getting function
  float GetWetUnitWeight(MkPoint &pnt);
  float GetCohesion(MkPoint &pnt);
  float GetFriction(MkPoint &pnt);
  float GetHorSubReact(MkPoint &pnt);
  float GetVerSubReact(MkPoint &pnt);
  float GetWetUnitWeight(MkLine &line);
  float GetCohesion(MkLine &line);
  float GetFriction(MkLine &line);
  float GetHorSubReact(MkLine &line);
  float GetVerSubReact(MkLine &line);
public: //key function
  MkPolygon &GetStrata(){return Strata;}
//  float GetWeight(){return (WetUnitWeight[0]+WetUnitWeight[1])/2.0*Rect.GetHeight();}
  bool IsIn(MkPoint &pnt){return Strata.IsIn(pnt);}
  bool IsIn(MkLine &line){return Strata.IsIn(line[0]) || Strata.IsIn(line[1]);}
  float InLen(MkLine &line);
  MkLine InLine(MkLine &line);

#ifdef __BCPLUSPLUS__
  AnsiString ClassName(){return AnsiString("MkStrata");}
  bool UpdateFrom(TStringGrid *grid){Grid = grid;return UpdateFrom();};
  bool UpdateTo(TStringGrid *grid){Grid = grid;return UpdateTo();};
  bool UpdateFrom();
  bool UpdateTo();
#else
  char* ClassName(){return "MkStrata";}
#endif

public: // operator function
  bool operator==(MkStrata&);
  bool operator!=(MkStrata&);

#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif
};

class MkStratum {
protected:
    MkStrata *FStrata;
    int FSize;//Actual size of entities
    int FSizeOfArray;
#ifdef __BCPLUSPLUS__
    TColor Color;
#endif
public:
    MkStratum(int size,MkStrata *ent);
    MkStratum(int size);
    MkStratum(){FSizeOfArray = FSize = 0;FStrata = NULL;}
     ~MkStratum();
    virtual void Initialize(int size);
    virtual void Initialize(int size,MkStrata *);
    bool Add(MkStrata &strata);  // change of size of ground
    bool Add(int index,MkStrata &strata);
    bool Delete(MkStrata &strata);  // change of size of ground
    bool Delete(int index);
    int Grow(int Delta);            // change of size of array
    int Shrink(int Delta);          // change of size of array

    int GetSize(){return FSize;};
    int GetNumber(){return FSize;};
    bool Clear();
#ifdef __BCPLUSPLUS__
    TColor GetColor(){return Color;};
    void SetColor(TColor c){Color = c;}
#endif

#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif

    virtual MkStrata & operator[](int);
    MkStratum & operator=(MkStratum &stratum);
    bool operator==(MkStratum &stratum);

    float GetWetUnitWeight(MkPoint &pnt)
      {
        for (int i=0;i<FSize;i++)
          if(FStrata[i].IsIn(pnt))
            return FStrata[i].GetWetUnitWeight(pnt);
        return 0;
      }
    float GetCohesion(MkPoint &pnt)
      {
        for (int i=0;i<FSize;i++)
          if(FStrata[i].IsIn(pnt))
            return FStrata[i].GetCohesion(pnt);
        return 0;
      }
    float GetFriction(MkPoint &pnt)
      {
        for (int i=0;i<FSize;i++)
          if(FStrata[i].IsIn(pnt))
            return FStrata[i].GetFriction(pnt);
        return 0;
      }
    float GetHorSubReact(MkPoint &pnt)
      {
        for (int i=0;i<FSize;i++)
          if(FStrata[i].IsIn(pnt))
            return FStrata[i].GetHorSubReact(pnt);
        return 0;
      }
    float GetVerSubReact(MkPoint &pnt)
      {
        for (int i=0;i<FSize;i++)
          if(FStrata[i].IsIn(pnt))
            return FStrata[i].GetVerSubReact(pnt);
        return 0;
      }
    float GetWetUnitWeight(MkLine &line)
      {
        float w=0,l;
        if(line.GetLength()<0.001) return GetWetUnitWeight(line[0]);
        for (int i=0;i<FSize;i++)
          if(FStrata[i].IsIn(line)) {
            l = FStrata[i].InLen(line);
            w+=FStrata[i].GetWetUnitWeight(line)*l;
          }
        return w/line.GetLength();
      }
    float GetCohesion(MkLine &line)
      {
        float c=0,l;
        if(line.GetLength()<0.001) return GetCohesion(line[0]);
        for (int i=0;i<FSize;i++)
          if(FStrata[i].IsIn(line)) {
            l = FStrata[i].InLen(line);
            c+= FStrata[i].GetCohesion(line)*l;
          }
         return c/line.GetLength();
      }
    float GetFriction(MkLine &line)
      {
        float f=0,l;
        if(line.GetLength()<0.001) return GetFriction(line[0]);
        for (int i=0;i<FSize;i++)
          if(FStrata[i].IsIn(line)) {
            l = FStrata[i].InLen(line);
            f+=FStrata[i].GetCohesion(line)*l;
          }
        return f/line.GetLength();
      }
    float GetHorSubReact(MkLine &line)
      {
        float h=0,l;
        if(line.GetLength()<0.001) return GetHorSubReact(line[0]);
        for (int i=0;i<FSize;i++)
          if(FStrata[i].IsIn(line)) {
            l = FStrata[i].InLen(line);
            h += FStrata[i].GetHorSubReact(line)*l;
          }
        return h/line.GetLength();
      }
    float GetVerSubReact(MkLine &line)
      {
        float v=0,l;
        if(line.GetLength()<0.001) return GetVerSubReact(line[0]);
        for (int i=0;i<FSize;i++)
          if(FStrata[i].IsIn(line)) {
            l = FStrata[i].InLen(line);
            v += FStrata[i].GetHorSubReact(line)*l;
          }
        return v/line.GetLength();
      }
};
//---------------------------------------------------------------------------
class MkCut;
class MkFill;

class MkLayer : public MkEntity {
protected:
  MkRect Rect;
  float WetUnitWeight[2];
  float SubUnitWeight[2];
  float Cohesion[2];
  float Friction[2];
  float HorSubReact[2]; // ���� ���ݹݷ°��(modulus of subgrade reaction
  float VerSubReact[2]; // ���� ���ݹݷ°��(modulus of subgrade reaction
  float Burden;
  float K0;
  float Ka;
  float Kp;
public:
  MkLayer();
  MkLayer(int n);
  ~MkLayer(){};
public:
  void SetRect(MkRect &rect){Rect=rect;}
  void SetK0(float k0){K0 = k0;}
  void SetKa(float ka){Ka = ka;}
  void SetKp(float kp){Kp = kp;}
  void SetBurden(float burden){Burden=burden;}
  void SetWetUnitWeight(int n,float w){if(n>=0&&n<2) WetUnitWeight[n] = w;}
  void SetSubUnitWeight(int n,float w){if(n>=0&&n<2) SubUnitWeight[n] = w;}
  void SetCohesion(int n,float w){if(n>=0&&n<2) Cohesion[n] = w;}
  void SetFriction(int n,float w){if(n>=0&&n<2) Friction[n] = w;}
  void SetHorSubReact(int n,float w){if(n>=0&&n<2) HorSubReact[n] = w;}
  void SetVerSubReact(int n,float w){if(n>=0&&n<2) VerSubReact[n] = w;}  
public:
  float GetActivPress(MkPoint &pnt);
  float GetPassivPress(MkPoint &pnt);
  float GetStopPress(MkPoint &pnt);
  float GetWetUnitWeight(MkPoint &pnt);
  float GetCohesion(MkPoint &pnt);
  float GetFriction(MkPoint &pnt);
  float GetHorSubReact(MkPoint &pnt);
  float GetVerSubReact(MkPoint &pnt);
  float GetK0(MkPoint &pnt);
  float GetKa(MkPoint &pnt);
  float GetKp(MkPoint &pnt);
  float GetWetUnitWeight(MkLine &line);
  float GetCohesion(MkLine &line);
  float GetFriction(MkLine &line);
  float GetHorSubReact(MkLine &line);
  float GetVerSubReact(MkLine &line);
  float GetK0(MkLine &line);
  float GetKa(MkLine &line);
  float GetKp(MkLine &line);

public: //key function
  MkRect &GetRect(){return Rect;}
//  float GetWeight(){return (WetUnitWeight[0]+WetUnitWeight[1])/2.0*Rect.GetHeight();}
  bool IsIn(MkPoint &pnt){return Rect.IsInSurface(pnt,(float)EPS) || Rect.IsIn(pnt);}
  bool IsIn(MkLine &line){return Rect.IsIn(line[0]) || Rect.IsIn(line[1]);}
  float InLen(MkLine &line);
  MkLine InLine(MkLine &line);
  void CalcCoeff();

#ifdef __BCPLUSPLUS__
  AnsiString ClassName(){return AnsiString("MkLayer");}
  bool UpdateFrom(TStringGrid *grid){Grid = grid;return UpdateFrom();};
  bool UpdateTo(TStringGrid *grid){Grid = grid;return UpdateTo();};
  bool UpdateFrom();
  bool UpdateTo();
  void Out(TObject *);
#else
  char* ClassName(){return "MkLayer";}
#endif
  void Out(char *fname);

#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif

public: // operator function

  bool operator==(MkLayer&);
  bool operator!=(MkLayer&);
  MkLayer & operator=(MkLayer&);
};

class MkLayers {
protected:
    MkLayer *FLayer;
    int FSize;//Actual size of entities
    int FSizeOfArray;
#ifdef __BCPLUSPLUS__
    TColor Color;
#endif
public:
    MkLayers(int size,MkLayer *ent);
    MkLayers(int size);
    MkLayers(){FSizeOfArray = FSize = 0;FLayer = NULL;}
     ~MkLayers();
    virtual void Initialize(int size);
    virtual void Initialize(int size,MkLayer *);

    bool Add(MkLayer &layer);  // change of size of ground
    bool Add(int index,MkLayer &layer);
    bool Delete(MkLayer &layer);  // change of size of ground
    bool Delete(int index);
    int Grow(int Delta);            // change of size of array
    int Shrink(int Delta);          // change of size of array

    void SetupPress();
    int GetSize(){return FSize;};
    int GetNumber(){return FSize;};

    bool Apply(MkCut &);
    bool Apply(MkFill &);

    bool Clear();
    virtual MkLayer & operator[](int);

    MkLayers & operator=(MkLayers &layers);
    bool operator==(MkLayers &layers);
#ifdef __BCPLUSPLUS__
    TColor GetColor(){return Color;};
    void SetColor(TColor c){Color = c;}
    void Out(TObject *);
#else
#endif

  void Out(char *fname);
  
    float GetStopPress(MkPoint &pnt)
      {
        for (int i=0;i<FSize;i++)
          if(FLayer[i].IsIn(pnt))
            return FLayer[i].GetStopPress(pnt);
        return 0;
      }
    float GetActivPress(MkPoint &pnt)
      {
        for (int i=0;i<FSize;i++)
          if(FLayer[i].IsIn(pnt))
            return FLayer[i].GetActivPress(pnt);
        return 0;
      }
    float GetPassivPress(MkPoint &pnt)
      {
        for (int i=0;i<FSize;i++)
          if(FLayer[i].IsIn(pnt))
            return FLayer[i].GetPassivPress(pnt);
        return 0;
      }
    float GetWetUnitWeight(MkPoint &pnt)
      {
        for (int i=0;i<FSize;i++)
          if(FLayer[i].IsIn(pnt))
            return FLayer[i].GetWetUnitWeight(pnt);
        return 0;
      }
    float GetCohesion(MkPoint &pnt)
      {
        for (int i=0;i<FSize;i++)
          if(FLayer[i].IsIn(pnt))
            return FLayer[i].GetCohesion(pnt);
        return 0;
      }
    float GetFriction(MkPoint &pnt)
      {
        for (int i=0;i<FSize;i++)
          if(FLayer[i].IsIn(pnt))
            return FLayer[i].GetFriction(pnt);
        return 0;
      }
    float GetHorSubReact(MkPoint &pnt)
      {
        for (int i=0;i<FSize;i++)
          if(FLayer[i].IsIn(pnt))
            return FLayer[i].GetHorSubReact(pnt);
        return 0;
      }
    float GetVerSubReact(MkPoint &pnt)
      {
        for (int i=0;i<FSize;i++)
          if(FLayer[i].IsIn(pnt))
            return FLayer[i].GetVerSubReact(pnt);
        return 0;
      }
    float GetK0(MkPoint &pnt)
      {
        for (int i=0;i<FSize;i++)
          if(FLayer[i].IsIn(pnt))
            return FLayer[i].GetK0(pnt);
        return 0;
      }
    float GetKa(MkPoint &pnt)
      {
        for (int i=0;i<FSize;i++)
          if(FLayer[i].IsIn(pnt))
            return FLayer[i].GetKa(pnt);
        return 0;
      }
    float GetKp(MkPoint &pnt)
      {
        for (int i=0;i<FSize;i++)
          if(FLayer[i].IsIn(pnt))
            return FLayer[i].GetKp(pnt);
        return 0;
      }
    float GetWetUnitWeight(MkLine &line)
      {
        float w=0,l;
        if(line.GetLength()<0.001) return GetWetUnitWeight(line[0]);
        for (int i=0;i<FSize;i++)
          if(FLayer[i].IsIn(line)) {
            l = FLayer[i].InLen(line);
            w+=FLayer[i].GetWetUnitWeight(line)*l;
          }
        return w/line.GetLength();
      }
    float GetCohesion(MkLine &line)
      {
        float c=0,l;
        if(line.GetLength()<0.001) return GetCohesion(line[0]);
        for (int i=0;i<FSize;i++)
          if(FLayer[i].IsIn(line)) {
            l = FLayer[i].InLen(line);
            c+= FLayer[i].GetCohesion(line)*l;
          }
         return c/line.GetLength();
      }
    float GetFriction(MkLine &line)
      {
        float f=0,l;
        if(line.GetLength()<0.001) return GetFriction(line[0]);
        for (int i=0;i<FSize;i++)
          if(FLayer[i].IsIn(line)) {
            l = FLayer[i].InLen(line);
            f+=FLayer[i].GetCohesion(line)*l;
          }
        return f/line.GetLength();
      }
    float GetHorSubReact(MkLine &line)
      {
        float h=0,l;
        if(line.GetLength()<0.001) return GetHorSubReact(line[0]);
        for (int i=0;i<FSize;i++)
          if(FLayer[i].IsIn(line)) {
            l = FLayer[i].InLen(line);
            h += FLayer[i].GetHorSubReact(line)*l;
          }
        return h/line.GetLength();
      }
    float GetVerSubReact(MkLine &line)
      {
        float v=0,l;
        if(line.GetLength()<0.001) return GetVerSubReact(line[0]);
        for (int i=0;i<FSize;i++)
          if(FLayer[i].IsIn(line)) {
            l = FLayer[i].InLen(line);
            v += FLayer[i].GetHorSubReact(line)*l;
          }
        return v/line.GetLength();
      }
    float GetK0(MkLine &line)
      {
        float v=0,l;
        if(line.GetLength()<0.001) return GetVerSubReact(line[0]);
        for (int i=0;i<FSize;i++)
          if(FLayer[i].IsIn(line)) {
            l = FLayer[i].InLen(line);
            v += FLayer[i].GetK0(line)*l;
          }
        return v/line.GetLength();
      }
    float GetKa(MkLine &line)
      {
        float v=0,l;
        if(line.GetLength()<0.001) return GetVerSubReact(line[0]);
        for (int i=0;i<FSize;i++)
          if(FLayer[i].IsIn(line)) {
            l = FLayer[i].InLen(line);
            v += FLayer[i].GetKa(line)*l;
          }
        return v/line.GetLength();
      }
    float GetKp(MkLine &line)
      {
        float v=0,l;
        if(line.GetLength()<0.001) return GetVerSubReact(line[0]);
        for (int i=0;i<FSize;i++)
          if(FLayer[i].IsIn(line)) {
            l = FLayer[i].InLen(line);
            v += FLayer[i].GetKp(line)*l;
          }
        return v/line.GetLength();
      }
 
#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
    void Draw(MkPaint *);
#endif

};
//---------------------------------------------------------------------------
class MkCut : public MkEntity {
protected:
  MkWall *Wall[2];
public:
  MkCut();
  MkCut(int );
  ~MkCut(){}
  void SetWall(MkWall *wall){Wall[0] = wall;}
  void SetWall(MkWall *wall, int n){if (n<0||n>2) return;Wall[n]=wall;}
public:
  MkWall *GetWall(int n){if (0<=n && n < 2) return Wall[n];else return NULL;}

#ifdef __BCPLUSPLUS__
  AnsiString ClassName(){return AnsiString("MkCut");}; 
  bool UpdateFrom(TStringGrid*){return false;}
  bool UpdateTo(TStringGrid*){return false;}
  bool UpdateFrom();
  bool UpdateTo();
  void Out(TObject *);
#else
  char* ClassName(){return "MkCut";}
#endif

  void Out(char *fname);

#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif

  bool operator==(MkCut &);
  bool operator!=(MkCut &);
  MkCut& operator=(MkCut& cut);
};

class MkCuts {
protected:
    MkCut *FCut;
    int FSize;//Actual size of entities
    int FSizeOfArray;
#ifdef __BCPLUSPLUS__
    TColor Color;
#endif
public:
    MkCuts(int size,MkCut *ent);
    MkCuts(int size);
    MkCuts(){FSizeOfArray = FSize = 0;FCut = NULL;}
     ~MkCuts();
    virtual void Initialize(int size);
    virtual void Initialize(int size,MkCut *);
    int GetSize(){return FSize;};
    int GetNumber(){return FSize;};
    bool Add(MkCut &cut);  // change of size of cut
    bool Add(int index,MkCut &cut);
    bool Delete(MkCut &cut);  // change of size of cut
    bool Delete(int index);
    int Grow(int Delta);            // change of size of array
    int Shrink(int Delta);          // change of size of array
    bool Clear();
#ifdef __BCPLUSPLUS__
    TColor GetColor(){return Color;};
    void SetColor(TColor c){Color = c;}
    void Out(TObject *);
#else
#endif

    void Out(char *fname);

#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif

    virtual MkCut & operator[](int);
    MkCuts & operator=(MkCuts &cuts);
    bool operator==(MkCuts &cuts);
};
//---------------------------------------------------------------------------
class MkFill : public MkEntity {
protected:
  float WetUnitWeight;
  float SubUnitWeight;
  float Cohesion;
  float Friction;
  float HorSubReact; // ���� ���ݹݷ°��(modulus of subgrade reaction
  float VerSubReact; // ���� ���ݹݷ°��(modulus of subgrade reaction
  float Burden;
  float K0;
  float Ka;
  float Kp;

  MkWall *Wall[2];
public:
  MkFill();
    MkFill(int );
  ~MkFill(){}
  void SetWall(MkWall *wall){Wall[0] = wall;}
  void SetWall(MkWall *wall, int n){if (n<0||n>2) return;Wall[n]=wall;}
  void SetK0(float k0){K0 = k0;}
  void SetKa(float ka){Ka = ka;}
  void SetKp(float kp){Kp = kp;}
  void SetWetUnitWeight(float w){WetUnitWeight = w;}
  void SetSubUnitWeight(float w){SubUnitWeight = w;}
  void SetCohesion(float w){Cohesion = w;}
  void SetFriction(float w){Friction = w;}
  void SetHorSubReact(float w){HorSubReact = w;}
  void SetVerSubReact(float w){VerSubReact = w;}

public:
  float GetK0(){return K0;}
  float GetKa(){return Ka;}
  float GetKp(){return Kp;}
  float GetWetUnitWeight(){return WetUnitWeight;}
  float GetSubUnitWeight(){return SubUnitWeight;}
  float GetCohesion(){return Cohesion;}
  float GetFriction(){return Friction;}
  float GetHorSubReact(){return HorSubReact;}
  float GetVerSubReact(){return VerSubReact;}  

#ifdef __BCPLUSPLUS__
  AnsiString ClassName(){return AnsiString("MkFill");};
  bool UpdateFrom(TStringGrid* grid){Grid=grid;UpdateFrom();}
  bool UpdateTo(TStringGrid* grid){Grid=grid;UpdateTo();}
  bool UpdateFrom();
  bool UpdateTo();
  void Out(TObject *);
#else
  char* ClassName(){return "MkFill";}
#endif

  void Out(char *fname);

#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif
  
#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif

  bool operator==(MkFill &fill);
  bool operator!=(MkFill &fill);
  MkFill& operator=(MkFill &fill);
};

class MkFills {
protected:
    MkFill *FFill;
    int FSize;//Actual size of entities
    int FSizeOfArray;
#ifdef __BCPLUSPLUS__
    TColor Color;
#endif
public:
    MkFills(int size,MkFill *ent);
    MkFills(int size);
    MkFills(){FSizeOfArray = FSize = 0;FFill = NULL;}
     ~MkFills();
    virtual void Initialize(int size);
    virtual void Initialize(int size,MkFill *);
    int GetSize(){return FSize;};
    int GetNumber(){return FSize;};
    bool Add(MkFill &fill);  // change of size of fill
    bool Add(int index,MkFill &fill);
    bool Delete(MkFill &fill);  // change of size of fill
    bool Delete(int index);
    int Grow(int Delta);            // change of size of array
    int Shrink(int Delta);          // change of size of array
    bool Clear();
#ifdef __BCPLUSPLUS__
    TColor GetColor(){return Color;};
    void SetColor(TColor c){Color = c;}
    void Out(TObject *);
#else
#endif

    void Out(char *fname);

    virtual MkFill & operator[](int);
    MkFills & operator=(MkFills &fills);
    bool operator==(MkFills &fills);

#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif
    
#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif
};

//---------------------------------------------------------------------------
class MkStrut : public MkEntity {
protected:
  MkLine StrutLine;
  float Area;
  float Spacing;
  float JackingForce;
  float IniDisp;
  float StressLoss;
  float RakerAng;
  float T1,T2;
  float Width;
  float Height;
  float Weight;
  float YoungMod;
  float ShearTor;
  float SecMomentY, SecMomentZ;  // second moment of inertial
  float RadX,RadY;  // radius for second moment of inertia

public:
  MkStrut();
  MkStrut(int n);
  ~MkStrut(){};
public: //setting function
  void SetArea(float a){Area=a;}
  void SetSpacing(float hs){Spacing=hs;}
  void SetJackingForce(float is){JackingForce=is;}
  void SetIniDisp(float id){IniDisp=id;}
  void SetStressLoss(float sl){StressLoss=sl;}
  void SetRakerAng(float ra){RakerAng=ra;}
  void SetT1(float t){T1=t;}
  void SetT2(float t){T2=t;}
  void SetWidth(float w){Width=w;}
  void SetHeight(float h){Height=h;}
  void SetWeight(float w){Weight=w;}
  void SetYoungMod(float y){YoungMod = y;}
  void SetShearTor(float s){ShearTor = s;}
  void SetSecMomentY(float sm){SecMomentY=sm;}
  void SetSecMomentZ(float sm){SecMomentZ=sm;}
  void SetRadX(float rx){RadX = rx;}
  void SetRadY(float ry){RadY = ry;}
  void SetLine(MkLine &line)
    {
      StrutLine = line;
      StrutLine.SetFiniteness(true);
      Depth = -StrutLine[0].Y;
      Length = StrutLine.GetLength();
    };
public: //getting function
  float GetArea(){return Area;}
  float GetSpacing(){return Spacing;}
  float GetJackingForce(){return JackingForce;}
  float GetIniDisp(){return IniDisp;}
  float GetStressLoss(){return StressLoss;}
  float GetRakerAng(){return RakerAng;}
  float GetT1(){return T1;}
  float GetT2(){return T2;}
  float GetWidth(){return Width;}
  float GetHeight(){return Height;}
  float GetWeight(){return Weight;}
  float GetYoungMod(){return YoungMod;}
  float GetShearTor(){return ShearTor;}
  float GetSecMomentY(){return SecMomentY;}  // second moment of inertial
  float GetSecMomentZ(){return SecMomentZ;}  // second moment of inertial
  float GetRadX(){return RadX;}
  float GetRadY(){return RadY;}  // radius for second moment of inertia
  MkLine &GetLine(){return StrutLine;}

public: 
#ifdef __BCPLUSPLUS__
  AnsiString ClassName(){return AnsiString("MkStrut");};
  bool UpdateFrom(TStringGrid *grid){Grid = grid;return UpdateFrom();};
  bool UpdateTo(TStringGrid *grid){Grid = grid;return UpdateTo();};
  bool UpdateFrom();
  bool UpdateTo();
  void Out(TObject *);
#else
  char* ClassName(){return "MkStrut";}
#endif

  void Out(char *);
  
#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif
  bool operator==(MkStrut&);
  bool operator!=(MkStrut&);
  MkStrut&operator=(MkStrut&);
};

class MkStruts {
protected:
    MkStrut *FStrut;
    int FSize;//Actual size of entities
    int FSizeOfArray;
#ifdef __BCPLUSPLUS__
    TColor Color;
#endif
public:
    MkStruts(int size,MkStrut *ent);
    MkStruts(int size);
    MkStruts(){FSizeOfArray = FSize = 0;FStrut = NULL;}
     ~MkStruts();
    virtual void Initialize(int size);
    virtual void Initialize(int size,MkStrut *);
    int GetSize(){return FSize;};
    int GetNumber(){return FSize;};
    bool Add(MkStrut &strut);  // change of size of strut
    bool Add(int index,MkStrut &strut);
    bool Delete(MkStrut &strut);  // change of size of strut
    bool Delete(int index);
    int Grow(int Delta);            // change of size of array
    int Shrink(int Delta);          // change of size of array
    bool Clear();
#ifdef __BCPLUSPLUS__
    TColor GetColor(){return Color;};
    void SetColor(TColor c){Color = c;}
    void Out(TObject *);
#else
#endif

    void Out(char *fname);
#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif

    virtual MkStrut & operator[](int);
    MkStruts & operator=(MkStruts &struts);
    bool operator==(MkStruts &struts);
};
//---------------------------------------------------------------------------
class MkRetainPanel : public MkEntity {
protected:
  float Thick;
  float Press;
  float Width;
  float BendCompStressAllow;
  float Moment;
public:
  MkRetainPanel();
  MkRetainPanel(int );
  ~MkRetainPanel(){}
public: // Setting
  void SetCompStress(float str){BendCompStressAllow = str;}
  void SetMoment(float mom){Moment = mom;}
  void SetPress(float p){Press = p;}
  void SetWidth(float w){Width = w;}
  void SetThick(float t){Thick = t;}
#ifdef __BCPLUSPLUS__
  bool UpdateFrom();
  bool UpdateTo();
#endif

#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif

  bool operator==(MkRetainPanel&);
  bool operator!=(MkRetainPanel&);
  MkRetainPanel & operator=(MkRetainPanel&);
};

class MkRetainPanels {
protected:
    MkRetainPanel *FRetainPanel;
    int FSize; // Actual size of entities
    int FSizeOfArray;
#ifdef __BCPLUSPLUS__
    TColor Color;
#endif
public:
    MkRetainPanels(int size,MkRetainPanel *ent);
    MkRetainPanels(int size);
    MkRetainPanels(){FSizeOfArray = FSize = 0;FRetainPanel = NULL;}
    ~MkRetainPanels();
    virtual void Initialize(int size);
    virtual void Initialize(int size,MkRetainPanel *);
    int GetSize(){return FSize;};
    int GetNumber(){return FSize;};
    bool Add(MkRetainPanel &retainpan);  // change of size of retainpan
    bool Add(int index,MkRetainPanel &retainpan);
    bool Delete(MkRetainPanel &retainpan);  // change of size of retainpan
    bool Delete(int index);
    int Grow(int Delta);            // change of size of array
    int Shrink(int Delta);          // change of size of array
    bool Clear();
#ifdef __BCPLUSPLUS__
    TColor GetColor(){return Color;};
    void SetColor(TColor c){Color = c;}
#endif

#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
    void Draw(MkPaint *);
#endif

    virtual MkRetainPanel & operator[](int);
    MkRetainPanels & operator=(MkRetainPanels &retainpans);
    bool operator==(MkRetainPanels &retainpans);
};
//---------------------------------------------------------------------------
class MkWale : public MkEntity {
protected:
  MkLine WaleLine;

public:
  MkWale();
  MkWale(int n);
  ~MkWale(){};
#ifdef __BCPLUSPLUS__
  AnsiString ClassName(){return AnsiString("MkWale");};
  bool UpdateFrom(TStringGrid *grid){Grid = grid;return UpdateFrom();};
  bool UpdateTo(TStringGrid *grid){Grid = grid;return UpdateTo();};
  bool UpdateFrom();
  bool UpdateTo();
  void Out(TObject *);
#else
  char* ClassName(){return "MkWale";}
#endif

  void Out(char *fname);
  
#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif

  bool operator==(MkWale&);
  bool operator!=(MkWale&);
  MkWale& operator=(MkWale& wale);
};

class MkWales {
protected:
    MkWale *FWale;
    int FSize;//Actual size of entities
    int FSizeOfArray;
#ifdef __BCPLUSPLUS__
    TColor Color;
#endif
public:
    MkWales(int size,MkWale *ent);
    MkWales(int size);
    MkWales(){FSizeOfArray = FSize = 0;FWale = NULL;}
    ~MkWales();
    virtual void Initialize(int size);
    virtual void Initialize(int size,MkWale *);
    int GetSize(){return FSize;};
    int GetNumber(){return FSize;};
    bool Add(MkWale &wale);  // change of size of wale
    bool Add(int index,MkWale &wale);
    bool Delete(MkWale &wale);  // change of size of wale
    bool Delete(int index);
    int Grow(int Delta);            // change of size of array
    int Shrink(int Delta);          // change of size of array
    bool Clear();
#ifdef __BCPLUSPLUS__
    TColor GetColor(){return Color;};
    void SetColor(TColor c){Color = c;}
    void Out(TObject *);
#else
#endif

    void Out(char *fname);
    
#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif

    virtual MkWale & operator[](int);
    MkWales & operator=(MkWales &wales);
    bool operator==(MkWales &wales);
};
//---------------------------------------------------------------------------
enum MkInstallSide {isNone=0,isLeft,isRight};
class MkAnchor : public MkEntity {
protected:
  MkLine AnchorLine;
  float Area;
  float Angle;
  float Spacing;
  float JackingForce;
  float TenLoss;
  float IniDis;
  float WireNum;
  float FreeLength;
  float StickLength;
  float JackForce;
  float YoungMod;
  float ShearTor;
  float SecMomentY, SecMomentZ;  // second moment of inertial
  MkInstallSide InstallSide;

public:
  MkAnchor();
  MkAnchor(int n);
  ~MkAnchor(){};
public: // setting function
  void SetArea(float a){Area=a;}
  void SetAngle(float a){Angle=a;}
  void SetSpacing(float s){Spacing=s;}
  void SetYoungMod(float y){YoungMod = y;}
  void SetJackingForce(float it){JackingForce=it;}
  void SetTenLoss(float tl){TenLoss=tl;}
  void SetIniDis(float id){IniDis=id;}
  void SetWireNum(float wn){WireNum=wn;}
  void SetFreeLength(float fl){FreeLength=fl;}
  void SetStickLength(float sl){StickLength=sl;}
  void SetJackForce(float f){JackForce=f;}
  void SetSide(MkInstallSide is){InstallSide = is;}
public:
  float GetArea(){return Area;}
  float GetSpacing(){return Spacing;}
  float GetYoungMod(){return YoungMod;}
  float GetShearTor(){return ShearTor;}
  float GetSecMomentY(){return SecMomentY;}  // second moment of inertial
  float GetSecMomentZ(){return SecMomentZ;}  // second moment of inertial
  MkInstallSide GetSide(){return InstallSide;}
  float GetJackingForce(){return JackingForce;}
public:
#ifdef __BCPLUSPLUS__
  AnsiString ClassName(){return AnsiString("MkAnchor");};
  bool UpdateFrom(TStringGrid *grid){Grid = grid;return UpdateFrom();};
  bool UpdateTo(TStringGrid *grid){Grid = grid;return UpdateTo();};
  bool UpdateFrom();
  bool UpdateTo();
  void Out(TObject *);
#else
  char* ClassName(){return "MkAnchor";}
#endif

  void Out(char *fname);

#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif
  void SetLine(MkLine &line)
    {
      AnchorLine = line;
      AnchorLine.SetFiniteness(true);
      Depth = -AnchorLine[0].Y;
      Length = AnchorLine.GetLength();
    };
  MkLine &GetLine(){return AnchorLine;}
  bool operator==(MkAnchor&);
  bool operator!=(MkAnchor&);
  MkAnchor &operator=(MkAnchor&);
};

class MkAnchors {
protected:
    MkAnchor *FAnchor;
    int FSize;//Actual size of entities
    int FSizeOfArray;
#ifdef __BCPLUSPLUS__
    TColor Color;
#endif
public:
    MkAnchors(int size,MkAnchor *ent);
    MkAnchors(int size);
    MkAnchors(){FSizeOfArray = FSize = 0;FAnchor = NULL;}
    ~MkAnchors();
    virtual void Initialize(int size);
    virtual void Initialize(int size,MkAnchor *);
    int GetSize(){return FSize;};
    int GetNumber(){return FSize;};
    bool Add(MkAnchor &anchor);  // change of size of anchor
    bool Add(int index,MkAnchor &anchor);
    bool Delete(MkAnchor &anchor);  // change of size of anchor
    bool Delete(int index);
    int Grow(int Delta);            // change of size of array
    int Shrink(int Delta);          // change of size of array
    bool Clear();
#ifdef __BCPLUSPLUS__
    TColor GetColor(){return Color;};
    void SetColor(TColor c){Color = c;}
    void Out(TObject *);
#else
#endif
    void Out(char *fname);
#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif

    virtual MkAnchor & operator[](int);
    MkAnchors & operator=(MkAnchors &anchors);
    bool operator==(MkAnchors &anchors);
};
//---------------------------------------------------------------------------
class MkBolt : public MkEntity {
protected:
  MkLine BoltLine;
  float Area;
  float Angle;
  float Spacing;
  float YoungMod;
  float ShearTor;
  float SecMomentY, SecMomentZ;  // second moment of inertial
  MkInstallSide InstallSide;

public:
  MkBolt();
  MkBolt(int n);
  ~MkBolt(){};
public: //setting function
  void SetArea(float a){Area=a;}
  void SetAngle(float a){Angle=a;}
  void SetSpacing(float s){Spacing=s;}
  void SetLength(float l){Length=l;}
  void SetYoungMod(float y){YoungMod = y;}
  void SetShearTor(float s){ShearTor = s;}
  void SetSecMomentY(float sm){SecMomentY=sm;}
  void SetSecMomentZ(float sm){SecMomentZ=sm;}
  void SetSide(MkInstallSide is){InstallSide = is;}
public:
  float GetSpacing(){return Spacing;}
  float GetYoungMod(){return YoungMod;}
  float GetArea(){return Area;}
  float GetShearTor(){return ShearTor;}
  float GetSecMomentY(){return SecMomentY;}  // second moment of inertial
  float GetSecMomentZ(){return SecMomentZ;}  // second moment of inertial
  MkInstallSide GetSide(){return InstallSide;}
public:
#ifdef __BCPLUSPLUS__
  AnsiString ClassName(){return AnsiString("MkBolt");};
  bool UpdateFrom(TStringGrid *grid){Grid = grid;return UpdateFrom();};
  bool UpdateTo(TStringGrid *grid){Grid = grid;return UpdateTo();};
  bool UpdateFrom();
  bool UpdateTo();
  void Out(TObject *);
#else
  char* ClassName(){return "MkBolt";}
#endif
  void Out(char *fname);
#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif

  void SetLine(MkLine &line)
    {
      BoltLine = line;
      BoltLine.SetFiniteness(true);
      Depth = -BoltLine[0].Y;
      Length = BoltLine.GetLength();
    }
  MkLine &GetLine(){return BoltLine;}
  bool operator==(MkBolt&);
  bool operator!=(MkBolt&);
  MkBolt& operator=(MkBolt&);
};

class MkBolts {
protected:
    MkBolt *FBolt;
    int FSize;//Actual size of entities
    int FSizeOfArray;
#ifdef __BCPLUSPLUS__
    TColor Color;
#endif
public:
    MkBolts(int size,MkBolt *ent);
    MkBolts(int size);
    MkBolts(){FSizeOfArray = FSize = 0;FBolt = NULL;}
    ~MkBolts();
    virtual void Initialize(int size);
    virtual void Initialize(int size,MkBolt *);
    int GetSize(){return FSize;};
    int GetNumber(){return FSize;};
    bool Add(MkBolt &bolt);  // change of size of bolt
    bool Add(int index,MkBolt &bolt);
    bool Delete(MkBolt &bolt);  // change of size of bolt
    bool Delete(int index);
    int Grow(int Delta);            // change of size of array
    int Shrink(int Delta);          // change of size of array
    bool Clear();
#ifdef __BCPLUSPLUS__
    TColor GetColor(){return Color;};
    void SetColor(TColor c){Color = c;}
    void Out(TObject *);
#else
#endif

    void Out(char *fname);
    
#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif

    virtual MkBolt & operator[](int);
    MkBolts & operator=(MkBolts &bolts);
    bool operator==(MkBolts &bolts);
};

//---------------------------------------------------------------------------
class MkSlab : public MkEntity {
protected:
  MkLine SlabLine;
  float Area;
  float Angle;
  float YoungMod;
  float ShearTor;
  float SecMomentY, SecMomentZ;  // second moment of inertial
public:
  MkSlab();
  MkSlab(int n);
  ~MkSlab(){};
  void SetYoungMod(float y){YoungMod = y;}
  void SetShearTor(float s){ShearTor = s;}
  void SetSecMomentY(float sm){SecMomentY=sm;}
  void SetSecMomentZ(float sm){SecMomentZ=sm;}

#ifdef __BCPLUSPLUS__
  AnsiString ClassName(){return AnsiString("MkSlab");};
  bool UpdateFrom(TStringGrid *grid){Grid = grid;return UpdateFrom();};
  bool UpdateTo(TStringGrid *grid){Grid = grid;return UpdateTo();};
  bool UpdateFrom();
  bool UpdateTo();
  void Out(TObject *);
#else
  char* ClassName(){return "MkSlab";}
#endif

  void Out(char *fname);

  void SetLine(MkLine &line){SlabLine = line;SlabLine.SetFiniteness(true);}
  MkLine &GetLine(){return SlabLine;}
  bool operator==(MkSlab&);
  bool operator!=(MkSlab&);
  MkSlab & operator=(MkSlab&);

#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif
  
#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif

};

class MkSlabs {
protected:
    MkSlab *FSlab;
    int FSize;//Actual size of entities
    int FSizeOfArray;
#ifdef __BCPLUSPLUS__
    TColor Color;
#endif
public:
    MkSlabs(int size,MkSlab *ent);
    MkSlabs(int size);
    MkSlabs(){FSizeOfArray = FSize = 0;FSlab = NULL;}
    ~MkSlabs();
    virtual void Initialize(int size);
    virtual void Initialize(int size,MkSlab *);
    int GetSize(){return FSize;};
    int GetNumber(){return FSize;};
    bool Add(MkSlab &bolt);  // change of size of bolt
    bool Add(int index,MkSlab &bolt);
    bool Delete(MkSlab &bolt);  // change of size of bolt
    bool Delete(int index);
    int Grow(int Delta);            // change of size of array
    int Shrink(int Delta);          // change of size of array
    bool Clear();
#ifdef __BCPLUSPLUS__
    TColor GetColor(){return Color;};
    void SetColor(TColor c){Color = c;}
    void Out(TObject *);
#else
#endif

    void Out(char *fname);

#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif

    virtual MkSlab & operator[](int);
    MkSlabs & operator=(MkSlabs &bolts);
    bool operator==(MkSlabs &bolts);
};

extern MkEntity NullEntity;
extern MkLayer NullLayer;
extern MkStrata NullStrata;
extern MkLayers NullLayers;
extern MkStratum NullStratum;
extern MkPile NullPile;
extern MkStrut NullStrut;
extern MkWale NullWale;
extern MkAnchor NullAnchor;
extern MkBolt NullBolt;
extern MkCut  NullCut;
extern MkFill NullFill;
extern MkSlab NullSlab;
extern MkRetainPanel NullRetainPanel;
//---------------------------------------------------------------------------
#endif
