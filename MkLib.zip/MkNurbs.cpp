//---------------------------------------------------------------------------
#include "MkNurbs.h"

static bool isNurbInitialized=false;

MkNurbs::MkNurbs()
{
  if(!isNurbInitialized) {
    nrb_initialise();
    isNurbInitialized = true;
  }
  nrb_clear(&FNurbs);
}

MkNurbs::~MkNurbs()
{
  nrb_clear(&FNurbs);
}

void MkNurbs::AllocateKnots(NurbsDirection nd)
{
  nd == ndU ? nrb_allocateknots(&FNurbs.pf_u):nrb_allocateknots(&FNurbs.pf_v);
}

void MkNurbs::AllocatePoints()
{
  int n = FNurbs.pf_u.pf_n*FNurbs.pf_v.pf_n;
  nrb_allocatepts(n,&FNurbs.pf_ppp);
}

void MkNurbs::Boehmc(PR_dir dir, PR_nurb &new_nurb)
{
  nrb_boehmc(&FNurbs,&dir,&new_nurb);
}

void MkNurbs::Bvalue(float u, int deriv, PR_nurb &new_nurb)
{
  nrb_bvalue(&FNurbs, u, deriv, &new_nurb);
}

void MkNurbs::Clear()
{
  nrb_clear(&FNurbs);
}

void MkNurbs::Copy(PR_nurb &nurb)
{
  nrb_copy(&nurb,&FNurbs);
}

void MkNurbs::CopyKnots(NurbsDirection nd, PR_nurb &nurb)
{
  nd == ndU ? nrb_copyknots(&nurb.pf_u,&FNurbs.pf_u):nrb_copyknots(&nurb.pf_v,&FNurbs.pf_v);
}

void MkNurbs::DeallocateKnots(NurbsDirection nd)
{
  nd == ndU ? nrb_deallocateknots(&FNurbs.pf_u):nrb_deallocateknots(&FNurbs.pf_v);
}

void MkNurbs::DeallocatePoints(void)
{
  nrb_deallocatepts(&FNurbs.pf_ppp);
}

void MkNurbs::DifferenceKnots(NurbsDirection nd, PR_dir &k1, PR_dir &k2)
{
  PR_dir *kk;
  kk = nd == ndU ? &FNurbs.pf_u : &FNurbs.pf_v;
  kk->pf_nt < k1.pf_nt ? nrb_differenceknots(kk, &k1, &k2):nrb_differenceknots(&k1,kk,&k2);
}

void MkNurbs::Du(float x, MkPoints &rps)
{
  PR_pts *points;
  int num;
  nrb_du(&FNurbs,x,&points);
  num = points->pf_size;
  rps.Initialize(num);
  for (int i = 0 ; i < num ; i ++)
    if (fabs(points->pts[i].w)>0.00001) {
      rps[i].X = points->pts[i].x/points->pts[i].w;
      rps[i].Y = points->pts[i].y/points->pts[i].w;
      rps[i].Z = points->pts[i].z/points->pts[i].w;
    }
    else {
      rps[i].X = points->pts[i].x;
      rps[i].Y = points->pts[i].y;
      rps[i].Z = points->pts[i].z;
    }
}

void MkNurbs::Dump(char *fname)
{
  FILE *fp;
  if(!(fp=fopen(fname,"w"))) return;
  nrb_dump(fp,&FNurbs);
  fclose(fp);
}

void MkNurbs::DumpKnots(char *fname, NurbsDirection nd, char *str)
{
  PR_dir knots;
  FILE *fp;
  if(!(fp=fopen(fname,"w"))) return;
  knots = nd == ndU ? knots = FNurbs.pf_u : FNurbs.pf_v ;
  nrb_dumpknots(fp,str,&knots);
  fclose(fp);
}

void MkNurbs::DumpLists(char *fname)
{
  FILE *fp = fopen(fname,"w");
  if(!fp) return;
  nrb_dumplists(fp);
  fclose(fp);
}

void MkNurbs::DumpSummary(char *fname)
{
  FILE *fp;
  if(!(fp=fopen(fname,"w"))) return;
  nrb_dumpsummary(fp,&FNurbs);
  fclose(fp);
}

void MkNurbs::Elevate()
{
  PR_nurb temp_nurb;
  nrb_clear(&temp_nurb);
  if(FNurbs.pf_v.pf_nt>1) {
    nrb_elevate(TRUE,&FNurbs,&temp_nurb);
    nrb_elevate(TRUE,&temp_nurb,&FNurbs);
    nrb_clear(&temp_nurb);
  }
  else {
    nrb_elevate(FALSE,&FNurbs,&temp_nurb);
    nrb_copy(&temp_nurb,&FNurbs);
    nrb_clear(&temp_nurb);
  }
}

MkPoint MkNurbs::Evaluate(float u)
{
  PR_nurb temp_nurb;
  MkPoint rp;
  nrb_clear(&temp_nurb);
  if(FNurbs.pf_v.pf_nt>1) return NullPoint;
  nrb_evaluate(&FNurbs,u,&temp_nurb);
  if(fabs(temp_nurb.pf_ppp[0].pts[0].w)>0.0001) {
    rp.X = temp_nurb.pf_ppp[0].pts[0].x/temp_nurb.pf_ppp[0].pts[0].w;
    rp.Y = temp_nurb.pf_ppp[0].pts[0].y/temp_nurb.pf_ppp[0].pts[0].w;
    rp.Z = temp_nurb.pf_ppp[0].pts[0].z/temp_nurb.pf_ppp[0].pts[0].w;
    nrb_clear(&temp_nurb);
    return rp;
  }
  else {
    rp.X = temp_nurb.pf_ppp[0].pts[0].x;
    rp.Y = temp_nurb.pf_ppp[0].pts[0].y;
    rp.Z = temp_nurb.pf_ppp[0].pts[0].z;
    nrb_clear(&temp_nurb);
    return rp;
  }
}

MkPoint MkNurbs::Evaluate(float u, float v)
{
  PR_nurb temp_nurb, temp2_nurb;
  MkPoint rp;
  nrb_clear(&temp_nurb);
  nrb_clear(&temp2_nurb);
  if(FNurbs.pf_v.pf_nt<1) return NullPoint;
  nrb_evaluate(&FNurbs,u,&temp_nurb);
  nrb_evaluate(&temp_nurb,v,&temp2_nurb);
  if(fabs(temp2_nurb.pf_ppp[0].pts[0].w)>0.0001) {
    rp.X = temp2_nurb.pf_ppp[0].pts[0].x/temp2_nurb.pf_ppp[0].pts[0].w;
    rp.Y = temp2_nurb.pf_ppp[0].pts[0].y/temp2_nurb.pf_ppp[0].pts[0].w;
    rp.Z = temp2_nurb.pf_ppp[0].pts[0].z/temp2_nurb.pf_ppp[0].pts[0].w;
    nrb_clear(&temp_nurb);
    nrb_clear(&temp2_nurb);
    return rp;
  }
  else {
    rp.X = temp2_nurb.pf_ppp[0].pts[0].x;
    rp.Y = temp2_nurb.pf_ppp[0].pts[0].y;
    rp.Z = temp2_nurb.pf_ppp[0].pts[0].z;
    nrb_clear(&temp_nurb);
    nrb_clear(&temp2_nurb);
    return rp;
  }
}

void MkNurbs::Extrude(MkPoint rp)
{
  PR_nurb temp_nurb;
  Ppoint3 pnt;
  Pint err;
  pnt.x = rp.X; pnt.y = rp.Y; pnt.z = rp.Z;
  nrb_clear(&temp_nurb);
  nrb_extrude(&FNurbs,pnt,&temp_nurb,&err);
  nrb_copy(&temp_nurb,&FNurbs);
  nrb_clear(&temp_nurb);
}

void MkNurbs::Init(int kx,int ntx,int ky,int nty)
{
  nrb_clear(&FNurbs);
  nrb_init(kx,ntx,ky,nty,&FNurbs);
}

int MkNurbs::InqErrorCount()
{
  int n;
  nrb_inqerrorcount(&n);
  return n;
}

void MkNurbs::Interchange()
{
  nrb_interchange(&FNurbs);
}

void MkNurbs::Interpolate(PR_nurb &nurb, float tol)
{
  nrb_clear(&FNurbs);
  nrb_interpolate(&nurb,tol,&FNurbs);
  nrb_transpose(&FNurbs);
}

void MkNurbs::MakeKnots(NurbsDirection nd,int order, int cpnum)
{
  int nt;
  nt = order+cpnum;
  if (nd==ndU) {
    nrb_deallocateknots(&FNurbs.pf_u);
    FNurbs.pf_u.pf_k = order;
    FNurbs.pf_u.pf_n = cpnum;
    FNurbs.pf_u.pf_nt = nt;
    nrb_allocateknots(&FNurbs.pf_u);
    nrb_makeknots(0,1,&FNurbs.pf_u);
  }
  else if (nd==ndV) {
    nrb_deallocateknots(&FNurbs.pf_v);
    FNurbs.pf_v.pf_k = order;
    FNurbs.pf_v.pf_n = cpnum;
    FNurbs.pf_v.pf_nt = nt;
    nrb_allocateknots(&FNurbs.pf_v);
    nrb_makeknots(0,1,&FNurbs.pf_v);
  }
}

void MkNurbs::NumSubDivs(NurbsDirection nd, float tol)
{
  if (nd==ndU) {
    nrb_numsubdivs(&FNurbs, PVudir, tol);
  }
  else if (nd==ndV) {
    nrb_numsubdivs(&FNurbs, PVvdir, tol);
  }
}

MkPoint MkNurbs::PartialDU(float u, float v)
{
  PR_nurb temp_nurb,temp2_nurb;
  PR_pts pts;
  nrb_clear(&temp_nurb);
  nrb_clear(&temp2_nurb);
  nrb_bvalue(&FNurbs, u, 1, &temp_nurb);
  nrb_evaluate(&temp_nurb,v,&temp2_nurb);
  pts = temp2_nurb.pf_ppp[0];
  nrb_clear(&temp_nurb);
  nrb_clear(&temp2_nurb);
  float w = pts.pts[0].w;
  return fabs(w)>0.0001 ? MkPoint(pts.pts[0].x/w,pts.pts[0].y/w,pts.pts[0].z/w) :
                          MkPoint(pts.pts[0].x,pts.pts[0].y,pts.pts[0].z);
}

MkPoint MkNurbs::PartialDV(float u, float v)
{
  return NullPoint;
}

MkPoint MkNurbs::PartialDUV(float u, float v)
{
  return NullPoint;
}

void MkNurbs::Revolve()
{
  PR_nurb temp_nurb;
  nrb_clear(&temp_nurb);
  nrb_revolve(&FNurbs,&temp_nurb);
  nrb_copy(&temp_nurb,&FNurbs);
  nrb_clear(&temp_nurb);
}

void MkNurbs::Ruled(PR_nurb &nurb1, PR_nurb &nurb2, int &err)
{
  nrb_ruled(&FNurbs, &nurb1, &nurb2, &err);
}

void MkNurbs::ScaleKnots(float min, float max, NurbsDirection nd)
{
  if(nd==ndU) nrb_scaleknots(min,max,&FNurbs.pf_u);
  else if(nd==ndV) nrb_scaleknots(min,max,&FNurbs.pf_v);
}

void MkNurbs::Split(float f, PR_nurb &nurb1, PR_nurb &nurb2)
{
  nrb_split(&FNurbs,f,&nurb1,&nurb2);
}

void MkNurbs::Stats(char *fname)
{
  FILE *fp;
  if(!(fp=fopen(fname,"w"))) return;
  nrb_stats(fp);
  fclose(fp);
}

void MkNurbs::Tessalate(int f)
{
  PR_nurb temp_nurb,temp2_nurb;
  nrb_clear(&temp_nurb);
  nrb_clear(&temp2_nurb);
  if(FNurbs.pf_v.pf_nt>1) {
    nrb_tessalate(&FNurbs,f,&temp_nurb);
    nrb_tessalate(&temp_nurb,f,&temp2_nurb);
    nrb_copy(&temp2_nurb,&FNurbs);
  }
  else {
    nrb_tessalate(&FNurbs,f,&temp_nurb);
    nrb_transpose(&temp_nurb);
    nrb_copy(&temp_nurb,&FNurbs);
  }
  nrb_clear(&temp_nurb);
  nrb_clear(&temp2_nurb);
}

void MkNurbs::Transpose()
{
  nrb_transpose(&FNurbs);
}

void MkNurbs::UnionKnots(PR_dir &k1, NurbsDirection nd)
{
  if(nd==ndU) {
    nrb_unionknots(&FNurbs.pf_u, &k1, &FNurbs.pf_u);
  }
  else if(nd==ndV) {
    nrb_unionknots(&FNurbs.pf_v, &k1, &FNurbs.pf_v);
  }
}

void MkNurbs::Write(char *fname)
{
  FILE *fp;
  if(!(fp=fopen(fname,"w"))) return;
  nrb_write(fp,&FNurbs);
  fclose(fp);
}

void MkNurbs::Xform(Pmatrix3 &mat)
{
  nrb_xform(&FNurbs,mat);
}

// Shape
void MkNurbs::MakeItArc(float startAng, float endAng)
{
  nrb_arc(startAng, endAng, &FNurbs);
}

void MkNurbs::MakeItCircle()
{
  nrb_circle(&FNurbs);
}

void MkNurbs::MakeItPolyline(MkPoints &rps)
{
  Ppoint3 *pp;
  int npnt = rps.GetSize();
  pp = new Ppoint3[npnt];
  for (int i = 0 ; i < npnt;i++) {
    pp[i].x = rps[i].X;
    pp[i].y = rps[i].Y;
    pp[i].z = rps[i].Z;
  }
  nrb_polyline(npnt,pp,&FNurbs);
  delete[] pp;
}

void MkNurbs::MakeItTorus()
{
  nrb_torus(&FNurbs);
}

void MkNurbs::MakeItTriangle()
{
  nrb_triangle(&FNurbs);
}

void MkNurbs::MakeItSquare()
{
  nrb_square(&FNurbs);
}

void MkNurbs::MakeItSphere()
{
  nrb_sphere(&FNurbs);
}

void MkNurbs::MakeItVase()
{
  nrb_vase(&FNurbs);
}

SoSeparator * MkNurbs::MakeFaceSet()
{
  /*  int i,j;
  int Div=100;
  SoSeparator *shape = new SoSeparator;
  shape->ref();
  SoIndexedFaceSet *face = new SoIndexedFaceSet;
  SoCoordinate3 *coord = new SoCoordinate3;
  SbVec3f *vert;
  int *indices;
  
  MkPoint rp;
  vert = new SbVec3f[Div*Div];
  if(!vert) exit(-1);
  indices = new int[5*(Div)*(Div)];
  if(!indices) exit(-1);
  
  for (i=0;i<Div;i++) {
  	for (j=0;j<Div;j++) {
	  rp = Evaluate(float(i)/float(Div),float(j)/float(Div));
  	  vert[i*Div+j][0] = rp.X;
	  vert[i*Div+j][1] = rp.Y;
	  vert[i*Div+j][2] = rp.Z;
	  
	  //printf("i:%d,j:%d = (%f,%f,%f)\n",i,j,rp.X,rp.Y,rp.Z);
	}
  }
 
  int cnt=0;
  for (i=0;i<Div;i++) {
  	for (j=0;j<Div;j++) {
	  int I,J; 
	  I = i+1 == Div ? 0 : i+1;
	  J = j+1 == Div ? 0 : j+1;
	  indices[cnt] = i*Div+j;			cnt++;
	  indices[cnt] = I*Div+j;		cnt++;
	  indices[cnt] = I*Div+J;		cnt++;
	  indices[cnt] = i*Div+J;			cnt++;
	  indices[cnt] = SO_END_FACE_INDEX;	cnt++;
	}
  }
	  
  coord->point.setValues(0,Div*Div,vert);
  face->coordIndex.setValues(0,5*(Div)*(Div),indices);
  
 // mat = new SoMaterial;
 // mat->diffuseColor.setValue(1, 0, 1);
 // shape->addChild(mat);
  
  shape->addChild(coord);
  shape->addChild(face);
    
  delete[] vert;
  delete[] indices;
  shape->unrefNoDelete();
  return shape;  
  */
  return NULL;
}
/*
MkPoints & MkNurbs::GetControlPoint()
{

}

void MkNurbs::SetControlPoint(MkPoints &rps)
{

}

Float & MkNurbs::GetKnot()
{

}

void MkNurbs::SetKnot(Float & knots)
{

}
*/
//---------------------------------------------------------------------------

