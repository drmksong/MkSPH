//---------------------------------------------------------------------------
#include "MkLane.h"

#ifdef __BCPLUSPLUS__
#include <vcl.h>
#endif
#pragma hdrstop
//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#pragma package(smart_init)
#endif
//---------------------------------------------------------------------------
MkLane NullMkLane(0);
MkLanes::MkLanes(int size,MkLane *lanes)
{
    if (size < 0) {
      MkDebug("::MkLanes - MkLanes(int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSize == 0) {
       FLane = NULL;
       return;
    }

    FLane = new MkLane[FSize];
    for (int i=0;i<FSize;i++) (*this)[i] = lanes[i];
}

MkLanes::MkLanes(int size)
{
    if (size < 0) {
      MkDebug("::MkLanes - MkLanes(int size)");;
      return;
    }

    FSize = FSizeOfArray = size;

    if (FSizeOfArray == 0) {
       FLane = NULL;
       return;
    }

    FLane = new MkLane[FSizeOfArray];
}

MkLanes::~MkLanes()
{
   FSizeOfArray = FSize = 0;
   if (FLane) {
      delete[] FLane;
      FLane = NULL;
   }
}

void MkLanes::Initialize(int size)
{
    if (size < 0) {
      MkDebug("::MkLanes - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;

    FSize = FSizeOfArray = size;

    if (FSizeOfArray == 0) {
       if (FLane!=NULL) delete[] (MkLane*)FLane;
       FLane = NULL;
       return;
    }

    if (FLane!=NULL) delete[] (MkLane*)FLane;
    FLane = new MkLane[FSizeOfArray];
}

void MkLanes::Initialize(int size,MkLane *lanes)
{

    if (size < 0 || lanes == NULL) {
      MkDebug("::MkLanes - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSize = FSizeOfArray = size;
    if (FSizeOfArray == 0) {
       if (FLane!=NULL) delete[] (MkLane*)FLane;
       FLane = NULL;
       return;
    }

    if (FLane!=NULL) delete[] (MkLane*)FLane;
    FLane = new MkLane[FSizeOfArray];
    for (int i=0;i<FSizeOfArray;i++) FLane[i] = lanes[i];
}

int MkLanes::Grow(int delta)
{
    int i;
    MkLane *lane=NULL;

    if (!(lane = new MkLane[FSizeOfArray+delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        lane[i] = FLane[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        lane[i] = NullMkLane;
    if (FLane) {
       delete[] (MkLane*)FLane;
       FLane = NULL;
    }
    FLane = lane;
    FSizeOfArray = FSizeOfArray+delta;

    return FSizeOfArray;
}

int MkLanes::Shrink(int delta)
{
    int i;
    MkLane *lane=NULL;

    if (!(lane = new MkLane[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        lane[i] = FLane[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        lane[i] = NullMkLane;
    if (FLane) {
       delete[] (MkLane*)FLane;
       FLane = NULL;
    }
    FLane = lane;
    FSizeOfArray = FSizeOfArray-delta;

    return FSizeOfArray;
}

bool MkLanes::Add(MkLane &lane)
{
    int tmp=FSizeOfArray;
    bool flag=false;
    for (int i=0;i<FSize;i++) if (FLane[i]==lane) flag=true;

    if(flag) return false;
    if (FSize>=FSizeOfArray) {
       Grow(FSize-FSizeOfArray+10);
       if (tmp==FSizeOfArray) return false;
    }
    FSize++;
    FLane[FSize-1] = lane;

    return true;
}

bool MkLanes::Add(int index, MkLane &lane)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) Grow(FSize-FSizeOfArray+1);
    if(tmp==FSizeOfArray) return false;

    for (int i=FSize-1;i>=index;i--)
      FLane[i+1] = FLane[i];
    FSize++;
    FLane[index] = lane;
    return true;
}

bool MkLanes::Delete(MkLane &lane)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FLane[i] == lane) break;
    }
    if(i==FSize) return false;
    if(FLane[i] == lane) {
      for (int j=i;j<FSize-1;j++)
        FLane[j] = FLane[j+1];
    }
    FSize--;
    FLane[FSize] = NullMkLane;
    return true;
}

bool MkLanes::Delete(int index)
{
    for (int j=index;j<FSize-1;j++)
        FLane[j] = FLane[j+1];

    FSize--;
    FLane[FSize] = NullMkLane;
    return true;
}

bool MkLanes::Clear()
{
   FSizeOfArray = FSize = 0;
   if (FLane) {
      delete[] FLane;
      FLane = NULL;
   }
   return true;
}

MkLane & MkLanes::operator[](int i)
{
    if (FSizeOfArray == 0) return NullMkLane;
    if (i >= FSize && i < FSizeOfArray) FSize = i+1;

    if (i >=0 && i < FSize) return FLane[i];
    else return NullMkLane;
}

MkLanes & MkLanes::operator=(MkLanes &lanes)
{
    int i;

    Clear();
    FSize = lanes.FSize;
    FSizeOfArray = lanes.FSizeOfArray;
    if (FSize == 0) {
       FLane = NULL;
       return *this;
    }
    this->FLane = new MkLane[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FLane[i] = lanes.FLane[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FLane[i] = NullMkLane;

    return *this;
}

bool MkLanes::operator==(MkLanes &lanes)
{
  int i;

  if (FSize != lanes.FSize) return false;
  for (i=0;i<FSize;i++)
    if (this->FLane[i] != lanes.FLane[i]) return false;

  return true;
}

#ifdef __BCPLUSPLUS__
void MkLanes::Import(MkGlobalVar &globalvar, int sec, int pilesec)
{
  int i,j;
  for(i=0;i<FSize && i<10;i++) {
    FLane[i].load_type = load_type[sec+1][pilesec+1][i+1];
    FLane[i].load_dist = load_dist[sec+1][pilesec+1][i+1];
    for(j=0;j<FLane[i].load_kind.getSzX();j++) {
      FLane[i].load_kind(j) = load_kind[sec+1][pilesec+1][i+1][j+1];
    }
  }
}

void MkLanes::Export(MkGlobalVar &globalvar, int sec, int pilesec)
{
  int i,j;
  for(i=0;i<FSize && i<10;i++) {
    load_type[sec+1][pilesec+1][i+1] = FLane[i].load_type;
    load_dist[sec+1][pilesec+1][i+1] = FLane[i].load_dist;
    for(j=0;j<FLane[i].load_kind.getSzX();j++) {
      load_kind[sec+1][pilesec+1][i+1][j+1] = FLane[i].load_kind(j);
    }
  }
  load_ea[sec+1][pilesec+1] = FSize;
}
#endif
//---------------------------------------------------------------------------
