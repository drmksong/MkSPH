//---------------------------------------------------------------------------
#include "MkIn.h"
#ifdef __BCPLUSPLUS__
#include <vcl.h>
#endif
#pragma hdrstop
//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#pragma package(smart_init)
#endif
//---------------------------------------------------------------------------
MkIn::MkIn()
{
  Clear();
}

MkIn::MkIn(int)
{
  Clear();
}

void MkIn::Clear()
{
  liveload=0;
  layer_ea=0;
  layer=0;
  layerdepth=0;
  steel=0;
  bracing=0;
  support_L=0;
  support_R=0;
  cal=0;
  surang=0;
  estimate=0;
  jibanbogang=0;
  Exca_Step=0;
  bearing=0;
  anchor=0;
  Call_data=0;
  InputLayerEA=0;
  Inputplan=0;
  Inputwale=0;
  InputBogangjae=0;
  SelectLayer=0;
  LayerBogang=0;
}

void MkIn::Import(MkGlobalVar &globalvar)
{
  liveload=globalvar.In_liveload;
  layer_ea=globalvar.In_layer_ea;
  layer=globalvar.In_layer;
  layerdepth=globalvar.In_layerdepth;
  steel=In_steel;
  bracing=In_bracing;
  support_L=globalvar.In_support_L;
  support_R=globalvar.In_support_R;
  cal=In_cal;
  surang=In_surang;
  estimate=In_estimate;
  jibanbogang=globalvar.In_jibanbogang;
  Exca_Step=In_Exca_Step;
  bearing=In_bearing;
  anchor=In_anchor;
  Call_data=In_Call_data;
  InputLayerEA=globalvar.InputLayerEA;
  Inputplan=globalvar.Inputplan;
  Inputwale=globalvar.Inputwale;
  InputBogangjae=globalvar.InputBogangjae;
  SelectLayer=globalvar.SelectLayer;
  LayerBogang=globalvar.LayerBogang;
}

void MkIn::Export(MkGlobalVar &globalvar)
{
  globalvar.In_liveload=liveload;
  globalvar.In_layer_ea=layer_ea;
  globalvar.In_layer=layer;
  globalvar.In_layerdepth=layerdepth;
  In_steel=steel;
  In_bracing=bracing;
  globalvar.In_support_L=support_L;
  globalvar.In_support_R=support_R;
  In_cal=cal;
  In_surang=surang;
  In_estimate=estimate;
  globalvar.In_jibanbogang=jibanbogang;
  In_Exca_Step=Exca_Step;
  In_bearing=bearing;
  In_anchor=anchor;
  In_Call_data=Call_data;
  globalvar.InputLayerEA=InputLayerEA;
  globalvar.Inputplan=Inputplan;
  globalvar.Inputwale=Inputwale;
  globalvar.InputBogangjae=InputBogangjae;
  globalvar.SelectLayer=SelectLayer;
  globalvar.LayerBogang=LayerBogang;
}

MkIn &MkIn::operator=(MkIn &in)
{
  liveload=in.liveload;
  layer_ea=in.layer_ea;
  layer=in.layer;
  layerdepth=in.layerdepth;
  steel=in.steel;
  bracing=in.bracing;
  support_L=in.support_L;
  support_R=in.support_R;
  cal=in.cal;
  surang=in.surang;
  estimate=in.estimate;
  jibanbogang=in.jibanbogang;
  Exca_Step=in.Exca_Step;
  bearing=in.bearing;
  anchor=in.anchor;
  Call_data=in.Call_data;
  InputLayerEA=in.InputLayerEA;
  Inputplan=in.Inputplan;
  Inputwale=in.Inputwale;
  InputBogangjae=in.InputBogangjae;
  SelectLayer=in.SelectLayer;
  LayerBogang=in.LayerBogang;
}
//---------------------------------------------------------------------------
