//---------------------------------------------------------------------------
#ifndef MkWaleH
#define MkWaleH

#ifdef __BCPLUSPLUS__
#include "GlobalVarUnit.h"
#endif

#include "MkObject.h"
#include "MkBeam.h"
//---------------------------------------------------------------------------
class MkWale : public MkBeam {

#ifdef __BCPLUSPLUS__
private:
  AnsiString MajorWale;
public:
  AnsiString walename;//, walekind;
#else 
private:
  char MajorWale[256];
public:
  char walename[256];//, walekind;
#endif
public:
  MkWale();
  MkWale(int);
  ~MkWale(){}
  void Clear();
#ifdef __BCPLUSPLUS__
  void Import(MkGlobalVar &globalvar, int sec, int tan);
  void Export(MkGlobalVar &globalvar, int sec, int tan);
  void ExtractSpec(AnsiString &spec);
  void ComposeSpec(AnsiString &spec);
  void SetMajorWale(AnsiString str){MajorWale = str;}
  AnsiString GetMajorWale(){return MajorWale;}
#endif
  void SetHeight(float h){HH = h;}
  void SetWidth(float w){BB = w;}
  void SetT1(float t){tt1 = t;}
  void SetT2(float t){tt2 = t;}

  bool operator==(MkWale &);
  bool operator!=(MkWale &);
  MkWale &operator=(MkWale &);
};

class MkWales {
protected:
  MkWale *FWale;
  int FSize;//Actual size of nodes
  int FSizeOfArray;
public:
  MkWales(int size,MkWale *wale);
  MkWales(int size);
  MkWales(){FSizeOfArray = FSize = 0;FWale = NULL;}
  ~MkWales();

  virtual void Initialize(int size);
  virtual void Initialize(int size,MkWale *);
  int GetSize(){return FSize;};
  int GetNumber(){return FSize;};
  bool Add(MkWale &wale);  // change of size of wale
  bool Add(int index,MkWale &wale);
  bool Delete(MkWale &wale);  // change of size of wale
  bool Delete(int index);
  int Grow(int Delta);            // change of size of array
  int Shrink(int Delta);          // change of size of array
  bool Clear();
  virtual MkWale & operator[](int);
  MkWales & operator=(MkWales &wales);
  bool operator==(MkWales &wales);
#ifdef __BCPLUSPLUS__
  void Import(MkGlobalVar &globalvar, int sec);
  void Export(MkGlobalVar &globalvar, int sec);
#endif
};
//---------------------------------------------------------------------------
extern MkWale NullMkWale;
//extern MkWale NullWale;
#endif


//---------------------------------------------------------------------------
/*class MkWale : public MkEntity {
protected:
  MkLine WaleLine;

public:
  MkWale();
  MkWale(int n);
  ~MkWale(){};
#ifdef __BCPLUSPLUS__
  AnsiString ClassName(){return AnsiString("MkWale");};
  bool UpdateFrom(TStringGrid *grid){Grid = grid;return UpdateFrom();};
  bool UpdateTo(TStringGrid *grid){Grid = grid;return UpdateTo();};
  bool UpdateFrom();
  bool UpdateTo();
  void Out(TObject *);
#else
  char* ClassName(){return "MkWale";}
#endif

  void Out(char *fname);
  
#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif

  bool operator==(MkWale&);
  bool operator!=(MkWale&);
  MkWale& operator=(MkWale& wale);
};

class MkWales {
protected:
    MkWale *FWale;
    int FSize;//Actual size of entities
    int FSizeOfArray;
#ifdef __BCPLUSPLUS__
    TColor Color;
#endif
public:
    MkWales(int size,MkWale *ent);
    MkWales(int size);
    MkWales(){FSizeOfArray = FSize = 0;FWale = NULL;}
    ~MkWales();
    virtual void Initialize(int size);
    virtual void Initialize(int size,MkWale *);
    int GetSize(){return FSize;};
    int GetNumber(){return FSize;};
    bool Add(MkWale &wale);  // change of size of wale
    bool Add(int index,MkWale &wale);
    bool Delete(MkWale &wale);  // change of size of wale
    bool Delete(int index);
    int Grow(int Delta);            // change of size of array
    int Shrink(int Delta);          // change of size of array
    bool Clear();
#ifdef __BCPLUSPLUS__
    TColor GetColor(){return Color;};
    void SetColor(TColor c){Color = c;}
    void Out(TObject *);
#else
#endif

    void Out(char *fname);
    
#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif

    virtual MkWale & operator[](int);
    MkWales & operator=(MkWales &wales);
    bool operator==(MkWales &wales);
};*/

