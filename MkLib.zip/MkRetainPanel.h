//---------------------------------------------------------------------------
#ifndef MkRetainPanelH
#define MkRetainPanelH
#include "MkEntity.h"
//---------------------------------------------------------------------------
class MkRetainPanel : public MkEntity {
protected:
  float Height;
  float Width;
  float Thick;
  float Press;
  float BendCompStressAllow;
  float Moment;
public:
  MkRetainPanel();
  MkRetainPanel(int );
  ~MkRetainPanel(){}
public: // Setting
  void SetHeight(float h){Height = h;}
  void SetWidth(float w){Width = w;}
  void SetThick(float t){Thick = t;}
  void SetPress(float p){Press = p;}
  void SetCompStress(float str){BendCompStressAllow = str;}
  void SetMoment(float mom){Moment = mom;}

  void Clear()
  {
    Number=0;
    Height=0;
    Width=0;
    Thick=0;
    Press=0;
    BendCompStressAllow=0;
    Moment=0;
  }

#ifdef __BCPLUSPLUS__
  bool UpdateFrom();
  bool UpdateTo();
#endif

#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif

  bool operator==(MkRetainPanel&);
  bool operator!=(MkRetainPanel&);
  MkRetainPanel & operator=(MkRetainPanel&);
};

class MkRetainPanels {
protected:
    MkRetainPanel *FRetainPanel;
    int FSize; // Actual size of entities
    int FSizeOfArray;
#ifdef __BCPLUSPLUS__
    TColor Color;
#endif
public:
    MkRetainPanels(int size,MkRetainPanel *ent);
    MkRetainPanels(int size);
    MkRetainPanels(){FSizeOfArray = FSize = 0;FRetainPanel = NULL;}
    ~MkRetainPanels();
    virtual void Initialize(int size);
    virtual void Initialize(int size,MkRetainPanel *);
    int GetSize(){return FSize;};
    int GetNumber(){return FSize;};
    bool Add(MkRetainPanel &retainpan);  // change of size of retainpan
    bool Add(int index,MkRetainPanel &retainpan);
    bool Delete(MkRetainPanel &retainpan);  // change of size of retainpan
    bool Delete(int index);
    int Grow(int Delta);            // change of size of array
    int Shrink(int Delta);          // change of size of array
    bool Clear();
#ifdef __BCPLUSPLUS__
    TColor GetColor(){return Color;};
    void SetColor(TColor c){Color = c;}
#endif

#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
    void Draw(MkPaint *);
#endif

    virtual MkRetainPanel & operator[](int);
    MkRetainPanels & operator=(MkRetainPanels &retainpans);
    bool operator==(MkRetainPanels &retainpans);
};
//---------------------------------------------------------------------------
extern MkRetainPanel NullRetainPanel;
//---------------------------------------------------------------------------
#endif
