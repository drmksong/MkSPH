//--------------------------------------------------------------------
// MkMori.h
// 
// Last Revised. 2004. April. 13
//--------------------------------------------------------------------
#pragma hdrstop
#include "stdafx.h"
#include "MkMori.h"

#ifdef __BCPLUSPLUS__
#include <vcl.h>
#endif

//--------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#pragma package(smart_init)
#endif
//--------------------------------------------------------------------
bool MkMori::Initialize()
{
  static bool flag=false;
  if(flag) return flag;
  InitVar();
  flag = true;
#ifdef __BCPLUSPLUS__
  Memo = NULL;
#endif
  return false;
}

bool MkMori::Setup()
{
  int size,i,j;
  float nl,tl,tr;

  Elements.SetupStiff();
  Stiff.Assemble(*NodeRef,Elements);

  size=Stiff.GetStiffMatrix().GetFI();
  if(Var.GetSize()!=size) Var.Initialize(size);

  for(i=0;i<NodeRef->GetSize();i++) {
    for(j=0;j<2;j++) {
      tl = TotLeftEarthLoad(i,j);
      tr = TotRightEarthLoad(i,j);
      nl = tl+tr;
      NodalLoad(i,j) = TotLeftEarthLoad(i,j)+TotRightEarthLoad(i,j);
    }
  }
  OutStiff("stiff.chk");
  OutLoad("load.chk");
  return true;
}

bool MkMori::Pre(MkMatrix &stiff)
{
  int i,j,k,size=Var.GetSize();
  ApplySubreact(stiff); 

  for (i=0;i<JackingForce.GetSize();i++) {
    //    NodalLoad(JackingForce.GetNode(i),0) += JackingForce.GetForce(i);
  }
  for (i=0;i<IniForceCorrect.GetSize();i++) {
    //    NodalLoad(IniForceCorrect.GetNode(i),0) += IniForceCorrect.GetForce(i);
  }

  for (i=0;i<size;i++) {
    j=Stiff.GetSteer().Node(i);
    k=Stiff.GetSteer().NDof(i);
    if((*NodeRef)[j].GetDOFs()[k].GetDOFType()==doftXDis) {
      float r;
      r = NodalLoad(j,0);
      Var(i) = NodalLoad(j,0);
    }
    if((*NodeRef)[j].GetDOFs()[k].GetDOFType()==doftZAng) {
      float r;
      r = NodalLoad(j,1);
      Var(i) = NodalLoad(j,1);
    }
  }
  OutStiff("stiff1.chk");
  OutLoad("load1.chk");
  return true;
}

bool MkMori::Solve()
{
  static MkVector post;
  int i,j,k;
  bool flag=true;
  int nnode = NodeRef->GetSize();
  char str[256];
  MkMatrix stiff;

  CalcLimitQu();

  for(i=0;i<CurStepDis.getSzX();i++) {
    CurStepDis(i) = 0;
  }

  for(i=0;i<CurStepAng.getSzX();i++) {
    CurStepAng(i) = 0;
  }

  Step=0;
  do {
    flag=Setup() && flag;
    stiff = Stiff.GetStiffMatrix();
    post = Var;  // backup the variable(the result), after Pre(), Var is changed to right hand side vector
    Pre(stiff);
    OutVar("var.chk");
    stiff.Solve(Var,stHybrid);
    OutVar("var1.chk");
    Post();

    if(!(Step%PrintStep)) flag=Out() && flag;
    sprintf(str,"Current step is %d\n",Step++);MkDebug(str);

  } while(!CheckTol(post,Var) && Step < 100);//100 must be max step
  flag=Out() && flag;
  CalcNodalLen();
  CalcNodalPress();
  ExtractResult();
  return flag;
}

bool MkMori::Post()
{
  UpdateNodalDis();
  return true;
}

void MkMori::ApplySubreact(MkMatrix &mat)
{
  int i,j,k,size;
  size=Var.GetSize();
  float nd, rlq, nq, llq,eps,lk,rk;
  bool le,re;

  OutStiff(mat,"CompStiff.chk");
  for (i=0;i<size;i++) {
    j=Stiff.GetSteer().Node(i);
    k=Stiff.GetSteer().NDof(i);
    nd = NodalDis(j);
    rlq = RightLimitQu(j,0);
    nq = NodalQu(j,0);
    llq = LeftLimitQu(j,0);
    lk = LeftNodalKh(j,0);
    rk = RightNodalKh(j,0);
    eps = EPS;  // NodalQu must be added to consider plastic deformation
    le=re=true;
    if((*NodeRef)[j].GetDOFs()[k].GetDOFType()==doftXDis) {
      if(NodalDis(j)*RightNodalKh(j,0)>-RightEarthLd(j,0)+RightEarthLoad(j,0)) { // failure of ground use effective stress
	NodalLoad(j,0)+=RightEarthLd(j,0)-TotRightEarthLoad(j,0);  // acture load use total stress
	re = false;
      }
      else if(NodalDis(j)*RightNodalKh(j,0)<-RightEarthLu(j,0)+RightEarthLoad(j,0)) { 
	NodalLoad(j,0)+=RightEarthLu(j,0)-TotRightEarthLoad(j,0);  // acture load use total stress
	re = false;
      }
      if(NodalDis(j)*LeftNodalKh(j,0)>LeftEarthLd(j,0)-LeftEarthLoad(j,0)) { // failure of ground use effective stress
	NodalLoad(j,0)+=LeftEarthLd(j,0)-TotLeftEarthLoad(j,0);  // acture load use total stress
	le = false;
      }
      else if(NodalDis(j)*LeftNodalKh(j,0)<LeftEarthLu(j,0)-LeftEarthLoad(j,0)) { 
	NodalLoad(j,0)+=LeftEarthLu(j,0)-TotLeftEarthLoad(j,0);  // acture load use total stress
	le = false;
      }
      else {
	float frac;
	frac = max(NodalDis(j),NodalQu(j,0))<EPS?1:fabs(NodalDis(j)-NodalQu(j,0))/max(NodalDis(j),NodalQu(j,0));
	mat(i,i)+=(NodalDis(j)-NodalQu(j,0))>0?(re?1:0)*frac*RightNodalKh(j,0):(le?1:0)*frac*LeftNodalKh(j,0);
      }
    }
    else if((*NodeRef)[j].GetDOFs()[k].GetDOFType()==doftZAng) {
      if(NodalAng(j)*RightNodalKh(j,1)>-RightEarthLd(j,1)+RightEarthLoad(j,1)) { // failure of ground use effective stress
	NodalLoad(j,1)+=RightEarthLd(j,1)-TotRightEarthLoad(j,1);  // acture load use total stress
	re = false;
      }
      else if(NodalAng(j)*RightNodalKh(j,1)<-RightEarthLu(j,1)+RightEarthLoad(j,1)) { 
	NodalLoad(j,1)+=RightEarthLu(j,1)-TotRightEarthLoad(j,1);  // acture load use total stress
	re = false;
      }
      if(NodalAng(j)*LeftNodalKh(j,1)>LeftEarthLd(j,1)-LeftEarthLoad(j,1)) { // failure of ground use effective stress
	NodalLoad(j,1)+=LeftEarthLd(j,1)-TotLeftEarthLoad(j,1);  // acture load use total stress
	le = false;
      }
      else if(NodalAng(j)*LeftNodalKh(j,1)<LeftEarthLu(j,1)-LeftEarthLoad(j,1)) { 
	NodalLoad(j,1)+=LeftEarthLd(j,1)-TotLeftEarthLoad(j,1);  // acture load use total stress
	le = false;
      }
      else {
	float frac;
	frac = max(NodalAng(j),NodalQu(j,0))<EPS?1:fabs(NodalAng(j)-NodalQu(j,0))/max(NodalAng(j),NodalQu(j,0));
	mat(i,i)+=(NodalAng(j)-NodalQu(j,0))>0?(re?1:0)*frac*RightNodalKh(j,0):(le?1:0)*frac*LeftNodalKh(j,0);
      }
    }
  }
  OutStiff(mat,"CompStiff.chk");
}

bool MkMori::Apply(MkSubreacts &sub)
{
  bool flag=true;
  for(int j=0;j<NodeRef->GetSize();j++) {
    LeftNodalKh(j,0) = 0;
    LeftNodalKh(j,1) = 0;
    RightNodalKh(j,0) = 0;
    RightNodalKh(j,1) = 0;
  }
  for (int i=0;i<sub.GetSize();i++) {
    if(SpringType==stNodal)  flag = ApplyNodal(sub[i]) && flag;
    else if(SpringType==stDistributal) flag = ApplyDistributal(sub[i]) && flag;
  }
  return flag;
}

bool MkMori::ApplyNodal(MkSubreact &sub) // must be checked!!! how to consider excavated face
{
  int i;
  float ymin,ymax,len;
  MkNode node[2];
  int nodenum[2];
  MkPolygon poly;
  MkPolygon &subreact = sub.GetSubreact();
  MkVector &dir=sub.GetDirection();
  dir.Normalize();

  for(i=0;i<Elements.GetSize();i++) {
    if(!Elements[i].isBeamElement()) continue;
    node[0] = Elements[i].GetElemNode(0);
    node[1] = Elements[i].GetElemNode(1);
    if(fabs(node[0].GetPoint().Y-node[1].GetPoint().Y)<EPS) continue;
    if(!sub.isIn(node[0].GetPoint()) || !sub.isIn(node[1].GetPoint())) continue;

    nodenum[0] = Elements[i].GetNodeNumber(0);
    nodenum[1] = Elements[i].GetNodeNumber(1);
    ymin = node[0].GetPoint().Y;
    ymax = (node[0].GetPoint().Y+node[1].GetPoint().Y)/2;
    len = fabs(ymax-ymin);
    if(ymin>ymax) swap(ymin,ymax);
    GetSubPolygon(ymin,ymax,subreact,poly);
    if(dir[0]<0) { // must be checked if it is right!!!
      RightNodalKh(nodenum[0],0) -= fabs(dir[0])*poly.GetArea();// += -> -= to check the result 10/18
      //      RightNodalKh(nodenum[0],1) += 0;
    }
    else if(dir[0]>0) { // must be checked if it is right!!!
      LeftNodalKh(nodenum[0],0) -= fabs(dir[0])*poly.GetArea();// += -> -= to check the result 10/18
      //      LeftNodalKh(nodenum[0],1) += 0;
    }

    ymin = (node[0].GetPoint().Y+node[1].GetPoint().Y)/2;
    ymax = node[1].GetPoint().Y;
    len = fabs(ymax-ymin);
    if(ymin>ymax) swap(ymin,ymax);
    GetSubPolygon(ymin,ymax,subreact,poly);
    if(dir[0]<0) { // must be checked if it is right!!!
      RightNodalKh(nodenum[1],0) -= fabs(dir[0])*poly.GetArea();// += -> -= to check the result 10/18
      //      RightNodalKh(nodenum[1],1) += 0;
    }
    else if(dir[0]>0) { // must be checked if it is right!!!
      LeftNodalKh(nodenum[1],0) -= fabs(dir[0])*poly.GetArea();// += -> -= to check the result 10/18
      //      LeftNodalKh(nodenum[1],1) += 0;
    }
  }
  return true;
}

bool MkMori::ApplyDistributal(MkSubreact &sub)
{
  int i,j;
  float ymin,ymax;
  MkNode node[2];
  int nodenum[2];
  float aj,bj,lj,lj1,len;
  float f1,f2,f3,f4;
  MkPolygon poly;
  MkPolygon &subreact = sub.GetSubreact();

  for(i=0;i<Elements.GetSize();i++) {
    if(!Elements[i].isBeamElement()) continue;
    MkBeamElement *beam = dynamic_cast<MkBeamElement*>(&Elements[i]);
    node[0] = Elements[i].GetElemNode(0);
    node[1] = Elements[i].GetElemNode(1);
    if(fabs(node[0].GetPoint().Y-node[1].GetPoint().Y)<EPS) continue;
    if(!sub.isIn(node[0].GetPoint()) || !sub.isIn(node[1].GetPoint())) continue;

    nodenum[0] = Elements[i].GetNodeNumber(0);
    nodenum[1] = Elements[i].GetNodeNumber(1);

    if(node[0].GetPoint().Y<node[1].GetPoint().Y) {
      Swap(node[0],node[1]);
      swap(nodenum[0],nodenum[1]);
    }

    ymin = node[0].GetPoint().Y;
    ymax = node[1].GetPoint().Y;
    len = fabs(ymax-ymin);
    if(ymin>ymax) swap(ymin,ymax);

    GetSubPolygon(ymin,ymax,subreact,poly);

    f1=f2=f3=f4=0; // element-wise integration of shape function...
    for(j=0;j<poly.GetSize();j++) {
      GetSubParam(j,poly,aj,bj,lj1,lj);
      f1 += ShapeFunInteg1(aj,bj,len,lj1,lj);
      f2 += ShapeFunInteg2(aj,bj,len,lj1,lj);
      f3 += ShapeFunInteg3(aj,bj,len,lj1,lj);
      f4 += ShapeFunInteg4(aj,bj,len,lj1,lj);
    }
    if(sub.GetDirection()[0]<0) {
      RightNodalKh(nodenum[0],0) += fabs(f1);
      RightNodalKh(nodenum[0],1) += fabs(f2);
      RightNodalKh(nodenum[1],0) += fabs(f3);
      LeftNodalKh(nodenum[1],1) += fabs(f4); // it is because that right nodal kh is for positive angle,
    }
    else {
      LeftNodalKh(nodenum[0],0) += fabs(f1);
      LeftNodalKh(nodenum[0],1) += fabs(f2);
      LeftNodalKh(nodenum[1],0) += fabs(f3);
      RightNodalKh(nodenum[1],1) += fabs(f4); // and left nodal kh is for negative angle.
    }
    if(!beam) continue;
  }
  return true;
}

void MkMori::CalcLimitQu() // very confusing because left earth pressure is minus, but left earth load is plus, and right is like-wize.
{
  int i;
  for (i=0;i<NodeRef->GetSize();i++) {
    float lnk = LeftNodalKh(i,0);
    float lel0 = LeftEarthLoad(i,0);
    float leu0 = LeftEarthLu(i,0);
    float lel1 = LeftEarthLoad(i,1);
    float leu1 = LeftEarthLu(i,1);
    float rnk = RightNodalKh(i,0);
    float rel0 = RightEarthLoad(i,0);
    float reu0 = RightEarthLu(i,0);
    float rel1 = RightEarthLoad(i,1);
    float reu1 = RightEarthLu(i,1);
    LeftLimitQu(i,0)=(fabs(LeftNodalKh(i,0))<EPS)?0:-1*(LeftEarthLoad(i,0)-LeftEarthLu(i,0))/LeftNodalKh(i,0);  // 100 is for test...if you see this delete it ASAP
    LeftLimitQu(i,1)=(fabs(LeftNodalKh(i,1))<EPS)?0:-1*(LeftEarthLoad(i,1)-LeftEarthLu(i,1))/LeftNodalKh(i,1);// 100 is for test...if you see this delete it ASAP
    RightLimitQu(i,0)=(fabs(RightNodalKh(i,0))<EPS)?0:-1*(RightEarthLoad(i,0)-RightEarthLu(i,0))/RightNodalKh(i,0);//+ //100 is for test...if you see this delete it ASAP
    RightLimitQu(i,1)=(fabs(RightNodalKh(i,1))<EPS)?0:-1*(RightEarthLoad(i,1)-RightEarthLu(i,1))/RightNodalKh(i,1);//+ //100 is for test...if you see this delete it ASAP
  }
}

bool MkMori::Apply(MkLoads &load,MkLayers &lay)
{
  // set NodalLoad, NodalLu, NodalLd
  int i,j;
  bool flag=true;
  float temp;
  MkNode node[2];
  int nodenum[2];

  for(i=0;i<NodeRef->GetSize();i++) {
    TotLeftEarthLoad(i,0) = 0;
    TotLeftEarthLoad(i,1) = 0;    
    LeftEarthLoad(i,0) = 0;
    LeftEarthLoad(i,1) = 0;
    LeftEarthLu(i,0) = 0;
    LeftEarthLu(i,1) = 0;
    LeftEarthLd(i,0) = 0;
    LeftEarthLd(i,1) = 0;
    TotRightEarthLoad(i,0) = 0;
    TotRightEarthLoad(i,1) = 0;
    RightEarthLoad(i,0) = 0;
    RightEarthLoad(i,1) = 0;
    RightEarthLu(i,0) = 0;
    RightEarthLu(i,1) = 0;
    RightEarthLd(i,0) = 0;
    RightEarthLd(i,1) = 0;
  }

  for(i=0;i<load.GetSize();i++) {
    flag = CalcEarthLoad(&load[i]) && flag;
    flag = CalcEarthLu(&load[i]) && flag;
    flag = CalcEarthLd(&load[i]) && flag;
    //    flag = CalcHydLoad(&load[i]) && flag;  // make this alive if you see this
  }
  flag = CalcEarthLoad(lay) && flag;
//  flag = CalcEarthLu(lay) && flag;
//  flag = CalcEarthLd(lay) && flag;

  for(i=0;i<NodeRef->GetSize();i++) {
    temp = LeftEarthLoad(i,0);
    temp = LeftEarthLoad(i,1);
    temp = LeftEarthLu(i,0);
    temp = LeftEarthLu(i,1);
    temp = LeftEarthLd(i,0);
    temp = LeftEarthLd(i,1);
    temp = RightEarthLoad(i,0);
    temp = RightEarthLoad(i,1);
    temp = RightEarthLu(i,0);
    temp = RightEarthLu(i,1);
    temp = RightEarthLd(i,0);
    temp = RightEarthLd(i,1);
  }
  return flag;
}

bool MkMori::CalcNodalLoad(MkRangeTree &range, MkPolygon &press, MkFloat &nodal) // must be checked!!!
{
  int i;
  float ymin,ymax,len;
  MkNode node[2];
  int nodenum[2];
  MkPolygon poly;

  for(i=0;i<Elements.GetSize();i++) {
    if(!Elements[i].isBeamElement()) continue;
    node[0] = Elements[i].GetElemNode(0);
    node[1] = Elements[i].GetElemNode(1);
    if(fabs(node[0].GetPoint().Y-node[1].GetPoint().Y)<EPS) continue;
    if(!range.Operate(node[0].GetPoint()) || !range.Operate(node[1].GetPoint())) continue;

    nodenum[0] = Elements[i].GetNodeNumber(0);
    nodenum[1] = Elements[i].GetNodeNumber(1);
    ymin = node[0].GetPoint().Y;
    ymax = (node[0].GetPoint().Y+node[1].GetPoint().Y)/2;
    len = fabs(ymax-ymin);
    if(ymin>ymax) swap(ymin,ymax);
    GetSubPolygon(ymin,ymax,press,poly);
    nodal(nodenum[0],0) += poly.GetArea();

    ymin = (node[0].GetPoint().Y+node[1].GetPoint().Y)/2;
    ymax = node[1].GetPoint().Y;
    len = fabs(ymax-ymin);
    if(ymin>ymax) swap(ymin,ymax);
    GetSubPolygon(ymin,ymax,press,poly);
    nodal(nodenum[1],0) += poly.GetArea();
  }
  return true;
}

bool MkMori::CalcDistLoad(MkRangeTree &range, MkPolygon &press, MkFloat &nodal)
{
  int i,j;
  float ymin,ymax;
  MkNode node[2];
  int nodenum[2];
  float aj,bj,lj,lj1,len;
  float f1,f2,f3,f4;
  MkPolygon poly;

  for(i=0;i<Elements.GetSize();i++) {
    if(!Elements[i].isBeamElement()) continue;
    MkBeamElement *beam = dynamic_cast<MkBeamElement*>(&Elements[i]);
    node[0] = Elements[i].GetElemNode(0);
    node[1] = Elements[i].GetElemNode(1);
    if(fabs(node[0].GetPoint().Y-node[1].GetPoint().Y)<EPS) continue;
    if(!range.Operate(node[0].GetPoint()) || !range.Operate(node[1].GetPoint())) continue;

    nodenum[0] = Elements[i].GetNodeNumber(0);
    nodenum[1] = Elements[i].GetNodeNumber(1);

    if(node[0].GetPoint().Y<node[1].GetPoint().Y) {
      Swap(node[0],node[1]);
      swap(nodenum[0],nodenum[1]);
    }

    ymin = node[0].GetPoint().Y;
    ymax = node[1].GetPoint().Y;
    len = fabs(ymax-ymin);
    if(ymin>ymax) swap(ymin,ymax);

    GetSubPolygon(ymin,ymax,press,poly);

    f1=f2=f3=f4=0; // element-wise integration of shape function...
    for(j=0;j<poly.GetSize();j++) {
      GetSubParam(j,poly,aj,bj,lj1,lj);
      f1 += ShapeFunInteg1(aj,bj,len,lj1,lj);
      f2 += ShapeFunInteg2(aj,bj,len,lj1,lj);
      f3 += ShapeFunInteg3(aj,bj,len,lj1,lj);
      f4 += ShapeFunInteg4(aj,bj,len,lj1,lj);
    }
    nodal(nodenum[0],0) -= f1;
    nodal(nodenum[0],1) -= f2;
    nodal(nodenum[1],0) -= f3;
    nodal(nodenum[1],1) -= f4;
    if(!beam) continue;
    beam->GetFixedEnd()[0] += f3;  // still I can not figure it out...!
    beam->GetFixedEnd()[5] += f4;  // I hope I can understand sometime later.
    beam->GetFixedEnd()[6] += f1;
    beam->GetFixedEnd()[11] += f2;      
  }
  return true;
}

bool MkMori::CalcEarthLoad(MkLoad *load)
{
  bool flag;
  MkPolygon *refpoly;

  flag = true;
  flag = flag && load->GetLoadType() != ltRankine;
  flag = flag && load->GetLoadType() != ltPointBackLoad;
  flag = flag && load->GetLoadType() != ltLineBackLoad;
  if (flag) return false;
  if (load->GetLoadType() == ltRankine) refpoly = &load->GetStaticPress();
  else if (load->GetLoadType() != ltPointBackLoad) refpoly = &load->GetBackLoad();
  else if (load->GetLoadType() != ltLineBackLoad) refpoly = &load->GetBackLoad();

  MkPolygon &press = *refpoly;

  if(LoadingType==ltNodal) {
    if(load->GetDirection()[0]>0) flag = CalcNodalLoad(load->GetRange(),press,LeftEarthLoad);
    else if(load->GetDirection()[0]<0) flag = CalcNodalLoad(load->GetRange(),press,RightEarthLoad);
  }
  else if(LoadingType==ltDistributal) {
    if(load->GetDirection()[0]>0) flag = CalcDistLoad(load->GetRange(),press,LeftEarthLoad);
    else if(load->GetDirection()[0]<0) flag = CalcDistLoad(load->GetRange(),press,RightEarthLoad);
  }
  return flag;
}

bool MkMori::CalcEarthLu(MkLoad *load)
{
  bool flag;
  MkPolygon *refpoly;

  flag = true;
  flag = flag && load->GetLoadType() != ltRankine;
  flag = flag && load->GetLoadType() != ltPointBackLoad;
  flag = flag && load->GetLoadType() != ltLineBackLoad;
  if (flag) return false;
  if (load->GetLoadType() == ltRankine) refpoly = &load->GetPassivPress();
  else if (load->GetLoadType() != ltPointBackLoad) refpoly = &load->GetBackLoad();
  else if (load->GetLoadType() != ltLineBackLoad) refpoly = &load->GetBackLoad();

  MkPolygon &press = *refpoly;

  if(LoadingType==ltNodal) {
    if(load->GetDirection()[0]>0) flag = CalcNodalLoad(load->GetRange(),press,LeftEarthLu);
    else if(load->GetDirection()[0]<0) flag = CalcNodalLoad(load->GetRange(),press,RightEarthLu);
  }
  else if(LoadingType==ltDistributal) {
    if(load->GetDirection()[0]>0) flag = CalcDistLoad(load->GetRange(),press,LeftEarthLu);
    else if(load->GetDirection()[0]<0) flag = CalcDistLoad(load->GetRange(),press,RightEarthLu);
  }

  return flag;
}

bool MkMori::CalcEarthLd(MkLoad *load)
{
  bool flag;
  MkPolygon *refpoly;

  flag = true;
  flag = flag && load->GetLoadType() != ltRankine;
  flag = flag && load->GetLoadType() != ltPointBackLoad;
  flag = flag && load->GetLoadType() != ltLineBackLoad;
  if (flag) return false;
  if (load->GetLoadType() == ltRankine) refpoly = &load->GetActivPress();
  else if (load->GetLoadType() != ltPointBackLoad) refpoly = &load->GetBackLoad();
  else if (load->GetLoadType() != ltLineBackLoad) refpoly = &load->GetBackLoad();

  MkPolygon &press = *refpoly;

  if(LoadingType==ltNodal) {
    if(load->GetDirection()[0]>0) flag = CalcNodalLoad(load->GetRange(),press,LeftEarthLd);
    else if(load->GetDirection()[0]<0) flag = CalcNodalLoad(load->GetRange(),press,RightEarthLd);
  }
  else if(LoadingType==ltDistributal) {
    if(load->GetDirection()[0]>0) flag = CalcDistLoad(load->GetRange(),press,LeftEarthLd);
    else if(load->GetDirection()[0]<0) flag = CalcDistLoad(load->GetRange(),press,RightEarthLd);
  }

  return flag;
}

bool MkMori::CalcHydLoad(MkLoad *load)
{
  bool flag;
  MkPolygon *refpoly;
  flag = true;
  flag = flag && load->GetLoadType() != ltStaticHydLoad;
  flag = flag && load->GetLoadType() != ltArbtrHydLoad;
  if (flag) return false;
  if (load->GetLoadType() != ltStaticHydLoad) refpoly = &load->GetWatPress();
  else if (load->GetLoadType() != ltArbtrHydLoad) refpoly = &load->GetWatPress();

  MkPolygon &press = *refpoly;

  if(LoadingType==ltNodal) {
    if(load->GetDirection()[0]>0) flag = CalcNodalLoad(load->GetRange(),press,LeftHydLoad);
    else if(load->GetDirection()[0]<0) flag = CalcNodalLoad(load->GetRange(),press,RightHydLoad);
  }
  else if(LoadingType==ltDistributal) {
    if(load->GetDirection()[0]>0) flag = CalcDistLoad(load->GetRange(),press,LeftHydLoad);
    else if(load->GetDirection()[0]<0) flag = CalcDistLoad(load->GetRange(),press,RightHydLoad);
  }

  return flag;
}

bool MkMori::CalcEarthLoad(MkLayers &lay)
{
  int i,j;
  int size;
  float ph,wp;
  MkPoint p;
  size = NodeRef->GetSize();
  if(size!=LeftHydLoad.getSzX()) return false;
  for(i=0;i<size;i++) {
    for (j=0;j<2;j++) {
      p = (*NodeRef)[i].GetPoint(); 
      ph = LeftEarthLoad(i,j); // should be vertical load
      wp = LeftHydLoad(i,j);
      TotLeftEarthLoad(i,j) = ph+wp; //2005/6/22
    }
  }
  if(size!=RightHydLoad.getSzX()) return false;
  for(i=0;i<size;i++) {
    for (j=0;j<2;j++) {
      p = (*NodeRef)[i].GetPoint();
      ph = RightEarthLoad(i,j);  
      wp = RightHydLoad(i,j);
      TotRightEarthLoad(i,j) = ph+wp; //2005/6/22
    }
  }
  return true;
}

void MkMori::UpdateNodalDis()
{
  int i,j,k,size=Var.GetSize();
  for (i=0;i<size;i++) {
    j=Stiff.GetSteer().Node(i);
    k=Stiff.GetSteer().NDof(i);
    if((*NodeRef)[j].GetDOFs()[k].GetDOFType()==doftXDis) {
      NodalDis(j) = Var(i);
      (*NodeRef)[j].SetXDis(Var(i));

      if(NodalDis(j)+EPS>NodalQu(j,0)+RightLimitQu(j,0)) {
	if(useQu) NodalQu(j,0) = NodalDis(j)-EPS*NodalDis(j)-RightLimitQu(j,0); // 
      }
      else if(NodalDis(j)-EPS<NodalQu(j,0)+LeftLimitQu(j,0)) {
	if(useQu) NodalQu(j,0) = NodalDis(j)-EPS*NodalDis(j)-LeftLimitQu(j,0);
      }
    }
    else if((*NodeRef)[j].GetDOFs()[k].GetDOFType()==doftZAng) {
      NodalAng(j) = Var(i);
      (*NodeRef)[j].SetZAng(Var(i));
      if(NodalAng(j)+EPS>NodalQu(j,1)+RightLimitQu(j,1)) {
	if(useQu) NodalQu(j,1) = NodalAng(j)-EPS*NodalAng(j)-RightLimitQu(j,1);
      }
      else if(NodalAng(j)-EPS<NodalQu(j,1)+LeftLimitQu(j,1)) {
	if(useQu) NodalQu(j,1) = NodalAng(j)-EPS*NodalAng(j)-LeftLimitQu(j,1);
      }
    }
  }                        
}

void MkMori::ExtractResult()
{
  int i,j,k,ndata=0,cnt=0;
  float t[]={0.0,0.25,0.5,0.75,1.0};
  float loc[2]={1e4,-1e4};
  float lp,rp;
  for (i=0;i<Elements.GetSize();i++) {
    Elements[i].Post();
    if(Elements[i].isBeamElement()) {
      MkBeamElement *beam = dynamic_cast<MkBeamElement*>(&Elements[i]);
      if(!beam) continue;
      MkLine &l = beam->GetLine();
      if(l[0].X<loc[0]) loc[0] = l[0].X;
      if(l[0].X>loc[1]) loc[1] = l[0].X;
      ndata+=2;
    }
  }

  WallResult.Clear();
  WallResult.Initialize(6,ndata);

  cnt=0;
  for (i=0;i<Elements.GetSize();i++) {
    if(Elements[i].isBeamElement()) {
      MkBeamElement *beam = dynamic_cast<MkBeamElement*>(&Elements[i]);
      if(!beam) continue;
      MkLine &l = beam->GetLine();
      for(j=0;j<2;j++,cnt++) {
        WallResult(0,cnt) = fabs(loc[0]-l[0].X)<EPS?0:1; // wall
        WallResult(1,cnt) = l.GetDivision(j).Y+((j==0)?+EPS:-EPS); // y-coord
        WallResult(2,cnt) = beam->GetDisp(j); // dis
	lp = LeftEarthPress(j);
	rp = RightEarthPress(j);
        WallResult(3,cnt) = LeftEarthPress(j)+RightEarthPress(j); // press
        WallResult(4,cnt) = ((j==0)?1:-1)*beam->GetShearForce(j); // shear
        WallResult(5,cnt) = ((j==0)?1:-1)*beam->GetMoment(j); // mom
      }
    }
  }

  for (i=0;i<ndata-1;i++) {
    for (j=i+1;j<ndata;j++) {
      if(fabs(WallResult(0,i)-WallResult(0,j))<EPS && WallResult(1,i)<WallResult(1,j)) {
        for (k=0;k<WallResult.getSzX();k++) {
//          swap(WallResult(k,i),WallResult(k,j));
        }
      }
    }
  }

  for (i=0;i<Elements.GetSize();i++) {
    if(Elements[i].isTrussElement()) {
      MkTrussElement *truss = dynamic_cast<MkTrussElement*>(&Elements[i]);
      if(!truss) continue;
      MkLine &l = truss->GetLine();
      ndata++;
    }
  }

  AxialResult.Initialize(3,ndata);
  cnt=0;
  for (i=0;i<Elements.GetSize();i++) {
    if(Elements[i].isTrussElement()) {
      MkTrussElement *truss = dynamic_cast<MkTrussElement*>(&Elements[i]);
      if(!truss) continue;
      MkLine &l = truss->GetLine();
      AxialResult(0,cnt) = l.GetDivision(0.5).X; // x-coord
      AxialResult(1,cnt) = l.GetDivision(0.5).Y; // y-coord
      AxialResult(2,cnt) = truss->GetAxialForce(0.5) ; //   axial force
    }
  }
}

void MkMori::CalcNodalLen() // nodal length
{
  static bool flag=true; 
  int i,nnode,nelem;
  float len;

  nnode = NodeRef->GetSize();
  nelem = Elements.GetSize();

  if(flag) for (i=0;i<nnode;i++) NodalLen(i) = 0;

  for(i=0;i<nelem;i++) {
    int nd[2];
    MkBeamElement *beam;
    beam = dynamic_cast<MkBeamElement*>(&Elements[i]);
    if(!beam) continue;
    len = beam->GetLength();
    nd[0] = beam->GetNodeNumber(0);
    nd[1] = beam->GetNodeNumber(1);
    if(flag) {
      NodalLen(nd[0]) += len/2;
      NodalLen(nd[1]) += len/2;
    }
  }
}

void MkMori::CalcNodalPress() // need to update 05/06/24
{
  float dis,ang,len;
  int nnode = NodeRef->GetSize();

  for(int i=0;i<nnode;i++) {
    dis = NodalDis(i)-NodalQu(i,0);
    ang = NodalAng(i)-NodalQu(i,1);
    len = NodalLen(i);
    if(len<EPS) continue;
    LeftEarthPress(i) = (TotLeftEarthLoad(i,0)+LeftNodalKh(i,0)*dis)/len;
    RightEarthPress(i) = (TotRightEarthLoad(i,0)+RightNodalKh(i,0)*dis)/len;
  }
}

void MkMori::InitVar()
{
  TotLeftEarthLoad.Initialize(NodeRef->GetSize(),2);
  TotRightEarthLoad.Initialize(NodeRef->GetSize(),2);
  //  EffLeftEarthLu.Initialize(NodeRef->GetSize(),2);
  //  EffRightEarthLu.Initialize(NodeRef->GetSize(),2);
  //  EffLeftEarthLd.Initialize(NodeRef->GetSize(),2);
  //  EffRightEarthLd.Initialize(NodeRef->GetSize(),2);

  LeftEarthLoad.Initialize(NodeRef->GetSize(),2);
  RightEarthLoad.Initialize(NodeRef->GetSize(),2);
  LeftEarthLu.Initialize(NodeRef->GetSize(),2);
  RightEarthLu.Initialize(NodeRef->GetSize(),2);
  LeftEarthLd.Initialize(NodeRef->GetSize(),2);
  RightEarthLd.Initialize(NodeRef->GetSize(),2);
  LeftHydLoad.Initialize(NodeRef->GetSize(),2);
  RightHydLoad.Initialize(NodeRef->GetSize(),2);

  NodalLoad.Initialize(NodeRef->GetSize(),2);

  LeftNodalKh.Initialize(NodeRef->GetSize(),2);
  RightNodalKh.Initialize(NodeRef->GetSize(),2);
  NodalQu.Initialize(NodeRef->GetSize(),2);
  LeftLimitQu.Initialize(NodeRef->GetSize(),2);
  RightLimitQu.Initialize(NodeRef->GetSize(),2);

  NodalLen.Initialize(NodeRef->GetSize());
  NodalDis.Initialize(NodeRef->GetSize());
  CurStepDis.Initialize(NodeRef->GetSize());
  NodalAng.Initialize(NodeRef->GetSize());
  CurStepAng.Initialize(NodeRef->GetSize());
  NodalShear.Initialize(NodeRef->GetSize());
  NodalMom.Initialize(NodeRef->GetSize());

  LeftEarthPress.Initialize(NodeRef->GetSize());
  RightEarthPress.Initialize(NodeRef->GetSize());
  LeftHydPress.Initialize(NodeRef->GetSize());
  RightHydPress.Initialize(NodeRef->GetSize());
  useQu = false; // default is does not consider Qu 
}

bool MkMori::CheckTol(MkVector &f, MkVector &b)
{
  bool flag;
  float q,w,m;
  int size=f.GetSize();
  if(size!=b.GetSize()) return false;
  flag = true;
  for (int i=0;i<size;i++) {
    q = f(i);
    w = b(i);
    m = max(q,w);
    if(TOL*TOL<m && m<TOL*10 && fabs((q-w)/m)>TOL) flag = false;
    else if(fabs(q-w)>TOL) flag = false;
  }
  return flag;
}

bool MkMori::Out()
{
  FILE *fp;
  char str[256];
  static bool flag=false;
  int nnode,nelem,i;
  memset(str,'\0',255);
  nnode = NodeRef->GetSize();
  nelem = Elements.GetSize();

  MkDebug("MkMori::Start function Out()\n");

  MkDebug("FileName is ");MkDebug(FileName);MkDebug("\n");

  if(strlen(FileName)) {
    fp = fopen(FileName,"a");

    if(!fp) {
      MkDebug(FileName);MkDebug(" is not found...fp is null so return false\n");
      return false;
    }

    if(!flag) {
      sprintf(str,"--------------BASIC OUTPUT-------------------\n");
      fputs(str,fp);
      sprintf(str,"- This is tempory outfile format to verify  -\n");
      fputs(str,fp);
      sprintf(str,"- the program logic and the results.        -\n");
      fputs(str,fp);
      sprintf(str,"- ESCOT(c)Copyright 2004, ESCO Eng. & Cons. -\n");
      fputs(str,fp);
      sprintf(str,"---------------------------------------------\n\n");
      fputs(str,fp);
    }

    sprintf(str,"STEP : %d\n\n",Step);
    fputs(str,fp);

    sprintf(str,"Node coordinate : number of node is %d\n", nnode);
    fputs(str,fp);
//               12345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890
    sprintf(str,"node      x       y     llq      disp      rlq        ld     lload        lu        rd     rload        ru    lstiff    rstiff\n");
    fputs(str,fp);

    for(i=0;i<nnode;i++) {
      float load;
      load = NodalLoad(i,0);
      load = NodalLoad(i,1);

      sprintf(str,"%3d %7.2f %7.2f %7.3f %9.3f %9.3f %9.3f %9.3f %9.3f %9.3f %9.3f %9.3f %9.3f %9.3f\n",
	      i, (*NodeRef)[i].GetPoint().X, (*NodeRef)[i].GetPoint().Y,LeftLimitQu(i,0)*1000,
	      /*(*NodeRef)[i].GetXDis()*1000*/NodalDis(i)*1000,RightLimitQu(i,0)*1000,LeftEarthLd(i,0),TotLeftEarthLoad(i,0),LeftEarthLu(i,0),RightEarthLd(i,0),TotRightEarthLoad(i,0),RightEarthLu(i,0)
        ,LeftNodalKh(i,0),RightNodalKh(i,0));
      fputs(str,fp);
    }

    sprintf(str,"\nElement : number of element is %d\n", nelem);
    fputs(str,fp);

//                 12345678901234567890123456789012345678901234567890
    sprintf(str,"   element    node0     node1 \n");
    fputs(str,fp);

    for(i=0;i<nelem;i++) {
      sprintf(str,"%10d %10d %10d\n", i, Elements[i].GetNodeNumber(0),Elements[i].GetNodeNumber(1));
      fputs(str,fp);
    }
    fclose(fp);
  }

#ifdef __BCPLUSPLUS__
  if(Memo) {
    sprintf(str,"STEP : %d\n\n",Step);
    Memo->Lines->Add(str);

//               123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890
    sprintf(str,"     node         x         y         z      disp    lpress    rpress     lload    rload\n");
    Memo->Lines->Add(str);

    for(int i=0;i<nnode;i++) {
      sprintf(str,"%3d %7.1f %7.1f %7.3f %9.3f %9.3f %9.3f %9.3f %9.3f %9.3f %9.3f %9.3f\n",
        i, (*NodeRef)[i].GetPoint().X, (*NodeRef)[i].GetPoint().Y,
        (*NodeRef)[i].GetXDis()*1000,LeftEarthLd(i,0),LeftEarthLoad(i,0),LeftEarthLu(i,0),RightEarthLd(i,0),RightEarthLoad(i,0),RightEarthLu(i,0)
        ,LeftNodalKh(i,0),RightNodalKh(i,0));
      Memo->Lines->Add(str);
    }

    sprintf(str,"\nElement : number of element is %d\n", nelem);
//    Memo->Lines->Add(str);
//               12345678901234567890123456789012345678901234567890
    sprintf(str,"   element    node0     node1 \n");
//    Memo->Lines->Add(str);

    for(int i=0;i<nelem;i++) {
      sprintf(str,"%10d %10d %10d\n", i, Elements[i].GetNodeNumber(0),Elements[i].GetNodeNumber(1));
//      Memo->Lines->Add(str);
    }
  }
#endif

  flag = true;
  return flag;
}

bool MkMori::Out(char *fname)
{
  FILE *fp;
  char str[256];
  static bool flag=false;
  int nnode,nelem,i;

  SetFileName(fname);
  memset(str,'\0',255);
  nnode = NodeRef->GetSize();
  nelem = Elements.GetSize();

  MkDebug("MkMori::Start function Out()\n");

  MkDebug("FileName is ");MkDebug(FileName);MkDebug("\n");

  if(strlen(FileName)) {
    if(!flag) fp = fopen(FileName,"w");
    else fp = fopen(FileName,"a");

    if(!fp) {
      MkDebug(FileName);MkDebug(" is not found...fp is null so return false\n");
      return false;
    }

    if(!flag) {
      sprintf(str,"--------------BASIC OUTPUT-------------------\n");
      fputs(str,fp);
      sprintf(str,"- This is tempory outfile format to verify  -\n");
      fputs(str,fp);
      sprintf(str,"- the program logic and the results.        -\n");
      fputs(str,fp);
      sprintf(str,"- ESCOT(c)Copyright 2004, ESCO Eng. & Cons. -\n");
      fputs(str,fp);
      sprintf(str,"---------------------------------------------\n\n");
      fputs(str,fp);
    }

    sprintf(str,"STEP : %d\n\n",Step);
    fputs(str,fp);

    sprintf(str,"Node coordinate : number of node is %d\n", nnode);
    fputs(str,fp);
//               12345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890
    sprintf(str,"     node         x         y         z      disp    lpress    rpress      load    moment     lstiff    rstiff\n");
    fputs(str,fp);

    for(i=0;i<nnode;i++) {
      sprintf(str,"%9d %9.3f %9.3f %9.3f %9.6f %9.6f %9.6f %9.6f %9.6f %9.3f %9.3f\n",
        i, (*NodeRef)[i].GetPoint().X, (*NodeRef)[i].GetPoint().Y,(*NodeRef)[i].GetPoint().Z,
	      /*(*NodeRef)[i].GetXDis()*1000*/NodalDis(i)*1000,LeftEarthPress(i,0),RightEarthPress(i,1),
        NodalLoad(i,0),NodalLoad(i,1),LeftNodalKh(i,0),RightNodalKh(i,0));
      fputs(str,fp);
    }

    sprintf(str,"\nElement : number of element is %d\n", nelem);
    fputs(str,fp);

//               12345678901234567890123456789012345678901234567890
    sprintf(str,"   element    node0     node1 \n");
    fputs(str,fp);

    for(i=0;i<nelem;i++) {
      sprintf(str,"%10d %10d %10d\n", i, Elements[i].GetNodeNumber(0),Elements[i].GetNodeNumber(1));
      fputs(str,fp);
    }
    fclose(fp);
  }
  flag = true;
  return flag;
}

void MkMori::Clear()
{
  TOL=(float)0.00001;
  AnalysisType=atMori;
  memset(FileName,'\0',255);
#ifdef __BCPLUSPLUS__  
  Memo=NULL;
#endif
}

bool MkMori::OutStiff(char *fname)
{
  int i,j,len;
  FILE *fp;  
  static bool once = false;
  char str[1024],s[256];
  MkMatrix &mat = Stiff.GetStiffMatrix();
  if(strlen(fname)==0) return false;

  if(once) fp = fopen(fname,"a");
  else fp = fopen(fname,"w");

  for(i=0;i<mat.GetFI();i++) {
    len = 0;
    memset(str,'\0',1023);
    for(j=0;j<mat.GetFJ();j++) {
      sprintf(s,"%11.1f ",mat(i,j));
      len = len+strlen(s);
      if(len>1024) break;
      strcat(str,s);
    }
    strcat(str,"\n");
    fputs(str,fp);
  }
  strcat(str,"\n");
  fputs(str,fp);
  fclose(fp);
  once = true;
}

bool MkMori::OutStiff(MkMatrix &mat, char *fname)
{
  int i,j,len;
  FILE *fp;  
  static bool once = false;
  char str[1024],s[256];
  if(strlen(fname)==0) return false;

  if(once) fp = fopen(fname,"a");
  else fp = fopen(fname,"w");

  for(i=0;i<mat.GetFI();i++) {
    len = 0;
    memset(str,'\0',1023);
    for(j=0;j<mat.GetFJ();j++) {
      sprintf(s,"%11.1f ",mat(i,j));
      len = len+strlen(s);
      if(len>1024) break;
      strcat(str,s);
    }
    strcat(str,"\n");
    fputs(str,fp);
  }
  fputs("\n",fp);
  fclose(fp);
  once = true;
}

bool MkMori::OutLoad(char *fname)
{
  int i;
  float tl,tr,nl0,nl1;
  FILE *fp;  
  char str[512];
  if(strlen(fname)==0) return false;
  fp = fopen(fname,"a");
  //     123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890
  fputs("     no.      NLoad0    NLoad1   ELLoad0    LLoad0    LLoad1      LLu0      LLu1      LLd0      LLd1   ERLoad0    RLoad0    RLoad1      RLu0      RLu1      RLd0      RLd1\n",fp);
  for(i=0;i<NodeRef->GetSize();i++) {
    tl = TotLeftEarthLoad(i,0);
    tr = TotRightEarthLoad(i,0);
    nl0 = NodalLoad(i,0);
    nl1 = NodalLoad(i,1);
    sprintf(str,"%10d%10.3f%10.3f%10.3f%10.3f%10.3f%10.3f%10.3f%10.3f%10.3f%10.3f%10.3f%10.3f%10.3f%10.3f%10.3f%10.3f\n",
	    i,
	    NodalLoad(i,0),
	    NodalLoad(i,1),
	    TotLeftEarthLoad(i,0),
	    LeftEarthLoad(i,0),
	    LeftEarthLoad(i,1),
	    LeftEarthLu(i,0),
	    LeftEarthLu(i,1),
	    LeftEarthLd(i,0),
	    LeftEarthLd(i,1),
	    TotRightEarthLoad(i,0),
	    RightEarthLoad(i,0),
	    RightEarthLoad(i,1),
	    RightEarthLu(i,0),
	    RightEarthLu(i,1),
	    RightEarthLd(i,0),
	    RightEarthLd(i,1));
    fputs(str,fp);
  }

  fclose(fp);
}

bool MkMori::OutVar(char *fname)
{
 int i;
  FILE *fp;  
  char str[512];
  if(strlen(fname)==0) return false;
  fp = fopen(fname,"a");
  //     123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890
  fputs("     no.      Var    \n",fp);
  for(i=0;i<Var.GetSize();i++) {
    sprintf(str,"%10d%20.8f\n", i, Var(i));
    fputs(str,fp);
  }

  fclose(fp);
}

