//---------------------------------------------------------------------------
#ifndef MkPileH
#define MkPileH

#ifdef __BCPLUSPLUS__
#include "GlobalVarUnit.h"
#endif

#include "MkWall.h"
#include "MkMisc.h"
#include "MkBeam.h"
//---------------------------------------------------------------------------
enum MkPileLoc {plSide, plMid};  // to export pile with respect to sidepile, midpile(can not be sheetpile)
enum MkPileType {ptHBeam, ptIBeam, ptChannel, ptAngle, ptSheet}; // to determine sidepile or sheetpile

class MkPile : public MkWall {
protected:
  MkPileLoc  PileLoc;
  MkSteelType SteelType;
//HH,BB,tt1, tt2, AA, Aw,W,Zx,Ix,rx,ry for beam
  float Height;        // HH
  float Width;         // BB
  float T1,T2;         // tt1, tt2
  float Area, AreaWeb; // AA, Aw
  float Weight;        // W
  float SecCoeffY, SecCoeffZ;    // Section coefficient Zx, Zy
  float SecMomentY, SecMomentZ;  // second moment of inertial Ix, Iy
  float SecRadiusY, SecRadiusZ;  // second radius of inertia rx, ry

  float YoungMod;      // E
  float Spacing;
  float ShearTor;      //
  float YieldMom;
  float ActiveWidth, PassiveWidth;
public:
  MkPile();
  MkPile(int n);
  ~MkPile(){};
public:
  void SetPileLoc(MkPileLoc loc){PileLoc = loc;}
  void SetSteelType(MkSteelType st){SteelType = st;}
  void SetHeight(float h){Height=h;}
  void SetWidth(float w){Width=w;}
  void SetT1(float t){T1 = t;}
  void SetT2(float t){T2 = t;}
  void SetArea(float a){Area=a;}
  void SetAreaWeb(float a){AreaWeb=a;}
  void SetWeight(float w){Weight=w;}
  void SetSecCoeffY(float sm){SecCoeffY=sm;}
  void SetSecCoeffZ(float sm){SecCoeffZ=sm;}
  void SetSecMomentY(float sm){SecMomentY=sm;}
  void SetSecMomentZ(float sm){SecMomentZ=sm;}
  void SetSecRadiusY(float sm){SecRadiusY=sm;}
  void SetSecRadiusZ(float sm){SecRadiusZ=sm;}
  void SetBeam(MkBeam beam);

  void SetYoungMod(float y){YoungMod = y;}
  void SetSpacing(float s){Spacing=s;}
  void SetShearTor(float s){ShearTor = s;}
  void SetYieldMom(float ym){YieldMom=ym;}
  void SetActiveWidth(float aw){ActiveWidth = aw;}
  void SetPassiveWidth(float pw){PassiveWidth = pw;}
public:
  MkPileLoc GetPileLoc(){return PileLoc;}
  MkSteelType GetSteelType(){return SteelType;}
  float GetHeight(){return Height;}
  float GetWidth(){return Width;}
  float GetT1(){return T1;}
  float GetT2(){return T2;}
  float GetArea(){return Area;}
  float GetAreaWeb(){return AreaWeb;}
  float GetWeight(){return Weight;}
  float GetSecCoeffY(){return SecCoeffY;}
  float GetSecCoeffZ(){return SecCoeffZ;}
  float GetSecMomentY(){return SecMomentY;}  // second moment of inertial
  float GetSecMomentZ(){return SecMomentZ;}  // second moment of inertial
  float GetSecRadiusY(){return SecRadiusY;}
  float GetSecRadiusZ(){return SecRadiusZ;}

  float GetYoungMod(){return YoungMod;}
  float GetSpacing(){return Spacing;}
  float GetShearTor(){return ShearTor;}
  float GetYieldMom(){return YieldMom;}
  float GetActiveWidth(){return ActiveWidth;}
  float GetPassiveWidth(){return PassiveWidth;}
public:
#ifdef __BCPLUSPLUS__
  AnsiString ClassName(){return AnsiString("MkPile");};
  bool UpdateFrom(TStringGrid *grid){Grid = grid;return UpdateFrom();}
  bool UpdateTo(TStringGrid *grid){Grid = grid;return UpdateTo();}
  bool UpdateFrom();
  bool UpdateTo();
  void Out(TObject *);
  void Import(MkGlobalVar &globalvar, int sec);
  void Export(MkGlobalVar &globalvar, int sec);
#else
  char* ClassName(){return "MkPile";}
#endif

  void Out(char *fname);
  void Clear();

  MkLine &GetLine(){return Wall;}
  bool operator==(MkPile&);
  bool operator!=(MkPile&);
  MkPile &operator=(MkPile&);

#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif
};

class MkPiles {
protected:
  MkPile *FPile;
  int FSize;//Actual size of entities
  int FSizeOfArray;
#ifdef __BCPLUSPLUS__
  TColor Color;
#endif
public:
  MkPiles(int size,MkPile *ent);
  MkPiles(int size);
  MkPiles(){FSizeOfArray = FSize = 0;FPile = NULL;}
   ~MkPiles();
  virtual void Initialize(int size);
  virtual void Initialize(int size,MkPile *);
  int GetSize(){return FSize;};
  int GetSizeOfArray(){return FSizeOfArray;}
  int GetNumber(){return FSize;};
  bool Add(MkPile &pile);  // change of size of pile
  bool Add(int index,MkPile &pile);
  bool Delete(MkPile &pile);  // change of size of pile
  bool Delete(int index);
  int Grow(int Delta);            // change of size of array
  int Shrink(int Delta);          // change of size of array
  bool Clear();
#ifdef __BCPLUSPLUS__
  TColor GetColor(){return Color;};
  void SetColor(TColor c){Color = c;}
  void Out(TObject *);
  void Import(MkGlobalVar &globalvar, int sec);
  void Export(MkGlobalVar &globalvar, int sec);
#else
#endif

  void Out(char *fname);

#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif

  virtual MkPile & operator[](int);
  MkPiles & operator=(MkPiles &piles);
  bool operator==(MkPiles &piles);
};
//---------------------------------------------------------------------------
extern MkPile NullPile;
#endif
