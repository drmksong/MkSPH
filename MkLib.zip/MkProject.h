//---------------------------------------------------------------------------
#ifndef MkProjectH
#define MkProjectH

#ifdef __BCPLUSPLUS__

#include "GlobalVarUnit.h"
#include "MkIn.h"
#include "GLEntity.h"
#include <ComCtrls.hpp>
#include "treelist.hpp"

#include "MkKeyword.h"
#include "MkDimUnit.h"
#include "MkProfile.h"

//#include "KoVarUnit.h"
#include "MainUnit.h"
#include "MkAnalysis.h"
#include "MkSection.h"

#include "AnaCondUnit.h"
#include "ExcavStepUnit.h"
#include "LayerPropUnit.h"
#include "MajorSteelSpecUnit.h"
#include "PrjSettingUnit.h"
#include "ProfUnit.h"

#define AType 0
#define BType 1
//---------------------------------------------------------------------------
class MkProject {
protected:
  AnsiString FileName;
  MkAnalysisType AnaType;
  AnsiString projectcontent;

  bool Modified;
  bool isTanLoaded;
  int  CurrentStep;
  int  CurSec;

  int stress_type;  // AType : 0, BType : 1
  int liveloaddirection;
  int liveload1, liveload2, liveload3;

  MkDimUnit DimUnit;
  MkSections Section;
  GLEarthWalls EarthWall;

  MkIn In;
  MkGlobalVar GlobalVar;
  
public:
  AnsiString rpath;
  AnsiString projectname;

public:
  MkProject();
  ~MkProject(){};

public:
  void Clear();
  void Initialize(int nsec);
  bool Open(char *fname);
  bool OpenBasic(char *fname);
  bool OpenTxt(char *fname);

  bool Save();
  bool SaveAs(char *fname);
  bool SaveTxt(char *fname);

public:
  void Import(MkGlobalVar &globalvar);
  void Export(MkGlobalVar &globalvar);

  bool Import(char *fname); // SUNEX
  bool Export(char *fname); // SUNEX data file
  bool SetupSection();

  bool UpdateGLEntity();
  bool UpdateOverView(TTreeList *);
  bool Draw(TObject *Sender);
  bool UpdateTo(TObject *Sender);
  bool UpdateToMain(TObject *&Sender);
  bool UpdateToCond(TObject *Sender);
  bool UpdateToExcavStep(TObject *Sender);
  bool UpdateToPrjSetting(TObject *Sender);
  bool UpdateToProf(TObject *Sender);

  bool UpdateFrom(TObject *Sender);
  bool UpdateFromMain(TObject *Sender);
  bool UpdateFromCond(TObject *Sender);
  bool UpdateFromExcavStep(TObject *Sender);
  bool UpdateFromPrjSetting(TObject *Sender);
  bool UpdateFromProf(TObject *Sender);

  void SetFileName(AnsiString name){FileName = name;}
  void SetPrjName(AnsiString name){projectname = name;}
  void SetPrjDesc(AnsiString desc){projectcontent = desc;}
  void SetGlobalVar(MkGlobalVar &var){GlobalVar = var;}
  void SetStressType(int type){stress_type = type;}
  void SetCurSec(int cursec){CurSec = cursec;}
  void SetAnaType(MkAnalysisType at){AnaType =at;}
  void SetDimUnit(MkDimUnit &du){DimUnit = du;}
  void SetModified(bool flag){Modified=flag;}
  void SetModified(){Modified = true;}

  AnsiString GetFileName(){return FileName;}
  AnsiString GetPrjName(){return projectname;}
  AnsiString GetPrjDesc(){return projectcontent;}
  MkGlobalVar &GetGlobalVar(){return GlobalVar;}
  int GetStressType(){return stress_type;}
  MkSection &GetSection(int sec){return Section[sec];}
  MkSections &GetSection(){return Section;}
  int &GetCurSec(){return CurSec;}
  GLEarthWalls & GetEarthWall(){return EarthWall;}
  GLEarthWall & GetEarthWall(int i){return EarthWall[i];}
  MkAnalysisType GetAnaType(){return AnaType;}
  MkDimUnit &GetDimUnit(){return DimUnit;}
  int GetNumOfSec(){return Section.GetSize();/*NumOfSection;*/}
  bool isModified(){return Modified;}
};

TTreeNode *find(TTreeList *, char *target);
TTreeNode *find(TTreeList *, char *boundstart, char *boundend, char *target);
int know_pile_ea(char txt[]);

extern AnsiString acLoadStr[3];
extern MkProject Project;
//---------------------------------------------------------------------------
#endif //#ifdef __BCPLUSPLUS__
#endif //ifndef MkProjectH
