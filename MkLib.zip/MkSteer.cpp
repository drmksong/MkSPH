//---------------------------------------------------------------------------
#pragma hdrstop
//#include "stdafx.h"
#include "MkSteer.h"

#ifdef __BCPLUSPLUS__
#include <vcl.h>
#endif

//--------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#pragma package(smart_init)
#endif
//--------------------------------------------------------------------
void MkSteer::SetupSteer(MkNodes &nodes)
{
  int st_size,st_index;
  int i,j;

  st_size = 0;
  for(i=0;i<nodes.GetSize();i++) {
    for (j=0;j<nodes[i].GetDOFs().GetSize();j++)
        if(nodes[i].GetDOFs()[j].GetBNDType()==bndtFree) {
          st_size++;
        }
  }

  Steer.Initialize(st_size,2);

  st_index = 0;
  for(i=0;i<nodes.GetSize();i++) {
    for (j=0;j<nodes[i].GetDOFs().GetSize();j++)
        if(nodes[i].GetDOFs()[j].GetBNDType()==bndtFree) {
          nodes[i].GetDOFs()[j].SetSteer(st_index);
          Steer(st_index,0) = i; // number of node
          Steer(st_index,1) = j; // number of dof of node above 
          st_index++;
        }
  }

  assert(st_size==st_index);
}

#ifdef __BCPLUSPLUS__
void MkSteer::Out(TMemo *memo)
{
  char str[256];
  memo->Lines->Add("Output of MkSteer");

  for(int i=0;i<Steer.getSzX();i++) {
    sprintf(str,"%d-th term in stiff matrix is in %d-th node's %d-th dof",i,Steer(i,0),Steer(i,1));
    memo->Lines->Add(str);
  }
}
#else
void MkSteer::Out(char *fname)
{
  FILE *fp;
  char str[256];

  fp=fopen(fname,"a");
  if(!fp) return;

  fprintf(fp,"Output of MkSteer");

  for(int i=0;i<Steer.getSzX();i++) {
    sprintf(str,"%d-th term in stiff matrix is in %d-th node's %d-th dof",i,Steer(i,0),Steer(i,1));
    fprintf(fp,str);
  }
  fclose(fp);
}
#endif
//---------------------------------------------------------------------------

