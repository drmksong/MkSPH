//---------------------------------------------------------------------------
//#include <vcl.h>
//#pragma hdrstop
//#include "ParseEscot.h"
//---------------------------------------------------------------------------
//#pragma package(smart_init)

bool MkEscotParser::ParseEscot(char *str, MkKeyKind key)
{
  char s[256], *p;
  MkKeyword keyword;

  if(strlen(str)<1) return false;
  TrimLeft(s,str);

  if(keyword.IsKeyword(s)) p = strchr(s,' ');
  else p = s;

  if((p-s)>255) return false;

  switch(key) {
    case kkProject: return ParseEscotPrj(p); 
    case kkLayer: return ParseEscotLay(p); 
    case kkProfile: return ParseEscotPrf(p); 
    case kkWall: return ParseEscotWall(p); 
    case kkStrut: return ParseEscotStrut(p); 
    case kkAnchor: return ParseEscotAnchor(p); 
    case kkRockbolt: return ParseEscotRockbolt(p); 
    case kkSlab: return ParseEscotSlab(p); 
    case kkSlabWall: return ParseEscotSlabWall(p);
    case kkDivision: return ParseEscotDiv(p); 
    case kkSolution: return ParseEscotSol(p); 
    case kkPoint: return ParseEscotPnt(p); 
    case kkNoEcho: return ParseEscotNoEcho(p);
    case kkOutput: return ParseEscotOut(p); 
    case kkStep: return ParseEscotStep(p);
    case kkBottom: return ParseEscotBot(p); 
    case kkRankine: return ParseEscotRankine(p); 
    case kkPeck: return ParseEscotPeck(p); 
    case kkPeck1: return ParseEscotPeck1(p); 
    case kkEarthPress: return ParseEscotEarthPress(p); 
    case kkSlope: return ParseEscotSlope(p); 
    case kkPropileChange: return ParseEscotPrfChange(p);
    case kkGWL: return ParseEscotGWL(p);
    case kkWaterPress: return ParseEscotWaterPress(p);
    case kkSurcharge: return ParseEscotSurcharge(p);
    case kkLoad: return ParseEscotLoad(p); 
    case kkPress: return ParseEscotPress(p); 
    case kkMinAcive: return ParseEscotMinAct(p);
    case kkExcav: return ParseEscotExcav(p);
    case kkConst: return ParseEscotConst(p);
    case kkRemove: return ParseEscotRemove(p);
    case kkInsertCheck: return ParseEscotInsertCheck(p);
    case kkIteration: return ParseEscotInteration(p);
    case kkGroundSettle: return ParseEscotGroundSettle(p);
    case kkSlip: return ParseEscotSlip(p);
    case kkEnd: return true;
  }
}

bool MkEscotParser::ParseEscotPrj(char *str)
{
  PrjData.projectcontent = str;
}

bool MkEscotParser::ParseEscotLay(char *str)
{
  
}

bool MkEscotParser::ParseEscotPrf(char *str)
{

}

bool MkEscotParser::ParseEscotWall(char *str)
{

}

bool MkEscotParser::ParseEscotStrut(char *str)
{

}
bool MkEscotParser::ParseEscotAnchor(char *str)
{

}

bool MkEscotParser::ParseEscotRockbolt(char *str)
{

}

bool MkEscotParser::ParseEscotSlab(char *str)
{

}

bool MkEscotParser::ParseEscotSlabWall(char *str)
{

}

bool MkEscotParser::ParseEscotDiv(char *str)
{

}

bool MkEscotParser::ParseEscotSol(char *str)
{

}

bool MkEscotParser::ParseEscotPnt(char *str)
{

}

bool MkEscotParser::ParseEscotNoEcho(char *str)
{

}

bool MkEscotParser::ParseEscotOut(char *str)
{

}

bool MkEscotParser::ParseEscotStep(char *str)
{

}

bool MkEscotParser::ParseEscotBot(char *str)
{

}

bool MkEscotParser::ParseEscotRankine(char *str)
{

}

bool MkEscotParser::ParseEscotPeck(char *str)
{

}

bool MkEscotParser::ParseEscotPeck1(char *str)
{

}

bool MkEscotParser::ParseEscotEarthPress(char *str)
{

}

bool MkEscotParser::ParseEscotSlope(char *str)
{

}

bool MkEscotParser::ParseEscotPropile(char *str)
{

}

bool MkEscotParser::ParseEscotGWL(char *str)
{

}

bool MkEscotParser::ParseEscotWaterPress(char *str)
{

}

bool MkEscotParser::ParseEscotSurcharge(char *str)
{

}

bool MkEscotParser::ParseEscotLoad(char *str)
{

}

bool MkEscotParser::ParseEscotPress(char *str)
{

}

bool MkEscotParser::ParseEscotMinAct(char *str)
{

}

bool MkEscotParser::ParseEscotExcav(char *str)
{

}

bool MkEscotParser::ParseEscotConst(char *str)
{

}

bool MkEscotParser::ParseEscotRemove(char *str)
{

}

bool MkEscotParser::ParseEscotInsertCheck(char *str)
{

}

bool MkEscotParser::ParseEscotInteration(char *str)
{

}

bool MkEscotParser::ParseEscotGroundSettle(char *str)
{

}

bool MkEscotParser::ParseEscotSlip(char *str)
{

}

