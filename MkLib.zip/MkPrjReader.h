//---------------------------------------------------------------------------

#ifndef MkPrjReaderH
#define MkPrjReaderH
#include "MkPoint.h"
#include "MkEntity.h"
#include "Assert.h"
//---------------------------------------------------------------------------

class MkPrjReader {
protected:
  char        PrjFolder[256];
  MkPoints    CenterLine;
  MkPoints    LeftLine;
  MkPoints    RightLine;
  MkPoint     LeftStartPoint;
  MkPoint     RightStartPoint;
  float       GroundDiff;
  MkFloat     LeftExcavDepth;
  MkFloat     LeftLayerDepth;
  MkFloat     RightExcavDepth;
  MkFloat     RightLayerDepth;
  MkPoints    CentSectPoint;
  MkPoints    LeftSectPoint;
  MkFloat     SectWidth;
  MkInt       SectNum;
  MkFloat     RsmData;
  MkInt       RsmNum;
  MkInt       WaleNum;
  MkInt       AnchorNum;
  MkInt       BoltNum;
  AnsiString  *LayerNames;
  int         NumOfLayer;
  MkLayer     *Layers;
  MkWale      *Wales;
  MkStrut     *Struts;
  MkPile      *Piles;
  MkBolt      *Bolts;
  MkAnchor    *Anchors;
  TMemo       *Memo;
  TStringGrid *Grid;
public:
  MkPrjReader();
  MkPrjReader(char *fname);
  ~MkPrjReader();
  bool Read(char *fname);
  bool ReadLayerName();
  bool ReadCenterLine();
  bool ReadSideLine();
  bool ReadStartPosition();
  bool ReadSectPoint();
  bool ReadLayer();
  bool ReadSectWidth();
  bool ReadRSM();
  bool ReadSupport();
  void SetPrjName(char *fname){strcpy(PrjFolder,fname);}
  void SetMemo(TMemo *memo){Memo = memo;}
  void SetGrid(TStringGrid *grid){Grid = grid;}
  bool Clear();
  AnsiString GetName(int i){return (i<NumOfLayer)?LayerNames[i]:AnsiString("");}
  void SetName(int i,AnsiString){}
  __property AnsiString LayerName[int Index] = {read=GetName, write=SetName};
};
#endif
