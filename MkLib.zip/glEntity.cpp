//---------------------------------------------------------------------------
#include "glEntity.h"
//#include <vcl.h>
#pragma hdrstop
//---------------------------------------------------------------------------
#pragma package(smart_init)

TColor NullGLColor = clBlack;
GLDim NullGLDim(0);
GLCylinder NullGLCylinder(0);
GLCut NullGLCut(0);
GLFill NullGLFill(0);
GLBeam NullGLBeam(0);
GLStrata NullGLStrata(0);
GLPieceBracket NullGLPieceBracket(0);
GLMainBeamProp NullGLMainBeamProp(0);
GLWall NullGLWall(0);
GLRockBolt NullGLRockBolt(0);
GLAnchor NullGLAnchor(0);
GLWale NullGLWale(0);
GLPile NullGLPile(0);
GLEarthWall NullGLEarthWall(0);

GLObject::GLObject()
{
  MkPoint p[2];
  RotX=0;
  RotY=0;
  RotZ=0;
  LocX=0;
  LocY=0;
  LocZ=0;

  p[0].X = 0; p[0].Y = -0.5; p[0].Z = 0;
  p[1].X = 0; p[1].Y =  0.5; p[1].Z = 0;
  Line.SetLine(p[0],p[1]);
  Up.Initialize(3);
  Up[0]=1;Up[1]=0;Up[2]=0;
}

// rotate in y, and rotate in x, then in z. after rotate translate to the center
void GLObject::CalcRot()
{
  static MkVector vec(3);
  float v[3],up[3],u[3];
  MkMatrix4 mat;
  MkPoint cen;
  float X, Y, Z, L, delta, theta, psi;

  vec[0] = Line[1].X-Line[0].X;
  vec[1] = Line[1].Y-Line[0].Y;
  vec[2] = Line[1].Z-Line[0].Z;
  vec.Normalize();

  if(fabs(vec*Up)>EPS*10) {
    MkDebug("Direction and Up Vector is not perpendicular\n");
    return;
  }

  cen.X = (Line[1].X+Line[0].X)/2;
  cen.Y = (Line[1].Y+Line[0].Y)/2;
  cen.Z = (Line[1].Z+Line[0].Z)/2;

  LocX = cen.X;
  LocY = cen.Y;
  LocZ = cen.Z;

  X = vec[1];
  Y = vec[2];
  L = sqrt(X*X+Y*Y);

  if(L<EPS) {
    delta=0;
    psi = (fabs(vec[0]-1)<EPS) ? M_PI/2 : -M_PI/2;
  }
  else {
    delta = acos(X/L);
    if(fabs(sin(delta)-Y/L)<EPS);
    else delta = delta + M_PI;

    mat.LoadIdentity();
    mat.RotateInX(-delta*180/M_PI);

    v[0] = mat(0,0)*vec[0]+mat(0,1)*vec[1]+mat(0,2)*vec[2];
    v[1] = mat(1,0)*vec[0]+mat(1,1)*vec[1]+mat(1,2)*vec[2];
    v[2] = mat(2,0)*vec[0]+mat(2,1)*vec[1]+mat(2,2)*vec[2];

    X = v[0];
    Y = L;
    L = sqrt(X*X+Y*Y);

    psi = acos(Y/L);
    if(fabs(sin(psi)-X/L)<EPS);
    else psi = -psi;
  }

  RotX = -delta*180.0/M_PI;
  RotZ = -psi*180.0/M_PI;

  Up.Normalize();
  u[0] = Up[0]; u[1] = Up[1]; u[2] = Up[2];

  mat.LoadIdentity();
  mat.RotateInZ(-psi*180/M_PI);
  mat.RotateInX(-delta*180/M_PI);

  up[0] = mat(0,0)*u[0]+mat(0,1)*u[1]+mat(0,2)*u[2];
  up[1] = mat(1,0)*u[0]+mat(1,1)*u[1]+mat(1,2)*u[2];
  up[2] = mat(2,0)*u[0]+mat(2,1)*u[1]+mat(2,2)*u[2];

  L = up[0]*up[0]+up[1]*up[1]+up[2]*up[2];

//  if(fabs(up[1]/L)>0.05) return;

  X = up[0];
  Y = -up[2];
  L = sqrt(X*X+Y*Y);

  if(L<EPS) return;

  theta = acos(X/L);
  if(fabs(sin(theta)-Y/L) < EPS);
  else theta = theta + M_PI;

  RotY = -theta*180.0/M_PI;
}

void GLObject::TranRot()
{
  glTranslatef(LocX,LocY,LocZ);
  glRotatef(RotX,1.0,0.0,0.0);
  glRotatef(RotZ,0.0,0.0,1.0);
  glRotatef(RotY,0.0,1.0,0.0);
}

bool GLObject::operator==(GLObject &obj)
{
  bool flag = true;
  flag = flag && RotX==obj.RotX;
  flag = flag && RotY==obj.RotY;
  flag = flag && RotZ==obj.RotZ;
  flag = flag && LocX==obj.LocX;
  flag = flag && LocY==obj.LocY;
  flag = flag && LocZ==obj.LocZ;
  flag = flag && Line==obj.Line;
  flag = flag && Up==obj.Up;
  flag = flag && DrawMode==obj.DrawMode;
  return flag;
}

bool GLObject::operator!=(GLObject &obj)
{
  return !operator==(obj);
}

GLObject &GLObject::operator=(GLObject &obj)
{
  RotX=obj.RotX;
  RotY=obj.RotY;
  RotZ=obj.RotZ;
  LocX=obj.LocX;
  LocY=obj.LocY;
  LocZ=obj.LocZ;
  Line=obj.Line;
  Up=obj.Up;
  DrawMode=obj.DrawMode;
  return *this;
}

void GLObject::DrawGL()
{

}

void GLObject::DrawModel()
{

}

void GLObject::DrawResult()
{

}
//---------------------------------------------------------------------------
GLRect::GLRect() : GLObject()
{
  Width=0;
  Height=0;
}

void GLRect::DrawGL()
{
  glPushMatrix();
  TranRot();
  glBegin(GL_POLYGON);
     glColor3f(1.0,0.0,0.0);
     glNormal3f(0.0, 0.0,  1.0);
     glVertex3f(0, Height/2,  Width/2);
     glVertex3f(0, Height/2, -Width/2);
     glVertex3f(0,-Height/2, -Width/2);
     glVertex3f(0,-Height/2,  Width/2);
  glEnd();

  glPopMatrix();
}
//---------------------------------------------------------------------------
GLCube::GLCube() : GLRect()
{
  Thick=0;
}

void GLCube::DrawGL()
{
  glPushMatrix();
  TranRot();
  glBegin(GL_POLYGON);
     glColor3f(0.0,0.0,1.0);
     glNormal3f(0.0, 0.0,  1.0);
     glVertex3f(Thick/2, Height/2, Width/2 );
     glVertex3f(Thick/2, Height/2,-Width/2 );
     glVertex3f(Thick/2,-Height/2,-Width/2 );
     glVertex3f(Thick/2,-Height/2, Width/2 );
  glEnd();

  glBegin(GL_POLYGON);
     glColor3f(0.0,1.0,0.0);
     glNormal3f(-1.0, 0.0,  0.0);
     glVertex3f( Thick/2,-Height/2,-Width/2);
     glVertex3f( Thick/2, Height/2,-Width/2);
     glVertex3f(-Thick/2, Height/2,-Width/2);
     glVertex3f(-Thick/2,-Height/2,-Width/2);
  glEnd();

  glBegin(GL_POLYGON);
     glColor3f(0.0,1.0,1.0);
     glNormal3f(0.0, 1.0,  0.0);
     glVertex3f( Thick/2, Height/2,-Width/2);
     glVertex3f( Thick/2, Height/2, Width/2);
     glVertex3f(-Thick/2, Height/2, Width/2);
     glVertex3f(-Thick/2, Height/2,-Width/2);
  glEnd();

  glBegin(GL_POLYGON);
     glColor3f(1.0,0.0,0.0);
     glNormal3f(0.0, 0.0, -1.0);
     glVertex3f(-Thick/2, Height/2,-Width/2);
     glVertex3f(-Thick/2, Height/2, Width/2);
     glVertex3f(-Thick/2,-Height/2, Width/2);
     glVertex3f(-Thick/2,-Height/2,-Width/2);
  glEnd();

  glBegin(GL_POLYGON);
     glColor3f(1.0,0.0,1.0);
     glNormal3f( 1.0, 0.0,  0.0);
     glVertex3f( Thick/2, Height/2, Width/2);
     glVertex3f( Thick/2,-Height/2, Width/2);
     glVertex3f(-Thick/2,-Height/2, Width/2);
     glVertex3f(-Thick/2, Height/2, Width/2);
  glEnd();

  glBegin(GL_POLYGON);
     glColor3f(1.0,1.0,0.0);
     glNormal3f( 0.0, -1.0,  0.0);
     glVertex3f( Thick/2, -Height/2, Width/2);
     glVertex3f( Thick/2, -Height/2,-Width/2);
     glVertex3f(-Thick/2, -Height/2,-Width/2);
     glVertex3f(-Thick/2, -Height/2, Width/2);
  glEnd();

  glPopMatrix();
}
//---------------------------------------------------------------------------
GLCone::GLCone() : GLObject()
{
  TopRad=0;
  QObj = gluNewQuadric();
}

void GLCone::TranRot()
{
  glTranslatef(LocX,LocY,LocZ);
  glRotatef(RotX,1.0,0.0,0.0);
  glRotatef(RotY,0.0,1.0,0.0);
  glRotatef(RotZ,0.0,0.0,1.0);
}

// rotate in y, and rotate in x, then in z. after rotate translate to the center
void GLCone::CalcRot()
{
  static MkVector vec(3);
  float v[3],up[3],u[3];
  MkMatrix4 mat;
  MkPoint cen;
  float X, Y, Z, L, delta, theta, psi;

  vec[0] = Line[1].X-Line[0].X;
  vec[1] = Line[1].Y-Line[0].Y;
  vec[2] = Line[1].Z-Line[0].Z;
  vec.Normalize();

  if(fabs(vec*Up)>EPS*10) {
    MkDebug("Direction and Up Vector is not perpendicular\n");
    return;
  }

  Cen.X = (Line[1].X-Line[0].X)/2;
  Cen.Y = (Line[1].Y-Line[0].Y)/2;
  Cen.Z = (Line[1].Z-Line[0].Z)/2;

  LocX =  (Line[1].X+Line[0].X)/2;
  LocY =  (Line[1].Y+Line[0].Y)/2;
  LocZ =  (Line[1].Z+Line[0].Z)/2;

  X = vec[2];
  Y = -vec[1];
  L = sqrt(X*X+Y*Y);

  if(L<EPS) {
    delta=0;
    psi = (fabs(vec[0]-1)<EPS) ? M_PI/2 : -M_PI/2;
  }
  else {
    delta = acos(X/L);
    if(fabs(sin(delta)-Y/L)<EPS);
    else delta = delta + M_PI;

    mat.LoadIdentity();
    mat.RotateInX(-delta*180/M_PI);

    v[0] = mat(0,0)*vec[0]+mat(0,1)*vec[1]+mat(0,2)*vec[2];
    v[1] = mat(1,0)*vec[0]+mat(1,1)*vec[1]+mat(1,2)*vec[2];
    v[2] = mat(2,0)*vec[0]+mat(2,1)*vec[1]+mat(2,2)*vec[2];

    X = v[2];
    Y = v[0];
    L = sqrt(X*X+Y*Y);

    psi = acos(X/L);
    if(fabs(sin(psi)-Y/L)<EPS);
    else psi = -psi;
  }

  RotX = delta*180.0/M_PI;
  RotY = psi*180.0/M_PI;

  Up.Normalize();
  u[0] = Up[0]; u[1] = Up[1]; u[2] = Up[2];

  mat.LoadIdentity();
  mat.RotateInZ(-psi*180/M_PI);
  mat.RotateInX(-delta*180/M_PI);

  up[0] = mat(0,0)*u[0]+mat(0,1)*u[1]+mat(0,2)*u[2];
  up[1] = mat(1,0)*u[0]+mat(1,1)*u[1]+mat(1,2)*u[2];
  up[2] = mat(2,0)*u[0]+mat(2,1)*u[1]+mat(2,2)*u[2];

  L = up[0]*up[0]+up[1]*up[1]+up[2]*up[2];

//  if(fabs(up[1]/L)>0.05) return;

  X = up[0];
  Y = up[1];
  L = sqrt(X*X+Y*Y);

  if(L<EPS) return;

  theta = acos(X/L);
  if(fabs(sin(theta)-Y/L) < EPS);
  else theta = theta + M_PI;

  RotZ = theta*180.0/M_PI;
}

void GLCone::DrawGL()
{
  glPushMatrix();
  TranRot();
    glPushMatrix();
    glTranslatef(0,0,-Height/2);
    gluCylinder(QObj, 0, TopRad, Height, 36,36);
    glPopMatrix();
  glPopMatrix();
}
//---------------------------------------------------------------------------
GLCylinder::GLCylinder()
{
  BaseRad=0;
  QObj = gluNewQuadric();
}

GLCylinder::GLCylinder(int )
{
  BaseRad=0;
  QObj = gluNewQuadric();
}

void GLCylinder::DrawGL()
{
  glPushMatrix();
  TranRot();
    glPushMatrix();
    glTranslatef(0,0,-Height/2);
    gluCylinder(QObj, BaseRad, TopRad, Height, 36,36);
    glPopMatrix();
  glPopMatrix();
}
//---------------------------------------------------------------------------
GLCylinders::GLCylinders(int size,GLCylinder *cylinders)
{
    if (size < 0) {
      MkDebug("::GLCylinders - GLCylinders(int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSize == 0) {
       FCylinder = NULL;
       return;
    }

    FCylinder = new GLCylinder[FSize];
    if(!FCylinder)
      for (int i=0;i<FSize;i++) FCylinder[i] = cylinders[i];
}

GLCylinders::GLCylinders(int size)
{
    if (size < 0) {
      MkDebug("::GLCylinders - GLCylinders(int size)");;
      return;
    }

    FSize = FSizeOfArray = size;

    if (FSizeOfArray == 0) {
       FCylinder = NULL;
       return;
    }

    FCylinder = new GLCylinder[FSizeOfArray];
}

GLCylinders::~GLCylinders()
{
   FSizeOfArray = FSize = 0;
   if (FCylinder) {
      delete[] FCylinder;
      FCylinder = NULL;
   }
}

void GLCylinders::Initialize(int size)
{
    if (size < 0) {
      MkDebug("::GLCylinders - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;

    FSize = FSizeOfArray = size;

    if (FSizeOfArray == 0) {
       if (FCylinder!=NULL) delete[] (GLCylinder*)FCylinder;
       FCylinder = NULL;
       return;
    }

    if (FCylinder!=NULL) delete[] (GLCylinder*)FCylinder;
    FCylinder = new GLCylinder[FSizeOfArray];
}

void GLCylinders::Initialize(int size,GLCylinder *cylinders)
{

    if (size < 0 || cylinders == NULL) {
      MkDebug("::GLCylinders - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSize = FSizeOfArray = size;
    if (FSizeOfArray == 0) {
       if (FCylinder!=NULL) delete[] (GLCylinder*)FCylinder;
       FCylinder = NULL;
       return;
    }

    if (FCylinder!=NULL) delete[] (GLCylinder*)FCylinder;
    FCylinder = new GLCylinder[FSizeOfArray];
    for (int i=0;i<FSizeOfArray;i++) FCylinder[i] = cylinders[i];
}

int GLCylinders::Grow(int delta)
{
    int i;
    GLCylinder *cylinder=NULL;

    if (!(cylinder = new GLCylinder[FSizeOfArray+delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        cylinder[i] = FCylinder[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        cylinder[i] = NullGLCylinder;
    if (FCylinder) {
       delete[] (GLCylinder*)FCylinder;
       FCylinder = NULL;
    }
    FCylinder = cylinder;
    FSizeOfArray = FSizeOfArray+delta;

    return FSizeOfArray;
}

int GLCylinders::Shrink(int delta)
{
    int i;
    GLCylinder *cylinder=NULL;

    if (!(cylinder = new GLCylinder[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        cylinder[i] = FCylinder[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        cylinder[i] = NullGLCylinder;
    if (FCylinder) {
       delete[] (GLCylinder*)FCylinder;
       FCylinder = NULL;
    }
    FCylinder = cylinder;
    FSizeOfArray = FSizeOfArray-delta;

    return FSizeOfArray;
}

bool GLCylinders::Add(GLCylinder &cylinder)
{
    int tmp=FSizeOfArray;
    bool flag=false;
    for (int i=0;i<FSize;i++) if (FCylinder[i]==cylinder) flag=true;

    if(flag) return false;
    if (FSize>=FSizeOfArray) {
       Grow(FSize-FSizeOfArray+10);
       if (tmp==FSizeOfArray) return false;
    }
    FSize++;
    FCylinder[FSize-1] = cylinder;

    return true;
}

bool GLCylinders::Delete(GLCylinder &cylinder)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FCylinder[i] == cylinder) break;
    }
    if(i==FSize) return false;
    if(FCylinder[i] == cylinder) {
      for (int j=i;j<FSize-1;j++)
        FCylinder[j] = FCylinder[j+1];
    }
    FSize--;
    FCylinder[FSize] = NullGLCylinder;
    return true;
}

bool GLCylinders::Clear()
{
   FSizeOfArray = FSize = 0;
   if (FCylinder) {
      delete[] FCylinder;
      FCylinder = NULL;
   }
   return true;
}

GLCylinder & GLCylinders::operator[](int i)
{
    if (FSizeOfArray == 0) return NullGLCylinder;
    if (i >= FSize && i < FSizeOfArray) FSize = i+1;

    if (i >=0 && i < FSize) return FCylinder[i];
    else return NullGLCylinder;
}

GLCylinders & GLCylinders::operator=(GLCylinders &cylinders)
{
    int i;

    Clear();
    FSize = cylinders.FSize;
    FSizeOfArray = cylinders.FSizeOfArray;
    if (FSize == 0) {
       FCylinder = NULL;
       return *this;
    }
    this->FCylinder = new GLCylinder[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FCylinder[i] = cylinders.FCylinder[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FCylinder[i] = NullGLCylinder;

    return *this;
}

bool GLCylinders::operator==(GLCylinders &cylinders)
{
  int i;

  if (FSize != cylinders.FSize) return false;
  for (i=0;i<FSize;i++)
    if (this->FCylinder[i] != cylinders.FCylinder[i]) return false;

  return true;
}

//---------------------------------------------------------------------------
GLSphere::GLSphere()
{
  Rad=0;
  QObj = gluNewQuadric();
}

void GLSphere::DrawGL()
{
  glPushMatrix();
  TranRot();
  gluSphere(QObj, Rad, 36,36);

  glPopMatrix();
}
//---------------------------------------------------------------------------
GLBeam::GLBeam()
{
  BeamType = btHBeam;

  H=0;
  B=0;
  L=0;
  T1 = 0;
  T2 = 0;
}

GLBeam::GLBeam(int )
{
  BeamType = btHBeam;

  H=0;
  B=0;
  L=0;
  T1 = 0;
  T2 = 0;
}

bool GLBeam::operator==(GLBeam &beam)
{
  bool flag=true;
  flag = GLObject::operator==(beam);
  
  flag == flag && BeamType==beam.BeamType;
  flag == flag && Spec==beam.Spec;
  flag == flag && H==beam.H;
  flag == flag && B==beam.B;
  flag == flag && L==beam.L;
  flag == flag && T1==beam.T1;
  flag == flag && T2==beam.T2;
  return flag;
}

bool GLBeam::operator!=(GLBeam &beam)
{
  return !operator==(beam);
}

GLBeam &GLBeam::operator=(GLBeam &beam)
{
  BeamType=beam.BeamType;
  Spec=beam.Spec;
  H=beam.H;
  B=beam.B;
  L=beam.L;
  T1=beam.T1;
  T2=beam.T2;
  return *this;
}

void GLBeam::DrawGL()
{
  switch(BeamType) {
    case btHBeam:
         DrawHBeam();
         break;
    case btIBeam:
         DrawIBeam();
         break;
    case btLBeam:
         DrawLBeam();
         break;
    case btCBeam:
         DrawCBeam();
         break;
    case btSheet:
         DrawSheet();
         break;
  }
}

void GLBeam::DrawHBeam()
{
  glPushMatrix();
  TranRot();
/*  glBegin(GL_POLYGON);
     glColor4f(0.0,0.0,1.0,0.5);
     glNormal3f( 1.0, 0.0,  0.0);
     glVertex3f(-H/2, L/2, B/2);
     glVertex3f(-H/2, L/2,-B/2);
     glVertex3f(-H/2,-L/2,-B/2);
     glVertex3f(-H/2,-L/2, B/2);
  glEnd();

  glBegin(GL_POLYGON);
     glColor3f(0.0,1.0,0.0);
     glNormal3f(-1.0, 0.0,  0.0);
     glVertex3f( H/2, L/2, B/2);
     glVertex3f( H/2,-L/2, B/2);
     glVertex3f( H/2,-L/2,-B/2);
     glVertex3f( H/2, L/2,-B/2);
  glEnd();

  glBegin(GL_POLYGON);
     glColor3f(0.0,1.0,1.0);
     glNormal3f(0.0, 0.0, 1.0);
     glVertex3f(-H/2, L/2,0-0.01);
     glVertex3f(-H/2,-L/2,0-0.01);
     glVertex3f( H/2,-L/2,0-0.01);
     glVertex3f( H/2, L/2,0-0.01);
  glEnd();
*/
  glBegin(GL_POLYGON);
     glColor4f(0.0,0.0,1.0,0.5);
     glNormal3f( 1.0, 0.0,  0.0);
     glVertex3f(-H/2-0.00,-L/2, B/2);
     glVertex3f(-H/2-0.00,-L/2,-B/2);
     glVertex3f(-H/2-0.00, L/2,-B/2);
     glVertex3f(-H/2-0.00, L/2, B/2);
  glEnd();

  glBegin(GL_POLYGON);
     glColor3f(0.0,1.0,0.0);
     glNormal3f(-1.0, 0.0,  0.0);
     glVertex3f( H/2+0.00, L/2,-B/2);
     glVertex3f( H/2+0.00,-L/2,-B/2);
     glVertex3f( H/2+0.00,-L/2, B/2);
     glVertex3f( H/2+0.00, L/2, B/2);
  glEnd();

  glBegin(GL_POLYGON);
     glColor3f(0.0,1.0,1.0);
     glNormal3f(0.0, 0.0, 1.0);
     glVertex3f( H/2, L/2,0+0.00);
     glVertex3f( H/2,-L/2,0+0.00);
     glVertex3f(-H/2,-L/2,0+0.00);
     glVertex3f(-H/2, L/2,0+0.00);
  glEnd();

  glBegin(GL_LINES);
     glVertex3f(-H/2-0.00,-L/2, B/2);
     glVertex3f(-H/2-0.00,-L/2,-B/2);
     glVertex3f(-H/2-0.00,-L/2,-B/2);
     glVertex3f(-H/2-0.00, L/2,-B/2);
     glVertex3f(-H/2-0.00, L/2,-B/2);
     glVertex3f(-H/2-0.00, L/2, B/2);
     glVertex3f(-H/2-0.00, L/2, B/2);
     glVertex3f(-H/2-0.00,-L/2, B/2);

     glVertex3f(H/2-0.00,-L/2, B/2);
     glVertex3f(H/2-0.00,-L/2,-B/2);
     glVertex3f(H/2-0.00,-L/2,-B/2);
     glVertex3f(H/2-0.00, L/2,-B/2);
     glVertex3f(H/2-0.00, L/2,-B/2);
     glVertex3f(H/2-0.00, L/2, B/2);
     glVertex3f(H/2-0.00, L/2, B/2);
     glVertex3f(H/2-0.00,-L/2, B/2);

     glVertex3f( H/2, L/2,0+0.00);
     glVertex3f( H/2,-L/2,0+0.00);
     glVertex3f( H/2,-L/2,0+0.00);
     glVertex3f(-H/2,-L/2,0+0.00);
     glVertex3f(-H/2,-L/2,0+0.00);
     glVertex3f(-H/2, L/2,0+0.00);
     glVertex3f(-H/2, L/2,0+0.00);
     glVertex3f( H/2, L/2,0+0.00);
  glEnd();

  glPopMatrix();
}

void GLBeam::DrawIBeam()
{
  glPushMatrix();
  TranRot();
  glBegin(GL_POLYGON);
     glColor4f(0.0,0.0,1.0,0.5);
     glNormal3f( 1.0, 0.0,  0.0);
     glVertex3f(-H/2, L/2, B/2);
     glVertex3f(-H/2, L/2,-B/2);
     glVertex3f(-H/2,-L/2,-B/2);
     glVertex3f(-H/2,-L/2, B/2);
  glEnd();

  glBegin(GL_POLYGON);
     glColor3f(0.0,1.0,0.0);
     glNormal3f(-1.0, 0.0,  0.0);
     glVertex3f( H/2, L/2, B/2);
     glVertex3f( H/2,-L/2, B/2);
     glVertex3f( H/2,-L/2,-B/2);
     glVertex3f( H/2, L/2,-B/2);
  glEnd();

  glBegin(GL_POLYGON);
     glColor3f(0.0,1.0,1.0);
     glNormal3f(0.0, 0.0, 1.0);
     glVertex3f(-H/2, L/2,0);
     glVertex3f(-H/2,-L/2,0);
     glVertex3f( H/2,-L/2,0);
     glVertex3f( H/2, L/2,0);
  glEnd();

  glPopMatrix();
}

void GLBeam::DrawLBeam()
{
  glPushMatrix();
  TranRot();
  glBegin(GL_POLYGON);
     glColor3f(0.0,0.0,1.0);
     glNormal3f( 1.0, 0.0,  0.0);
     glVertex3f(-H/2, L/2, B/2);
     glVertex3f(-H/2, L/2,-B/2);
     glVertex3f(-H/2,-L/2,-B/2);
     glVertex3f(-H/2,-L/2, B/2);
  glEnd();

  glBegin(GL_POLYGON);
     glColor3f(0.0,1.0,1.0);
     glNormal3f(0.0, 0.0, 1.0);
     glVertex3f(-H/2, L/2, B/2);
     glVertex3f(-H/2,-L/2, B/2);
     glVertex3f( H/2,-L/2, B/2);
     glVertex3f( H/2, L/2, B/2);
  glEnd();

  glPopMatrix();
}

void GLBeam::DrawCBeam()
{
  glPushMatrix();
  TranRot();
  glBegin(GL_POLYGON);
     glColor3f(0.0,0.0,1.0);
     glVertex3f(-H/2, L/2, B/2);
     glVertex3f(-H/2,-L/2, B/2);
     glVertex3f(-H/2,-L/2,-B/2);
     glVertex3f(-H/2, L/2,-B/2);
  glEnd();

  glBegin(GL_POLYGON);
     glColor3f(0.0,1.0,1.0);
     glNormal3f(0.0, 0.0, 1.0);
     glVertex3f(-H/2, L/2, B/2);
     glVertex3f(-H/2,-L/2, B/2);
     glVertex3f( H/2,-L/2, B/2);
     glVertex3f( H/2, L/2, B/2);
  glEnd();

  glBegin(GL_POLYGON);
     glColor3f(0.0,1.0,1.0);
     glNormal3f(0.0, 0.0, -1.0);
     glVertex3f(-H/2, L/2,-B/2);
     glVertex3f( H/2, L/2,-B/2);
     glVertex3f( H/2,-L/2,-B/2);
     glVertex3f(-H/2,-L/2,-B/2);
  glEnd();

  glPopMatrix();
}

void GLBeam::DrawSheet()
{
  float h, b;
  b = 2*H*sin(5*3.14/180.0);
  glPushMatrix();
  TranRot();
  glBegin(GL_POLYGON);
     glColor3f(0.0,0.0,1.0);
     glVertex3f(-H/2, L/2, B/2-b);
     glVertex3f(-H/2,-L/2, B/2-b);
     glVertex3f(-H/2,-L/2,-B/2+b);
     glVertex3f(-H/2, L/2,-B/2+b);
  glEnd();

  glBegin(GL_POLYGON);
     glColor3f(0.0,1.0,1.0);
     glNormal3f(0.0, 0.0, 1.0);
     glVertex3f(-H/2, L/2, B/2-b);
     glVertex3f(-H/2,-L/2, B/2-b);
     glVertex3f( H/2,-L/2, B/2);
     glVertex3f( H/2, L/2, B/2);
  glEnd();

  glBegin(GL_POLYGON);
     glColor3f(0.0,1.0,1.0);
     glNormal3f(0.0, 0.0, -1.0);
     glVertex3f(-H/2, L/2,-B/2+b);
     glVertex3f( H/2, L/2,-B/2);
     glVertex3f( H/2,-L/2,-B/2);
     glVertex3f(-H/2,-L/2,-B/2+b);
  glEnd();

  glPopMatrix();
}
//---------------------------------------------------------------------------
GLColorBeam::GLColorBeam() : GLBeam()
{
  Font = NULL;
  Font2D = NULL;
  Division = 1;
  Scale = 1;
  matShi[0]=0,
  matAmb[0]=matAmb[1]=matAmb[2]=matAmb[3]=1.0;
  matDif[0]=matDif[1]=matDif[2]=matDif[3]=1.0;
  matSpc[0]=matSpc[1]=matSpc[2]=matSpc[3]=1.0;
}

void GLColorBeam::Mat(float r, float g, float b)
{
    matAmb[0]=r;
    matAmb[1]=g;
    matAmb[2]=b;

    matDif[0]=r;
    matDif[1]=g;
    matDif[2]=b;

    matSpc[0]=r;
    matSpc[1]=g;
    matSpc[2]=b;

    glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT, matAmb);
    glMaterialfv(GL_FRONT_AND_BACK,GL_DIFFUSE, matDif);
    glMaterialfv(GL_FRONT_AND_BACK,GL_SPECULAR, matSpc);
    glMaterialfv(GL_FRONT_AND_BACK,GL_SHININESS, matShi);
}

void GLColorBeam::DrawGL(MkFloat &res, GLColorLegend &legend)
{
  int i;
  float start,end,r,g,b,r1,g1,b1;
  TColor c;
  MkPolygon poly;
  AnsiString str;
  GLText label;
  label.SetFont(Font);

  Scale = 10;
  poly.Initialize(res.getSzX());
  for (i=0;i<res.getSzX();i++) {
    poly[i].Y = -res(i,0)-L/2;
    poly[i].X = res(i,1)*Scale;
  }

  glPushMatrix();
  TranRot();
  for (i=0;i<res.getSzX()-1;i++) {
    c = legend.GetColor(res(i,1));
    r = legend.GetRed(c);
    g = legend.GetGreen(c);
    b = legend.GetBlue(c);

    c = legend.GetColor(res(i+1,1));
    r1 = legend.GetRed(c);
    g1 = legend.GetGreen(c);
    b1 = legend.GetBlue(c);

//    r=g=b=1;
//    r1=g1=b1=1;

    start = -res(i,0);
    end = -res(i+1,0);

    glBegin(GL_POLYGON);
       Mat(r1,g1,b1);
       glVertex3f(-H/2,end-L/2, B/2);
       glVertex3f(-H/2,end-L/2,-B/2);
       Mat(r,g,b);
       glVertex3f(-H/2,start-L/2,-B/2);
       glVertex3f(-H/2,start-L/2,B/2);
    glEnd();

    glBegin(GL_POLYGON);
       Mat(r1,g1,b1);
       glNormal3f(0.0, 0.0, 1.0);
       Mat(r1,g1,b1);
       glVertex3f( H/2,end-L/2, -B/2);
       Mat(r,g,b);
       glVertex3f( H/2,start-L/2,-B/2);
       glVertex3f( H/2,start-L/2, B/2);
       Mat(r1,g1,b1);
       glVertex3f( H/2,end-L/2, B/2);
    glEnd();

    glBegin(GL_POLYGON);
       glNormal3f(0.0, 0.0, -1.0);
       Mat(r1,g1,b1);
       glVertex3f( H/2,end-L/2,0);
       Mat(r,g,b);
       glVertex3f( H/2,start-L/2,0);
       glVertex3f(-H/2,start-L/2,0);
       Mat(r1,g1,b1);
       glVertex3f(-H/2,end-L/2,0);
    glEnd();

    glPushMatrix();
      glTranslatef(H/2+0.2, poly[i].Y, 0);
      glScalef(0.5,0.5,0.5);
      Mat(0.2,0.2,0.2);
      str = FloatToStrF(res(i,1),ffGeneral,7,3);
      label.SetText(str);
      label.DrawGL();
    glPopMatrix();

    glLineWidth(2);
    glBegin(GL_LINES);
       Mat(r,g,b);
       glVertex3f(poly[i].X, poly[i].Y, poly[i].Z);
       Mat(r1,g1,b1);
       glVertex3f(poly[i+1].X, poly[i+1].Y, poly[i+1].Z);
    glEnd();
    glLineWidth(1);
  }

  glPushMatrix();
    glTranslatef(H/2+0.2, poly[i].Y, 0);
    glScalef(0.5,0.5,0.5);
    Mat(0.2,0.2,0.2);
    str = FloatToStrF(res(i,1),ffGeneral,7,3);
    label.SetText(str);
    label.DrawGL();
  glPopMatrix();

  glPopMatrix();
}
//---------------------------------------------------------------------------
GLBeams::GLBeams(int size,GLBeam *beams)
{
    if (size < 0) {
      MkDebug("::GLBeams - GLBeams(int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSize == 0) {
       FBeam = NULL;
       return;
    }

    FBeam = new GLBeam[FSize];
    if(!FBeam)
      for (int i=0;i<FSize;i++) FBeam[i] = beams[i];
}

GLBeams::GLBeams(int size)
{
    if (size < 0) {
      MkDebug("::GLBeams - GLBeams(int size)");;
      return;
    }

    FSize = FSizeOfArray = size;

    if (FSizeOfArray == 0) {
       FBeam = NULL;
       return;
    }

    FBeam = new GLBeam[FSizeOfArray];
}

GLBeams::~GLBeams()
{
   FSizeOfArray = FSize = 0;
   if (FBeam) {
      delete[] FBeam;
      FBeam = NULL;
   }
}

void GLBeams::Initialize(int size)
{
    if (size < 0) {
      MkDebug("::GLBeams - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;

    FSize = FSizeOfArray = size;

    if (FSizeOfArray == 0) {
       if (FBeam!=NULL) delete[] (GLBeam*)FBeam;
       FBeam = NULL;
       return;
    }

    if (FBeam!=NULL) delete[] (GLBeam*)FBeam;
    FBeam = new GLBeam[FSizeOfArray];
}

void GLBeams::Initialize(int size,GLBeam *beams)
{

    if (size < 0 || beams == NULL) {
      MkDebug("::GLBeams - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSize = FSizeOfArray = size;
    if (FSizeOfArray == 0) {
       if (FBeam!=NULL) delete[] (GLBeam*)FBeam;
       FBeam = NULL;
       return;
    }

    if (FBeam!=NULL) delete[] (GLBeam*)FBeam;
    FBeam = new GLBeam[FSizeOfArray];
    for (int i=0;i<FSizeOfArray;i++) FBeam[i] = beams[i];
}

int GLBeams::Grow(int delta)
{
    int i;
    GLBeam *beam=NULL;

    if (!(beam = new GLBeam[FSizeOfArray+delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        beam[i] = FBeam[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        beam[i] = NullGLBeam;
    if (FBeam) {
       delete[] (GLBeam*)FBeam;
       FBeam = NULL;
    }
    FBeam = beam;
    FSizeOfArray = FSizeOfArray+delta;

    return FSizeOfArray;
}

int GLBeams::Shrink(int delta)
{
    int i;
    GLBeam *beam=NULL;

    if (!(beam = new GLBeam[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        beam[i] = FBeam[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        beam[i] = NullGLBeam;
    if (FBeam) {
       delete[] (GLBeam*)FBeam;
       FBeam = NULL;
    }
    FBeam = beam;
    FSizeOfArray = FSizeOfArray-delta;

    return FSizeOfArray;
}

bool GLBeams::Add(GLBeam &beam)
{
    int tmp=FSizeOfArray;
    bool flag=false;
    for (int i=0;i<FSize;i++) if (FBeam[i]==beam) flag=true;

    if(flag) return false;
    if (FSize>=FSizeOfArray) {
       Grow(FSize-FSizeOfArray+10);
       if (tmp==FSizeOfArray) return false;
    }
    FSize++;
    FBeam[FSize-1] = beam;

    return true;
}

bool GLBeams::Delete(GLBeam &beam)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FBeam[i] == beam) break;
    }
    if(i==FSize) return false;
    if(FBeam[i] == beam) {
      for (int j=i;j<FSize-1;j++)
        FBeam[j] = FBeam[j+1];
    }
    FSize--;
    FBeam[FSize] = NullGLBeam;
    return true;
}

bool GLBeams::Clear()
{
   FSizeOfArray = FSize = 0;
   if (FBeam) {
      delete[] FBeam;
      FBeam = NULL;
   }
   return true;
}

GLBeam & GLBeams::operator[](int i)
{
    if (FSizeOfArray == 0) return NullGLBeam;
    if (i >= FSize && i < FSizeOfArray) FSize = i+1;

    if (i >=0 && i < FSize) return FBeam[i];
    else return NullGLBeam;
}

GLBeams & GLBeams::operator=(GLBeams &beams)
{
    int i;

    Clear();
    FSize = beams.FSize;
    FSizeOfArray = beams.FSizeOfArray;
    if (FSize == 0) {
       FBeam = NULL;
       return *this;
    }
    this->FBeam = new GLBeam[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FBeam[i] = beams.FBeam[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FBeam[i] = NullGLBeam;

    return *this;
}

bool GLBeams::operator==(GLBeams &beams)
{
  int i;

  if (FSize != beams.FSize) return false;
  for (i=0;i<FSize;i++)
    if (this->FBeam[i] != beams.FBeam[i]) return false;

  return true;
}
//---------------------------------------------------------------------------
bool GLCut::operator==(GLCut &s)
{
  bool flag=true;
  flag = GLObject::operator==(s);
  flag = flag && Piles == s.Piles;
  flag = flag && CutLine == s.CutLine;
  return flag;
}

bool GLCut::operator!=(GLCut &s)
{
  return !operator==(s);
}

GLCut & GLCut::operator=(GLCut &s)
{
  Piles = s.Piles;
  CutLine = s.CutLine;
  Dim = s.Dim;
  return *this;
}

bool GLCut::ImportStep(MkSection &sec)
{
  CutLine = sec.GetStepCut().GetProfile().GetProfile();
}

GLCuts::GLCuts(int size,GLCut *cuts)
{
    if (size < 0) {
      MkDebug("::GLCuts - GLCuts(int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSize == 0) {
       FCut = NULL;
       return;
    }

    FCut = new GLCut[FSize];
    if(!FCut)
      for (int i=0;i<FSize;i++) FCut[i] = cuts[i];
}

GLCuts::GLCuts(int size)
{
    if (size < 0) {
      MkDebug("::GLCuts - GLCuts(int size)");;
      return;
    }

    FSize = FSizeOfArray = size;

    if (FSizeOfArray == 0) {
       FCut = NULL;
       return;
    }

    FCut = new GLCut[FSizeOfArray];
}

GLCuts::~GLCuts()
{
   FSizeOfArray = FSize = 0;
   if (FCut) {
      delete[] FCut;
      FCut = NULL;
   }
}

void GLCuts::Initialize(int size)
{
    if (size < 0) {
      MkDebug("::GLCuts - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;

    FSize = FSizeOfArray = size;

    if (FSizeOfArray == 0) {
       if (FCut!=NULL) delete[] (GLCut*)FCut;
       FCut = NULL;
       return;
    }

    if (FCut!=NULL) delete[] (GLCut*)FCut;
    FCut = new GLCut[FSizeOfArray];
}

void GLCuts::Initialize(int size,GLCut *cuts)
{

    if (size < 0 || cuts == NULL) {
      MkDebug("::GLCuts - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSize = FSizeOfArray = size;
    if (FSizeOfArray == 0) {
       if (FCut!=NULL) delete[] (GLCut*)FCut;
       FCut = NULL;
       return;
    }

    if (FCut!=NULL) delete[] (GLCut*)FCut;
    FCut = new GLCut[FSizeOfArray];
    for (int i=0;i<FSizeOfArray;i++) FCut[i] = cuts[i];
}

int GLCuts::Grow(int delta)
{
    int i;
    GLCut *cut=NULL;

    if (!(cut = new GLCut[FSizeOfArray+delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        cut[i] = FCut[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        cut[i] = NullGLCut;
    if (FCut) {
       delete[] (GLCut*)FCut;
       FCut = NULL;
    }
    FCut = cut;
    FSizeOfArray = FSizeOfArray+delta;

    return FSizeOfArray;
}

int GLCuts::Shrink(int delta)
{
    int i;
    GLCut *cut=NULL;

    if (!(cut = new GLCut[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        cut[i] = FCut[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        cut[i] = NullGLCut;
    if (FCut) {
       delete[] (GLCut*)FCut;
       FCut = NULL;
    }
    FCut = cut;
    FSizeOfArray = FSizeOfArray-delta;

    return FSizeOfArray;
}

bool GLCuts::Add(GLCut &cut)
{
    int tmp=FSizeOfArray;
    bool flag=false;
    for (int i=0;i<FSize;i++) if (FCut[i]==cut) flag=true;

    if(flag) return false;
    if (FSize>=FSizeOfArray) {
       Grow(FSize-FSizeOfArray+10);
       if (tmp==FSizeOfArray) return false;
    }
    FSize++;
    FCut[FSize-1] = cut;

    return true;
}

bool GLCuts::Delete(GLCut &cut)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FCut[i] == cut) break;
    }
    if(i==FSize) return false;
    if(FCut[i] == cut) {
      for (int j=i;j<FSize-1;j++)
        FCut[j] = FCut[j+1];
    }
    FSize--;
    FCut[FSize] = NullGLCut;
    return true;
}

bool GLCuts::Clear()
{
   FSizeOfArray = FSize = 0;
   if (FCut) {
      delete[] FCut;
      FCut = NULL;
   }
   return true;
}

GLCut & GLCuts::operator[](int i)
{
    if (FSizeOfArray == 0) return NullGLCut;
    if (i >= FSize && i < FSizeOfArray) FSize = i+1;

    if (i >=0 && i < FSize) return FCut[i];
    else return NullGLCut;
}

GLCuts & GLCuts::operator=(GLCuts &cuts)
{
    int i;

    Clear();
    FSize = cuts.FSize;
    FSizeOfArray = cuts.FSizeOfArray;
    if (FSize == 0) {
       FCut = NULL;
       return *this;
    }
    this->FCut = new GLCut[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FCut[i] = cuts.FCut[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FCut[i] = NullGLCut;

    return *this;
}

bool GLCuts::operator==(GLCuts &cuts)
{
  int i;

  if (FSize != cuts.FSize) return false;
  for (i=0;i<FSize;i++)
    if (this->FCut[i] != cuts.FCut[i]) return false;

  return true;
}
//---------------------------------------------------------------------------
bool GLFill::operator==(GLFill &s)
{
  bool flag=true;
  flag = GLObject::operator==(s);  
  flag = flag && Piles == s.Piles;
  flag = flag && FillLine == s.FillLine;
  return flag;
}

bool GLFill::operator!=(GLFill &s)
{
  return !operator==(s);
}

GLFill & GLFill::operator=(GLFill &s)
{
  Piles = s.Piles;
  FillLine = s.FillLine;
  Dim = s.Dim;
  return *this;
}

bool GLFill::ImportStep(MkSection &sec)
{
  FillLine = sec.GetStepFill().GetProfile().GetProfile();
}

GLFills::GLFills(int size,GLFill *fills)
{
    if (size < 0) {
      MkDebug("::GLFills - GLFills(int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSize == 0) {
       FFill = NULL;
       return;
    }

    FFill = new GLFill[FSize];
    if(!FFill)
      for (int i=0;i<FSize;i++) FFill[i] = fills[i];
}

GLFills::GLFills(int size)
{
    if (size < 0) {
      MkDebug("::GLFills - GLFills(int size)");;
      return;
    }

    FSize = FSizeOfArray = size;

    if (FSizeOfArray == 0) {
       FFill = NULL;
       return;
    }

    FFill = new GLFill[FSizeOfArray];
}

GLFills::~GLFills()
{
   FSizeOfArray = FSize = 0;
   if (FFill) {
      delete[] FFill;
      FFill = NULL;
   }
}

void GLFills::Initialize(int size)
{
    if (size < 0) {
      MkDebug("::GLFills - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;

    FSize = FSizeOfArray = size;

    if (FSizeOfArray == 0) {
       if (FFill!=NULL) delete[] (GLFill*)FFill;
       FFill = NULL;
       return;
    }

    if (FFill!=NULL) delete[] (GLFill*)FFill;
    FFill = new GLFill[FSizeOfArray];
}

void GLFills::Initialize(int size,GLFill *fills)
{

    if (size < 0 || fills == NULL) {
      MkDebug("::GLFills - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSize = FSizeOfArray = size;
    if (FSizeOfArray == 0) {
       if (FFill!=NULL) delete[] (GLFill*)FFill;
       FFill = NULL;
       return;
    }

    if (FFill!=NULL) delete[] (GLFill*)FFill;
    FFill = new GLFill[FSizeOfArray];
    for (int i=0;i<FSizeOfArray;i++) FFill[i] = fills[i];
}

int GLFills::Grow(int delta)
{
    int i;
    GLFill *fill=NULL;

    if (!(fill = new GLFill[FSizeOfArray+delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        fill[i] = FFill[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        fill[i] = NullGLFill;
    if (FFill) {
       delete[] (GLFill*)FFill;
       FFill = NULL;
    }
    FFill = fill;
    FSizeOfArray = FSizeOfArray+delta;

    return FSizeOfArray;
}

int GLFills::Shrink(int delta)
{
    int i;
    GLFill *fill=NULL;

    if (!(fill = new GLFill[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        fill[i] = FFill[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        fill[i] = NullGLFill;
    if (FFill) {
       delete[] (GLFill*)FFill;
       FFill = NULL;
    }
    FFill = fill;
    FSizeOfArray = FSizeOfArray-delta;

    return FSizeOfArray;
}

bool GLFills::Add(GLFill &fill)
{
    int tmp=FSizeOfArray;
    bool flag=false;
    for (int i=0;i<FSize;i++) if (FFill[i]==fill) flag=true;

    if(flag) return false;
    if (FSize>=FSizeOfArray) {
       Grow(FSize-FSizeOfArray+10);
       if (tmp==FSizeOfArray) return false;
    }
    FSize++;
    FFill[FSize-1] = fill;

    return true;
}

bool GLFills::Delete(GLFill &fill)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FFill[i] == fill) break;
    }
    if(i==FSize) return false;
    if(FFill[i] == fill) {
      for (int j=i;j<FSize-1;j++)
        FFill[j] = FFill[j+1];
    }
    FSize--;
    FFill[FSize] = NullGLFill;
    return true;
}

bool GLFills::Clear()
{
   FSizeOfArray = FSize = 0;
   if (FFill) {
      delete[] FFill;
      FFill = NULL;
   }
   return true;
}

GLFill & GLFills::operator[](int i)
{
    if (FSizeOfArray == 0) return NullGLFill;
    if (i >= FSize && i < FSizeOfArray) FSize = i+1;

    if (i >=0 && i < FSize) return FFill[i];
    else return NullGLFill;
}

GLFills & GLFills::operator=(GLFills &fills)
{
    int i;

    Clear();
    FSize = fills.FSize;
    FSizeOfArray = fills.FSizeOfArray;
    if (FSize == 0) {
       FFill = NULL;
       return *this;
    }
    this->FFill = new GLFill[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FFill[i] = fills.FFill[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FFill[i] = NullGLFill;

    return *this;
}

bool GLFills::operator==(GLFills &fills)
{
  int i;

  if (FSize != fills.FSize) return false;
  for (i=0;i<FSize;i++)
    if (this->FFill[i] != fills.FFill[i]) return false;

  return true;
}
//---------------------------------------------------------------------------
GLStrata::GLStrata()
{
  isBuilt = false;
  Length=0;
}

GLStrata::GLStrata(int )
{
  isBuilt = false;
  Length=0;
}

void GLStrata::SetBaseFrom(MkLayers &lay)
{
  MkPolygon top, bot;

  if(lay.GetSize()<=0) {
    top.Initialize(2);
    top[0].SetPoint(-10,-10);
    top[1].SetPoint(10,-10);
    bot.Initialize(2);
    bot[0].SetPoint(-10,-11);
    bot[1].SetPoint(10,-11);
    SetTopProf(top);
    SetBotProf(bot);
  }
  else {

  }

}

bool GLStrata::operator==(GLStrata &s)
{
  bool flag=true;
  flag = GLObject::operator==(s);
  flag = flag && (RotX == s.RotX);
  flag = flag && (RotY == s.RotY);
  flag = flag && (RotZ == s.RotZ);
  flag = flag && (LocX == s.LocX);
  flag = flag && (LocY == s.LocY);
  flag = flag && (LocZ == s.LocZ);

  flag = flag && (Length = s.Length);
  return flag;
}

bool GLStrata::operator!=(GLStrata &s)
{
  return !operator==(s);
}

bool GLStrata::operator=(GLStrata &s)
{
  RotX = s.RotX;
  RotY = s.RotY;
  RotZ = s.RotZ;
  LocX = s.LocX;
  LocY = s.LocY;
  LocZ = s.LocZ;

  Name = s.Name;
  Length = s.Length;
  TopProf = s.TopProf;
  BotProf =  s.BotProf;
  Dim =  s.Dim;
  drawStrata  = s.drawStrata;
  isBuilt = false;
}

void GLStrata::BuildGL()
{
  int i,j,npoly,npnt;
  bool found;
  MkPoint pnt;
  MkPoints pnts;
  MkPolygon poly, cut, fill, &top = TopProf, &bot = BotProf;
  MkPolygons polys;

  Cut.GetCutLine();
  Fill.GetFillLine();

  poly.Clear();
  poly.SetCloseness(true);
  poly.Add(top[0]);

  for(i=0;i<bot.GetSize();i++) {
    poly.Add(bot[i]);
  }

  for(i=top.GetSize()-1;i>0;i--) {
    poly.Add(top[i]);
  }

  if(!Cut.GetCutLine().GetSize()) {
    Polys.Initialize(1);
    Polys[0] = poly;
    isBuilt = true;
    return;
  }

  cut.Clear();
  pnt.SetPoint(Cut.GetCutLine()[0].X,10);
  cut.Add(pnt);
  for(i=0;i<Cut.GetCutLine().GetSize();i++) cut.Add(Cut.GetCutLine()[i]);
//  cut.Add(Cut.GetCutLine().GetPoints());
  pnt.SetPoint(Cut.GetCutLine()[Cut.GetCutLine().GetSize()-1].X,10);
  cut.Add(pnt);
  cut.SetCloseness(true);

  poly.BoolSub(cut,Polys);
  isBuilt = true;
}

void GLStrata::DrawGL()
{
  int i,j,size=TopProf.GetSize();
  if(TopProf.GetSize()!=BotProf.GetSize()) return;

  static MkVector a(3),b(3),c(3);
  MkPoint pnt[8];

  if(!isBuilt) BuildGL();

  glPushMatrix();
  for(i=0;i<Polys.GetSize();i++) {
/*    glBegin(GL_POLYGON);
    c = Polys[i].GetVector();
    c.Normalize();
    glNormal3f( c[0], c[1], c[2]);

    for(j=0;j<Polys[i].GetSize()-(Polys[i].GetCloseness()?0:1);j++) {
      glVertex3f(Polys[i][j].X,Polys[i][j].Y,Polys[i][j].Z);
    }
    glEnd();
*/
    for (j=0;j<Polys[i].GetSize()-(Polys[i].GetCloseness()?0:1);j++) {
      pnt[0] = Polys[i][j];                                      //    3--------2
      pnt[1] = Polys[i][(j+1==Polys[i].GetSize())?0:j+1];        //    |        |
      pnt[2] = MkPoint(pnt[1].X, pnt[1].Y, Length);              //    |        |
      pnt[3] = MkPoint(pnt[0].X, pnt[0].Y, Length);              //    0--------1

      glBegin(GL_POLYGON);
      a[0] = pnt[1].X-pnt[0].X;a[1] = pnt[1].Y-pnt[0].Y;a[2] = pnt[1].Z-pnt[0].Z;
      b[0] = pnt[3].X-pnt[0].X;b[1] = pnt[3].Y-pnt[0].Y;b[2] = pnt[3].Z-pnt[0].Z;
      a.Cross(b,c); //cross product
      c.Normalize();

      glNormal3f( c[0], c[1], c[2]);
      glVertex3f(pnt[3].X,pnt[3].Y,pnt[3].Z);
      glVertex3f(pnt[2].X,pnt[2].Y,pnt[2].Z);
      glVertex3f(pnt[1].X,pnt[1].Y,pnt[1].Z);
      glVertex3f(pnt[0].X,pnt[0].Y,pnt[0].Z);
      glEnd();
    }
  }
  glPopMatrix();
/*
  glPushMatrix();
  TranRot();
  for (i=0;i<size-1;i++) {
    pnt[0] = TopProf[i];
    pnt[1] = BotProf[i];
    pnt[2] = BotProf[i+1];
    pnt[3] = TopProf[i+1];
    pnt[0].Z = 0;pnt[1].Z = 0;pnt[2].Z = 0;pnt[3].Z = 0;
    pnt[4] = MkPoint(pnt[0].X, pnt[0].Y, Length);
    pnt[5] = MkPoint(pnt[1].X, pnt[1].Y, Length);
    pnt[6] = MkPoint(pnt[2].X, pnt[2].Y, Length);
    pnt[7] = MkPoint(pnt[3].X, pnt[3].Y, Length);

    glBegin(GL_POLYGON);
      glColor3f(1.0,0.0,0.0);
      a[0] = pnt[1].X-pnt[0].X;a[1] = pnt[1].Y-pnt[0].Y;a[2] = pnt[1].Z-pnt[0].Z;
      b[0] = pnt[2].X-pnt[0].X;b[1] = pnt[2].Y-pnt[0].Y;b[2] = pnt[2].Z-pnt[0].Z;
      c=a&b; //cross product
      c.Normalize();
      glNormal3f( c[0], c[1], c[2]);
      glVertex3f(pnt[0].X,pnt[0].Y,pnt[0].Z);
      glVertex3f(pnt[1].X,pnt[1].Y,pnt[1].Z);
      glVertex3f(pnt[2].X,pnt[2].Y,pnt[2].Z);
      glVertex3f(pnt[3].X,pnt[3].Y,pnt[3].Z);
    glEnd();

    glBegin(GL_POLYGON);
      glColor3f(0.0,1.0,0.0);
      a[0] = pnt[7].X-pnt[4].X;a[1] = pnt[7].Y-pnt[4].Y;a[2] = pnt[7].Z-pnt[4].Z;
      b[0] = pnt[6].X-pnt[4].X;b[1] = pnt[6].Y-pnt[4].Y;b[2] = pnt[6].Z-pnt[4].Z;
      c=a&b; //cross product
      c.Normalize();
      glNormal3f( c[0], c[1], c[2]);
      glVertex3f(pnt[4].X,pnt[4].Y,pnt[4].Z);
      glVertex3f(pnt[7].X,pnt[7].Y,pnt[7].Z);
      glVertex3f(pnt[6].X,pnt[6].Y,pnt[6].Z);
      glVertex3f(pnt[5].X,pnt[5].Y,pnt[5].Z);
    glEnd();

    glBegin(GL_POLYGON);
      glColor3f(0.0,0.0,1.0);
      a[0] = pnt[3].X-pnt[0].X;a[1] = pnt[3].Y-pnt[0].Y;a[2] = pnt[3].Z-pnt[0].Z;
      b[0] = pnt[7].X-pnt[0].X;b[1] = pnt[7].Y-pnt[0].Y;b[2] = pnt[7].Z-pnt[0].Z;
      c=a&b; //cross product
      c.Normalize();
      glNormal3f( c[0], c[1], c[2]);
      glVertex3f(pnt[0].X,pnt[0].Y,pnt[0].Z);
      glVertex3f(pnt[3].X,pnt[3].Y,pnt[3].Z);
      glVertex3f(pnt[7].X,pnt[7].Y,pnt[7].Z);
      glVertex3f(pnt[4].X,pnt[4].Y,pnt[4].Z);
    glEnd();

    glBegin(GL_POLYGON);
      glColor3f(1.0,1.0,0.0);
      a[0] = pnt[5].X-pnt[1].X;a[1] = pnt[5].Y-pnt[1].Y;a[2] = pnt[5].Z-pnt[1].Z;
      b[0] = pnt[6].X-pnt[1].X;b[1] = pnt[6].Y-pnt[1].Y;b[2] = pnt[6].Z-pnt[1].Z;
      c=a&b; //cross product
      c.Normalize();
      glNormal3f( c[0], c[1], c[2]);
      glVertex3f(pnt[1].X,pnt[1].Y,pnt[1].Z);
      glVertex3f(pnt[5].X,pnt[5].Y,pnt[5].Z);
      glVertex3f(pnt[6].X,pnt[6].Y,pnt[6].Z);
      glVertex3f(pnt[2].X,pnt[2].Y,pnt[2].Z);
    glEnd();

  }

  for (i=0;i<size;i+=size-1) {
    if(i==0) {
      pnt[0] = TopProf[i];
      pnt[1] = TopProf[i];
      pnt[2] = BotProf[i];
      pnt[3] = BotProf[i];
      pnt[1].Z = Length;
      pnt[2].Z = Length;
    }
    else {
      pnt[0] = TopProf[i];
      pnt[1] = BotProf[i];
      pnt[2] = BotProf[i];
      pnt[3] = TopProf[i];
      pnt[2].Z = Length;
      pnt[3].Z = Length;
    }

    glBegin(GL_POLYGON);
      glColor3f(1.0,0.0,0.0);
      a[0] = pnt[1].X-pnt[0].X;a[1] = pnt[1].Y-pnt[0].Y;a[2] = pnt[1].Z-pnt[0].Z;
      b[0] = pnt[2].X-pnt[0].X;b[1] = pnt[2].Y-pnt[0].Y;b[2] = pnt[2].Z-pnt[0].Z;
      c=a&b; //cross product
      c.Normalize();
      glNormal3f( c[0], c[1], c[2]);
      glVertex3f(pnt[0].X,pnt[0].Y,pnt[0].Z);
      glVertex3f(pnt[1].X,pnt[1].Y,pnt[1].Z);
      glVertex3f(pnt[2].X,pnt[2].Y,pnt[2].Z);
      glVertex3f(pnt[3].X,pnt[3].Y,pnt[3].Z);
    glEnd();
  }

  glPopMatrix();
*/
}

bool GLStrata::Import(MkSection &sec)
{
  if(Number<0||Number>=sec.GetLayers().GetSize()) return false;
  
  MkLayer &lay = sec.GetLayers()[Number];
  MkCuts  &cuts = sec.GetCuts();
  MkFills &fills = sec.GetFills();
  
  Name = lay.GetName();
  Length = sec.GetSectionLength();

  if(!lay.GetProfile().GetSize()) return false;

  TopProf = lay.GetProfile().GetProfile();

  return true;
}
//---------------------------------------------------------------------------
GLStratum::GLStratum(int size,GLStrata *stratum)
{
    if (size < 0) {
      MkDebug("::GLStratum - GLStratum(int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSize == 0) {
       FStrata = NULL;
       return;
    }

    FStrata = new GLStrata[FSize];
    if(!FStrata)
      for (int i=0;i<FSize;i++) FStrata[i] = stratum[i];
}

GLStratum::GLStratum(int size)
{
    if (size < 0) {
      MkDebug("::GLStratum - GLStratum(int size)");;
      return;
    }

    FSize = FSizeOfArray = size;

    if (FSizeOfArray == 0) {
       FStrata = NULL;
       return;
    }

    FStrata = new GLStrata[FSizeOfArray];
}

GLStratum::~GLStratum()
{
   FSizeOfArray = FSize = 0;
   if (FStrata) {
      delete[] FStrata;
      FStrata = NULL;
   }
}

void GLStratum::Initialize(int size)
{
    if (size < 0) {
      MkDebug("::GLStratum - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;

    FSize = FSizeOfArray = size;

    if (FSizeOfArray == 0) {
       if (FStrata!=NULL) delete[] (GLStrata*)FStrata;
       FStrata = NULL;
       return;
    }

    if (FStrata!=NULL) delete[] (GLStrata*)FStrata;
    FStrata = new GLStrata[FSizeOfArray];
}

void GLStratum::Initialize(int size,GLStrata *stratum)
{

    if (size < 0 || stratum == NULL) {
      MkDebug("::GLStratum - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSize = FSizeOfArray = size;
    if (FSizeOfArray == 0) {
       if (FStrata!=NULL) delete[] (GLStrata*)FStrata;
       FStrata = NULL;
       return;
    }

    if (FStrata!=NULL) delete[] (GLStrata*)FStrata;
    FStrata = new GLStrata[FSizeOfArray];
    for (int i=0;i<FSizeOfArray;i++) FStrata[i] = stratum[i];
}

int GLStratum::Grow(int delta)
{
    int i;
    GLStrata *strata=NULL;

    if (!(strata = new GLStrata[FSizeOfArray+delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        strata[i] = FStrata[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        strata[i] = NullGLStrata;
    if (FStrata) {
       delete[] (GLStrata*)FStrata;
       FStrata = NULL;
    }
    FStrata = strata;
    FSizeOfArray = FSizeOfArray+delta;

    return FSizeOfArray;
}

int GLStratum::Shrink(int delta)
{
    int i;
    GLStrata *strata=NULL;

    if (!(strata = new GLStrata[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        strata[i] = FStrata[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        strata[i] = NullGLStrata;
    if (FStrata) {
       delete[] (GLStrata*)FStrata;
       FStrata = NULL;
    }
    FStrata = strata;
    FSizeOfArray = FSizeOfArray-delta;

    return FSizeOfArray;
}

bool GLStratum::Add(GLStrata &strata)
{
    int tmp=FSizeOfArray;
    bool flag=false;
    for (int i=0;i<FSize;i++) if (FStrata[i]==strata) flag=true;

    if(flag) return false;
    if (FSize>=FSizeOfArray) {
       Grow(FSize-FSizeOfArray+10);
       if (tmp==FSizeOfArray) return false;
    }
    FSize++;
    FStrata[FSize-1] = strata;

    return true;
}

bool GLStratum::Delete(GLStrata &strata)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FStrata[i] == strata) break;
    }
    if(i==FSize) return false;
    if(FStrata[i] == strata) {
      for (int j=i;j<FSize-1;j++)
        FStrata[j] = FStrata[j+1];
    }
    FSize--;
    FStrata[FSize] = NullGLStrata;
    return true;
}

bool GLStratum::Clear()
{
   FSizeOfArray = FSize = 0;
   if (FStrata) {
      delete[] FStrata;
      FStrata = NULL;
   }
   return true;
}

GLStrata & GLStratum::operator[](int i)
{
    if (FSizeOfArray == 0) return NullGLStrata;
    if (i >= FSize && i < FSizeOfArray) FSize = i+1;

    if (i >=0 && i < FSize) return FStrata[i];
    else return NullGLStrata;
}

GLStratum & GLStratum::operator=(GLStratum &stratum)
{
    int i;

    Clear();
    FSize = stratum.FSize;
    FSizeOfArray = stratum.FSizeOfArray;
    if (FSize == 0) {
       FStrata = NULL;
       return *this;
    }
    this->FStrata = new GLStrata[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FStrata[i] = stratum.FStrata[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FStrata[i] = NullGLStrata;

    return *this;
}

bool GLStratum::operator==(GLStratum &stratum)
{
  int i;

  if (FSize != stratum.FSize) return false;
  for (i=0;i<FSize;i++)
    if (this->FStrata[i] != stratum.FStrata[i]) return false;

  return true;
}

void GLStratum::DrawGL()
{
  int i;
  GLfloat matShi[]={0}, matAmb[]={1.0f,1.0f,1.0f,1.0f},
          matDif[]={1.0f,1.0f,1.0f,1.0f},matSpc[]={0.5f,0.5f,0.5f,1.0f};
  for(int i=0;i<FSize;i++) {
    matAmb[0]=(FSize-i)/float(FSize);
    matAmb[1]=i/float(FSize);
    matAmb[2]=i/2*float(FSize);

    matDif[0]=(FSize-i)/float(FSize);
    matDif[1]=i/float(FSize);
    matDif[2]=i/2*float(FSize);

    matSpc[0]=(FSize-i)/float(FSize);
    matSpc[1]=i/float(FSize);
    matSpc[2]=i/2*float(FSize);

    glMaterialfv(GL_FRONT,GL_AMBIENT, matAmb);
    glMaterialfv(GL_FRONT,GL_DIFFUSE, matDif);
    glMaterialfv(GL_FRONT,GL_SPECULAR, matSpc);
    glMaterialfv(GL_FRONT,GL_SHININESS, matShi);

    matAmb[0]=matAmb[0]/2;
    matAmb[1]=matAmb[1]/2;
    matAmb[2]=matAmb[2]/2;

    matDif[0]=matDif[0]/2;
    matDif[1]=matDif[1]/2;
    matDif[2]=matDif[2]/2;

    matSpc[0]=matSpc[0]/2;
    matSpc[1]=matSpc[1]/2;
    matSpc[2]=matSpc[2]/2;

    glMaterialfv(GL_BACK,GL_AMBIENT, matAmb);
    glMaterialfv(GL_BACK,GL_DIFFUSE, matDif);
    glMaterialfv(GL_BACK,GL_SPECULAR, matSpc);
    glMaterialfv(GL_BACK,GL_SHININESS, matShi);

    FStrata[i].DrawGL();
  }

  matAmb[0]=1;
  matAmb[1]=1;
  matAmb[2]=1;

  matDif[0]=1;
  matDif[1]=1;
  matDif[2]=1;

  matSpc[0]=0.5;
  matSpc[1]=0.5;
  matSpc[2]=0.5;

  glMaterialfv(GL_FRONT,GL_AMBIENT, matAmb);
  glMaterialfv(GL_FRONT,GL_DIFFUSE, matDif);
  glMaterialfv(GL_FRONT,GL_SPECULAR, matSpc);
  glMaterialfv(GL_FRONT,GL_SHININESS, matShi);

  matAmb[0]=matAmb[0]/2;
  matAmb[1]=matAmb[1]/2;
  matAmb[2]=matAmb[2]/2;

  matDif[0]=matDif[0]/2;
  matDif[1]=matDif[1]/2;
  matDif[2]=matDif[2]/2;

  matSpc[0]=matSpc[0]/2;
  matSpc[1]=matSpc[1]/2;
  matSpc[2]=matSpc[2]/2;

  glMaterialfv(GL_BACK,GL_AMBIENT, matAmb);
  glMaterialfv(GL_BACK,GL_DIFFUSE, matDif);
  glMaterialfv(GL_BACK,GL_SPECULAR, matSpc);
  glMaterialfv(GL_BACK,GL_SHININESS, matShi);
}

bool GLStratum::Import(MkSection &sec)
{
  int i;

  MkProfiles prof;
  MkLayers &lay = sec.GetLayers();
  if(lay.GetSize()<=0) return false;

  Initialize(lay.GetSize());
  prof.Initialize(lay.GetSize()+1);

  prof[0].SetBound(-10,40);
  prof[0].SetProfType(pfLayer);

  for(i=0;i<FSize;i++) {
    prof[i+1] = lay[i].GetProfile();
    prof[i+1].SetBound(-10,40);
  }

  prof.SyncDivision();

  for(i=0;i<FSize;i++) {
    FStrata[i].SetTopProf(prof[i].GetProfile());
    FStrata[i].SetBotProf(prof[i+1].GetProfile());
    if(FStrata[i].GetLength()<EPS) FStrata[i].SetLength(10);    
  }

  return true;
}

bool GLStratum::ClearMember()
{
  // nothing to do. all the action was done real time.(no build operation)
  return true;
}
//---------------------------------------------------------------------------
GLPile::GLPile()                              
{
  RootDepth=0.5;
  isBuilt = false;

  isClosed = false;
  isBuilt = false;
  Side = gsLeft;
}

GLPile::GLPile(int)
{
  RootDepth=0.5;
  isBuilt = false;

  isClosed = false;
  isBuilt = false;
  Side = gsLeft;
}

void GLPile::CalcDir(int i, MkVector &dir)
{
  int size;
  static MkVector v[2];
  MkPoint p[2];

  if(v[0].GetSize()!=3) v[0].Initialize(3);
  if(v[0].GetSize()!=3) v[1].Initialize(3);
  if(i<0 || i>=size) return;

  if(useDir) {
    dir = GlobalUp;
  }
  else {
    p[0] = Loc[i]; // forward
    p[1] = Loc[i]; // downward

    p[0].X = (i==size-1)? Loc[i].X-Loc[i-1].X:Loc[i+1].X-Loc[i].X;
    p[0].Y = (i==size-1)? Loc[i].Y-Loc[i-1].Y:Loc[i+1].Y-Loc[i].Y;
    p[0].Z = (i==size-1)? Loc[i].Z-Loc[i-1].Z:Loc[i+1].Z-Loc[i].Z;
    p[1].Y = p[1].Y-CalcDepth(Loc[i].X)-RootDepth;

    v[0].SetVector(p[0].X,p[0].Y,p[0].Z);
    v[1].SetVector(p[1].X,p[1].Y,p[1].Z);

    v[0].Normalize();
    v[1].Normalize();

    ((Side==gsLeft)?v[0].Cross(v[1],dir):v[1].Cross(v[0],dir));
  }
}

float GLPile::CalcDepth(float x)
{
  int i;
  float depth, xs, xe;

  MkPolygon &poly = BaseStrata.GetTopProf();
  if(poly.GetSize()<=0) return -15; // default 10 meter depth

  xs = poly[0].X;
  if(x<=xs) depth = poly[0].Y;
  for(i=1;i<poly.GetSize();i++) {
    xe = poly[i].X;
    if(xs<=x && x<xe) depth = poly[i-1].Y+(poly[i].Y-poly[i-1].Y)/(xe-xs)*(x-xs);
    xs = xe;
  }
  if(xe<=x) depth = poly[poly.GetSize()-1].Y;
  return depth;
/*
  if(BaseDepth.getSzY()<=0) return 0;
  xs = BaseDepth(0,0); // x-coord
  if(x<=xs) depth = BaseDepth(1,0);
  for(i=1;i<BaseDepth.getSzY();i++) {
    xe = BaseDepth(0,i);
    if(xs<=x && x<xe) depth = BaseDepth(1,i-1)+(BaseDepth(1,i)-BaseDepth(1,i-1))/(xe-xs)*(x-xs);
    xs = xe;
  }
  if(xe<=x) depth = BaseDepth(0,BaseDepth.getSzX()-1);
  return depth;
*/
}

bool GLPile::operator==(GLPile &obj)
{
  bool flag = true;
  flag = GLObject::operator==(obj);
  flag = flag && Beam==obj.Beam;
  flag = flag && RootDepth==obj.RootDepth;
  flag = flag && GlobalUp==obj.GlobalUp;
  flag = flag && Loc==obj.Loc;
  flag = flag && Lines==obj.Lines;
  flag = flag && isBuilt==obj.isBuilt;
  flag = flag && Dim==obj.Dim;
  flag = flag && BaseStrata==obj.BaseStrata;

  flag = flag && Side==obj.Side;
  flag = flag && ResultType==obj.ResultType;
  flag = flag && useDir==obj.useDir;
  flag = flag && isClosed==obj.isClosed;
  flag = flag && XDis==obj.XDis;
  flag = flag && AngDis==obj.AngDis;
  flag = flag && Moment==obj.Moment;
  flag = flag && Shear==obj.Shear;
  flag = flag && Press==obj.Press;
  flag = flag && Dim==obj.Dim;
  return flag;
}

bool GLPile::operator!=(GLPile &obj)
{
  return !operator==(obj);
}

GLPile &GLPile::operator=(GLPile &obj)
{
  Beam=obj.Beam;
  RootDepth=obj.RootDepth;
  GlobalUp=obj.GlobalUp;
  Loc=obj.Loc; // it doesn't have to be sequential(center-top of pile)
  Lines=obj.Lines;
  isBuilt=obj.isBuilt;
  Dim=obj.Dim;
  BaseStrata=obj.BaseStrata;
  Side=obj.Side;
  ResultType=obj.ResultType;
  useDir=obj.useDir;
  isClosed=obj.isClosed;
  XDis=obj.XDis;
  AngDis=obj.AngDis;
  Moment=obj.Moment;
  Shear=obj.Shear;
  Press=obj.Press;
  Dim=obj.Dim;
  return *this;
}

void GLPile::DrawModel()
{
  int i,j,k,size;
  float ang; // RootDepth is temporary and should be replaced with input value.
  static GLBeam beam;
  static MkVector dir(3);
  MkLine line;
  MkPoint pnt[2];

  if (Loc.GetSize()<=0) return;

  beam = Beam;
  if(!isBuilt) {
    size = Loc.GetSize();
    Lines.Initialize(size);
    for(i=0;i<size;i++) {
      pnt[1] = Loc[i];
      pnt[0] = pnt[1];
      pnt[0].Y = pnt[0].Y + CalcDepth(Loc[i].X)-RootDepth;
      Lines[i].SetLine(pnt[0],pnt[1]);
    }
    isBuilt = true;
  }

  for(i=0;i<Lines.GetSize();i++) {
    beam.SetLine(Lines[i]);
    beam.SetLength(Lines[i].GetLength());
    if(useDir) {
      beam.SetDir(Lines[i],GlobalUp);
    }
    else {
      CalcDir(i,dir);
      beam.SetDir(Lines[i],dir);
    }
    beam.DrawGL();
  }
}

void GLPile::DrawResult()
{
  float maxv, minv;
  AnsiString title;
  MkFloat value;
  MkPolygon poly;
  GLColorBeam clbeam;
  GLColorLegend legend;

  clbeam.SetFont(Dim.GetFont());
  legend.SetFont2D(Dim.GetFont2D());
  
  int i,j,k,size;
  float ang; // RootDepth is temporary and should be replaced with input value.
  static GLBeam beam;
  static MkVector dir(3);
  MkLine line;
  MkPoint pnt[2];

  beam = Beam;
  switch(ResultType) {
    case resXDis: title="Displacement"; value = XDis; break;
    case resAngDis: title="Angular disp."; value = AngDis; break;
    case resMoment: title="Moment"; value = Moment; break;
    case resShear:title="Shear force"; value = Shear; break;
    case resPress: title="Earth pressure"; value = Press; break;
  }

  if(!isBuilt) {
    size = Loc.GetSize();
    Lines.Initialize(size);
    for(i=0;i<size;i++) {
      pnt[1] = Loc[i];
      pnt[0] = pnt[1];
      pnt[0].Y = pnt[0].Y + CalcDepth(Loc[i].X)-RootDepth;
      Lines[i].SetLine(pnt[0],pnt[1]);
    }
    isBuilt = true;
  }

  if(value.getSzX()<=0 || value.getSzY()<2) return;

  clbeam.SetHeight(Beam.GetHeight());
  clbeam.SetWidth(Beam.GetWidth());

  maxv = value(0,1);
  minv = value(0,1);
  for (i=0;i<value.getSzX();i++) {
    maxv = maxv>value(i,1) ? maxv:value(i,1);
    minv = minv<value(i,1) ? minv:value(i,1);
  }

  legend.AddColorValue(clBlue, minv);
  legend.AddColorValue(clRed, maxv);

  clbeam.SetLine(Lines[0]);
  clbeam.SetLength(Lines[0].GetLength());
  if(useDir) {
    clbeam.SetDir(Lines[0],GlobalUp);
  }
  else {
    CalcDir(i,dir);
    clbeam.SetDir(Lines[0],dir);
  }

  clbeam.DrawGL(value,legend);
  legend.DrawGL();
}

void GLPile::DrawGL()
{
  if(DrawMode == dmModel) DrawModel();
  else DrawResult();
}

bool GLPile::Import(MkSection &sec)
{
// seclen : �ܸ� ���������, width : ������
  int i, j, npile, nspile, nmpile, ns, nm, cursec;
  float ctc_s, ctc_m, seclen=10 , width=0,dist=0;
  bool flag=true;
  MkFloat pdist;
  MkPolygon loc;
  static MkVector dir(3);
//  MkPolygon top, bot;
  static GLBeam beam;
  GLStrata base;

  dir[0]=1;dir[1]=0;dir[2]=0;
  dir.Normalize();

  MkPileSections &psec = sec.GetPileSections();
  MkLayers &lay = sec.GetLayers();
//GLStratum &stratum = Project.GetEarthWall(cursec).GetStratum();

/*  top.Initialize(2);
  top[0].SetPoint(-10,-10);
  top[1].SetPoint(10,-10);
  bot.Initialize(2);
  bot[0].SetPoint(-10,-11);
  bot[1].SetPoint(10,-11);

  base.SetTopProf(top);
  base.SetBotProf(bot);*/
  base.SetBaseFrom(lay);

  ctc_s = sec.GetSidepileCTC();
  ctc_m = sec.GetMidpileCTC();
  seclen = sec.GetSectionLength();
  npile = sec.GetPiles().GetSize();
//  npile = psec.GetSize()+1;

  if(fabs(npile)<EPS) return false;
  if(npile>1) pdist.Initialize(npile-1);

  if(fabs(ctc_s)<EPS) return false;
  if(fabs(ctc_m)<EPS) return false;
  if(fabs(seclen)<EPS) return false;

  beam.SetHeight(sec.GetPiles()[0].GetHeight()/1000);
  beam.SetWidth(sec.GetPiles()[0].GetWidth()/1000);
  beam.SetT1(sec.GetPiles()[0].GetT1()/1000);
  beam.SetT2(sec.GetPiles()[0].GetT2()/1000);

  SetDrawMode(dmModel);

  width = 0;
//  for(i=0;i<npile-1;i++) {
  for(i=0;i<Number;i++) {
    pdist(i) = psec[i].piledist;
    if(pdist(i)<EPS) width += 1;
    else width += pdist(i);
  }

  nspile = ((npile>2)?2:1);
  nmpile = ((npile>2)?npile-2:0);

  ns = seclen/ctc_s;
  nm = seclen/ctc_m;

  if(Side!=gsMid) {
//  GLPile &lpile = Project.GetEarthWall(cursec).GetLeftPile();
    loc.Initialize(ns);
    for(i=0;i<ns;i++) {
      loc[i].X = width;
      loc[i].Y = (sec.GetDeck().GetInstall())?-0.4:0;
      loc[i].Z = i*ctc_s;
    }

    SetBeam(beam);
    SetBase(base);
//    if(stratum.GetSize()) SetBase(stratum.GetBaseStrata());
//    else SetBase(base);
    SetRootDepth(sec.GetSideInsert());
    SetGlobalUp(dir);
    SetLoc(loc);
    SetUseDir(true);
//    SetSide(gsLeft);
    SetBuilt(false);
//  SetXDis(xdis);
//    EnablePiles(true);
    if(nspile==1) return true;
  }
  else {
//  GLPile &rpile = Project.GetEarthWall(cursec).GetRightPile();
    loc.Initialize(nm);
    for(i=0;i<ns;i++) {
      loc[i].X = width;
      loc[i].Y = (sec.GetDeck().GetInstall())?-0.4:0;
      loc[i].Z = i*ctc_m;
    }

    SetBeam(beam);
    SetBase(base);
//    if(stratum.GetSize()) SetBase(stratum.GetBaseStrata());
//    else SetBase(base);
    SetRootDepth(sec.GetSideInsert());
    SetGlobalUp(dir);
    SetLoc(loc);
    SetUseDir(true);
//    SetSide(gsRight);
    SetBuilt(false);
//  SetXDis(xdis);
//    EnablePiles(true);
  }

  return true;
}

bool GLPile::ImportStep(MkSection &sec)
{
// seclen : �ܸ� ���������, width : ������
  int i, j, npile, nspile, nmpile, ns, nm, cursec;
  float ctc_s, ctc_m, seclen=10 , width=0,dist=0;
  bool flag=true;
  MkFloat pdist;
  MkPolygon loc;
  static MkVector dir(3);
  static GLBeam beam;
  GLStrata base;

  dir[0]=1;dir[1]=0;dir[2]=0;
  dir.Normalize();

  MkPileSections &psec = sec.GetPileSections();
  MkPiles &piles = sec.GetStepPiles();
  MkLayers &lay = sec.GetLayers();

  base.SetBaseFrom(lay);

  ctc_s = sec.GetSidepileCTC();
  ctc_m = sec.GetMidpileCTC();
  seclen = sec.GetSectionLength();
  npile = piles.GetSize();

  if(fabs(npile)<EPS) return false;
  if(npile>1) pdist.Initialize(npile-1);

  if(fabs(ctc_s)<EPS) return false;
  if(fabs(ctc_m)<EPS) return false;
  if(fabs(seclen)<EPS) return false;

  beam.SetHeight(piles[0].GetHeight()/1000);
  beam.SetWidth(piles[0].GetWidth()/1000);
  beam.SetT1(piles[0].GetT1()/1000);
  beam.SetT2(piles[0].GetT2()/1000);

  SetDrawMode(dmModel);
  width = 0;

  for(i=0;i<Number;i++) {
    pdist(i) = psec[i].piledist;
    if(pdist(i)<EPS) width += 1;
    else width += pdist(i);
  }

  nspile = ((npile>2)?2:1);
  nmpile = ((npile>2)?npile-2:0);
  ns = seclen/ctc_s;
  nm = seclen/ctc_m;

  if(Side!=gsMid) {
    loc.Initialize(ns);
    for(i=0;i<ns;i++) {
      loc[i].X = width;
      loc[i].Y = (sec.GetDeck().GetInstall())?-0.4:0;
      loc[i].Z = i*ctc_s;
    }

    SetBeam(beam);
    SetBase(base);
    SetRootDepth(sec.GetSideInsert());
    SetGlobalUp(dir);
    SetLoc(loc);
    SetUseDir(true);
    SetBuilt(false);
    if(nspile==1) return true;
  }
  else {
    loc.Initialize(nm);
    for(i=0;i<ns;i++) {
      loc[i].X = width;
      loc[i].Y = (sec.GetDeck().GetInstall())?-0.4:0;
      loc[i].Z = i*ctc_m;
    }

    SetBeam(beam);
    SetBase(base);
    SetRootDepth(sec.GetSideInsert());
    SetGlobalUp(dir);
    SetLoc(loc);
    SetUseDir(true);
    SetBuilt(false);
  }
  return true;
}
bool GLPile::ClearMember()
{
  isBuilt = false;
  return true;
}
//---------------------------------------------------------------------------
GLPiles::GLPiles(int size,GLPile *piles)
{
    if (size < 0) {
      MkDebug("::GLPiles - GLPiles (int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSizeOfArray == 0) {
       FPile= NULL;
       return;
    }

    FPile= new GLPile[FSizeOfArray];
    for (int i=0;i<FSizeOfArray;i++) (*this)[i] = piles[i];
}

GLPiles::GLPiles(int size)
{
    if (size < 0) {
      MkDebug("::GLPiles - GLPiles (int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSizeOfArray == 0) {
       FPile= NULL;
       return;
    }

    FPile= new GLPile[FSizeOfArray];
}

GLPiles::~GLPiles()
{
   FSizeOfArray = FSize = 0;
   if (FPile) {
      delete[] FPile;
      FPile = NULL;
   }
}

void GLPiles::Initialize(int size)
{
    int i;
    if (size < 0) {
      MkDebug("::GLPiles - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray== size) return;

    FSizeOfArray= FSize=size;

    if (FSizeOfArray== 0) {
       if (FPile!=NULL) delete[] (GLPile*)FPile;
       FPile = NULL;
       return;
    }

    if (FPile!=NULL) delete[] (GLPile*)FPile;
    FPile = new GLPile[FSizeOfArray];
}

void GLPiles::Initialize(int size,GLPile *piles)
{
    int i;
    if (size < 0 || piles == NULL) {
      MkDebug("::GLPiles - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSizeOfArray = size;
    FSize = size;

    if (FSizeOfArray== 0) {
       if (FPile!=NULL) delete[] (GLPile*)FPile;
       FPile = NULL;
       return;
    }

    if (FPile!=NULL) delete[] (GLPile*)FPile;
    FPile = new GLPile[FSizeOfArray];
    for (i=0;i<FSizeOfArray;i++) FPile[i] = piles[i];
}

int GLPiles::Grow(int delta)
{
    int i;
    GLPile *pile=NULL;

    if (!(pile = new GLPile[FSizeOfArray+delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        pile[i] = FPile[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        pile[i] = NullGLPile;
    if (FPile) {
       delete[] (GLPile*)FPile;
       FPile = NULL;
    }
    FPile = pile;
    FSizeOfArray = FSizeOfArray+delta;
    return FSizeOfArray;
}

int GLPiles::Shrink(int delta)
{
    int i;
    GLPile *pile=NULL;

    if (!(pile = new GLPile[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        pile[i] = FPile[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        pile[i] = NullGLPile;
    if (FPile) {
       delete[] (GLPile*)FPile;
       FPile = NULL;
    }
    FPile = pile;
    FSizeOfArray = FSizeOfArray-delta;
    return FSizeOfArray;
}

bool GLPiles::Add(GLPile &pile)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }
    
    FSize++;
    FPile[FSize-1] = pile;
    return true;
}

bool GLPiles::Add(int index, GLPile &pile)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    for (int i=FSize-1;i>=index;i--)
      FPile[i+1] = FPile[i];
    FSize++;
    FPile[index] = pile;
    return true;
}

bool GLPiles::Delete(GLPile &pile)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FPile[i] == pile) break;
    }
    if(i==FSize) return false;
    if(FPile[i] == pile) {
      for (int j=i;j<FSize-1;j++)
        FPile[j] = FPile[j+1];
    }
    FSize--;
    FPile[FSize] = NullGLPile;
    return true;
}

bool GLPiles::Delete(int index)
{
    for (int j=index;j<FSize-1;j++)
        FPile[j] = FPile[j+1];

    FSize--;
    FPile[FSize] = NullGLPile;
    return true;
}

bool GLPiles::Clear()
{
   FSize = 0;
   if (FPile) {
      delete[] FPile;
      FPile = NULL;
   }
   return true;
}

GLPile & GLPiles::operator[](int i)
{
    if (0<=i && i<FSize) return FPile[i];
    else if(FSize<=i && i<FSizeOfArray) {
      FSize=i+1;
      return FPile[i];
    }
    else if (FSizeOfArray <= i) {
      Grow(i-FSizeOfArray+5);
      return NullGLPile;
    }
    else return NullGLPile;
}

GLPiles & GLPiles::operator=(GLPiles &piles)
{
    int i;

    Clear();
    FSize = piles.FSize;
    FSizeOfArray = piles.FSizeOfArray;

    if (FSizeOfArray == 0) {
       FPile = NULL;
       return *this;
    }
    this->FPile = new GLPile[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FPile[i] = piles.FPile[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FPile[i] = NullGLPile;


    return *this;
}

bool GLPiles::operator==(GLPiles &piles)
{
    int i;

    if (FSize != piles.FSize) return false;
    for (i=0;i<FSize;i++)
      if (this->FPile[i] != piles.FPile[i]) return false;

    return true;
}

void GLPiles::Out(char *fname)
{

}

#ifdef __BCPLUSPLUS__
void GLPiles::Import(MkGlobalVar &globalvar, int sec)
{

}
#endif

bool GLPiles::Import(MkSection &sec)
{
  int i;
  bool flag=true;
  Initialize(sec.GetPiles().GetSize());
  FPile[FSize-1].SetSide(gsRight);
  FPile[0].SetSide(gsLeft);
  for(i=1;i<FSize-1;i++) FPile[i].SetSide(gsMid);

  for(i=0;i<FSize;i++) {
    FPile[i].SetNumber(i);
    flag = flag && FPile[i].Import(sec);
  }
  return flag;
}

bool GLPiles::ImportStep(MkSection &sec)
{
  int i;
  bool flag=true;
  Initialize(sec.GetPiles().GetSize());
  FPile[FSize-1].SetSide(gsRight);
  FPile[0].SetSide(gsLeft);
  for(i=1;i<FSize-1;i++) FPile[i].SetSide(gsMid);

  for(i=0;i<FSize;i++) {
    FPile[i].SetNumber(i);
    flag = flag && FPile[i].ImportStep(sec);
  }
  return flag;
}

bool GLPiles::ClearMember()
{
  int i;
  bool flag = true;
  for(i=0;i<FSize;i++) {
    flag = flag && FPile[i].ClearMember();
  }
  return flag;
}
//---------------------------------------------------------------------------
GLWale::GLWale()
{
  Pile=NULL;
  Side = gsLeft;
}

GLWale::GLWale(int )
{
  Pile=NULL;
  Side = gsLeft;
}

void GLWale::DrawGL()
{
  int i,j;
  float wh, ph;
  static MkVector up(3);
  MkLine line;
  MkPolygon loc;

  if(!Pile) return;
  GLPile &pile = (*Pile);

  bool isClosed = pile.GetClosed();
  GLSide ws = pile.GetSide();

  up[0] = 0;up[1] = 1;up[2] = 0;

  for(i=0;i<InstallDepth.getSzX();i++) {
    ph = pile.GetBeam().GetHeight();
    wh = Beam[i].GetHeight();
    pile.GetLoc().Offset(loc, up, (ws==gsLeft)?false:true, (ph+wh)/2);
    for(j=0;j<Loc.GetSize()-(isClosed?0:1);j++) {
      line[0] = loc[j];
      line[1] = loc[(j+1==Loc.GetSize())?0:j+1];

      line[0].Y = InstallDepth(i);
      line[1].Y = InstallDepth(i);

      Beam[i].SetLine(line);
      Beam[i].SetLength(line.GetLength());
      Beam[i].DrawGL();
    }
  }
}

void GLWale::DrawModel()
{

}

void GLWale::DrawResult()
{

}

bool GLWale::operator==(GLWale& wale)
{
  bool flag;

  flag = flag && Beam == wale.Beam;
  flag = flag && InstallDepth == wale.InstallDepth;
  flag = flag && Loc == wale.Loc;
  flag = flag && *Pile== *wale.Pile;
  flag = flag && Dim == wale.Dim;
  flag = flag && Side == wale.Side;

  return flag;
}

bool GLWale::operator!=(GLWale& wale)
{
  return !operator==(wale);
}

GLWale & GLWale::operator=(GLWale &wale)
{
  Beam = wale.Beam;
  InstallDepth.CopyFrom(wale.InstallDepth);
  Loc = wale.Loc;
  *Pile= *wale.Pile;
  Dim = wale.Dim;
  Side = wale.Side;

  return *this;
}

bool GLWale::Import(MkSection &sec)
{
  int i, nwale, nanc=0,n=0;
  MkStruts &strut = sec.GetStruts();
  MkAnchors &anc = sec.GetAnchors();

  MkWale wale;

  GLBeams beam;

  nwale = strut.GetSize();
  if(Side==gsLeft) {
    for(i=0;i<anc.GetSize();i++) {
      nanc += (anc[i].GetSide()==mkLeft?1:0);
    }
  }
  else {
    for(i=0;i<anc.GetSize();i++) {
      nanc += (anc[i].GetSide()==mkLeft?0:1);
    }
  }
  nwale += nanc*2;

  if(nwale<=0) return true;
  InstallDepth.Initialize(nwale);
  beam.Initialize(nwale);

  for(i=0;i<strut.GetSize();i++) {
    InstallDepth(n) = strut[i].GetDepth();
    wale = strut[i].GetWale();

    if(Pile) {
      GLPile &pile = (*Pile);
      static MkVector up(3);
      float ph = pile.GetBeam().GetHeight();
      float wh = wale.HH/1000;
      GLSide ws = pile.GetSide();
      up[0] = 0;up[1] = 1;up[2] = 0;
      pile.GetLoc().Offset(Loc, up, (ws==gsLeft)?false:true, (ph+wh)/2);
    }

    beam[n].SetHeight(wale.HH/1000);
    beam[n].SetWidth(wale.BB/1000);
    beam[n].SetT1(wale.tt1/1000);
    beam[n].SetT2(wale.tt2/1000);

    n++;
  }

  for(i=0;i<anc.GetSize();i++) {
    if(anc[i].GetSide()==mkLeft && Side==gsLeft) {
      wale = anc[i].GetWale();

      InstallDepth(n) = anc[i].GetDepth()-0.2;
      beam[n].SetHeight(wale.HH/1000);
      beam[n].SetWidth(wale.BB/1000);
      beam[n].SetT1(wale.tt1/1000);
      beam[n].SetT2(wale.tt2/1000);
      n++;

      InstallDepth(n) = anc[i].GetDepth()+0.2;
      beam[n].SetHeight(wale.HH/1000);
      beam[n].SetWidth(wale.BB/1000);
      beam[n].SetT1(wale.tt1/1000);
      beam[n].SetT2(wale.tt2/1000);
      n++;
    }
  }

  for(i=0;i<anc.GetSize();i++) {
    if(anc[i].GetSide()==mkRight && Side==gsRight) {
      wale = anc[i].GetWale();

      InstallDepth(n) = anc[i].GetDepth()-0.2;
      beam[n].SetHeight(wale.HH/1000);
      beam[n].SetWidth(wale.BB/1000);
      beam[n].SetT1(wale.tt1/1000);
      beam[n].SetT2(wale.tt2/1000);
      n++;

      InstallDepth(n) = anc[i].GetDepth()+0.2;
      beam[n].SetHeight(wale.HH/1000);
      beam[n].SetWidth(wale.BB/1000);
      beam[n].SetT1(wale.tt1/1000);
      beam[n].SetT2(wale.tt2/1000);
      n++;
    }
  }

  SetBeam(beam);
  SetDrawMode(dmModel);

  return true;
}

bool GLWale::ImportStep(MkSection &sec)
{
  int i, nwale, nanc=0,n=0;
  MkStruts &strut = sec.GetStepStruts();
  MkAnchors &anc = sec.GetStepAnchors();

  MkWale wale;

  GLBeams beam;

  nwale = strut.GetSize();
  if(Side==gsLeft) {
    for(i=0;i<anc.GetSize();i++) {
      nanc += (anc[i].GetSide()==mkLeft?1:0);
    }
  }
  else {
    for(i=0;i<anc.GetSize();i++) {
      nanc += (anc[i].GetSide()==mkLeft?0:1);
    }
  }
  nwale += nanc*2;

  if(nwale<=0) return true;
  InstallDepth.Initialize(nwale);
  beam.Initialize(nwale);

  for(i=0;i<strut.GetSize();i++) {
    InstallDepth(n) = strut[i].GetDepth();
    wale = strut[i].GetWale();

    if(Pile) {
      GLPile &pile = (*Pile);
      static MkVector up(3);
      float ph = pile.GetBeam().GetHeight();
      float wh = wale.HH/1000;
      GLSide ws = pile.GetSide();
      up[0] = 0;up[1] = 1;up[2] = 0;
      pile.GetLoc().Offset(Loc, up, (ws==gsLeft)?false:true, (ph+wh)/2);
    }

    beam[n].SetHeight(wale.HH/1000);
    beam[n].SetWidth(wale.BB/1000);
    beam[n].SetT1(wale.tt1/1000);
    beam[n].SetT2(wale.tt2/1000);

    n++;
  }

  for(i=0;i<anc.GetSize();i++) {
    if(anc[i].GetSide()==mkLeft && Side==gsLeft) {
      wale = anc[i].GetWale();

      InstallDepth(n) = anc[i].GetDepth()-0.2;
      beam[n].SetHeight(wale.HH/1000);
      beam[n].SetWidth(wale.BB/1000);
      beam[n].SetT1(wale.tt1/1000);
      beam[n].SetT2(wale.tt2/1000);
      n++;

      InstallDepth(n) = anc[i].GetDepth()+0.2;
      beam[n].SetHeight(wale.HH/1000);
      beam[n].SetWidth(wale.BB/1000);
      beam[n].SetT1(wale.tt1/1000);
      beam[n].SetT2(wale.tt2/1000);
      n++;
    }
  }

  for(i=0;i<anc.GetSize();i++) {
    if(anc[i].GetSide()==mkRight && Side==gsRight) {
      wale = anc[i].GetWale();

      InstallDepth(n) = anc[i].GetDepth()-0.2;
      beam[n].SetHeight(wale.HH/1000);
      beam[n].SetWidth(wale.BB/1000);
      beam[n].SetT1(wale.tt1/1000);
      beam[n].SetT2(wale.tt2/1000);
      n++;

      InstallDepth(n) = anc[i].GetDepth()+0.2;
      beam[n].SetHeight(wale.HH/1000);
      beam[n].SetWidth(wale.BB/1000);
      beam[n].SetT1(wale.tt1/1000);
      beam[n].SetT2(wale.tt2/1000);
      n++;
    }
  }

  SetBeam(beam);
  SetDrawMode(dmModel);

  return true;
}

bool GLWale::ClearMember()
{
  // nothing to do...for this time...^^
  return true;
}
//---------------------------------------------------------------------------
GLWales::GLWales(int size,GLWale *wales)
{
    if (size < 0) {
      MkDebug("::GLWales - GLWales (int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSizeOfArray == 0) {
       FWale= NULL;
       return;
    }

    FWale= new GLWale[FSizeOfArray];
    for (int i=0;i<FSizeOfArray;i++) (*this)[i] = wales[i];
}

GLWales::GLWales(int size)
{
    if (size < 0) {
      MkDebug("::GLWales - GLWales (int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSizeOfArray == 0) {
       FWale= NULL;
       return;
    }

    FWale= new GLWale[FSizeOfArray];
}

GLWales::~GLWales()
{
   FSizeOfArray = FSize = 0;
   if (FWale) {
      delete[] FWale;
      FWale = NULL;
   }
}

void GLWales::Initialize(int size)
{
    int i;
    if (size < 0) {
      MkDebug("::GLWales - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray== size) return;

    FSizeOfArray= FSize=size;

    if (FSizeOfArray== 0) {
       if (FWale!=NULL) delete[] (GLWale*)FWale;
       FWale = NULL;
       return;
    }

    if (FWale!=NULL) delete[] (GLWale*)FWale;
    FWale = new GLWale[FSizeOfArray];
}

void GLWales::Initialize(int size,GLWale *wales)
{
    int i;
    if (size < 0 || wales == NULL) {
      MkDebug("::GLWales - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSizeOfArray = size;
    FSize = size;

    if (FSizeOfArray== 0) {
       if (FWale!=NULL) delete[] (GLWale*)FWale;
       FWale = NULL;
       return;
    }

    if (FWale!=NULL) delete[] (GLWale*)FWale;
    FWale = new GLWale[FSizeOfArray];
    for (i=0;i<FSizeOfArray;i++) FWale[i] = wales[i];
}

int GLWales::Grow(int delta)
{
    int i;
    GLWale *wale=NULL;

    if (!(wale = new GLWale[FSizeOfArray+delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        wale[i] = FWale[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        wale[i] = NullGLWale;
    if (FWale) {
       delete[] (GLWale*)FWale;
       FWale = NULL;
    }
    FWale = wale;
    FSizeOfArray = FSizeOfArray+delta;
    return FSizeOfArray;
}

int GLWales::Shrink(int delta)
{
    int i;
    GLWale *wale=NULL;

    if (!(wale = new GLWale[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        wale[i] = FWale[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        wale[i] = NullGLWale;
    if (FWale) {
       delete[] (GLWale*)FWale;
       FWale = NULL;
    }
    FWale = wale;
    FSizeOfArray = FSizeOfArray-delta;
    return FSizeOfArray;
}

bool GLWales::Add(GLWale &wale)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }
    
    FSize++;
    FWale[FSize-1] = wale;
    return true;
}

bool GLWales::Add(int index, GLWale &wale)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    for (int i=FSize-1;i>=index;i--)
      FWale[i+1] = FWale[i];
    FSize++;
    FWale[index] = wale;
    return true;
}

bool GLWales::Delete(GLWale &wale)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FWale[i] == wale) break;
    }
    if(i==FSize) return false;
    if(FWale[i] == wale) {
      for (int j=i;j<FSize-1;j++)
        FWale[j] = FWale[j+1];
    }
    FSize--;
    FWale[FSize] = NullGLWale;
    return true;
}

bool GLWales::Delete(int index)
{
    for (int j=index;j<FSize-1;j++)
        FWale[j] = FWale[j+1];

    FSize--;
    FWale[FSize] = NullGLWale;
    return true;
}

bool GLWales::Clear()
{
   FSize = 0;
   if (FWale) {
      delete[] FWale;
      FWale = NULL;
   }
   return true;
}

GLWale & GLWales::operator[](int i)
{
    if (0<=i && i<FSize) return FWale[i];
    else if(FSize<=i && i<FSizeOfArray) {
      FSize=i+1;
      return FWale[i];
    }
    else if (FSizeOfArray <= i) {
      Grow(i-FSizeOfArray+5);
      return NullGLWale;
    }
    else return NullGLWale;
}

GLWales & GLWales::operator=(GLWales &wales)
{
    int i;

    Clear();
    FSize = wales.FSize;
    FSizeOfArray = wales.FSizeOfArray;

    if (FSizeOfArray == 0) {
       FWale = NULL;
       return *this;
    }
    this->FWale = new GLWale[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FWale[i] = wales.FWale[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FWale[i] = NullGLWale;


    return *this;
}

bool GLWales::operator==(GLWales &wales)
{
    int i;

    if (FSize != wales.FSize) return false;
    for (i=0;i<FSize;i++)
      if (this->FWale[i] != wales.FWale[i]) return false;

    return true;
}

void GLWales::Out(char *fname)
{

}

#ifdef __BCPLUSPLUS__
void GLWales::Import(MkGlobalVar &globalvar, int sec)
{

}
#endif

bool GLWales::Import(MkSection &sec)
{
  int i;
  bool flag=true;
  GLPile *pile[2] = {NULL,NULL};

  int nwale = sec.GetSidePileNum();
  if(nwale<=0) return false;
  for(i = 0;i<FSize;i++) pile[i] = FWale[i].GetPile();

  Initialize(nwale);
  FWale[0].SetSide(gsLeft);
  FWale[0].SetPile(*pile[0]);
  if(nwale>=2) {
    FWale[1].SetSide(gsRight);
    FWale[1].SetPile(*pile[1]);
  }

  for(i=0;i<FSize;i++) {
    flag = flag && FWale[i].Import(sec);
  }
  return flag;
}

bool GLWales::ImportStep(MkSection &sec)
{
  int i;
  bool flag=true;
  GLPile *pile[2] = {NULL,NULL};

  int nwale = sec.GetSidePileNum();
  if(nwale<=0) return false;
  for(i = 0;i<FSize;i++) pile[i] = FWale[i].GetPile();

  Initialize(nwale);
  FWale[0].SetSide(gsLeft);
  FWale[0].SetPile(*pile[0]);
  if(nwale>=2) {
    FWale[1].SetSide(gsRight);
    FWale[1].SetPile(*pile[1]);
  }

  for(i=0;i<FSize;i++) {
    flag = flag && FWale[i].ImportStep(sec);
  }
  return flag;
}

void GLWales::DrawGL()
{
  for(int i=0;i<FSize;i++) {
    FWale[i].DrawGL();
  }
}

bool GLWales::ClearMember()
{
  int i;
  bool flag=true;

  for (i=0;i<FSize;i++) {
    flag = flag && FWale[i].ClearMember();
  }
  return flag;
}
//---------------------------------------------------------------------------
GLStruts::GLStruts()
{
  Wales=NULL;
  Start = 0;
  Length = 10;
  isBuilt = false;
}

void GLStruts::DrawGL()
{
  static MkLines line;
  static int n;
  static MkVector up(3),dir(3);
  MkPolygon lpoly, rpoly;
  float len[2];
  int i,j,ndepth;
  MkFloat nstrut;

  if(InstallDepth.getSzX()<=0) return;
  if(Spacing.getSzX()<0) return;
  if(InstallDepth.getSzX()!=Spacing.getSzX()) return;

  ndepth =InstallDepth.getSzX();
  nstrut.Initialize(ndepth);

  for(i=0;i<ndepth;i++) {
    if(Spacing(i)<EPS) Spacing(i) = 2.0;  //default value = 2, if you want to make it parameter then you need extra work.
  }

  if(!isBuilt) {
    up[0] = 0;up[1] = 1;up[2] = 0;

    n = 0;
    for(i=0;i<ndepth;i++) {
      if (fabs(Spacing.getSzX())<EPS || !(Wales) || !InstallDepth.getSzX()) return;

      for(j=0;j<Wales->GetSize();j++) {
        MkPolygon &poly = ((*Wales)[j].GetSide()==gsLeft)?lpoly:rpoly;
        bool dir = ((*Wales)[j].GetSide()==gsLeft) ? false : true;
        GLBeam &beam = (*Wales)[j].GetBeam()[0];
        (*Wales)[j].GetLoc().Offset(poly,up,dir,beam.GetHeight()/2);
      }

      if (lpoly.GetSize()==0 && rpoly.GetSize()!=0) {
        rpoly.Offset(lpoly,up,false,Length);
      }
      else if (rpoly.GetSize()==0 && lpoly.GetSize()!=0) {
        lpoly.Offset(rpoly,up,false,Length); // it was true
      }
      else if (rpoly.GetSize()!=0 && lpoly.GetSize()!=0) {}
      else return;

      if(Wales->GetSize()==1) {
        float h = (*Wales)[0].GetBeam()[i].GetHeight();
        (*Wales)[0].GetLoc().Offset(lpoly,up,false,h/2); //dir : left=false, right=true
        len[0] = lpoly.GetLength();
      }
      else if(Wales->GetSize()==2) {
        float h = (*Wales)[0].GetBeam()[i].GetHeight();
        (*Wales)[0].GetLoc().Offset(lpoly,up,false,h/2); //dir : left=false, right=true
        h = (*Wales)[1].GetBeam()[i].GetHeight();
        (*Wales)[1].GetLoc().Offset(rpoly,up,true,h/2); //dir : left=false, right=true
        len[0] = lpoly.GetLength();
        len[1] = rpoly.GetLength();
      }

      len[0] = Length;
      nstrut(i) = len[0]/Spacing(i);
      n+=nstrut(i);
    }
    line.Initialize(n);

    n=0;
    for(i=0;i<ndepth;i++) {
      if (fabs(Spacing.getSzX())<EPS || !(Wales) || !InstallDepth.getSzX()) return;

      for(j=0;j<Wales->GetSize();j++) {
        MkPolygon &poly = ((*Wales)[j].GetSide()==gsLeft)?lpoly:rpoly;
        bool dir = ((*Wales)[j].GetSide()==gsLeft) ? false : true;
        GLBeam &beam = (*Wales)[j].GetBeam()[0];
        (*Wales)[j].GetLoc().Offset(poly,up,dir,beam.GetHeight()/2);
      }

      if (lpoly.GetSize()==0 && rpoly.GetSize()!=0) {
        rpoly.Offset(lpoly,up,false,Length);
      }
      else if (rpoly.GetSize()==0 && lpoly.GetSize()!=0) {
        lpoly.Offset(rpoly,up,false,Length);  // it was true
      }
      else if (rpoly.GetSize()!=0 && lpoly.GetSize()!=0) {}
      else return;

      if(Wales->GetSize()==1) {
        float h = (*Wales)[0].GetBeam()[i].GetHeight();
        (*Wales)[0].GetLoc().Offset(lpoly,up,false,h/2); //dir : left=false, right=true
        len[0] = lpoly.GetLength();
      }
      else if(Wales->GetSize()==2) {
        float h = (*Wales)[0].GetBeam()[i].GetHeight();
        (*Wales)[0].GetLoc().Offset(lpoly,up,false,h/2); //dir : left=false, right=true
        h = (*Wales)[1].GetBeam()[i].GetHeight();
        (*Wales)[1].GetLoc().Offset(rpoly,up,true,h/2); //dir : left=false, right=true
        len[0] = lpoly.GetLength();
        len[1] = rpoly.GetLength();
      }

      for(j=0;j<nstrut(i);j++) {
        line[n][0] = lpoly.Measure(Start+j*Spacing(i));
        line[n][1] = rpoly.Measure(Start+j*Spacing(i));
        line[n][0].Y = InstallDepth(i);
        line[n][1].Y = InstallDepth(i);
        n++;
      }
    }
    isBuilt = true;
  }

  for (i=0;i<n;i++) {
    Beam.SetLine(line[i]);
    Beam.SetLength(line[i].GetLength());
    Beam.DrawGL();
  }
}

void GLStruts::DrawModel()
{

}

void GLStruts::DrawResult()
{

}

bool GLStruts::Import(MkSection &sec)
{
  int i;
  static GLBeam beam;

  MkStruts &struts = sec.GetStruts();
  if(struts.GetSize()<=0) return false;
  
  InstallDepth.Initialize(struts.GetSize());
  Spacing.Initialize(struts.GetSize());

  for(i=0;i<struts.GetSize();i++) {
    InstallDepth(i) = struts[i].GetDepth();
    Spacing(i) = struts[i].GetSpacing();
  }
  Length = sec.GetSectionLength();
  Start = 0;
  beam.SetHeight(struts[0].GetHeight()/1000.0);
  beam.SetWidth(struts[0].GetWidth()/1000.0);
  beam.SetT1(struts[0].GetT1()/1000.0);
  beam.SetT2(struts[0].GetT2()/1000.0);
  
  SetBeam(beam);
  return true;
}

bool GLStruts::ImportStep(MkSection &sec)
{
  int i;
  static GLBeam beam;

  MkStruts &struts = sec.GetStepStruts();
  if(struts.GetSize()<=0) return false;

  InstallDepth.Initialize(struts.GetSize());
  Spacing.Initialize(struts.GetSize());

  for(i=0;i<struts.GetSize();i++) {
    InstallDepth(i) = struts[i].GetDepth();
    Spacing(i) = struts[i].GetSpacing();
  }
  Length = sec.GetSectionLength();
  Start = 0;
  beam.SetHeight(struts[0].GetHeight()/1000.0);
  beam.SetWidth(struts[0].GetWidth()/1000.0);
  beam.SetT1(struts[0].GetT1()/1000.0);
  beam.SetT2(struts[0].GetT2()/1000.0);

  SetBeam(beam);
  return true;
}

bool GLStruts::ClearMember()
{
  isBuilt = false; // rebuild it by force
  return true; 
}
//---------------------------------------------------------------------------
GLWoodWall::GLWoodWall()
{
  WoodType = wtPine;
  Height=0.3;
  Thick=0.06;
  InstallDepth = 1;
  Pile=NULL;
}

void GLWoodWall::DrawGL()
{
  GLCube woodpan;
  int i, j, n_hor, n_ver;
  MkPoint p[2],cen;
  MkLine l;
  static MkVector v(3),up,norm(3);
  GLSide ws;

  if(!Pile || fabs(Height)<EPS || fabs(Thick)<EPS || fabs(InstallDepth)<EPS) return;

  n_ver = InstallDepth/Height;
  n_hor = Pile->GetLoc().GetSize()-1;
  ws = Pile->GetSide();
  MkPolygon &poly=Pile->GetLoc();

  up[0] = 0;up[1] = 1;up[2] = 0;
  woodpan.SetHeight(Height-0.05);
  woodpan.SetThick(Thick);

  for (i=0;i<n_hor;i++) {
    cen = poly(i).GetMiddlePoint();
    v = poly(i).GetVector();
    v.Normalize();
    (ws==gsRight)? up.Cross(v,norm): v.Cross(up,norm);
    norm.Normalize();
    cen.X = cen.X + norm[0]*(Thick/2+Pile->GetBeam().GetHeight()/2);
    cen.Z = cen.Z + norm[2]*(Thick/2+Pile->GetBeam().GetHeight()/2);

    for (j=0;j<n_ver;j++) {

      p[0] = MkPoint(cen.X, -j*Height-Height/2, cen.Z);
      p[1] = MkPoint(cen.X, -(j+1)*Height-Height/2, cen.Z);
      l.SetLine(p[0],p[1]);
      woodpan.SetLine(l);
      woodpan.SetWidth(poly(i).GetLength()-0.05);
      woodpan.DrawGL();
    }
  }
}

bool GLWoodWall::ClearMember()
{
  // nothing to do right now...^^
  return true;
}
//---------------------------------------------------------------------------
GLConcWall::GLConcWall()
{
  Pile=NULL;
}

void GLConcWall::DrawGL()
{

}

bool GLConcWall::ClearMember()
{
  // nothing to do right now...^^
  return true;
}
//---------------------------------------------------------------------------
GLReinforce::GLReinforce()
{
  SuptType = stCIP;


}

void GLReinforce::DrawGL()
{

}

bool GLReinforce::ClearMember()
{
  // nothing to do right now...^^
  return true;
}
//---------------------------------------------------------------------------
GLWall::GLWall()
{
  WallType = wtWoodConc;
  Side = gsLeft;
  Pile = NULL;
}

GLWall::GLWall(int )
{
  WallType = wtWoodConc;
  Side = gsLeft;
  Pile = NULL;
}

void GLWall::DrawGL()
{
  switch(WallType) {
    case wtWood:
      WoodWall.DrawGL();
      break;
    case wtConc:
      ConcWall.DrawGL();
      break;
    case wtWoodConc:
      WoodWall.DrawGL();
      ConcWall.DrawGL();
      break;
    case wtSlurryWall:

      break;
  }
  Reinforce.DrawGL();
}

bool GLWall::operator==(GLWall& wall)
{
  bool flag;

  flag = flag && WallType == wall.WallType;
  flag = flag && Side == wall.Side;
  flag = flag && ConcWall == wall.ConcWall;
  flag = flag && WoodWall == wall.WoodWall;
  flag = flag && Reinforce== wall.Reinforce;
  flag = flag && *Pile == *wall.Pile;

  return flag;
}

bool GLWall::operator!=(GLWall& wall)
{
  return !operator==(wall);
}

GLWall & GLWall::operator=(GLWall &wall)
{
  WallType = wall.WallType;
  Side = wall.Side;
  ConcWall = wall.ConcWall;
  WoodWall = wall.WoodWall;
  Reinforce= wall.Reinforce;
  *Pile   = *wall.Pile;
  return *this;
}

bool GLWall::ClearMember()
{
  bool flag = true;
  switch(WallType) {
    case wtWood:
      flag = flag && WoodWall.ClearMember();
      break;
    case wtConc:
      flag = flag && ConcWall.ClearMember();
      break;
    case wtWoodConc:
      flag = flag && WoodWall.ClearMember();
      flag = flag && ConcWall.ClearMember();
      break;
    case wtSlurryWall:
      break;
  }
  flag = flag && Reinforce.ClearMember();
  return flag;
}
//---------------------------------------------------------------------------
GLWalls::GLWalls(int size,GLWall *walls)
{
    if (size < 0) {
      MkDebug("::GLWalls - GLWalls (int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSizeOfArray == 0) {
       FWall= NULL;
       return;
    }

    FWall= new GLWall[FSizeOfArray];
    for (int i=0;i<FSizeOfArray;i++) (*this)[i] = walls[i];
}

GLWalls::GLWalls(int size)
{
    if (size < 0) {
      MkDebug("::GLWalls - GLWalls (int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSizeOfArray == 0) {
       FWall= NULL;
       return;
    }

    FWall= new GLWall[FSizeOfArray];
}

GLWalls::~GLWalls()
{
   FSizeOfArray = FSize = 0;
   if (FWall) {
      delete[] FWall;
      FWall = NULL;
   }
}

void GLWalls::Initialize(int size)
{
    int i;
    if (size < 0) {
      MkDebug("::GLWalls - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray== size) return;

    FSizeOfArray= FSize=size;

    if (FSizeOfArray== 0) {
       if (FWall!=NULL) delete[] (GLWall*)FWall;
       FWall = NULL;
       return;
    }

    if (FWall!=NULL) delete[] (GLWall*)FWall;
    FWall = new GLWall[FSizeOfArray];
}

void GLWalls::Initialize(int size,GLWall *walls)
{
    int i;
    if (size < 0 || walls == NULL) {
      MkDebug("::GLWalls - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSizeOfArray = size;
    FSize = size;

    if (FSizeOfArray== 0) {
       if (FWall!=NULL) delete[] (GLWall*)FWall;
       FWall = NULL;
       return;
    }

    if (FWall!=NULL) delete[] (GLWall*)FWall;
    FWall = new GLWall[FSizeOfArray];
    for (i=0;i<FSizeOfArray;i++) FWall[i] = walls[i];
}

int GLWalls::Grow(int delta)
{
    int i;
    GLWall *wall=NULL;

    if (!(wall = new GLWall[FSizeOfArray+delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        wall[i] = FWall[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        wall[i] = NullGLWall;
    if (FWall) {
       delete[] (GLWall*)FWall;
       FWall = NULL;
    }
    FWall = wall;
    FSizeOfArray = FSizeOfArray+delta;
    return FSizeOfArray;
}

int GLWalls::Shrink(int delta)
{
    int i;
    GLWall *wall=NULL;

    if (!(wall = new GLWall[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        wall[i] = FWall[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        wall[i] = NullGLWall;
    if (FWall) {
       delete[] (GLWall*)FWall;
       FWall = NULL;
    }
    FWall = wall;
    FSizeOfArray = FSizeOfArray-delta;
    return FSizeOfArray;
}

bool GLWalls::Add(GLWall &wall)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }
    
    FSize++;
    FWall[FSize-1] = wall;
    return true;
}

bool GLWalls::Add(int index, GLWall &wall)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    for (int i=FSize-1;i>=index;i--)
      FWall[i+1] = FWall[i];
    FSize++;
    FWall[index] = wall;
    return true;
}

bool GLWalls::Delete(GLWall &wall)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FWall[i] == wall) break;
    }
    if(i==FSize) return false;
    if(FWall[i] == wall) {
      for (int j=i;j<FSize-1;j++)
        FWall[j] = FWall[j+1];
    }
    FSize--;
    FWall[FSize] = NullGLWall;
    return true;
}

bool GLWalls::Delete(int index)
{
    for (int j=index;j<FSize-1;j++)
        FWall[j] = FWall[j+1];

    FSize--;
    FWall[FSize] = NullGLWall;
    return true;
}

bool GLWalls::Clear()
{
   FSize = 0;
   if (FWall) {
      delete[] FWall;
      FWall = NULL;
   }
   return true;
}

GLWall & GLWalls::operator[](int i)
{
    if (0<=i && i<FSize) return FWall[i];
    else if(FSize<=i && i<FSizeOfArray) {
      FSize=i+1;
      return FWall[i];
    }
    else if (FSizeOfArray <= i) {
      Grow(i-FSizeOfArray+5);
      return NullGLWall;
    }
    else return NullGLWall;
}

GLWalls & GLWalls::operator=(GLWalls &walls)
{
    int i;

    Clear();
    FSize = walls.FSize;
    FSizeOfArray = walls.FSizeOfArray;

    if (FSizeOfArray == 0) {
       FWall = NULL;
       return *this;
    }
    this->FWall = new GLWall[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FWall[i] = walls.FWall[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FWall[i] = NullGLWall;


    return *this;
}

bool GLWalls::operator==(GLWalls &walls)
{
    int i;

    if (FSize != walls.FSize) return false;
    for (i=0;i<FSize;i++)
      if (this->FWall[i] != walls.FWall[i]) return false;

    return true;
}

void GLWalls::Out(char *fname)
{

}

#ifdef __BCPLUSPLUS__
void GLWalls::Import(MkGlobalVar &globalvar, int sec)
{

}
#endif

bool GLWalls::Import(MkSection &sec)
{

}

bool GLWalls::ClearMember()
{
  int i;
  bool flag=true;
  for (i=0;i<FSize;i++){
    flag = flag&&FWall[i].ClearMember();
  }
  return flag;
}
//---------------------------------------------------------------------------
GLAnchor::GLAnchor()
{
  HangerType = ahtOneWale;
  Diameter = 0;
  Wale=NULL;
  Side = gsLeft;
}

GLAnchor::GLAnchor(int )
{
  HangerType = ahtOneWale;
  Diameter = 0;
  Wale=NULL;
  Side = gsLeft;
}

void GLAnchor::DrawGL()
{
  int i,j;
  MkLines fl,sl;
  MkPoint pnt[2];
  if(!Wale || !InstallDepth.getSzX() || fabs(Diameter)<EPS || !FreeLen.getSzX() || !StickLen.getSzX()) return;

  for(i=0;i<FreeLen.getSzX();i++) if(fabs(FreeLen(i))<EPS) return;
  for(i=0;i<StickLen.getSzX();i++) if(fabs(StickLen(i))<EPS) return;

  GLPile *pile = Wale->GetPile();
  if(!pile) return;

  static MkVector up(3),dir(3),norm(3);
  MkPolygon &poly = pile->GetLoc();
  GLSide side = pile->GetSide();

  fl.Initialize(poly.GetSize()-1);
  sl.Initialize(poly.GetSize()-1);

  for(i=0;i<FreeLen.getSzX();i++) {
    if (FreeLen(i)<EPS) FreeLen(i) = 5.0;
  }

  for(i=0;i<StickLen.getSzX();i++) {
    if (StickLen(i)<EPS) StickLen(i) = 5.0;
  }

  if(Diameter<EPS) Diameter = 0.030;

  for (i=0;i<InstallDepth.getSzX();i++) {

    float ang = ((side==gsRight)?1:-1)*Angle(i)*M_PI/180.0;
    up[0] =-sin(ang);
    up[1] = cos(ang);

    for(j=0;j<poly.GetSize()-1;j++) {
      dir[0] = poly(j)[1].X - poly(j)[0].X;
      dir[1] = poly(j)[1].Y - poly(j)[0].Y;
      dir[2] = poly(j)[1].Z - poly(j)[0].Z;
      dir.Normalize();
      ((side==gsRight)?up.Cross(dir,norm):dir.Cross(up,norm));
//        norm = (side==gsRight)?dir&up:up&dir;
      norm.Normalize();
      norm = norm*FreeLen(i);

      pnt[0].SetPoint((poly(j)[1].X + poly(j)[0].X)/2,
                      (poly(j)[1].Y + poly(j)[0].Y)/2,
                      (poly(j)[1].Z + poly(j)[0].Z)/2);
      pnt[1].SetPoint( pnt[0].X + norm[0],
                       pnt[0].Y + norm[1],
                       pnt[0].Z + norm[2]);

      MkPoint p;
      p = pnt[1];

      pnt[1].Y = pnt[1].Y-pnt[0].Y;
      pnt[0].Y = 0;

      fl[j].SetLine(pnt[0],pnt[1]);

      norm = norm*((StickLen(i)+FreeLen(i))/FreeLen(i));

      pnt[0].SetPoint((poly(j)[1].X + poly(j)[0].X)/2,
                      (poly(j)[1].Y + poly(j)[0].Y)/2,
                      (poly(j)[1].Z + poly(j)[0].Z)/2);
      pnt[1].SetPoint( pnt[0].X + norm[0],
                       pnt[0].Y + norm[1],
                       pnt[0].Z + norm[2]);

      p.Y = p.Y-pnt[0].Y;
      pnt[1].Y = pnt[1].Y-pnt[0].Y;
      pnt[0] = p;

      sl[j].SetLine(pnt[0],pnt[1]);
    }


    for (j=0;j<fl.GetSize();j++) {
      fl[j][0].Y += InstallDepth(i);//-((i==0)?0:InstallDepth(i-1));
      fl[j][1].Y += InstallDepth(i);//-((i==0)?0:InstallDepth(i-1));
      Anchor.SetLine(fl[j]);
      Anchor.SetHeight(fl[j].GetLength());
      Anchor.DrawGL();

      sl[j][0].Y += InstallDepth(i);//-((i==0)?0:InstallDepth(i-1));
      sl[j][1].Y += InstallDepth(i);//-((i==0)?0:InstallDepth(i-1));
      Grout.SetLine(sl[j]);
      Grout.SetHeight(sl[j].GetLength());
      Grout.DrawGL();
    }
  }
}

void GLAnchor::DrawModel()
{

}

void GLAnchor::DrawResult()
{

}

bool GLAnchor::operator==(GLAnchor& anchor)
{
  bool flag;
  flag = flag && HangerType  == anchor.HangerType;
  flag = flag && Diameter == anchor.Diameter;
  flag = flag && Start == anchor.Start;
  flag = flag && FreeLen == anchor.FreeLen;
  flag = flag && StickLen == anchor.StickLen;
  flag = flag && Angle == anchor.Angle;
  flag = flag && InstallDepth == anchor.InstallDepth;
  flag = flag && *Wale == *anchor.Wale;
  flag = flag && Anchor == anchor.Anchor;
  flag = flag && Grout == anchor.Grout;
  flag = flag && AxialForce == anchor.AxialForce;
  flag = flag && Dim == anchor.Dim;
  flag = flag && Side == anchor.Side;

  return flag;
}

bool GLAnchor::operator!=(GLAnchor& anchor)
{
  return !operator==(anchor);
}

GLAnchor & GLAnchor::operator=(GLAnchor &anchor)
{
  HangerType  = anchor.HangerType;
  Diameter = anchor.Diameter;
  Start = anchor.Start;
  FreeLen.CopyFrom(anchor.FreeLen);
  StickLen.CopyFrom(anchor.StickLen);
  Angle.CopyFrom(anchor.Angle);
  InstallDepth.CopyFrom(anchor.InstallDepth);
  *Wale= *anchor.Wale;
  Anchor = anchor.Anchor;
  Grout = anchor.Grout;
  AxialForce = anchor.AxialForce;
  Dim = anchor.Dim;
  Side = anchor.Side;

  return *this;
}

bool GLAnchor::Import(MkSection &sec)
{
  int i,nanc=0;
  float area,dia;
  MkAnchors &anc = sec.GetAnchors();
  if(anc.GetSize()<=0) return false;
  if(Side==gsLeft) {
    for(i=0;i<anc.GetSize();i++) {
      if(anc[i].GetSide()==mkLeft) nanc++;
    }
  }
  else {
    for(i=0;i<anc.GetSize();i++) {
      if(anc[i].GetSide()==mkRight) nanc++;
    }
  }

  if(nanc<=0) {
    InstallDepth.Clear();
    FreeLen.Clear();
    StickLen.Clear();
    Angle.Clear();
    return true;
  }
  InstallDepth.Initialize(nanc);
  FreeLen.Initialize(nanc);
  StickLen.Initialize(nanc);
  Angle.Initialize(nanc);

  area = anc[0].GetArea();
  dia = (4*area/M_PI > EPS*EPS ? sqrt(4*area/M_PI) : 0.01);
  SetDiameter(dia);

  nanc = 0;
  for(i=0;i<anc.GetSize();i++) {
    if(anc[i].GetSide() == mkLeft && Side == gsRight) continue;
    if(anc[i].GetSide() == mkRight && Side == gsLeft) continue;
    InstallDepth(nanc) = anc[i].GetDepth();
    FreeLen(nanc) = anc[i].GetFreeLength();
    StickLen(nanc) = anc[i].GetStickLength();
    Angle(nanc) = anc[i].GetAngle();
    nanc++;
  }
  return true;
}

bool GLAnchor::ImportStep(MkSection &sec)
{
  int i,nanc=0;
  float area,dia;
  MkAnchors &anc = sec.GetStepAnchors();
  if(anc.GetSize()<=0) return false;
  if(Side==gsLeft) {
    for(i=0;i<anc.GetSize();i++) {
      if(anc[i].GetSide()==mkLeft) nanc++;
    }
  }
  else {
    for(i=0;i<anc.GetSize();i++) {
      if(anc[i].GetSide()==mkRight) nanc++;
    }
  }

  if(nanc<=0) {
    InstallDepth.Clear();
    FreeLen.Clear();
    StickLen.Clear();
    Angle.Clear();
    return true;
  }
  InstallDepth.Initialize(nanc);
  FreeLen.Initialize(nanc);
  StickLen.Initialize(nanc);
  Angle.Initialize(nanc);

  area = anc[0].GetArea();
  dia = (4*area/M_PI > EPS*EPS ? sqrt(4*area/M_PI) : 0.01);
  SetDiameter(dia);

  nanc = 0;
  for(i=0;i<anc.GetSize();i++) {
    if(anc[i].GetSide() == mkLeft && Side == gsRight) continue;
    if(anc[i].GetSide() == mkRight && Side == gsLeft) continue;
    InstallDepth(nanc) = anc[i].GetDepth();
    FreeLen(nanc) = anc[i].GetFreeLength();
    StickLen(nanc) = anc[i].GetStickLength();
    Angle(nanc) = anc[i].GetAngle();
    nanc++;
  }
  return true;
}

bool GLAnchor::ClearMember()
{
  // nothing to do right now.
  return true;
}
//---------------------------------------------------------------------------
GLAnchors::GLAnchors(int size,GLAnchor *anchors)
{
    if (size < 0) {
      MkDebug("::GLAnchors - GLAnchors (int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSizeOfArray == 0) {
       FAnchor= NULL;
       return;
    }

    FAnchor= new GLAnchor[FSizeOfArray];
    for (int i=0;i<FSizeOfArray;i++) (*this)[i] = anchors[i];
}

GLAnchors::GLAnchors(int size)
{
    if (size < 0) {
      MkDebug("::GLAnchors - GLAnchors (int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSizeOfArray == 0) {
       FAnchor= NULL;
       return;
    }

    FAnchor= new GLAnchor[FSizeOfArray];
}

GLAnchors::~GLAnchors()
{
   FSizeOfArray = FSize = 0;
   if (FAnchor) {
      delete[] FAnchor;
      FAnchor = NULL;
   }
}

void GLAnchors::Initialize(int size)
{
    int i;
    if (size < 0) {
      MkDebug("::GLAnchors - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray== size) return;

    FSizeOfArray= FSize=size;

    if (FSizeOfArray== 0) {
       if (FAnchor!=NULL) delete[] (GLAnchor*)FAnchor;
       FAnchor = NULL;
       return;
    }

    if (FAnchor!=NULL) delete[] (GLAnchor*)FAnchor;
    FAnchor = new GLAnchor[FSizeOfArray];
}

void GLAnchors::Initialize(int size,GLAnchor *anchors)
{
    int i;
    if (size < 0 || anchors == NULL) {
      MkDebug("::GLAnchors - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSizeOfArray = size;
    FSize = size;

    if (FSizeOfArray== 0) {
       if (FAnchor!=NULL) delete[] (GLAnchor*)FAnchor;
       FAnchor = NULL;
       return;
    }

    if (FAnchor!=NULL) delete[] (GLAnchor*)FAnchor;
    FAnchor = new GLAnchor[FSizeOfArray];
    for (i=0;i<FSizeOfArray;i++) FAnchor[i] = anchors[i];
}

int GLAnchors::Grow(int delta)
{
    int i;
    GLAnchor *anchor=NULL;

    if (!(anchor = new GLAnchor[FSizeOfArray+delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        anchor[i] = FAnchor[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        anchor[i] = NullGLAnchor;
    if (FAnchor) {
       delete[] (GLAnchor*)FAnchor;
       FAnchor = NULL;
    }
    FAnchor = anchor;
    FSizeOfArray = FSizeOfArray+delta;
    return FSizeOfArray;
}

int GLAnchors::Shrink(int delta)
{
    int i;
    GLAnchor *anchor=NULL;

    if (!(anchor = new GLAnchor[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        anchor[i] = FAnchor[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        anchor[i] = NullGLAnchor;
    if (FAnchor) {
       delete[] (GLAnchor*)FAnchor;
       FAnchor = NULL;
    }
    FAnchor = anchor;
    FSizeOfArray = FSizeOfArray-delta;
    return FSizeOfArray;
}

bool GLAnchors::Add(GLAnchor &anchor)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }
    
    FSize++;
    FAnchor[FSize-1] = anchor;
    return true;
}

bool GLAnchors::Add(int index, GLAnchor &anchor)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    for (int i=FSize-1;i>=index;i--)
      FAnchor[i+1] = FAnchor[i];
    FSize++;
    FAnchor[index] = anchor;
    return true;
}

bool GLAnchors::Delete(GLAnchor &anchor)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FAnchor[i] == anchor) break;
    }
    if(i==FSize) return false;
    if(FAnchor[i] == anchor) {
      for (int j=i;j<FSize-1;j++)
        FAnchor[j] = FAnchor[j+1];
    }
    FSize--;
    FAnchor[FSize] = NullGLAnchor;
    return true;
}

bool GLAnchors::Delete(int index)
{
    for (int j=index;j<FSize-1;j++)
        FAnchor[j] = FAnchor[j+1];

    FSize--;
    FAnchor[FSize] = NullGLAnchor;
    return true;
}

bool GLAnchors::Clear()
{
   FSizeOfArray = FSize = 0;
   if (FAnchor) {
      delete[] FAnchor;
      FAnchor = NULL;
   }
   return true;
}

GLAnchor & GLAnchors::operator[](int i)
{
    if (0<=i && i<FSize) return FAnchor[i];
    else if(FSize<=i && i<FSizeOfArray) {
      FSize=i+1;
      return FAnchor[i];
    }
    else if (FSizeOfArray <= i) {
      Grow(i-FSizeOfArray+5);
      return NullGLAnchor;
    }
    else return NullGLAnchor;
}

GLAnchors & GLAnchors::operator=(GLAnchors &anchors)
{
    int i;

    Clear();
    FSize = anchors.FSize;
    FSizeOfArray = anchors.FSizeOfArray;

    if (FSizeOfArray == 0) {
       FAnchor = NULL;
       return *this;
    }
    this->FAnchor = new GLAnchor[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FAnchor[i] = anchors.FAnchor[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FAnchor[i] = NullGLAnchor;


    return *this;
}

bool GLAnchors::operator==(GLAnchors &anchors)
{
    int i;

    if (FSize != anchors.FSize) return false;
    for (i=0;i<FSize;i++)
      if (this->FAnchor[i] != anchors.FAnchor[i]) return false;

    return true;
}

void GLAnchors::Out(char *fname)
{

}

#ifdef __BCPLUSPLUS__
void GLAnchors::Import(MkGlobalVar &globalvar, int sec)
{

}
#endif

bool GLAnchors::Import(MkSection &sec)
{
  bool flag=true;
  int nanc = sec.GetSidePileNum();
  if(nanc<=0) return false;
  Initialize(nanc);
  FAnchor[0].SetSide(gsLeft);
  if(nanc>=2) FAnchor[1].SetSide(gsRight);
  for(int i=0;i<FSize;i++) {
    flag = flag && FAnchor[i].Import(sec);
  }
  return flag;
}

bool GLAnchors::ImportStep(MkSection &sec)
{
  bool flag=true;
  int nanc = sec.GetSidePileNum();
  MkAnchors &anc = sec.GetStepAnchors();

  if(nanc<=0 || anc.GetSize()<=0) return false;
  Initialize(nanc);
  FAnchor[0].SetSide(gsLeft);
  if(nanc>=2) FAnchor[1].SetSide(gsRight);
  for(int i=0;i<FSize;i++) {
    flag = flag && FAnchor[i].ImportStep(sec);
  }
  return flag;
}

bool GLAnchors::ClearMember()
{
  int i;
  bool flag=true;
  for(i=0;i<FSize;i++) {
    flag = flag && FAnchor[i].ClearMember();
  }
  return flag;
}

//---------------------------------------------------------------------------
GLRockBolt::GLRockBolt()
{
  Diameter=0;
  Pile=NULL;
  Side = gsLeft;
}

GLRockBolt::GLRockBolt(int )
{
  Diameter=0;
  Pile=NULL;
  Side = gsLeft;
}

void GLRockBolt::DrawGL()
{
  int i,j;
  MkLines lines;
  MkPoint pnt[2];
  if(!Pile || !InstallDepth.getSzX() || fabs(Diameter)<EPS || !Length.getSzX()) return;

  static MkVector up(3),dir(3),norm(3);
  up[0]=0;up[1]=1;up[2]=0;
  MkPolygon &poly = Pile->GetLoc();
  GLSide side = Pile->GetSide();

  lines.Initialize(2*poly.GetSize());

  for(i=0;i<Length.getSzX();i++)
    if(Length(i)<EPS) Length(i) = 5.0;
    // default length of rock bolt is 5, if you want to make it parameter, then you need extra work.

  for (i=0;i<InstallDepth.getSzX();i++) {
    for(j=0;j<poly.GetSize();j++) {
      dir[0] = poly(j)[1].X - poly(j)[0].X;
      dir[1] = poly(j)[1].Y - poly(j)[0].Y;
      dir[2] = poly(j)[1].Z - poly(j)[0].Z;
      dir.Normalize();
      ((side==gsRight)?up.Cross(dir,norm):dir.Cross(up,norm));
      norm.Normalize();
      norm = norm*Length(i);

      pnt[0].SetPoint(poly(j)[0].X + dir[0]*0.2,
                      poly(j)[0].Y + dir[1]*0.2,
                      poly(j)[0].Z + dir[2]*0.2);
      pnt[1].SetPoint( pnt[0].X + norm[0],
                       pnt[0].Y + norm[1],
                       pnt[0].Z + norm[2]);

      lines[2*j].SetLine(pnt[0],pnt[1]);

      pnt[0].SetPoint(poly(j)[0].X - dir[0]*0.2,
                      poly(j)[0].Y - dir[1]*0.2,
                      poly(j)[0].Z - dir[2]*0.2);
      pnt[1].SetPoint( pnt[0].X + norm[0],
                       pnt[0].Y + norm[1],
                       pnt[0].Z + norm[2]);

      lines[2*j+1].SetLine(pnt[0],pnt[1]);
    }

    for (j=0;j<lines.GetSize();j++) {
      lines[j][0].Y = InstallDepth(i);
      lines[j][1].Y = InstallDepth(i);
      Bolt.SetLine(lines[j]);
      Bolt.SetHeight(lines[j].GetLength());
      Bolt.DrawGL();
    }
  }
}

void GLRockBolt::DrawModel()
{

}

void GLRockBolt::DrawResult()
{

}

bool GLRockBolt::operator==(GLRockBolt& rb)
{
  bool flag;

  flag = flag && Diameter == rb.Diameter;
  flag = flag && Start == rb.Start;
  flag = flag && InstallDepth == rb.InstallDepth;
  flag = flag && Length == rb.Length;
  flag = flag && *Pile == *rb.Pile;
  flag = flag && Bolt == rb.Bolt;
  flag = flag && AxialForce == rb.AxialForce;
  flag = flag && Dim == rb.Dim;
  flag = flag && Side == rb.Side;

  return flag;
}

bool GLRockBolt::operator!=(GLRockBolt& rb)
{
  return !operator==(rb);
}

GLRockBolt & GLRockBolt::operator=(GLRockBolt &rb)
{
  Diameter = rb.Diameter;
  Start = rb.Start;
  InstallDepth.CopyFrom(rb.InstallDepth);
  Length.CopyFrom(rb.Length);
  *Pile = *rb.Pile;
  Bolt = rb.Bolt;
  AxialForce.CopyFrom(rb.AxialForce);
  Dim = rb.Dim;
  Side = rb.Side;

  return *this;
}

bool GLRockBolt::Import(MkSection &sec)
{
  int i, nbolt,n=0;
  float dia;
  MkBolts &bolt = sec.GetBolts();
  if(bolt.GetSize()<=0) {
    InstallDepth.Clear();
    Length.Clear();
    return true;
  }
  nbolt = bolt.GetSize();

  for(i=0;i<nbolt;i++) {
    if(Side==gsLeft && bolt[i].GetSide() == mkRight) continue;
    if(Side==gsRight && bolt[i].GetSide() == mkLeft) continue;
    n++;
  }

  if(n<=0) {
    InstallDepth.Clear();
    Length.Clear();
    return true;
  }

  dia = bolt[0].GetDiameter() < EPS ? 0.025 : bolt[0].GetDiameter()/1000.0;
  SetDiameter(dia);
  
  if(n<=0) return true;
  InstallDepth.Initialize(n);
  Length.Initialize(n);

  n=0;
  for(i=0;i<nbolt;i++) {
    if(Side==gsLeft && bolt[i].GetSide() == mkRight) continue;
    if(Side==gsRight && bolt[i].GetSide() == mkLeft) continue;
    InstallDepth(n) = bolt[i].GetDepth();
    Length(n) = bolt[i].GetLength();
    n++;
  }
  return true;
}

bool GLRockBolt::ImportStep(MkSection &sec)
{
  int i, nbolt,n=0;
  float dia;
  MkBolts &bolt = sec.GetStepBolts();
  if(bolt.GetSize()<=0) {
    InstallDepth.Clear();
    Length.Clear();
    return true;
  }
  nbolt = bolt.GetSize();

  for(i=0;i<nbolt;i++) {
    if(Side==gsLeft && bolt[i].GetSide() == mkRight) continue;
    if(Side==gsRight && bolt[i].GetSide() == mkLeft) continue;
    n++;
  }

  if(n<=0) {
    InstallDepth.Clear();
    Length.Clear();
    return true;
  }

  dia = bolt[0].GetDiameter() < EPS ? 0.025 : bolt[0].GetDiameter()/1000.0;
  SetDiameter(dia);
  
  if(n<=0) return true;
  InstallDepth.Initialize(n);
  Length.Initialize(n);

  n=0;
  for(i=0;i<nbolt;i++) {
    if(Side==gsLeft && bolt[i].GetSide() == mkRight) continue;
    if(Side==gsRight && bolt[i].GetSide() == mkLeft) continue;
    InstallDepth(n) = bolt[i].GetDepth();
    Length(n) = bolt[i].GetLength();
    n++;
  }
  return true;
}

bool GLRockBolt::ClearMember()
{
  // nothing to do right now...^^
  return true;
}
//---------------------------------------------------------------------------
GLRockBolts::GLRockBolts(int size,GLRockBolt *bolts)
{
    if (size < 0) {
      MkDebug("::GLRockBolts - GLRockBolts (int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSizeOfArray == 0) {
       FRockBolt= NULL;
       return;
    }

    FRockBolt= new GLRockBolt[FSizeOfArray];
    for (int i=0;i<FSizeOfArray;i++) (*this)[i] = bolts[i];
}

GLRockBolts::GLRockBolts(int size)
{
    if (size < 0) {
      MkDebug("::GLRockBolts - GLRockBolts (int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSizeOfArray == 0) {
       FRockBolt= NULL;
       return;
    }

    FRockBolt= new GLRockBolt[FSizeOfArray];
}

GLRockBolts::~GLRockBolts()
{
   FSizeOfArray = FSize = 0;
   if (FRockBolt) {
      delete[] FRockBolt;
      FRockBolt = NULL;
   }
}

void GLRockBolts::Initialize(int size)
{
    int i;
    if (size < 0) {
      MkDebug("::GLRockBolts - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray== size) return;

    FSizeOfArray= FSize=size;

    if (FSizeOfArray== 0) {
       if (FRockBolt!=NULL) delete[] (GLRockBolt*)FRockBolt;
       FRockBolt = NULL;
       return;
    }

    if (FRockBolt!=NULL) delete[] (GLRockBolt*)FRockBolt;
    FRockBolt = new GLRockBolt[FSizeOfArray];
}

void GLRockBolts::Initialize(int size,GLRockBolt *bolts)
{
    int i;
    if (size < 0 || bolts == NULL) {
      MkDebug("::GLRockBolts - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSizeOfArray = size;
    FSize = size;

    if (FSizeOfArray== 0) {
       if (FRockBolt!=NULL) delete[] (GLRockBolt*)FRockBolt;
       FRockBolt = NULL;
       return;
    }

    if (FRockBolt!=NULL) delete[] (GLRockBolt*)FRockBolt;
    FRockBolt = new GLRockBolt[FSizeOfArray];
    for (i=0;i<FSizeOfArray;i++) FRockBolt[i] = bolts[i];
}

int GLRockBolts::Grow(int delta)
{
    int i;
    GLRockBolt *bolt=NULL;

    if (!(bolt = new GLRockBolt[FSizeOfArray+delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        bolt[i] = FRockBolt[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        bolt[i] = NullGLRockBolt;
    if (FRockBolt) {
       delete[] (GLRockBolt*)FRockBolt;
       FRockBolt = NULL;
    }
    FRockBolt = bolt;
    FSizeOfArray = FSizeOfArray+delta;
    return FSizeOfArray;
}

int GLRockBolts::Shrink(int delta)
{
    int i;
    GLRockBolt *bolt=NULL;

    if (!(bolt = new GLRockBolt[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        bolt[i] = FRockBolt[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        bolt[i] = NullGLRockBolt;
    if (FRockBolt) {
       delete[] (GLRockBolt*)FRockBolt;
       FRockBolt = NULL;
    }
    FRockBolt = bolt;
    FSizeOfArray = FSizeOfArray-delta;
    return FSizeOfArray;
}

bool GLRockBolts::Add(GLRockBolt &bolt)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }
    
    FSize++;
    FRockBolt[FSize-1] = bolt;
    return true;
}

bool GLRockBolts::Add(int index, GLRockBolt &bolt)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    for (int i=FSize-1;i>=index;i--)
      FRockBolt[i+1] = FRockBolt[i];
    FSize++;
    FRockBolt[index] = bolt;
    return true;
}

bool GLRockBolts::Delete(GLRockBolt &bolt)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FRockBolt[i] == bolt) break;
    }
    if(i==FSize) return false;
    if(FRockBolt[i] == bolt) {
      for (int j=i;j<FSize-1;j++)
        FRockBolt[j] = FRockBolt[j+1];
    }
    FSize--;
    FRockBolt[FSize] = NullGLRockBolt;
    return true;
}

bool GLRockBolts::Delete(int index)
{
    for (int j=index;j<FSize-1;j++)
        FRockBolt[j] = FRockBolt[j+1];

    FSize--;
    FRockBolt[FSize] = NullGLRockBolt;
    return true;
}

bool GLRockBolts::Clear()
{
   FSizeOfArray = FSize = 0;
   if (FRockBolt) {
      delete[] FRockBolt;
      FRockBolt = NULL;
   }
   return true;
}

GLRockBolt & GLRockBolts::operator[](int i)
{
    if (0<=i && i<FSize) return FRockBolt[i];
    else if(FSize<=i && i<FSizeOfArray) {
      FSize=i+1;
      return FRockBolt[i];
    }
    else if (FSizeOfArray <= i) {
      Grow(i-FSizeOfArray+5);
      return NullGLRockBolt;
    }
    else return NullGLRockBolt;
}

GLRockBolts & GLRockBolts::operator=(GLRockBolts &bolts)
{
    int i;

    Clear();
    FSize = bolts.FSize;
    FSizeOfArray = bolts.FSizeOfArray;

    if (FSizeOfArray == 0) {
       FRockBolt = NULL;
       return *this;
    }
    this->FRockBolt = new GLRockBolt[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FRockBolt[i] = bolts.FRockBolt[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FRockBolt[i] = NullGLRockBolt;


    return *this;
}

bool GLRockBolts::operator==(GLRockBolts &bolts)
{
    int i;

    if (FSize != bolts.FSize) return false;
    for (i=0;i<FSize;i++)
      if (this->FRockBolt[i] != bolts.FRockBolt[i]) return false;

    return true;
}

void GLRockBolts::Out(char *fname)
{

}

#ifdef __BCPLUSPLUS__
void GLRockBolts::Import(MkGlobalVar &globalvar, int sec)
{

}
#endif

bool GLRockBolts::Import(MkSection &sec)
{
  int i;
  bool flag=true;
  int nbolt = sec.GetSidePileNum();
  if(nbolt<=0) return false;
  Initialize(nbolt);
  FRockBolt[0].SetSide(gsLeft);
  if(nbolt>=2) FRockBolt[1].SetSide(gsRight);

  for(i=0;i<FSize;i++)
    flag = flag && FRockBolt[i].Import(sec);
  return flag;
}

bool GLRockBolts::ImportStep(MkSection &sec)
{
  int i;
  bool flag=true;
  int nbolt = sec.GetSidePileNum();
  if(nbolt<=0) return false;
  Initialize(nbolt);
  FRockBolt[0].SetSide(gsLeft);
  if(nbolt>=2) FRockBolt[1].SetSide(gsRight);

  for(i=0;i<FSize;i++)
    flag = flag && FRockBolt[i].ImportStep(sec);
  return flag;
}

bool GLRockBolts::ClearMember()
{
  int i;
  bool flag = true;
  for(i=0;i<FSize;i++) {
    flag = flag && FRockBolt[i].ClearMember();
  }
  return flag;
}
//---------------------------------------------------------------------------
GLMainBeamProp::GLMainBeamProp()
{
  Wale=NULL;
  Depth = 0;
  Side = gsLeft;
}

GLMainBeamProp::GLMainBeamProp(int)
{
  Wale=NULL;
  Depth = 0;
  Side = gsLeft;
}

void GLMainBeamProp::DrawGL()
{
  int i;
  MkLine line;
  static MkVector up(3);
  up[0] = 0;up[1] = 1;up[2] = 0;
  GLDeckType dt;

  if(!Wale || !MainBeam) return;
  GLDeck *Deck = MainBeam->GetDeck();
  if(!Deck) return;

  GLWale &wale = (*Wale);

  dt = MainBeam->GetDeck()->GetDeckType();
  bool isClosed = wale.GetPile()->GetClosed();
  MkPolygon &loc = wale.GetLoc();

  for(i=0;i<loc.GetSize()-(isClosed?0:1);i++) {
    line[0] = loc[i];
    line[1] = loc[(i+1==loc.GetSize())?0:i+1];

    line[0].Y = Depth;
    line[1].Y = Depth;
    line[0].Y = -Beam.GetHeight()/2 -MainBeam->GetBeam().GetHeight()+((dt==dtOnGround)?-Deck->GetThick()/2:Deck->GetThick()/2);
    line[1].Y = -Beam.GetHeight()/2 -MainBeam->GetBeam().GetHeight()+((dt==dtOnGround)?-Deck->GetThick()/2:Deck->GetThick()/2);

    Beam.SetLine(line);
    Beam.SetVector(up);
    Beam.SetLength(line.GetLength());
    Beam.DrawGL();
  }
}

bool GLMainBeamProp::operator==(GLMainBeamProp& prop)
{
  bool flag;

  flag = flag && Beam == prop.Beam;
  flag = flag && Depth == prop.Depth;
  flag = flag && *Wale == *prop.Wale;
  flag = flag && *MainBeam == *prop.MainBeam;
  flag = flag && Dim == prop.Dim;
  flag = flag && Side == prop.Side;

  return flag;
}

bool GLMainBeamProp::operator!=(GLMainBeamProp& prop)
{
  return !operator==(prop);
}

GLMainBeamProp & GLMainBeamProp::operator=(GLMainBeamProp &prop)
{
  Beam = prop.Beam;
  Depth = prop.Depth;
  *Wale = *prop.Wale;
  *MainBeam = *prop.MainBeam;
  Dim = prop.Dim;
  Side = prop.Side;

  return *this;
}

bool GLMainBeamProp::ClearMember()
{
  // nothing to do right now...
  return true;
}
//---------------------------------------------------------------------------
GLMainBeamProps::GLMainBeamProps(int size,GLMainBeamProp *props)
{
    if (size < 0) {
      MkDebug("::GLMainBeamProps - GLMainBeamProps (int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSizeOfArray == 0) {
       FMainBeamProp= NULL;
       return;
    }

    FMainBeamProp= new GLMainBeamProp[FSizeOfArray];
    for (int i=0;i<FSizeOfArray;i++) (*this)[i] = props[i];
}

GLMainBeamProps::GLMainBeamProps(int size)
{
    if (size < 0) {
      MkDebug("::GLMainBeamProps - GLMainBeamProps (int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSizeOfArray == 0) {
       FMainBeamProp= NULL;
       return;
    }

    FMainBeamProp= new GLMainBeamProp[FSizeOfArray];
}

GLMainBeamProps::~GLMainBeamProps()
{
   FSizeOfArray = FSize = 0;
   if (FMainBeamProp) {
      delete[] FMainBeamProp;
      FMainBeamProp = NULL;
   }
}

void GLMainBeamProps::Initialize(int size)
{
    int i;
    if (size < 0) {
      MkDebug("::GLMainBeamProps - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray== size) return;

    FSizeOfArray= FSize=size;

    if (FSizeOfArray== 0) {
       if (FMainBeamProp!=NULL) delete[] (GLMainBeamProp*)FMainBeamProp;
       FMainBeamProp = NULL;
       return;
    }

    if (FMainBeamProp!=NULL) delete[] (GLMainBeamProp*)FMainBeamProp;
    FMainBeamProp = new GLMainBeamProp[FSizeOfArray];
}

void GLMainBeamProps::Initialize(int size,GLMainBeamProp *props)
{
    int i;
    if (size < 0 || props == NULL) {
      MkDebug("::GLMainBeamProps - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSizeOfArray = size;
    FSize = size;

    if (FSizeOfArray== 0) {
       if (FMainBeamProp!=NULL) delete[] (GLMainBeamProp*)FMainBeamProp;
       FMainBeamProp = NULL;
       return;
    }

    if (FMainBeamProp!=NULL) delete[] (GLMainBeamProp*)FMainBeamProp;
    FMainBeamProp = new GLMainBeamProp[FSizeOfArray];
    for (i=0;i<FSizeOfArray;i++) FMainBeamProp[i] = props[i];
}

int GLMainBeamProps::Grow(int delta)
{
    int i;
    GLMainBeamProp *prop=NULL;

    if (!(prop = new GLMainBeamProp[FSizeOfArray+delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        prop[i] = FMainBeamProp[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        prop[i] = NullGLMainBeamProp;
    if (FMainBeamProp) {
       delete[] (GLMainBeamProp*)FMainBeamProp;
       FMainBeamProp = NULL;
    }
    FMainBeamProp = prop;
    FSizeOfArray = FSizeOfArray+delta;
    return FSizeOfArray;
}

int GLMainBeamProps::Shrink(int delta)
{
    int i;
    GLMainBeamProp *prop=NULL;

    if (!(prop = new GLMainBeamProp[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        prop[i] = FMainBeamProp[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        prop[i] = NullGLMainBeamProp;
    if (FMainBeamProp) {
       delete[] (GLMainBeamProp*)FMainBeamProp;
       FMainBeamProp = NULL;
    }
    FMainBeamProp = prop;
    FSizeOfArray = FSizeOfArray-delta;
    return FSizeOfArray;
}

bool GLMainBeamProps::Add(GLMainBeamProp &prop)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }
    
    FSize++;
    FMainBeamProp[FSize-1] = prop;
    return true;
}

bool GLMainBeamProps::Add(int index, GLMainBeamProp &prop)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    for (int i=FSize-1;i>=index;i--)
      FMainBeamProp[i+1] = FMainBeamProp[i];
    FSize++;
    FMainBeamProp[index] = prop;
    return true;
}

bool GLMainBeamProps::Delete(GLMainBeamProp &prop)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FMainBeamProp[i] == prop) break;
    }
    if(i==FSize) return false;
    if(FMainBeamProp[i] == prop) {
      for (int j=i;j<FSize-1;j++)
        FMainBeamProp[j] = FMainBeamProp[j+1];
    }
    FSize--;
    FMainBeamProp[FSize] = NullGLMainBeamProp;
    return true;
}

bool GLMainBeamProps::Delete(int index)
{
    for (int j=index;j<FSize-1;j++)
        FMainBeamProp[j] = FMainBeamProp[j+1];

    FSize--;
    FMainBeamProp[FSize] = NullGLMainBeamProp;
    return true;
}

bool GLMainBeamProps::Clear()
{
   FSize = 0;
   if (FMainBeamProp) {
      delete[] FMainBeamProp;
      FMainBeamProp = NULL;
   }
   return true;
}

GLMainBeamProp & GLMainBeamProps::operator[](int i)
{
    if (0<=i && i<FSize) return FMainBeamProp[i];
    else if(FSize<=i && i<FSizeOfArray) {
      FSize=i+1;
      return FMainBeamProp[i];
    }
    else if (FSizeOfArray <= i) {
      Grow(i-FSizeOfArray+5);
      return NullGLMainBeamProp;
    }
    else return NullGLMainBeamProp;
}

GLMainBeamProps & GLMainBeamProps::operator=(GLMainBeamProps &props)
{
    int i;

    Clear();
    FSize = props.FSize;
    FSizeOfArray = props.FSizeOfArray;

    if (FSizeOfArray == 0) {
       FMainBeamProp = NULL;
       return *this;
    }
    this->FMainBeamProp = new GLMainBeamProp[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FMainBeamProp[i] = props.FMainBeamProp[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FMainBeamProp[i] = NullGLMainBeamProp;


    return *this;
}

bool GLMainBeamProps::operator==(GLMainBeamProps &props)
{
    int i;

    if (FSize != props.FSize) return false;
    for (i=0;i<FSize;i++)
      if (this->FMainBeamProp[i] != props.FMainBeamProp[i]) return false;

    return true;
}

void GLMainBeamProps::Out(char *fname)
{

}

#ifdef __BCPLUSPLUS__
void GLMainBeamProps::Import(MkGlobalVar &globalvar, int sec)
{

}
#endif

bool GLMainBeamProps::Import(MkSection &sec)
{

}

bool GLMainBeamProps::ClearMember()
{
  int i;
  bool flag = true;
  for(i=0;i<FSize;i++) {
    flag = flag && FMainBeamProp[i].ClearMember();
  }
  return flag;
}
//---------------------------------------------------------------------------
GLMainBeam::GLMainBeam()
{
  Spacing = 0;
  Props = NULL;
  Length = 10;
}

void GLMainBeam::DrawGL()
{
  static MkVector up(3),dir(3);
  MkPolygon lpoly, rpoly;
  float len[2];
  int i,j,nbeam;

  if(!Props || !Deck) return;
  GLDeckType dt = Deck->GetDeckType();

  if(!isBuilt) {
    up[0]=0;up[1]=1;up[2]=0; //up.SetVector(0,1,0);
    if (fabs(Spacing)<EPS || Props->GetSize()<=0) return;

    for(i=0;i<Props->GetSize();i++) {
      MkPolygon &poly = ((*Props)[i].GetSide()==gsLeft)?lpoly:rpoly;
      bool dir = ((*Props)[i].GetSide()==gsLeft)?false:true;
      (*Props)[i].GetWale()->GetLoc().Offset(poly,up,dir,(*Props)[i].GetBeam().GetHeight()/2);
    }

    if(lpoly.GetSize()==0 && rpoly.GetSize()!=0) {
      rpoly.Offset(lpoly,up,false,Length);
    }
    else if(rpoly.GetSize()==0 && lpoly.GetSize()!=0) {
      lpoly.Offset(rpoly,up,true,Length);
    }
    else if(lpoly.GetSize()!=0 && rpoly.GetSize()!=0) {
    }
    else return;

    len[0] = lpoly.GetLength();
    len[1] = rpoly.GetLength();

    nbeam = len[0]/Spacing;
    Lines.Initialize(nbeam);

    for(i=0;i<nbeam;i++) {
      Lines[i][0] = lpoly.Measure(i*Spacing);
      Lines[i][1] = rpoly.Measure(i*Spacing);
    }

//    if (LeftProp&&RightProp) {
//      if(!LeftProp->GetWales()->GetLoc().GetSize() || !RightProp->GetWales()->GetLoc().GetSize()) return;
//      LeftProp->GetWales()->GetLoc().Offset(lpoly,up,false,LeftProp->GetBeam().GetHeight()/2);
//      RightProp->GetWales()->GetLoc().Offset(rpoly,up,true,RightProp->GetBeam().GetHeight()/2);
//      len[0] = lpoly.GetLength();
//      len[1] = rpoly.GetLength();
//
//      nbeam = len[0]/Spacing;
//      Lines.Initialize(nbeam);
//
//      for(i=0;i<nbeam;i++) {
//        Lines[i][0] = lpoly.Measure(i*Spacing);
//        Lines[i][1] = rpoly.Measure(i*Spacing);
//      }
//    }
//    else if (LeftProp) {
//      if(Length<EPS) Length = 10;
//      if(!LeftProp->GetWales()->GetLoc().GetSize()) return;
//      LeftProp->GetWales()->GetLoc().Offset(lpoly,up,false,LeftProp->GetBeam().GetHeight()/2);
//      LeftProp->GetWales()->GetLoc().Offset(rpoly,up,false,Length);
//      len[0] = lpoly.GetLength();
//
//      nbeam = len[0]/Spacing;
//      Lines.Initialize(nbeam);
//
//      for(i=0;i<nbeam;i++) {
//        Lines[i][0] = lpoly.Measure(i*Spacing);
//        Lines[i][1] = rpoly.Measure(i*Spacing);
//      }
//    }
//    else {
//      if(Length<EPS) Length = 10;
//      if(!RightProp->GetWales()->GetLoc().GetSize()) return;
//      RightProp->GetWales()->GetLoc().Offset(lpoly,up,true,Length);
//      RightProp->GetWales()->GetLoc().Offset(rpoly,up,true,RightProp->GetBeam().GetHeight()/2);
//      len[0] = rpoly.GetLength();
//
//      nbeam = len[0]/Spacing;
//      Lines.Initialize(nbeam);
//
//      for(i=0;i<nbeam;i++) {
//        Lines[i][0] = lpoly.Measure(i*Spacing);
//        Lines[i][1] = rpoly.Measure(i*Spacing);
//      }
//    }
//    isBuilt = true;
  }

  for (i=0;i<Lines.GetSize();i++) {
    Lines[i][0].Y = -Beam.GetHeight()/2 + ((dt==dtOnGround)?-Deck->GetThick()/2:Deck->GetThick()/2);
    Lines[i][1].Y = -Beam.GetHeight()/2 + ((dt==dtOnGround)?-Deck->GetThick()/2:Deck->GetThick()/2);

    Beam.SetLine(Lines[i]);
    Beam.SetLength(Lines[i].GetLength());
    Beam.DrawGL();
  }
}

bool GLMainBeam::Import(MkSection &sec)
{

}

bool GLMainBeam::ClearMember()
{
  isBuilt = false;
  return true;
}
//---------------------------------------------------------------------------
GLDeck::GLDeck()
{
  Height = 0;
  Width = 0;
  Thick = 0;
  MainBeam = NULL;
}

void GLDeck::DrawGL()
{
  int i,j,size,cnt;
  float div;
  MkPoint pnt[2];
  static MkVector dir(3), up(3), norm(3);
  up[0]=0;up[1]=1;up[2]=0;
  if(!MainBeam || fabs(Deck.GetHeight())<EPS || fabs(Deck.GetWidth())<EPS) return;

  MkLines &line = MainBeam->GetLines();
  MkLine l;
  size = line.GetSize();
  if(size<2) return;

  cnt=0;
  for (i=0;i<size-1;i++) {
    cnt += line[i].GetLength()/Width;
  }

  Lines.Initialize(cnt);

  cnt=0;
  for (i=0;i<size-1;i++) {
    if(fabs(line[i].GetLength())<EPS) continue;
    div = Height/line[i].GetLength();
    for (j=0;j<line[i].GetLength()/Height;j++, cnt++) {
      l[0].X = (line[i+1][0].X + line[i][0].X)/2;
      l[0].Y = (line[i+1][0].Y + line[i][0].Y)/2;
      l[0].Z = (line[i+1][0].Z + line[i][0].Z)/2;

      l[1].X = (line[i+1][1].X + line[i][1].X)/2;
      l[1].Y = (line[i+1][1].Y + line[i][1].Y)/2;
      l[1].Z = (line[i+1][1].Z + line[i][1].Z)/2;

      pnt[0] = l.GetDivision(j*div);
      pnt[1] = l.GetDivision((j+1)*div);
//      dir = line[i].GetVector();
//      dir.Normalize();
//      norm = up.Cross(dir); norm.Normalize();
//      norm = norm*Deck.GetWidth();
//      pnt[1].SetPoint(pnt[0].X + norm[0],pnt[0].Y + norm[1],pnt[0].Z + norm[2]);

      pnt[0].Y = ((DeckType==dtOnGround)?-Thick/2:Thick/2);
      pnt[1].Y = ((DeckType==dtOnGround)?-Thick/2:Thick/2);
      Lines[cnt].SetLine(pnt[0],pnt[1]);
    }
  }

  for (i=0;i<Lines.GetSize();i++) {
    Deck.SetLine(Lines[i]);
    Deck.SetWidth(Width-0.05);
    Deck.SetHeight(Lines[i].GetLength()-0.05);
    Deck.DrawGL();
  }
}

bool GLDeck::Import(MkSection &sec)
{

}

bool GLDeck::ClearMember()
{
  // nothing to do
  return true;
}

//---------------------------------------------------------------------------
GLBracket::GLBracket()
{
  BracketType = btSteelBeam;
  Diameter = 0;
  Height = 0;
  Width = 0;
  Thick = 0;
  RefStrut = NULL;
}

void GLBracket::DrawGL()
{

}

bool GLBracket::ClearMember()
{
  // nothing to do
  return true;
}

//---------------------------------------------------------------------------
GLPieceBracket::GLPieceBracket()
{
  Prop = NULL;
  Side = gsLeft;
}

GLPieceBracket::GLPieceBracket(int )
{
  Prop = NULL;
  Side = gsLeft;
}

void GLPieceBracket::DrawGL()
{
  int i;
  for (i=0;i<Lines.GetSize();i++) {
    Beam.SetLine(Lines[i]);
    Beam.SetLength(Lines[i].GetLength());
    Beam.DrawGL();
  }
}

bool GLPieceBracket::operator==(GLPieceBracket& bracket)
{
  bool flag;

  flag = flag && Beam == bracket.Beam;
  flag = flag && *Prop == *bracket.Prop;
  flag = flag && Lines == bracket.Lines;
  flag = flag && isBuilt== bracket.isBuilt;
  flag = flag && Side == bracket.Side;

  return flag;
}

bool GLPieceBracket::operator!=(GLPieceBracket& bracket)
{
  return !operator==(bracket);
}

GLPieceBracket & GLPieceBracket::operator=(GLPieceBracket &bracket)
{
  Beam = bracket.Beam;
  *Prop = *bracket.Prop;
  Lines = bracket.Lines;
  isBuilt= bracket.isBuilt;
  Side = bracket.Side;

  return *this;
}

bool GLPieceBracket::ClearMember()
{
  // nothing to do
  return true;
}

//---------------------------------------------------------------------------
GLPieceBrackets::GLPieceBrackets(int size,GLPieceBracket *brackets)
{
    if (size < 0) {
      MkDebug("::GLPieceBrackets - GLPieceBrackets (int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSizeOfArray == 0) {
       FPieceBracket= NULL;
       return;
    }

    FPieceBracket= new GLPieceBracket[FSizeOfArray];
    for (int i=0;i<FSizeOfArray;i++) (*this)[i] = brackets[i];
}

GLPieceBrackets::GLPieceBrackets(int size)
{
    if (size < 0) {
      MkDebug("::GLPieceBrackets - GLPieceBrackets (int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSizeOfArray == 0) {
       FPieceBracket= NULL;
       return;
    }

    FPieceBracket= new GLPieceBracket[FSizeOfArray];
}

GLPieceBrackets::~GLPieceBrackets()
{
   FSizeOfArray = FSize = 0;
   if (FPieceBracket) {
      delete[] FPieceBracket;
      FPieceBracket = NULL;
   }
}

void GLPieceBrackets::Initialize(int size)
{
    int i;
    if (size < 0) {
      MkDebug("::GLPieceBrackets - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray== size) return;

    FSizeOfArray= FSize=size;

    if (FSizeOfArray== 0) {
       if (FPieceBracket!=NULL) delete[] (GLPieceBracket*)FPieceBracket;
       FPieceBracket = NULL;
       return;
    }

    if (FPieceBracket!=NULL) delete[] (GLPieceBracket*)FPieceBracket;
    FPieceBracket = new GLPieceBracket[FSizeOfArray];
}

void GLPieceBrackets::Initialize(int size,GLPieceBracket *brackets)
{
    int i;
    if (size < 0 || brackets == NULL) {
      MkDebug("::GLPieceBrackets - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSizeOfArray = size;
    FSize = size;

    if (FSizeOfArray== 0) {
       if (FPieceBracket!=NULL) delete[] (GLPieceBracket*)FPieceBracket;
       FPieceBracket = NULL;
       return;
    }

    if (FPieceBracket!=NULL) delete[] (GLPieceBracket*)FPieceBracket;
    FPieceBracket = new GLPieceBracket[FSizeOfArray];
    for (i=0;i<FSizeOfArray;i++) FPieceBracket[i] = brackets[i];
}

int GLPieceBrackets::Grow(int delta)
{
    int i;
    GLPieceBracket *bracket=NULL;

    if (!(bracket = new GLPieceBracket[FSizeOfArray+delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        bracket[i] = FPieceBracket[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        bracket[i] = NullGLPieceBracket;
    if (FPieceBracket) {
       delete[] (GLPieceBracket*)FPieceBracket;
       FPieceBracket = NULL;
    }
    FPieceBracket = bracket;
    FSizeOfArray = FSizeOfArray+delta;
    return FSizeOfArray;
}

int GLPieceBrackets::Shrink(int delta)
{
    int i;
    GLPieceBracket *bracket=NULL;

    if (!(bracket = new GLPieceBracket[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        bracket[i] = FPieceBracket[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        bracket[i] = NullGLPieceBracket;
    if (FPieceBracket) {
       delete[] (GLPieceBracket*)FPieceBracket;
       FPieceBracket = NULL;
    }
    FPieceBracket = bracket;
    FSizeOfArray = FSizeOfArray-delta;
    return FSizeOfArray;
}

bool GLPieceBrackets::Add(GLPieceBracket &bracket)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }
    
    FSize++;
    FPieceBracket[FSize-1] = bracket;
    return true;
}

bool GLPieceBrackets::Add(int index, GLPieceBracket &bracket)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    for (int i=FSize-1;i>=index;i--)
      FPieceBracket[i+1] = FPieceBracket[i];
    FSize++;
    FPieceBracket[index] = bracket;
    return true;
}

bool GLPieceBrackets::Delete(GLPieceBracket &bracket)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FPieceBracket[i] == bracket) break;
    }
    if(i==FSize) return false;
    if(FPieceBracket[i] == bracket) {
      for (int j=i;j<FSize-1;j++)
        FPieceBracket[j] = FPieceBracket[j+1];
    }
    FSize--;
    FPieceBracket[FSize] = NullGLPieceBracket;
    return true;
}

bool GLPieceBrackets::Delete(int index)
{
    for (int j=index;j<FSize-1;j++)
        FPieceBracket[j] = FPieceBracket[j+1];

    FSize--;
    FPieceBracket[FSize] = NullGLPieceBracket;
    return true;
}

bool GLPieceBrackets::Clear()
{
   FSize = 0;
   if (FPieceBracket) {
      delete[] FPieceBracket;
      FPieceBracket = NULL;
   }
   return true;
}

GLPieceBracket & GLPieceBrackets::operator[](int i)
{
    if (0<=i && i<FSize) return FPieceBracket[i];
    else if(FSize<=i && i<FSizeOfArray) {
      FSize=i+1;
      return FPieceBracket[i];
    }
    else if (FSizeOfArray <= i) {
      Grow(i-FSizeOfArray+5);
      return NullGLPieceBracket;
    }
    else return NullGLPieceBracket;
}

GLPieceBrackets & GLPieceBrackets::operator=(GLPieceBrackets &brackets)
{
    int i;

    Clear();
    FSize = brackets.FSize;
    FSizeOfArray = brackets.FSizeOfArray;

    if (FSizeOfArray == 0) {
       FPieceBracket = NULL;
       return *this;
    }
    this->FPieceBracket = new GLPieceBracket[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FPieceBracket[i] = brackets.FPieceBracket[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FPieceBracket[i] = NullGLPieceBracket;


    return *this;
}

bool GLPieceBrackets::operator==(GLPieceBrackets &brackets)
{
    int i;

    if (FSize != brackets.FSize) return false;
    for (i=0;i<FSize;i++)
      if (this->FPieceBracket[i] != brackets.FPieceBracket[i]) return false;

    return true;
}

void GLPieceBrackets::Out(char *fname)
{

}

#ifdef __BCPLUSPLUS__
void GLPieceBrackets::Import(MkGlobalVar &globalvar, int sec)
{

}
#endif

bool GLPieceBrackets::Import(MkSection &sec)
{

}

bool GLPieceBrackets::ClearMember()
{
  int i;
  bool flag = true;
  for(i=0;i<FSize;i++) {
    flag = flag && FPieceBracket[i].ClearMember();
  }
  return flag;
}

//---------------------------------------------------------------------------
GLWater::GLWater()
{

}

void GLWater::DrawGL()
{

}

bool GLWater::Import(MkSection &sec)
{

}

bool GLWater::ClearMember()
{
  // nothing to do
  return true;
}
//---------------------------------------------------------------------------
GLLoad::GLLoad()
{

}

void GLLoad::DrawGL()
{

}

bool GLLoad::ClearMember()
{
  // nothing to do right now
  return true;
}
//---------------------------------------------------------------------------
GLLoads::GLLoads()
{

}

void GLLoads::DrawGL()
{

}

bool GLLoads::Import(MkSection &sec)
{

}

bool GLLoads::ClearMember()
{
  //nothing to do right now
  return true;
}
//---------------------------------------------------------------------------
GLColors::GLColors(int size,TColor *colors)
{
    if (size < 0) {
      MkDebug("::GLColors - GLColors(int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSize == 0) {
       FColor = NULL;
       return;
    }

    FColor = new TColor[FSize];
    if(!FColor)
      for (int i=0;i<FSize;i++) FColor[i] = colors[i];
}

GLColors::GLColors(int size)
{
    if (size < 0) {
      MkDebug("::GLColors - GLColors(int size)");;
      return;
    }

    FSize = FSizeOfArray = size;

    if (FSizeOfArray == 0) {
       FColor = NULL;
       return;
    }

    FColor = new TColor[FSizeOfArray];
}

GLColors::~GLColors()
{
   FSizeOfArray = FSize = 0;
   if (FColor) {
      delete[] FColor;
      FColor = NULL;
   }
}

void GLColors::Initialize(int size)
{
    if (size < 0) {
      MkDebug("::GLColors - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;

    FSize = FSizeOfArray = size;

    if (FSizeOfArray == 0) {
       if (FColor!=NULL) delete[] (TColor*)FColor;
       FColor = NULL;
       return;
    }

    if (FColor!=NULL) delete[] (TColor*)FColor;
    FColor = new TColor[FSizeOfArray];
}

void GLColors::Initialize(int size,TColor *colors)
{

    if (size < 0 || colors == NULL) {
      MkDebug("::GLColors - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSize = FSizeOfArray = size;
    if (FSizeOfArray == 0) {
       if (FColor!=NULL) delete[] (TColor*)FColor;
       FColor = NULL;
       return;
    }

    if (FColor!=NULL) delete[] (TColor*)FColor;
    FColor = new TColor[FSizeOfArray];
    for (int i=0;i<FSizeOfArray;i++) FColor[i] = colors[i];
}

int GLColors::Grow(int delta)
{
    int i;
    TColor *color=NULL;

    if (!(color = new TColor[FSizeOfArray+delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        color[i] = FColor[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        color[i] = NullGLColor;
    if (FColor) {
       delete[] (TColor*)FColor;
       FColor = NULL;
    }
    FColor = color;
    FSizeOfArray = FSizeOfArray+delta;

    return FSizeOfArray;
}

int GLColors::Shrink(int delta)
{
    int i;
    TColor *color=NULL;

    if (!(color = new TColor[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        color[i] = FColor[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        color[i] = NullGLColor;
    if (FColor) {
       delete[] (TColor*)FColor;
       FColor = NULL;
    }
    FColor = color;
    FSizeOfArray = FSizeOfArray-delta;

    return FSizeOfArray;
}

bool GLColors::Add(TColor &color)
{
    int tmp=FSizeOfArray;
    bool flag=false;
    for (int i=0;i<FSize;i++) if (FColor[i]==color) flag=true;

    if(flag) return false;
    if (FSize>=FSizeOfArray) {
       Grow(FSize-FSizeOfArray+10);
       if (tmp==FSizeOfArray) return false;
    }
    FSize++;
    FColor[FSize-1] = color;

    return true;
}

bool GLColors::Delete(TColor &color)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FColor[i] == color) break;
    }
    if(i==FSize) return false;
    if(FColor[i] == color) {
      for (int j=i;j<FSize-1;j++)
        FColor[j] = FColor[j+1];
    }
    FSize--;
    FColor[FSize] = NullGLColor;
    return true;
}

bool GLColors::Clear()
{
   FSizeOfArray = FSize = 0;
   if (FColor) {
      delete[] FColor;
      FColor = NULL;
   }
   return true;
}

TColor & GLColors::operator[](int i)
{
    if (FSizeOfArray == 0) return NullGLColor;
    if (i >= FSize && i < FSizeOfArray) FSize = i+1;

    if (i >=0 && i < FSize) return FColor[i];
    else return NullGLColor;
}

GLColors & GLColors::operator=(GLColors &colors)
{
    int i;

    Clear();
    FSize = colors.FSize;
    FSizeOfArray = colors.FSizeOfArray;
    if (FSize == 0) {
       FColor = NULL;
       return *this;
    }
    this->FColor = new TColor[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FColor[i] = colors.FColor[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FColor[i] = NullGLColor;

    return *this;
}

bool GLColors::operator==(GLColors &colors)
{
  int i;

  if (FSize != colors.FSize) return false;
  for (i=0;i<FSize;i++)
    if (this->FColor[i] != colors.FColor[i]) return false;

  return true;
}
//---------------------------------------------------------------------------
GLColorLegend::GLColorLegend()
{
  NumberOfColor = 0;
}

void GLColorLegend::MinMax()
{
  int i;
  float vmin=1e20, vmax=-1e20;

  if(NumberOfColor<=0) return;
  if(!Check()) return;

  vmin = Value(0);
  vmax = Value(0);
  for(i=1;i<NumberOfColor;i++) {
    vmin = ((Value(i)<vmin)?Value(i):vmin);
    vmax = ((Value(i)>vmax)?Value(i):vmax);
  }

  MaxValue = vmax;
  MinValue = vmin;
}

void GLColorLegend::Sort()
{
  int i,j;
  if(NumberOfColor<=0) return;
  if(!Check()) return;

  for(i=0;i<NumberOfColor-1;i++) {
    for(j=i+1;j<NumberOfColor;j++) {
      if(Value(i)>Value(j)) {
        swap(Value(i), Value(j));
        swap(Color[i], Color[j]);
      }
    }
  }
}

bool GLColorLegend::Check()
{
  bool flag=true;
  flag = flag && Value.getSzX()==NumberOfColor;
  flag = flag && Value.getSzX()==Color.GetSize();
  return flag;
}

void GLColorLegend::AddColorValue(TColor c, float t)
{
  int i;
  GLColors color;
  MkFloat  value;

  color.Initialize(NumberOfColor+1);
  value.Initialize(NumberOfColor+1);

  for(i=0;i<NumberOfColor;i++) {
    color[i] = Color[i];
    value(i) = Value(i);
  }
  color[NumberOfColor] = c;
  value(NumberOfColor) = t;

  NumberOfColor++;
  
  Color.Clear();
  Value.Clear();

  Color = color;
  Value.CopyFrom(value);

  Sort();
}

void GLColorLegend::DelColorValue(TColor c, float t)
{
  int i,I;
  float rmax,gmax,bmax,rmin,gmin,bmin;

  GLColors color;
  MkFloat  value;

  if(NumberOfColor<=0) return;
  
  for(i=0;i<NumberOfColor;i++) {
    if(fabs(Value(i)-t)<EPS) break;
  }
  if(fabs(Value(i)-t)>EPS) return;
  I = i;

  color.Initialize(NumberOfColor-1);
  value.Initialize(NumberOfColor-1);

  for(i=0;i<NumberOfColor;i++) {
    color[(i<=I)?i:i-1] = Color[i];
    value((i<=I)?i:i-1) = Value(i);
  }

  NumberOfColor--;

  Color.Clear();
  Value.Clear();

  Color = color;
  Value.CopyFrom(value);
}

TColor GLColorLegend::GetColor(float t)
{
  int i;
  float smin, smax, v, r, g, b;

  TColor red=0x0000FF,blue=0xFF0000,green=0x00FF00;
  TColor rmax, rmin, bmax, bmin, gmax, gmin, result;

  if(NumberOfColor<=0) return clWhite;

  if(t<Value(0)) return Color[0];
  else if(t>Value(NumberOfColor-1)) return Color[NumberOfColor-1];

  for(i=0;i<NumberOfColor-1;i++) {
    if(Value(i)<t && t<=Value(i+1)) {
      smin = Value(i);
      smax = Value(i+1);
      rmin = Color[i] & red;
      rmax = Color[i+1] & red;
      gmin = (Color[i] & green) >> 8;
      gmax = (Color[i+1] & green) >> 8;
      bmin = (Color[i] & blue) >> 16;
      bmax = (Color[i+1] & blue) >> 16;
      break;
    }
  }
  v = (t-smin)/(smax-smin);
  result = int(rmin*(1-v)+rmax*v)+(int(gmin*(1-v)+gmax*v)<<8)+(int(bmin*(1-v)+bmax*v)<<16);
  return result;
}

float GLColorLegend::GetRed(TColor c)
{
  TColor red=0x0000FF;
  TColor r;
  r = c & red;
  return r/255.0;
}

float GLColorLegend::GetGreen(TColor c)
{
  TColor green=0x00FF00;
  TColor g;
  g = (c & green)>>8;
  return g/255.0;
}

float GLColorLegend::GetBlue(TColor c)
{
  TColor blue=0xFF0000;
  TColor b;
  b = (c & blue)>>16;
  return b/255.0;
}

bool GLColorLegend::operator==(GLColorLegend &leg)
{
  bool flag=true;

  flag = flag && NumberOfColor==leg.NumberOfColor;
  flag = flag && Color==leg.Color;
  flag = flag && Value==leg.Value;
  flag = flag && fabs(MinValue-leg.MinValue)<EPS;
  flag = flag && fabs(MaxValue-leg.MaxValue)<EPS;

  return flag;
}

bool GLColorLegend::operator!=(GLColorLegend &leg)
{
  return !operator==(leg);
}

GLColorLegend &GLColorLegend::operator=(GLColorLegend &leg)
{
  NumberOfColor=leg.NumberOfColor;
  Color=leg.Color;
  Value=leg.Value;
  MinValue=leg.MinValue;
  MaxValue=leg.MaxValue;

}

void GLColorLegend::DrawGL()
{
  glPushMatrix();
    glTranslatef(0,0,-1);
    glRasterPos2f(-0.4,0.35);
    Label.SetText("Moment");
//    Label.DrawGL2D();

  glPopMatrix();
}

//---------------------------------------------------------------------------
GLText::GLText()
{
  Font = NULL;
  Font2D = NULL;
}

GLText::~GLText()
{
  
}

void GLText::DrawGL()
{
  GLint  FaceMode;
  unsigned char *c=(unsigned char *)Text.c_str();
  int            Index,Length=strlen((char *)c);
  
  if ((Font==NULL)||(Length==0)) return;
  for (int i=0;i<Length;i++)
  {
   Index=c[i]- Font->FirstGylph;
   if ((Index<0)||(Index>Font->NumGylph-1)) return;
  }
  glPushMatrix();
    TranRot();
    glPushAttrib(GL_LIST_BIT);
    glGetIntegerv(GL_FRONT_FACE,&FaceMode);
    glListBase(Font->ListBase-Font->FirstGylph);
    glCallLists (Length, GL_UNSIGNED_BYTE,c);
    glFrontFace(FaceMode);
    glPopAttrib();
  glPopMatrix();
  return;
}

void GLText::DrawGL2D()
{
  unsigned char *c=(unsigned char *)Text.c_str();
  int            Index,Length=strlen((char *)c);

  if ((Font2D==NULL)||(Length==0)) return;
  for (int i=0;i<Length;i++)
  {
   Index=c[i]- Font2D->FirstGylph;
   if ((Index<0)||(Index>Font2D->NumGylph-1)) return;
  }
  glPushMatrix();
  glPushAttrib(GL_LIST_BIT);
  glListBase(Font2D->ListBase-Font2D->FirstGylph);
  glCallLists (Length, GL_UNSIGNED_BYTE,c);
  glPopAttrib();
  glPopMatrix();
  return;
}

//---------------------------------------------------------------------------
GLDim::GLDim()
{
  DimType = dtLine;
}

GLDim::GLDim(int )
{
  DimType = dtLine;
}

void GLDim::SetArrowHead(float ah)
{
  ArrowHead = ah;
  StartArrow.SetTopRad(ArrowHead/2.0);
  StartArrow.SetHeight(ah);
  EndArrow.SetTopRad(ArrowHead/2.0);
  EndArrow.SetHeight(ah);

  MkLine l;
  if (DimType==dtLine) {
    l.SetLine(DimLine[0],DimLine.GetDivision(0.1));
    StartArrow.SetLine(l);
    StartArrow.SetHeight(l.GetLength());
    l.SetLine(DimLine[1],DimLine.GetDivision(0.9));
    EndArrow.SetLine(l);
    EndArrow.SetHeight(l.GetLength());
  }
}

bool GLDim::operator==(GLDim &s)
{
  bool flag=true;
  flag = flag && (DimType == s.DimType);
  flag = flag && (DimLine == s.DimLine);
  flag = flag && (DimArc == s.DimArc);
  flag = flag && (DimPoly == s.DimPoly);
  flag = flag && (DimText == s.DimText);
  return flag;
}

bool GLDim::operator!=(GLDim &s)
{
  return !operator==(s);
}

GLDim &GLDim::operator=(GLDim &s)
{
  DimType = s.DimType;
  DimLine = s.DimLine;
  DimArc = s.DimArc;
  DimPoly = s.DimPoly;
  DimText = s.DimText;
  return *this;
}

void GLDim::DrawGL()
{
  glPushMatrix();
  TranRot();

  switch (DimType) {
    case dtLine : DrawLine(); break;
    case dtArc :  DrawArc();  break;
    case dtPolygon : DrawPoly(); break;
  }
  glPopMatrix();
  DimText.DrawGL();
}

void GLDim::DrawLine()
{
  MkLine l[3];
  static MkVector up(3);
  MkPoint p[2];

  up = GetUpVector();
  up.Normalize();

  l[0] = DimLine;

  p[0].SetPoint(l[0][0].X-ArrowHead*up[0],l[0][0].Y-ArrowHead*up[1],l[0][0].Z-ArrowHead*up[2]);
  p[1].SetPoint(l[0][0].X+ArrowHead*up[0],l[0][0].Y+ArrowHead*up[1],l[0][0].Z+ArrowHead*up[2]);
  l[1].SetLine(p[0],p[1]);

  p[0].SetPoint(l[0][1].X-ArrowHead*up[0],l[0][1].Y-ArrowHead*up[1],l[0][1].Z-ArrowHead*up[2]);
  p[1].SetPoint(l[0][1].X+ArrowHead*up[0],l[0][1].Y+ArrowHead*up[1],l[0][1].Z+ArrowHead*up[2]);
  l[2].SetLine(p[0],p[1]);

  glBegin(GL_LINES);
    glVertex3f(l[0][0].X,l[0][0].Y,l[0][0].Z);
    glVertex3f(l[0][1].X,l[0][1].Y,l[0][1].Z);
    glVertex3f(l[1][0].X,l[1][0].Y,l[1][0].Z);
    glVertex3f(l[1][1].X,l[1][1].Y,l[1][1].Z);
    glVertex3f(l[2][0].X,l[2][0].Y,l[2][0].Z);
    glVertex3f(l[2][1].X,l[2][1].Y,l[2][1].Z);
  glEnd();
  StartArrow.DrawGL();
  EndArrow.DrawGL();
}

void GLDim::DrawArc()
{

}

void GLDim::DrawPoly()
{

}

GLDims::GLDims(int size,GLDim *dims)
{
    if (size < 0) {
      MkDebug("::GLDims - GLDims(int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSize == 0) {
       FDim = NULL;
       return;
    }

    FDim = new GLDim[FSize];
    if(!FDim)
      for (int i=0;i<FSize;i++) FDim[i] = dims[i];
}

GLDims::GLDims(int size)
{
    if (size < 0) {
      MkDebug("::GLDims - GLDims(int size)");;
      return;
    }

    FSize = FSizeOfArray = size;

    if (FSizeOfArray == 0) {
       FDim = NULL;
       return;
    }

    FDim = new GLDim[FSizeOfArray];
}

GLDims::~GLDims()
{
   FSizeOfArray = FSize = 0;
   if (FDim) {
      delete[] FDim;
      FDim = NULL;
   }
}

void GLDims::Initialize(int size)
{
    if (size < 0) {
      MkDebug("::GLDims - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;

    FSize = FSizeOfArray = size;

    if (FSizeOfArray == 0) {
       if (FDim!=NULL) delete[] (GLDim*)FDim;
       FDim = NULL;
       return;
    }

    if (FDim!=NULL) delete[] (GLDim*)FDim;
    FDim = new GLDim[FSizeOfArray];
}

void GLDims::Initialize(int size,GLDim *dims)
{

    if (size < 0 || dims == NULL) {
      MkDebug("::GLDims - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSize = FSizeOfArray = size;
    if (FSizeOfArray == 0) {
       if (FDim!=NULL) delete[] (GLDim*)FDim;
       FDim = NULL;
       return;
    }

    if (FDim!=NULL) delete[] (GLDim*)FDim;
    FDim = new GLDim[FSizeOfArray];
    for (int i=0;i<FSizeOfArray;i++) FDim[i] = dims[i];
}

int GLDims::Grow(int delta)
{
    int i;
    GLDim *dim=NULL;

    if (!(dim = new GLDim[FSizeOfArray+delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        dim[i] = FDim[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        dim[i] = NullGLDim;
    if (FDim) {
       delete[] (GLDim*)FDim;
       FDim = NULL;
    }
    FDim = dim;
    FSizeOfArray = FSizeOfArray+delta;

    return FSizeOfArray;
}

int GLDims::Shrink(int delta)
{
    int i;
    GLDim *dim=NULL;

    if (!(dim = new GLDim[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        dim[i] = FDim[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        dim[i] = NullGLDim;
    if (FDim) {
       delete[] (GLDim*)FDim;
       FDim = NULL;
    }
    FDim = dim;
    FSizeOfArray = FSizeOfArray-delta;

    return FSizeOfArray;
}

bool GLDims::Add(GLDim &dim)
{
    int tmp=FSizeOfArray;
    bool flag=false;
    for (int i=0;i<FSize;i++) if (FDim[i]==dim) flag=true;

    if(flag) return false;
    if (FSize>=FSizeOfArray) {
       Grow(FSize-FSizeOfArray+10);
       if (tmp==FSizeOfArray) return false;
    }
    FSize++;
    FDim[FSize-1] = dim;

    return true;
}

bool GLDims::Delete(GLDim &dim)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FDim[i] == dim) break;
    }
    if(i==FSize) return false;
    if(FDim[i] == dim) {
      for (int j=i;j<FSize-1;j++)
        FDim[j] = FDim[j+1];
    }
    FSize--;
    FDim[FSize] = NullGLDim;
    return true;
}

bool GLDims::Clear()
{
   FSizeOfArray = FSize = 0;
   if (FDim) {
      delete[] FDim;
      FDim = NULL;
   }
   return true;
}

GLDim & GLDims::operator[](int i)
{
    if (FSizeOfArray == 0) return NullGLDim;
    if (i >= FSize && i < FSizeOfArray) FSize = i+1;

    if (i >=0 && i < FSize) return FDim[i];
    else return NullGLDim;
}

GLDims & GLDims::operator=(GLDims &dims)
{
    int i;

    Clear();
    FSize = dims.FSize;
    FSizeOfArray = dims.FSizeOfArray;
    if (FSize == 0) {
       FDim = NULL;
       return *this;
    }
    this->FDim = new GLDim[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FDim[i] = dims.FDim[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FDim[i] = NullGLDim;

    return *this;
}

bool GLDims::operator==(GLDims &dims)
{
  int i;

  if (FSize != dims.FSize) return false;
  for (i=0;i<FSize;i++)
    if (this->FDim[i] != dims.FDim[i]) return false;

  return true;
}

void GLDims::DrawModel()
{

}

void GLDims::DrawResult()
{

}
//---------------------------------------------------------------------------
GLEarthWall::GLEarthWall()
{
  Dis = 10;
  RotX = RotY = 0;

  DrawMode =dmModel;

  drawStratum=false;
  drawPiles=false;
  drawWales=false;
  drawStruts=false;
  drawAnchors=false;
  drawBolts=false;
  drawWalls=false;
  drawDeck=false;
  drawMainBeam=false;
  drawProps=false;
  drawPieceBracket=false;
  drawWater=false;
  drawLoads=false;
  drawDims=false;
}

GLEarthWall::GLEarthWall(int i)
{
  Dis = 10;
  RotX = RotY = 0;

  DrawMode =dmModel;

  drawStratum=false;
  drawPiles=false;
  drawWales=false;
  drawStruts=false;
  drawAnchors=false;
  drawBolts=false;
  drawWalls=false;
  drawDeck=false;
  drawMainBeam=false;
  drawProps=false;
  drawPieceBracket=false;
  drawWater=false;
  drawLoads=false;
  drawDims=false;
}

bool GLEarthWall::Initialize()
{
  int i,j;

  for(i=0;i<Wales.GetSize();i++) {
    for(j=0;j<Piles.GetSize();j++) {
      if(Wales[i].GetSide()==Piles[j].GetSide()) Wales[i].SetPile(Piles[j]);
    }
  }

  for(i=0;i<Anchors.GetSize();i++) {
    for(j=0;j<Wales.GetSize();j++) {
      if(Anchors[i].GetSide()==Wales[j].GetSide()) Anchors[i].SetWale(Wales[j]);
    }
  }

  for(i=0;i<Bolts.GetSize();i++) {
    for(j=0;j<Piles.GetSize();j++) {
      if(Bolts[i].GetSide()==Piles[j].GetSide()) Bolts[i].SetPile(Piles[j]);
    }
  }

  for(i=0;i<Walls.GetSize();i++) {
    for(j=0;j<Piles.GetSize();j++) {
      if(Walls[i].GetSide()==Piles[j].GetSide()) Walls[i].SetPile(Piles[j]);
    }
  }

  for(i=0;i<Props.GetSize();i++) {
    for(j=0;j<Wales.GetSize();j++) {
      if(Props[i].GetSide()==Wales[j].GetSide()) Props[i].SetWale(Wales[j]);
    }
  }
  for(i=0;i<Props.GetSize();i++) {
    Props[i].SetMainBeam(MainBeam);
  }

  for(i=0;i<PieceBracket.GetSize();i++) {
    for(j=0;j<Props.GetSize();j++) {
      if(PieceBracket[i].GetSide()==Props[j].GetSide()) PieceBracket[i].SetProp(Props[j]);
    }
  }

  Struts.SetWales(Wales);
  Deck.SetMainBeam(MainBeam);
  MainBeam.SetDeck(Deck);
  MainBeam.SetProps(Props);

}

void GLEarthWall::SetDrawMode(GLDrawMode &a)
{
  Stratum.SetDrawMode(a);
  Piles.SetDrawMode(a);
  Wales.SetDrawMode(a);
  Struts.SetDrawMode(a);
  Anchors.SetDrawMode(a);
  Bolts.SetDrawMode(a);
  Walls.SetDrawMode(a);
  Deck.SetDrawMode(a);
  MainBeam.SetDrawMode(a);
  Props.SetDrawMode(a);
  Water.SetDrawMode(a);
  Loads.SetDrawMode(a);
  Dims.SetDrawMode(a);
  DrawMode = a;
  PieceBracket.SetDrawMode(a);  
}

bool GLEarthWall::operator==(GLEarthWall &earthwall)
{
  bool flag = true;
  flag = flag && Stratum               == earthwall.Stratum;
  flag = flag && Piles                 == earthwall.Piles;
  flag = flag && Wales                 == earthwall.Wales;
  flag = flag && Struts                == earthwall.Struts;
  flag = flag && Anchors               == earthwall.Anchors;
  flag = flag && Bolts                 == earthwall.Bolts;
  flag = flag && Walls                 == earthwall.Walls;
  flag = flag && Deck                  == earthwall.Deck;
  flag = flag && MainBeam              == earthwall.MainBeam;
  flag = flag && Props                  == earthwall.Props;
  flag = flag && PieceBracket          == earthwall.PieceBracket;
  flag = flag && Water                 == earthwall.Water;
  flag = flag && Loads                 == earthwall.Loads;
  flag = flag && Dims                  == earthwall.Dims;
  flag = flag && DrawMode              == earthwall.DrawMode;
  flag = flag && LegendXDis            == earthwall.LegendXDis;
  flag = flag && LegendAngDis          == earthwall.LegendAngDis;
  flag = flag && LegendMoment          == earthwall.LegendMoment;
  flag = flag && LegendShear           == earthwall.LegendShear;
  flag = flag && LegendAxial           == earthwall.LegendAxial;
  flag = flag && LegendPress           == earthwall.LegendPress;
  flag = flag && Dis                   == earthwall.Dis;
  flag = flag && RotX                  == earthwall.RotX;
  flag = flag && RotY                  == earthwall.RotY;

  flag = flag && drawStratum           == earthwall.drawStratum;
  flag = flag && drawPiles             == earthwall.drawPiles;
  flag = flag && drawWales             == earthwall.drawWales;
  flag = flag && drawStruts            == earthwall.drawStruts;
  flag = flag && drawAnchors           == earthwall.drawAnchors;
  flag = flag && drawBolts             == earthwall.drawBolts;
  flag = flag && drawWalls             == earthwall.drawWalls;
  flag = flag && drawDeck              == earthwall.drawDeck;
  flag = flag && drawMainBeam          == earthwall.drawMainBeam;
  flag = flag && drawProps              == earthwall.drawProps;
  flag = flag && drawPieceBracket      == earthwall.drawPieceBracket;
  flag = flag && drawWater             == earthwall.drawWater;
  flag = flag && drawLoads             == earthwall.drawLoads;
  flag = flag && drawDims              == earthwall.drawDims;
  flag = flag && drawLegendXDis        == earthwall.drawLegendXDis;
  flag = flag && drawLegendAngDis      == earthwall.drawLegendAngDis;
  flag = flag && drawLegendMoment      == earthwall.drawLegendMoment;
  flag = flag && drawLegendShear       == earthwall.drawLegendShear;
  flag = flag && drawLegendAxial       == earthwall.drawLegendAxial;
  flag = flag && drawLegendPress       == earthwall.drawLegendPress;
}

bool GLEarthWall::operator!=(GLEarthWall &earthwall)
{
  return !operator==(earthwall);
}

GLEarthWall &GLEarthWall::operator=(GLEarthWall &earthwall)
{
  Stratum               = earthwall.Stratum;
  Piles                 = earthwall.Piles;
  Wales                 = earthwall.Wales;
  Struts                = earthwall.Struts;
  Anchors               = earthwall.Anchors;
  Bolts                 = earthwall.Bolts;
  Walls                 = earthwall.Walls;
  Deck                  = earthwall.Deck;
  MainBeam              = earthwall.MainBeam;
  Props                  = earthwall.Props;
  PieceBracket          = earthwall.PieceBracket;
  Water                 = earthwall.Water;
  Loads                 = earthwall.Loads;
  Dims                  = earthwall.Dims;
  DrawMode              = earthwall.DrawMode;
  LegendXDis            = earthwall.LegendXDis;
  LegendAngDis          = earthwall.LegendAngDis;
  LegendMoment          = earthwall.LegendMoment;
  LegendShear           = earthwall.LegendShear;
  LegendAxial           = earthwall.LegendAxial;
  LegendPress           = earthwall.LegendPress;
  Dis                   = earthwall.Dis;
  RotX                  = earthwall.RotX;
  RotY                  = earthwall.RotY;

  drawStratum           = earthwall.drawStratum;
  drawPiles             = earthwall.drawPiles;
  drawWales             = earthwall.drawWales;
  drawStruts            = earthwall.drawStruts;
  drawAnchors           = earthwall.drawAnchors;
  drawBolts             = earthwall.drawBolts;
  drawWalls             = earthwall.drawWalls;
//  drawRightWall         = earthwall.drawRightWall;
  drawDeck              = earthwall.drawDeck;
  drawMainBeam          = earthwall.drawMainBeam;
  drawProps             = earthwall.drawProps;
  drawPieceBracket      = earthwall.drawPieceBracket;
  drawWater             = earthwall.drawWater;
  drawLoads             = earthwall.drawLoads;
  drawDims              = earthwall.drawDims;
  drawLegendXDis        = earthwall.drawLegendXDis;
  drawLegendAngDis      = earthwall.drawLegendAngDis;
  drawLegendMoment      = earthwall.drawLegendMoment;
  drawLegendShear       = earthwall.drawLegendShear;
  drawLegendAxial       = earthwall.drawLegendAxial;
  drawLegendPress       = earthwall.drawLegendPress;
}

void GLEarthWall::DrawGL()
{
  if(DrawMode==dmModel) {
    if(drawStratum) Stratum.DrawGL();
    if(drawPiles) Piles.DrawGL();
    if(drawWales) Wales.DrawGL();
    if(drawStruts) Struts.DrawGL();
    if(drawAnchors) Anchors.DrawGL();
    if(drawBolts) Bolts.DrawGL();
    if(drawWalls) Walls.DrawGL();
    if(drawDeck) Deck.DrawGL();
    if(drawMainBeam) MainBeam.DrawGL();
    if(drawProps) Props.DrawGL();
    if(drawPieceBracket) PieceBracket.DrawGL();
    if(drawWater) Water.DrawGL();
    if(drawLoads) Loads.DrawGL();
    if(drawDims) Dims.DrawGL();
    if(drawLegendXDis) LegendXDis.DrawGL();
    if(drawLegendAngDis) LegendAngDis.DrawGL();
    if(drawLegendMoment) LegendMoment.DrawGL();
    if(drawLegendShear) LegendShear.DrawGL();
    if(drawLegendAxial) LegendAxial.DrawGL();
    if(drawLegendPress) LegendPress.DrawGL();
  }
  else {
    if(drawPiles) Piles.DrawGL();
  }
}

void GLEarthWall::DrawLegend()
{
  if(DrawMode==dmModel) return;
  switch(ResultType) {
    case resXDis: {
      LegendXDis.DrawGL();
      break;
    }
    case resAngDis: {
      LegendAngDis.DrawGL();
      break;
    }
    case resMoment: {
      LegendMoment.DrawGL();
      break;
    }
    case resShear: {
      LegendShear.DrawGL();
      break;
    }
    case resPress: {
      LegendAxial.DrawGL();
      break;
    }
    case resAxial: {
      LegendPress.DrawGL();
      break;
    }
  }
}

bool GLEarthWall::Import(MkGlobalVar &var,int sec)
{
  //suspend it for a while
  return true;
}

bool GLEarthWall::Import(MkSection &sec)
{
  EnableStratum(Stratum.Import(sec));  //GLStratum
  EnablePiles(Piles.Import(sec));  //GLSidePiles
  EnableWales(Wales.Import(sec)); //GLWales
  EnableStruts(Struts.Import(sec));  //GLStruts
  EnableAnchors(Anchors.Import(sec)); //GLAnchors
  EnableBolts(Bolts.Import(sec));  //GLRockBolts
  EnableWalls(Walls.Import(sec)); //GLWall
  EnableDeck(Deck.Import(sec));  //GLDeck
  EnableMainBeam(MainBeam.Import(sec)); //GLMainBeam
  EnableProps(Props.Import(sec)); //GLMainBeamProp
  EnablePieceBrackets(PieceBracket.Import(sec)); //GLPieceBracket
  EnableWater(Water.Import(sec));  //GLWater
  EnableLoads(Loads.Import(sec)); //GLLoads
//  Dims.Import(sec); //GLDims
//  DrawMode.Import(sec); //GLDrawMode
//  ResultType.Import(sec); //GLResultType
//  LegendXDis.Import(sec); //GLColorLegend
//  LegendAngDis.Import(sec); //GLColorLegend
//  LegendMoment.Import(sec); //GLColorLegend
//  LegendShear.Import(sec); //GLColorLegend
//  LegendAxial.Import(sec); //GLColorLegend
//  LegendPress.Import(sec); //GLColorLegend
  return true;
}

bool GLEarthWall::ClearMember()
{
  bool flag=true;
  flag = flag && Stratum.ClearMember();  //GLStratum
  flag = flag && Piles.ClearMember();  //GLSidePiles
  flag = flag && Wales.ClearMember(); //GLWales
  flag = flag && Struts.ClearMember();  //GLStruts
  flag = flag && Anchors.ClearMember(); //GLAnchors
  flag = flag && Bolts.ClearMember();  //GLRockBolts
  flag = flag && Walls.ClearMember(); //GLWall
  flag = flag && Deck.ClearMember();  //GLDeck
  flag = flag && MainBeam.ClearMember(); //GLMainBeam
  flag = flag && Props.ClearMember(); //GLMainBeamProp
  flag = flag && PieceBracket.ClearMember(); //GLPieceBracket
  flag = flag && Water.ClearMember();  //GLWater
  flag = flag && Loads.ClearMember(); //GLLoads
}
//---------------------------------------------------------------------------
GLEarthWalls::GLEarthWalls(int size,GLEarthWall *earthwalls)
{
    if (size < 0) {
      MkDebug("::GLEarthWalls - GLEarthWalls(int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSize == 0) {
       FEarthWall = NULL;
       return;
    }

    FEarthWall = new GLEarthWall[FSize];
    if(!FEarthWall)
      for (int i=0;i<FSize;i++) FEarthWall[i] = earthwalls[i];
}

GLEarthWalls::GLEarthWalls(int size)
{
    if (size < 0) {
      MkDebug("::GLEarthWalls - GLEarthWalls(int size)");;
      return;
    }

    FSize = FSizeOfArray = size;

    if (FSizeOfArray == 0) {
       FEarthWall = NULL;
       return;
    }

    FEarthWall = new GLEarthWall[FSizeOfArray];
}

GLEarthWalls::~GLEarthWalls()
{
   FSizeOfArray = FSize = 0;
   if (FEarthWall) {
      delete[] FEarthWall;
      FEarthWall = NULL;
   }
}

void GLEarthWalls::Initialize(int size)
{
    if (size < 0) {
      MkDebug("::GLEarthWalls - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;

    FSize = FSizeOfArray = size;

    if (FSizeOfArray == 0) {
       if (FEarthWall!=NULL) delete[] (GLEarthWall*)FEarthWall;
       FEarthWall = NULL;
       return;
    }

    if (FEarthWall!=NULL) delete[] (GLEarthWall*)FEarthWall;
    FEarthWall = new GLEarthWall[FSizeOfArray];
}

void GLEarthWalls::Initialize(int size,GLEarthWall *earthwalls)
{

    if (size < 0 || earthwalls == NULL) {
      MkDebug("::GLEarthWalls - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSize = FSizeOfArray = size;
    if (FSizeOfArray == 0) {
       if (FEarthWall!=NULL) delete[] (GLEarthWall*)FEarthWall;
       FEarthWall = NULL;
       return;
    }

    if (FEarthWall!=NULL) delete[] (GLEarthWall*)FEarthWall;
    FEarthWall = new GLEarthWall[FSizeOfArray];
    for (int i=0;i<FSizeOfArray;i++) FEarthWall[i] = earthwalls[i];
}

int GLEarthWalls::Grow(int delta)
{
    int i;
    GLEarthWall *earthwall=NULL;

    if (!(earthwall = new GLEarthWall[FSizeOfArray+delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        earthwall[i] = FEarthWall[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        earthwall[i] = NullGLEarthWall;
    if (FEarthWall) {
       delete[] (GLEarthWall*)FEarthWall;
       FEarthWall = NULL;
    }
    FEarthWall = earthwall;
    FSizeOfArray = FSizeOfArray+delta;

    return FSizeOfArray;
}

int GLEarthWalls::Shrink(int delta)
{
    int i;
    GLEarthWall *earthwall=NULL;

    if (!(earthwall = new GLEarthWall[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        earthwall[i] = FEarthWall[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        earthwall[i] = NullGLEarthWall;
    if (FEarthWall) {
       delete[] (GLEarthWall*)FEarthWall;
       FEarthWall = NULL;
    }
    FEarthWall = earthwall;
    FSizeOfArray = FSizeOfArray-delta;

    return FSizeOfArray;
}

bool GLEarthWalls::Add(GLEarthWall &earthwall)
{
    int tmp=FSizeOfArray;
    bool flag=false;
    for (int i=0;i<FSize;i++) if (FEarthWall[i]==earthwall) flag=true;

    if(flag) return false;
    if (FSize>=FSizeOfArray) {
       Grow(FSize-FSizeOfArray+10);
       if (tmp==FSizeOfArray) return false;
    }
    FSize++;
    FEarthWall[FSize-1] = earthwall;

    return true;
}

bool GLEarthWalls::Delete(GLEarthWall &earthwall)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FEarthWall[i] == earthwall) break;
    }
    if(i==FSize) return false;
    if(FEarthWall[i] == earthwall) {
      for (int j=i;j<FSize-1;j++)
        FEarthWall[j] = FEarthWall[j+1];
    }
    FSize--;
    FEarthWall[FSize] = NullGLEarthWall;
    return true;
}

bool GLEarthWalls::Clear()
{
   FSizeOfArray = FSize = 0;
   if (FEarthWall) {
      delete[] FEarthWall;
      FEarthWall = NULL;
   }
   return true;
}

GLEarthWall & GLEarthWalls::operator[](int i)
{
    if (FSizeOfArray == 0) return NullGLEarthWall;
    if (i >= FSize && i < FSizeOfArray) FSize = i+1;

    if (i >=0 && i < FSize) return FEarthWall[i];
    else return NullGLEarthWall;
}

GLEarthWalls & GLEarthWalls::operator=(GLEarthWalls &earthwalls)
{
    int i;

    Clear();
    FSize = earthwalls.FSize;
    FSizeOfArray = earthwalls.FSizeOfArray;
    if (FSize == 0) {
       FEarthWall = NULL;
       return *this;
    }
    this->FEarthWall = new GLEarthWall[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FEarthWall[i] = earthwalls.FEarthWall[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FEarthWall[i] = NullGLEarthWall;

    return *this;
}

bool GLEarthWalls::operator==(GLEarthWalls &earthwalls)
{
  int i;

  if (FSize != earthwalls.FSize) return false;
  for (i=0;i<FSize;i++)
    if (this->FEarthWall[i] != earthwalls.FEarthWall[i]) return false;

  return true;
}

bool GLEarthWalls::Import(MkGlobalVar &var)
{
  int i;
  Initialize(var.section_ea);
  for (i=0;i<FSize;i++) {
    FEarthWall[i].Import(var,i);
    FEarthWall[i].Initialize();
  }
  return true;
}

bool GLEarthWalls::Import(MkSections &sec)
{
  int i;
  Initialize(sec.GetSize());
  for (i=0;i<FSize;i++) {
    FEarthWall[i].Import(sec[i]);
    FEarthWall[i].Initialize();
  }
  return true;
}

bool GLEarthWalls::ClearMember()
{
  int i;
  bool flag=true;
  for (i=0;i<FSize;i++) {
    flag = flag && FEarthWall[i].ClearMember();
  }
  return flag;
}
//---------------------------------------------------------------------------

