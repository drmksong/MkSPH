//---------------------------------------------------------------------------
#include "MkSupport.h"
#ifdef __BCPLUSPLUS__
#include <vcl.h>
#pragma hdrstop
#endif
//---------------------------------------------------------------------------
#pragma package(smart_init)

MkSupport NullSupport(0);

MkSupport::MkSupport()
{
  Clear();
}

MkSupport::MkSupport(int)
{
  Clear();
}

void MkSupport::Clear()
{
  Tan = 0;
#ifdef __BCPLUSPLUS__
  type="";
#else 
  memset(type,'\0',255);
#endif
  side = mkLeft;
  tendonEA=0;
  depth=0;
  R_depth=0;
  var=0;
  freelen=0;
  sticklen=0;
  jackingforce=0;
  Wale.Clear();
}

#ifdef __BCPLUSPLUS__
AnsiString MkSupport::GetInfo()
{
  AnsiString Spec=Wale.walename; // for temporary
  if(type=="������") info = AnsiString(var)+" "+jackingforce+" "+Spec;
  else if(type=="��Ŀ") info = AnsiString(var)+" "+freelen+" "+sticklen+" "+jackingforce+" "+Spec+" "+tendonEA;
  else if(type=="�Ϻ�Ʈ") info = AnsiString(var)+" D"+freelen;
  return info;
}
#else
char* MkSupport::GetInfo()
{
  char Spec[256];
  strcpy(Spec,Wale.walename); // for temporary
  if(!strcmp(type,"������")) sprintf(info,"%f %f %s",var,jackingforce,Spec);
  else if(!strcmp(type,"��Ŀ")) sprintf(info,"%f %f %f %f %s %d",var,freelen,+sticklen,jackingforce,Spec,tendonEA);
  else if(!strcmp(type,"�Ϻ�Ʈ")) sprintf(info,"%f D %f",var,freelen);
  return info;
}
#endif
#ifdef __BCPLUSPLUS__
void MkSupport::Import(MkGlobalVar &globalvar, int sec, MkSide s, int tan) // tan is simple reference to see
{
  side = s;

  Tan=((side==mkLeft)?globalvar.support_tan_L[sec+1][tan+1]:globalvar.support_tan_R[sec+1][tan+1]);
  type=((side==mkLeft)?(LPCTSTR)globalvar.support_type_L[sec+1][tan+1]:(LPCTSTR)globalvar.support_type_R[sec+1][tan+1]);
  tendonEA=((side==mkLeft)?globalvar.support_tendonEA_L[sec+1][tan+1]:globalvar.support_tendonEA_R[sec+1][tan+1]);
  depth=((side==mkLeft)?globalvar.support_depth_L[sec+1][tan+1]:globalvar.support_depth_R[sec+1][tan+1]);
  R_depth=((side==mkLeft)?R_support_depth_L[sec+1][tan+1]:R_support_depth_R[sec+1][tan+1]);
  var=((side==mkLeft)?globalvar.support_var_L[sec+1][tan+1]:globalvar.support_var_R[sec+1][tan+1]);
  freelen=((side==mkLeft)?globalvar.support_freelen_L[sec+1][tan+1]:globalvar.support_freelen_R[sec+1][tan+1]);
  sticklen=((side==mkLeft)?globalvar.support_sticklen_L[sec+1][tan+1]:globalvar.support_sticklen_R[sec+1][tan+1]);
  jackingforce=((side==mkLeft)?globalvar.support_jackingforce_L[sec+1][tan+1]:globalvar.support_jackingforce_R[sec+1][tan+1]);
  Wale.SetMajorWale(MajorWale);
  Wale.Import(globalvar,sec,Tan);

  GetInfo();
}

void MkSupport::Export(MkGlobalVar &globalvar, int sec, MkSide s, int tan)
{
  side = s;
  ((side==mkLeft)?globalvar.support_tan_L[sec+1][tan+1]:globalvar.support_tan_R[sec+1][tan+1])=Tan;
  ((side==mkLeft)?globalvar.support_type_L[sec+1][tan+1]:globalvar.support_type_R[sec+1][tan+1])=type.c_str();
  ((side==mkLeft)?globalvar.support_tendonEA_L[sec+1][tan+1]:globalvar.support_tendonEA_R[sec+1][tan+1])=tendonEA;
  ((side==mkLeft)?globalvar.support_depth_L[sec+1][tan+1]:globalvar.support_depth_R[sec+1][tan+1])=depth;
  ((side==mkLeft)?R_support_depth_L[sec+1][tan+1]:R_support_depth_R[sec+1][tan+1])=R_depth;
  ((side==mkLeft)?globalvar.support_var_L[sec+1][tan+1]:globalvar.support_var_R[sec+1][tan+1])=var;
  ((side==mkLeft)?globalvar.support_freelen_L[sec+1][tan+1]:globalvar.support_freelen_R[sec+1][tan+1])=freelen;
  ((side==mkLeft)?globalvar.support_sticklen_L[sec+1][tan+1]:globalvar.support_sticklen_R[sec+1][tan+1])=sticklen;
  ((side==mkLeft)?globalvar.support_jackingforce_L[sec+1][tan+1]:globalvar.support_jackingforce_R[sec+1][tan+1])=jackingforce;
  Wale.Export(globalvar, sec, Tan);
}
#endif
bool MkSupport::operator==(MkSupport &spt)
{
  bool flag=true;
  flag = MkObject::operator==(spt);
  flag = flag && Tan==spt.Tan;
#ifdef __BCPLUSPLUS__
  flag = flag && type==spt.type;
#else
  flag = flag && !strcmp(type,spt.type);
#endif
  flag = flag && side==spt.side;
  flag = flag && tendonEA==spt.tendonEA;
  flag = flag && fabs(depth-spt.depth)<EPS;
  flag = flag && fabs(R_depth-spt.R_depth)<EPS;
  flag = flag && fabs(var-spt.var)<EPS;
  flag = flag && fabs(freelen-spt.freelen)<EPS;
  flag = flag && fabs(sticklen-spt.sticklen)<EPS;
  flag = flag && fabs(jackingforce-spt.jackingforce)<EPS;
  flag = flag && Wale==spt.Wale;
  return flag;
}

bool MkSupport::operator!=(MkSupport &spt)
{
  return !operator==(spt);
}

MkSupport &MkSupport::operator=(MkSupport &spt)
{
  MkObject::operator=(spt);
  Tan=spt.Tan;
#ifdef __BCPLUSPLUS__
  type=spt.type;
#else
  strcpy(type,spt.type);
#endif
  side=spt.side;
  tendonEA=spt.tendonEA;
  depth=spt.depth;
  R_depth=spt.R_depth;
  var=spt.var;
  freelen=spt.freelen;
  sticklen=spt.sticklen;
  jackingforce=spt.jackingforce;
  Wale = spt.Wale;
  return *this;
}
//---------------------------------------------------------------------------
MkSupports::MkSupports(int size,MkSupport *supports)
{
    if (size < 0) {
      MkDebug("::MkSupports - MkSupports(int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSize == 0) {
       FSupport = NULL;
       return;
    }

    FSupport = new MkSupport[FSize];
    for (int i=0;i<FSize;i++) (*this)[i] = supports[i];
}

MkSupports::MkSupports(int size)
{
    if (size < 0) {
      MkDebug("::MkSupports - MkSupports(int size)");;
      return;
    }

    FSize = FSizeOfArray = size;

    if (FSizeOfArray == 0) {
       FSupport = NULL;
       return;
    }

    FSupport = new MkSupport[FSizeOfArray];
}

MkSupports::~MkSupports()
{
   FSizeOfArray = FSize = 0;
   if (FSupport) {
      delete[] FSupport;
      FSupport = NULL;
   }
}

void MkSupports::Initialize(int size)
{
    int i;
    MkSupport *spt;

    if (FSizeOfArray == size) return;

    if(size==0) {
      Clear();
      return;
    }
    if (size < 0) {
      MkDebug("::MkSupports - Initialize(int size)");;
      return;
    }

    spt = new MkSupport[size];
    if(!spt) {
      MkDebug("::MkSupports - Initialize(int size) : Cannot allocate memory\n");;
      return;
    }

    for(i=0;i<min(size,FSize);i++) {
      spt[i] = FSupport[i];
    }

    for(i=FSize;i<size;i++) {
      spt[i] = NullSupport;
    }

    FSize = FSizeOfArray = size;

    if (FSupport!=NULL) {
      delete[] (MkSupport*)FSupport;
      FSupport = NULL;
    }
    FSupport = spt;
}

void MkSupports::Initialize(int size,MkSupport *supports)
{

    if (size < 0 || supports == NULL) {
      MkDebug("::MkSupports - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSize = FSizeOfArray = size;
    if (FSizeOfArray == 0) {
       if (FSupport!=NULL) delete[] (MkSupport*)FSupport;
       FSupport = NULL;
       return;
    }

    if (FSupport!=NULL) delete[] (MkSupport*)FSupport;
    FSupport = new MkSupport[FSizeOfArray];
    for (int i=0;i<FSizeOfArray;i++) FSupport[i] = supports[i];
}

int MkSupports::Grow(int delta)
{
    int i;
    MkSupport *support=NULL;

    if (!(support = new MkSupport[FSizeOfArray+delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        support[i] = FSupport[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        support[i] = NullSupport;
    if (FSupport) {
       delete[] (MkSupport*)FSupport;
       FSupport = NULL;
    }
    FSupport = support;
    FSizeOfArray = FSizeOfArray+delta;

    return FSizeOfArray;
}

int MkSupports::Shrink(int delta)
{
    int i;
    MkSupport *support=NULL;

    if (!(support = new MkSupport[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        support[i] = FSupport[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        support[i] = NullSupport;
    if (FSupport) {
       delete[] (MkSupport*)FSupport;
       FSupport = NULL;
    }
    FSupport = support;
    FSizeOfArray = FSizeOfArray-delta;

    return FSizeOfArray;
}

bool MkSupports::Add(MkSupport &support)
{
    int tmp=FSizeOfArray;
    bool flag=false;
    for (int i=0;i<FSize;i++) if (FSupport[i]==support) flag=true;

    if(flag) return false;
    if (FSize>=FSizeOfArray) {
       Grow(FSize-FSizeOfArray+10);
       if (tmp==FSizeOfArray) return false;
    }
    FSize++;
    FSupport[FSize-1] = support;

    return true;
}

bool MkSupports::Add(int index, MkSupport &support)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) Grow(FSize-FSizeOfArray+1);
    if(tmp==FSizeOfArray) return false;

    for (int i=FSize-1;i>=index;i--)
      FSupport[i+1] = FSupport[i];
    FSize++;
    FSupport[index] = support;
    return true;
}

bool MkSupports::Delete(MkSupport &support)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FSupport[i] == support) break;
    }
    if(i==FSize) return false;
    if(FSupport[i] == support) {
      for (int j=i;j<FSize-1;j++)
        FSupport[j] = FSupport[j+1];
    }
    FSize--;
    FSupport[FSize] = NullSupport;
    return true;
}

bool MkSupports::Delete(int index)
{
    for (int j=index;j<FSize-1;j++)
        FSupport[j] = FSupport[j+1];

    FSize--;
    FSupport[FSize] = NullSupport;
    return true;
}

bool MkSupports::Clear()
{
   FSizeOfArray = FSize = 0;
   if (FSupport) {
      delete[] FSupport;
      FSupport = NULL;
   }
   return true;
}

MkSupport & MkSupports::operator[](int i)
{
    if (FSizeOfArray == 0) return NullSupport;
    if (i >= FSize && i < FSizeOfArray) FSize = i+1;

    if (i >=0 && i < FSize) return FSupport[i];
    else return NullSupport;
}

MkSupports & MkSupports::operator=(MkSupports &supports)
{
    int i;

    Clear();
    FSize = supports.FSize;
    FSizeOfArray = supports.FSizeOfArray;
    if (FSize == 0) {
       FSupport = NULL;
       return *this;
    }
    this->FSupport = new MkSupport[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FSupport[i] = supports.FSupport[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FSupport[i] = NullSupport;

    return *this;
}

bool MkSupports::operator==(MkSupports &supports)
{
  int i;

  if (FSize != supports.FSize) return false;
  for (i=0;i<FSize;i++)
    if (this->FSupport[i] != supports.FSupport[i]) return false;

  return true;
}
#ifdef __BCPLUSPLUS__
void MkSupports::Import(MkGlobalVar &globalvar, int sec,MkSide side)
{
  int i;

  if(side==mkLeft) {
    Initialize(globalvar.supportdan_L[sec+1]);
  }
  else if(side==mkRight) {
    Initialize(globalvar.supportdan_R[sec+1]);
  }
  for(i=0;i<FSize && i<30;i++) {
    FSupport[i].SetMajorWale(MajorWale);
    FSupport[i].Import(globalvar,sec,side,i);
  }
}

void MkSupports::Export(MkGlobalVar &globalvar, int sec,MkSide side)
{
  int i;
  if (side==mkLeft) {
    globalvar.supportdan_L[sec+1] = FSize;
  }
  else {
    globalvar.supportdan_R[sec+1] = FSize;
  }
  for(i=0;i<FSize && i<30;i++) {
    FSupport[i].Export(globalvar,sec,side,i);
  }
}
#endif
void Swap(MkSupports &Supports, int i, int j)
{
  MkSupport s = Supports[i];
  Supports[i] = Supports[j];
  Supports[j] = s;
}

