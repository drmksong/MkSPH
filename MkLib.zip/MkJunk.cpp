//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#include <vcl.h>
#endif
#pragma hdrstop

#include "MkJunk.h"

//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#pragma package(smart_init)
#endif

MkJunk::MkJunk()
{
  Clear();
}

void MkJunk::Clear()
{
  exca_depth_L= exca_depth_R=0;
  ToptoGL = SidepileCTC = MidpileCTC = SideInsert = MidInsert=0;

  GL_R_minus_GL_L=0;
  DepthUnderDan=0;

  EarthPressType= HydPressType= WaterTabType=0;
  SubsidType= GrdType= NumMeas=0;
  ExcaWidth= IntFricAng=0;
  MeasValue.Clear();

  ImpearmUnitWeight= PearmUnitWeight= ImpearmThick= PearmThick= BotHead=0;
  ShearStrength= UnitWeightAboveDatum= HeightFromExcavLevel/*D*/= LongLen/*L*/=0;
  GeoType=0;
  TotalUnitWeight= SubUnitWeight= HeadGradient=0;
}

MkJunk &MkJunk::operator=(MkJunk &junk)
{
  exca_depth_L = junk.exca_depth_L;
  exca_depth_R = junk.exca_depth_R;
  //  R_exca_depth_L = junk.R_exca_depth_L;
  //  R_exca_depth_R = junk.R_exca_depth_R;
  ToptoGL = junk.ToptoGL;
  SidepileCTC = junk.SidepileCTC;
  MidpileCTC = junk.MidpileCTC;
  SideInsert = junk.SideInsert;
  MidInsert = junk.MidInsert;
  GL_R_minus_GL_L = junk.GL_R_minus_GL_L;

  EarthPressType = junk.EarthPressType;
  HydPressType = junk.HydPressType;
  WaterTabType = junk.WaterTabType;
  SubsidType = junk.SubsidType;
  GrdType = junk.GrdType;
  NumMeas = junk.NumMeas;
  ExcaWidth = junk.ExcaWidth;
  IntFricAng = junk.IntFricAng;
  MeasValue = junk.MeasValue;

  ImpearmUnitWeight = junk.ImpearmUnitWeight;
  PearmUnitWeight = junk.PearmUnitWeight;
  ImpearmThick = junk.ImpearmThick;
  PearmThick = junk.PearmThick;
  BotHead = junk.BotHead;
  ShearStrength = junk.ShearStrength;
  UnitWeightAboveDatum = junk.UnitWeightAboveDatum;
  HeightFromExcavLevel= junk.HeightFromExcavLevel; /*D*/
  LongLen = junk.LongLen; /*L*/
  GeoType = junk.GeoType;
  TotalUnitWeight = junk.TotalUnitWeight;
  SubUnitWeight = junk.SubUnitWeight;
  HeadGradient = junk.HeadGradient;
  return *this;
}
