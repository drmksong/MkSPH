//---------------------------------------------------------------------------
#pragma hdrstop

#include "stdafx.h"
#include "MkBeamSpring.h"

#ifdef __BCPLUSPLUS__
#include <vcl.h>
#endif

//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#pragma package(smart_init)
#endif
//--------------------------------------------------------------------
bool MkBeamSpring::Initialize()
{
  if(Initialized) return true;
  int nnode = NodeRef->GetSize();
  int nstep = MaxExcavStep+1;

  U.Initialize(nstep,nnode,2);
  Upl.Initialize(nstep,nnode,2);
  Upr.Initialize(nstep,nnode,2);
  Uyal.Initialize(nstep,nnode,2);
  Uypl.Initialize(nstep,nnode,2);
  Uyar.Initialize(nstep,nnode,2);
  Uypr.Initialize(nstep,nnode,2);
  Kl.Initialize(nstep,nnode,2);
  Kr.Initialize(nstep,nnode,2);
  Pol.Initialize(nstep,nnode,2);
  Por.Initialize(nstep,nnode,2);
  Pal.Initialize(nstep,nnode,2);
  Par.Initialize(nstep,nnode,2);
  Ppl.Initialize(nstep,nnode,2);
  Ppr.Initialize(nstep,nnode,2);
  Pl.Initialize(nstep,nnode,2);
  Pr.Initialize(nstep,nnode,2);
  Al.Initialize(nstep,nnode,2);
  Ar.Initialize(nstep,nnode,2);

  dU.Initialize(nnode,2);
  dUpl.Initialize(nnode,2);
  dUpr.Initialize(nnode,2);
  dKl.Initialize(nnode,2);
  dKr.Initialize(nnode,2);
  dPol.Initialize(nnode,2);
  dPor.Initialize(nnode,2);
  dPl.Initialize(nnode,2);
  dPr.Initialize(nnode,2);

  TotLeftEarthLoad.Initialize(nnode,2);  
  TotRightEarthLoad.Initialize(nnode,2); 
  LeftEarthLoad.Initialize(nnode,2);  
  RightEarthLoad.Initialize(nnode,2); 
  LeftEarthLu.Initialize(nnode,2);    
  RightEarthLu.Initialize(nnode,2);   
  LeftEarthLd.Initialize(nnode,2);    
  RightEarthLd.Initialize(nnode,2);   

  LeftHydLoad.Initialize(nnode,2);
  RightHydLoad.Initialize(nnode,2);

  LeftNodalKh.Initialize(nnode,2);
  RightNodalKh.Initialize(nnode,2);

  Initialized = true;

  return false;
}

void  MkBeamSpring::IniCurStepVariable()  // dU,dUpl,dUpr,dKl,dKr,dPol,dPor,dPl,dPr
{
  int i,k=CurStep;
  for(i=0;i<NodeRef->GetSize();i++) { // direction is opposite
    dU(i,0) = 0;dU(i,1) = 0;
    dUpl(i,0) = Upl(k,i,0)-(k>0)?Upl(k-1,i,0):0;
    dUpl(i,1) = Upl(k,i,1)-(k>0)?Upl(k-1,i,1):0;
    dUpr(i,0) = Upr(k,i,0)-(k>0)?Upr(k-1,i,0):0;
    dUpr(i,1) = Upr(k,i,1)-(k>0)?Upr(k-1,i,1):0;
    dKl(i,0) = (1-Al(k,i,0))*Kl(k,i,0)-(k>0)?(1-Al(k-1,i,0))*Kl(k-1,i,0):0;
    dKl(i,1) = (1-Al(k,i,1))*Kl(k,i,1)-(k>0)?(1-Al(k-1,i,1))*Kl(k-1,i,1):0;
    dKr(i,0) = (1-Ar(k,i,0))*Kr(k,i,0)-(k>0)?(1-Ar(k-1,i,0))*Kr(k-1,i,0):0;
    dKr(i,1) = (1-Ar(k,i,1))*Kr(k,i,1)-(k>0)?(1-Ar(k-1,i,1))*Kr(k-1,i,1):0;
    dPol(i,0) = (1-Al(k,i,0))*Pol(k,i,0)-(k>0)?(1-Al(k-1,i,0))*Pol(k-1,i,0):0;
    dPol(i,1) = (1-Al(k,i,1))*Pol(k,i,1)-(k>0)?(1-Al(k-1,i,1))*Pol(k-1,i,1):0;
    dPor(i,0) = (1-Ar(k,i,0))*Por(k,i,0)-(k>0)?(1-Ar(k-1,i,0))*Por(k-1,i,0):0;
    dPor(i,1) = (1-Ar(k,i,1))*Por(k,i,1)-(k>0)?(1-Ar(k-1,i,1))*Por(k-1,i,1):0;
    dPl(i,0) = Al(k,i,0)*Pl(k,i,0)-(k>0)?Al(k-1,i,0)*Pl(k-1,i,0):0;
    dPl(i,1) = Al(k,i,1)*Pl(k,i,1)-(k>0)?Al(k-1,i,1)*Pl(k-1,i,1):0;
    dPr(i,0) = Ar(k,i,0)*Pr(k,i,0)-(k>0)?Ar(k-1,i,0)*Pr(k-1,i,0):0;
    dPr(i,1) = Ar(k,i,1)*Pr(k,i,1)-(k>0)?Ar(k-1,i,1)*Pr(k-1,i,1):0;
  }
}

bool MkBeamSpring::Setup() // Build Stiff and matrix related variables
{
  int size;

  //  NodeRef->Apply(BndCond); // boundary condition should be applied in advance 
  Elements.SetupStiff();
//  Elements.SetupSubReact(Layers,NodalSubreact);

  Stiff.SetupMatrix(*NodeRef);
  Stiff.Assemble(Elements);

  size=Stiff.GetStiffMatrix().GetFI();
  if(Var.GetSize()!=size) Var.Initialize(size);
  if(RHS.GetSize()!=size) RHS.Initialize(size);
  return true;
}

bool MkBeamSpring::Clear()
{
  Initialized = false;

  TOL=0;
  Iter=0;
  MaxIter=0;
  CurStep=0;
  PrintStep=0;
  MaxExcavStep=0;
  memset(FileName,'\0',255);

  Stiff.Clear();
  Var.Clear();
  RHS.Clear();

  NodalResultant.Clear();  // used at CalcNodalResultant
  NodalPress.Clear(); // used at CalcNodalPress and CalcNodalPress2

  U.Clear();
  Upl.Clear();
  Upr.Clear();
  Uyal.Clear();
  Uypl.Clear();
  Uyar.Clear();
  Uypr.Clear();
  Kl.Clear();
  Kr.Clear();
  Pol.Clear();
  Por.Clear();
  Pal.Clear();
  Par.Clear();
  Ppl.Clear();
  Ppr.Clear();
  Pl.Clear();
  Pr.Clear();
  Al.Clear();
  Ar.Clear();

  dU.Clear();
  dUpl.Clear();
  dUpr.Clear();
  dKl.Clear();
  dKr.Clear();
  dPol.Clear();
  dPor.Clear();
  dPl.Clear();
  dPr.Clear();
}

bool MkBeamSpring::CalcDistLoad(MkRangeTree &range, MkPolygon &press, MkFloat &nodal)
{
  int i,j;
  float ymin,ymax;
  MkNode node[2];
  int nodenum[2];
  float aj,bj,lj,lj1,len;
  float f1,f2,f3,f4;
  MkPolygon poly;

  for(i=0;i<Elements.GetSize();i++) {
    if(!Elements[i].isBeamElement()) continue;
    MkBeamElement *beam = dynamic_cast<MkBeamElement*>(&Elements[i]);
    node[0] = Elements[i].GetElemNode(0);
    node[1] = Elements[i].GetElemNode(1);
    if(fabs(node[0].GetPoint().Y-node[1].GetPoint().Y)<EPS) continue;
    if(!range.Operate(node[0].GetPoint()) || !range.Operate(node[1].GetPoint())) continue;

    nodenum[0] = Elements[i].GetNodeNumber(0);
    nodenum[1] = Elements[i].GetNodeNumber(1);

    if(node[0].GetPoint().Y<node[1].GetPoint().Y) {
      Swap(node[0],node[1]);
      swap(nodenum[0],nodenum[1]);
    }

    ymin = node[0].GetPoint().Y;
    ymax = node[1].GetPoint().Y;
    len = fabs(ymax-ymin);
    if(ymin>ymax) swap(ymin,ymax);

    GetSubPolygon(ymin,ymax,press,poly);

    f1=f2=f3=f4=0; // element-wise integration of shape function...
    for(j=0;j<poly.GetSize();j++) {
      GetSubParam(j,poly,aj,bj,lj1,lj);
      f1 += ShapeFunInteg1(aj,bj,len,lj1,lj);
      f2 += ShapeFunInteg2(aj,bj,len,lj1,lj);
      f3 += ShapeFunInteg3(aj,bj,len,lj1,lj);
      f4 += ShapeFunInteg4(aj,bj,len,lj1,lj);
    }
    nodal(nodenum[0],0) -= f1;
    nodal(nodenum[0],1) -= f2;
    nodal(nodenum[1],0) -= f3;
    nodal(nodenum[1],1) -= f4;
    if(!beam) continue;
    beam->GetFixedEnd()[0] += f3;  // still I can not figure it out...!
    beam->GetFixedEnd()[5] += f4;  // I hope I can understand sometime later.
    beam->GetFixedEnd()[6] += f1;
    beam->GetFixedEnd()[11] += f2;      
  }
  return true;
}

bool MkBeamSpring::CalcEarthLoad(MkLoad *load)
{
  bool flag;
  MkPolygon *refpoly;

  flag = true;
  flag = flag && load->GetLoadType() != ltRankine;
  flag = flag && load->GetLoadType() != ltPointBackLoad;
  flag = flag && load->GetLoadType() != ltLineBackLoad;
  if (flag) return false;
  if (load->GetLoadType() == ltRankine) refpoly = &load->GetStaticPress();
  else if (load->GetLoadType() != ltPointBackLoad) refpoly = &load->GetBackLoad();
  else if (load->GetLoadType() != ltLineBackLoad) refpoly = &load->GetBackLoad();

  MkPolygon &press = *refpoly;

  if(load->GetDirection()[0]>0) flag = CalcDistLoad(load->GetRange(),press,LeftEarthLoad);
  else if(load->GetDirection()[0]<0) flag = CalcDistLoad(load->GetRange(),press,RightEarthLoad);
  return flag;
}

bool MkBeamSpring::CalcEarthLu(MkLoad *load)
{
  bool flag;
  MkPolygon *refpoly;

  flag = true;
  flag = flag && load->GetLoadType() != ltRankine;
  flag = flag && load->GetLoadType() != ltPointBackLoad;
  flag = flag && load->GetLoadType() != ltLineBackLoad;
  if (flag) return false;
  if (load->GetLoadType() == ltRankine) refpoly = &load->GetPassivPress();
  else if (load->GetLoadType() != ltPointBackLoad) refpoly = &load->GetBackLoad();
  else if (load->GetLoadType() != ltLineBackLoad) refpoly = &load->GetBackLoad();

  MkPolygon &press = *refpoly;

  if(load->GetDirection()[0]>0) flag = CalcDistLoad(load->GetRange(),press,LeftEarthLu);
  else if(load->GetDirection()[0]<0) flag = CalcDistLoad(load->GetRange(),press,RightEarthLu);
  return flag;
}

bool MkBeamSpring::CalcEarthLd(MkLoad *load)
{
  bool flag;
  MkPolygon *refpoly;

  flag = true;
  flag = flag && load->GetLoadType() != ltRankine;
  flag = flag && load->GetLoadType() != ltPointBackLoad;
  flag = flag && load->GetLoadType() != ltLineBackLoad;
  if (flag) return false;
  if (load->GetLoadType() == ltRankine) refpoly = &load->GetActivPress();
  else if (load->GetLoadType() != ltPointBackLoad) refpoly = &load->GetBackLoad();
  else if (load->GetLoadType() != ltLineBackLoad) refpoly = &load->GetBackLoad();

  MkPolygon &press = *refpoly;

  if(load->GetDirection()[0]>0) flag = CalcDistLoad(load->GetRange(),press,LeftEarthLd);
  else if(load->GetDirection()[0]<0) flag = CalcDistLoad(load->GetRange(),press,RightEarthLd);
  return flag;
}

bool MkBeamSpring::CalcHydLoad(MkLoad *load)
{
  bool flag;
  MkPolygon *refpoly;
  flag = true;
  flag = flag && load->GetLoadType() != ltStaticHydLoad;
  flag = flag && load->GetLoadType() != ltArbtrHydLoad;
  if (flag) return false;
  if (load->GetLoadType() != ltStaticHydLoad) refpoly = &load->GetWatPress();
  else if (load->GetLoadType() != ltArbtrHydLoad) refpoly = &load->GetWatPress();

  MkPolygon &press = *refpoly;

  if(load->GetDirection()[0]>0) flag = CalcDistLoad(load->GetRange(),press,LeftHydLoad);
  else if(load->GetDirection()[0]<0) flag = CalcDistLoad(load->GetRange(),press,RightHydLoad);
  return flag;
}

void MkBeamSpring::BuildActiveLoad() //Pal(-), Par(+)
{
  int i, k = CurStep;
  bool flag=true;

  if(LoadRef==NULL) {
    MkDebug("Load data is not assigned to this class");
    exit(-10);
  }

  MkLoads &load = *LoadRef;

  for(i=0;i<NodeRef->GetSize();i++) {
    LeftEarthLd(i,0) = 0;
    LeftEarthLd(i,1) = 0;
    RightEarthLd(i,0) = 0;
    RightEarthLd(i,1) = 0;
  }

  for(i=0;i<load.GetSize();i++) {
    flag = CalcEarthLd(&load[i]) && flag;
  }

  for(i=0;i<NodeRef->GetSize();i++) { // direction is opposite and cut for the tensional strength
    Pal(k,i,0) = (-LeftEarthLd(i,0)>0)?0:-LeftEarthLd(i,0);
    Pal(k,i,1) = (-LeftEarthLd(i,1)>0)?0:-LeftEarthLd(i,1);
    Par(k,i,0) = (-RightEarthLd(i,0)<0)?0:-RightEarthLd(i,0);
    Par(k,i,1) = (-RightEarthLd(i,1)<0)?0:-RightEarthLd(i,1);
  }
}

void MkBeamSpring::BuildPassiveLoad() // Ppl(-), Ppr(+)
{
  int i,k=CurStep;
  bool flag=true;

  if(LoadRef==NULL) {
    MkDebug("Load data is not assigned to this class");
    exit(-10);
  }

  MkLoads &load = *LoadRef;

  for(i=0;i<NodeRef->GetSize();i++) {
    LeftEarthLu(i,0) = 0;
    LeftEarthLu(i,1) = 0;
    RightEarthLu(i,0) = 0;
    RightEarthLu(i,1) = 0;
  }

  for(i=0;i<load.GetSize();i++) {
    flag = CalcEarthLu(&load[i]) && flag;
  }

  for(i=0;i<NodeRef->GetSize();i++) {
    Ppl(k,i,0) = -LeftEarthLu(i,0);
    Ppl(k,i,1) = -LeftEarthLu(i,1);
    Ppr(k,i,0) = -RightEarthLu(i,0);
    Ppr(k,i,1) = -RightEarthLu(i,1);
  }
}

void MkBeamSpring::BuildStaticLoad() // Pol(-), Por(+)
{
  int i,k=CurStep;
  bool flag=true;

  if(LoadRef==NULL) {
    MkDebug("Load data is not assigned to this class");
    exit(-10);
  }

  MkLoads &load = *LoadRef;

  for(i=0;i<NodeRef->GetSize();i++) {
    TotLeftEarthLoad(i,0) = 0;
    TotLeftEarthLoad(i,1) = 0;    
    LeftEarthLoad(i,0) = 0;
    LeftEarthLoad(i,1) = 0;
    TotRightEarthLoad(i,0) = 0;
    TotRightEarthLoad(i,1) = 0;
    RightEarthLoad(i,0) = 0;
    RightEarthLoad(i,1) = 0;
  }

  for(i=0;i<load.GetSize();i++) {
    flag = CalcEarthLoad(&load[i]) && flag;
  }

  for(i=0;i<NodeRef->GetSize();i++) {
    Pol(k,i,0) = -TotLeftEarthLoad(i,0);
    Pol(k,i,1) = -TotLeftEarthLoad(i,1);
    Por(k,i,0) = -TotRightEarthLoad(i,0);
    Por(k,i,1) = -TotRightEarthLoad(i,1);
  }
}

void MkBeamSpring::BuildSpring() // Kl(+), Kr(+)
{
  bool flag=true;
  int i,k=CurStep;

  if(SubRef==NULL) {
    MkDebug("Subreact data is not assigned to this class");
    exit(-10);
  }

  MkSubreacts &sub = *SubRef;

  for(int j=0;j<NodeRef->GetSize();j++) {
    LeftNodalKh(j,0) = 0;
    LeftNodalKh(j,1) = 0;
    RightNodalKh(j,0) = 0;
    RightNodalKh(j,1) = 0;
  }
  for (int i=0;i<sub.GetSize();i++)
    if(SpringType==stNodal) flag = ApplyNodal(sub[i]) && flag;
    else if(SpringType==stDistributal) flag = ApplyDistributal(sub[i]) && flag;

  for(i=0;i<NodeRef->GetSize();i++) {
    Kl(k,i,0) = LeftNodalKh(i,0); 
    Kl(k,i,1) = LeftNodalKh(i,1); 
    Kr(k,i,0) = RightNodalKh(i,0); 
    Kr(k,i,1) = RightNodalKh(i,1); 
  }
  //  return flag;
}

bool MkBeamSpring::ApplyNodal(MkSubreact &sub)
{

}

bool MkBeamSpring::ApplyDistributal(MkSubreact &sub)
{
  int i,j;
  float ymin,ymax;
  MkNode node[2];
  int nodenum[2];
  float aj,bj,lj,lj1,len;
  float f1,f2,f3,f4;
  MkPolygon poly;
  if(SubRef==NULL) return false;
  MkPolygon &subreact = sub.GetSubreact();

  for(i=0;i<Elements.GetSize();i++) {
    if(!Elements[i].isBeamElement()) continue;
    MkBeamElement *beam = dynamic_cast<MkBeamElement*>(&Elements[i]);
    node[0] = Elements[i].GetElemNode(0);
    node[1] = Elements[i].GetElemNode(1);
    if(fabs(node[0].GetPoint().Y-node[1].GetPoint().Y)<EPS) continue;
    if(!sub.isIn(node[0].GetPoint()) || !sub.isIn(node[1].GetPoint())) continue;

    nodenum[0] = Elements[i].GetNodeNumber(0);
    nodenum[1] = Elements[i].GetNodeNumber(1);

    if(node[0].GetPoint().Y<node[1].GetPoint().Y) {
      Swap(node[0],node[1]);
      swap(nodenum[0],nodenum[1]);
    }

    ymin = node[0].GetPoint().Y;
    ymax = node[1].GetPoint().Y;
    len = fabs(ymax-ymin);
    if(ymin>ymax) swap(ymin,ymax);

    GetSubPolygon(ymin,ymax,subreact,poly);

    f1=f2=f3=f4=0; // element-wise integration of shape function...
    for(j=0;j<poly.GetSize();j++) {
      GetSubParam(j,poly,aj,bj,lj1,lj);
      f1 += ShapeFunInteg1(aj,bj,len,lj1,lj);
      f2 += ShapeFunInteg2(aj,bj,len,lj1,lj);
      f3 += ShapeFunInteg3(aj,bj,len,lj1,lj);
      f4 += ShapeFunInteg4(aj,bj,len,lj1,lj);
    }
    if(sub.GetDirection()[0]<0) {
      RightNodalKh(nodenum[0],0) += fabs(f1);
      RightNodalKh(nodenum[0],1) += fabs(f2);
      RightNodalKh(nodenum[1],0) += fabs(f3);
      LeftNodalKh(nodenum[1],1) += fabs(f4); // it is because that right nodal kh is for positive angle,
    }
    else {
      LeftNodalKh(nodenum[0],0) += fabs(f1);
      LeftNodalKh(nodenum[0],1) += fabs(f2);
      LeftNodalKh(nodenum[1],0) += fabs(f3);
      RightNodalKh(nodenum[1],1) += fabs(f4); // and left nodal kh is for negative angle.
    }
    if(!beam) continue;
  }
  return true;
}

void MkBeamSpring::ApplySpring(MkMatrix &mat) // apply ground spring to system matrix 
{                                             // should be done for every iteration
  int i,j,k=CurStep,l,m,size;
  size = mat.GetFI();
  for(i=0;i<size;i++) {
    j=Stiff.GetSteer().Node(i);
    l=Stiff.GetSteer().NDof(i);
    m = ((*NodeRef)[j].GetDOFs()[l].GetDOFType()==doftXDis)?0:1; // for 2D xdis, zrot, need to be update if for 3D general model
    mat(i,i) += (1-Al(k,j,m))*Kl(k,j,m)+(1-Ar(k,j,m))*Kr(k,j,m);
  }
}

void MkBeamSpring::BuildPlasticLimit() // Uya(depends on the side), Uyp(depends on the side)
{
  int i,k=CurStep;
  for (i=0;i<NodeRef->GetSize();i++) {
    //I have to cosider the case that Kl & Kr equal zero.
    Uyal(k,i,0) = (fabs(Kl(k,i,0))<EPS)?0:(Pal(k,i,0)-Pol(k,i,0))/Kl(k,i,0)+Upl(k,i,0);
    Uyal(k,i,1) = (fabs(Kl(k,i,1))<EPS)?0:(Pal(k,i,1)-Pol(k,i,1))/Kl(k,i,1)+Upl(k,i,1); 
    Uyar(k,i,0) = (fabs(Kr(k,i,0))<EPS)?0:(Par(k,i,0)-Por(k,i,0))/Kr(k,i,0)+Upr(k,i,0);
    Uyar(k,i,1) = (fabs(Kr(k,i,1))<EPS)?0:(Par(k,i,1)-Por(k,i,1))/Kr(k,i,1)+Upr(k,i,1);

    Uypl(k,i,0) = (fabs(Kl(k,i,0))<EPS)?0:(Ppl(k,i,0)-Pol(k,i,0))/Kl(k,i,0)+Upl(k,i,0);
    Uypl(k,i,1) = (fabs(Kl(k,i,1))<EPS)?0:(Ppl(k,i,1)-Pol(k,i,1))/Kl(k,i,1)+Upl(k,i,1); 
    Uypr(k,i,0) = (fabs(Kr(k,i,0))<EPS)?0:(Ppr(k,i,0)-Por(k,i,0))/Kr(k,i,0)+Upr(k,i,0);
    Uypr(k,i,1) = (fabs(Kr(k,i,1))<EPS)?0:(Ppr(k,i,1)-Por(k,i,1))/Kr(k,i,1)+Upr(k,i,1);
  }
}

void MkBeamSpring::BuildPlasticIndicator() // Al, Ar indicator defines current state is elastic/plastic
{
  int i;
  int k=CurStep;
  for (i=0;i<NodeRef->GetSize();i++) {
    Al(k,i,0) = (U(k,i,0)>max(Uyal(k,i,0),Uypl(k,i,0)) || U(k,i,0)<min(Uyal(k,i,0),Uypl(k,i,0)))?1:0;
    Al(k,i,1) = (U(k,i,1)>max(Uyal(k,i,1),Uypl(k,i,1)) || U(k,i,1)<min(Uyal(k,i,1),Uypl(k,i,1)))?1:0;
    Ar(k,i,0) = (U(k,i,0)>max(Uyar(k,i,0),Uypr(k,i,0)) || U(k,i,0)<min(Uyar(k,i,0),Uypr(k,i,0)))?1:0;
    Ar(k,i,1) = (U(k,i,1)>max(Uyar(k,i,1),Uypr(k,i,1)) || U(k,i,1)<min(Uyar(k,i,1),Uypr(k,i,1)))?1:0;
  }
}

void MkBeamSpring::BuildPressureLimit()  // Pl, Pr pressure when it comes to plastic state
{
  int i;
  int k=CurStep;
  for (i=0;i<NodeRef->GetSize();i++) {
    Pl(k,i,0) = (U(k,i,0)>Uyal(k,i,0)) ? Pal(k,i,0) : ((U(k,i,0)<Uypl(k,i,0))?Ppl(k,i,0):0);
    Pl(k,i,1) = (U(k,i,1)>Uyal(k,i,1)) ? Pal(k,i,1) : ((U(k,i,1)<Uypl(k,i,1))?Ppl(k,i,1):0);
    Pr(k,i,0) = (U(k,i,0)>Uypr(k,i,0)) ? Ppr(k,i,0) : ((U(k,i,0)<Uyar(k,i,0))?Par(k,i,0):0);
    Pr(k,i,1) = (U(k,i,1)>Uypr(k,i,1)) ? Ppr(k,i,1) : ((U(k,i,1)<Uyar(k,i,1))?Par(k,i,1):0);
  }
}

void MkBeamSpring::UpdateStiff() // Stiffness matrix
{
    KM = Stiff.GetStiffMatrix();
    ApplySpring(KM);
}

void MkBeamSpring::UpdateDisplacement() // U
{
  int i;
  int k=CurStep;
  for (i=0;i<NodeRef->GetSize();i++) {
    U(k,i,0) = ((k>0) ? U(k-1,i,0):0) + dU(0);
    U(k,i,1) = ((k>0) ? U(k-1,i,1):0) + dU(1);
  }
}

void MkBeamSpring::UpdatePlasticLimit() // Pl,Pr
{
  // UpdateDisplacement() should be called in advance
  BuildPlasticLimit();
}

void MkBeamSpring::UpdatePlasticIndacator() // Al, Ar
{
  // UpdateDisplacement() should be called in advance
  BuildPlasticIndicator();
}

void MkBeamSpring::CurStepInit()
{
  BuildActiveLoad(); //Pal, Par
  BuildPassiveLoad(); // Ppl, Ppr
  BuildStaticLoad(); // Pol, Por
  BuildSpring(); // Kl, Kr
  BuildPlasticLimit(); // Uya, Uyp
  BuildPressureLimit();  // Pl, Pr
  BuildPlasticIndicator(); // Al, Ar
  UpdateStiff(); // Stiffness matrix
  IniCurStepVariable(); // dU,dUpl,dUpr,dKl,dKr,dPol,dPor,dPl,dPr
}

void MkBeamSpring::IterUpdate()
{
  int i,j,k=CurStep,l,m;
  int size = RHS.GetSize();

  UpdateDisplacement(); // U
  UpdatePlasticLimit(); // Pl,Pr
  UpdatePlasticIndacator(); // Al, Ar
  UpdateStiff(); // KM : system matrix (Beam Bending + Ground Spring)

  for (i=0;i<size;i++) {
    j=Stiff.GetSteer().Node(i);
    l=Stiff.GetSteer().NDof(i);
    m = ((*NodeRef)[j].GetDOFs()[l].GetDOFType()==doftXDis)?0:1; // for 2D xdis, zrot, need to be update if for 3D general model
    RHS(i) = (k>0)?-dKl(j,m)*(U(k-1,j,m)-Upl(k-1,j,m))-dKr(j,m)*(U(k-1,j,m)-Upr(k-1,j,m)):0
             -dPol(j,m)-dPor(j,m)-dPl(j,m)-dPr(j,m);
  }
}

bool MkBeamSpring::Out()
{
  FILE *fp=NULL;
  char str[256];
  static bool flag=false;
  int nnode,nelem,i,k=CurStep;
  memset(str,'\0',255);
  nnode = NodeRef->GetSize();
  nelem = Elements.GetSize();

  if(strlen(FileName)) {
    if(!flag) {
      fp = fopen(FileName,"w");
      if(!fp) return false;
      sprintf(str,"--------------BASIC OUTPUT-------------------\n");
      fputs(str,fp);
      sprintf(str,"- This is tempory outfile format to verify  -\n");
      fputs(str,fp);
      sprintf(str,"- the program logic and the results.        -\n");
      fputs(str,fp);
      sprintf(str,"- ESCOT(c)Copyright 2004, ESCO Eng. & Cons. -\n");
      fputs(str,fp);
      sprintf(str,"---------------------------------------------\n\n");
      fputs(str,fp);
    }
    else {
      fp = fopen(FileName,"a");
      if(!fp) return false;
    }

    sprintf(str,"STEP : %d\n\n",CurStep);
    fputs(str,fp);

    sprintf(str,"Node coordinate : number of node is %d\n", nnode);
    fputs(str,fp);
//               12345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890
    sprintf(str,"     node         x         y         z      disp    lload     rload    lstiff    rstiff\n");
    fputs(str,fp);

    for(i=0;i<nnode;i++) {
      sprintf(str,"%9d %9.3f %9.3f %9.3f %9.6f %9.6f %9.6f %9.6f %9.6f %9.3f %9.3f\n",
        i, (*NodeRef)[i].GetPoint().X, (*NodeRef)[i].GetPoint().Y,(*NodeRef)[i].GetPoint().Z,
        (*NodeRef)[i].GetXDis(),Pol(k,i,0),Por(k,i,1),Kl(k,i,0),Kr(k,i,1));
      fputs(str,fp);
    }

    sprintf(str,"\nElement : number of element is %d\n", nelem);
//    fputs(str,fp);

//                 12345678901234567890123456789012345678901234567890
    sprintf(str,"   element    node0     node1 \n");
//    fputs(str,fp);

    for(i=0;i<nelem;i++) {
      sprintf(str,"%10d %10d %10d\n", i, Elements[i].GetNodeNumber(0),Elements[i].GetNodeNumber(1));
//      fputs(str,fp);
    }
  }

#ifdef __BCPLUSPLUS___
  if(Memo) {
    sprintf(str,"STEP : %d\n\n",Step);
    Memo->Lines->Add(str);

//               123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890
    sprintf(str,"     node         x         y         z      disp    lpress    rpress     lload    rload\n");
    Memo->Lines->Add(str);

    for(int i=0;i<nnode;i++) {
      sprintf(str,"%9d %9.3f %9.3f %9.3f %9.6f %9.6f %9.6f %9.6f %9.6f\n",
        i, (*NodeRef)[i].GetPoint().X, (*NodeRef)[i].GetPoint().Y,(*NodeRef)[i].GetPoint().Z,
        (*NodeRef)[i].GetXDis(),NodalPress(i,0),NodalPress(i,1),
        NodalLoad(i,0),NodalLoad(i,1));
      Memo->Lines->Add(str);
    }

    sprintf(str,"\nElement : number of element is %d\n", nelem);
//    Memo->Lines->Add(str);

//               12345678901234567890123456789012345678901234567890
    sprintf(str,"   element    node0     node1 \n");
//    Memo->Lines->Add(str);

    for(int i=0;i<nelem;i++) {
      sprintf(str,"%10d %10d %10d\n", i, Elements[i].GetNodeNumber(0),Elements[i].GetNodeNumber(1));
//      Memo->Lines->Add(str);
    }
  }
#endif

  if(fp) fclose(fp);
  flag = true;
  return flag;
}

bool MkBeamSpring::CheckTol(MkVector &f, MkVector &b)
{
  bool flag;
  float q,w;
  int size=f.GetSize();
  if(size!=b.GetSize()) return false;
  flag = true;
  for (int i=0;i<size;i++) {
    q = f(i);
    w = b(i);
    if(fabs(q-w)>TOL) flag = false;
  }
  return flag;
}

bool MkBeamSpring::Post()
{

}

bool MkBeamSpring::Solve()
{
  static MkVector post;
  int i,j,k,size;
  Initialize(); // initialize all variables, for just once(except Clear is called)
  CurStepInit(); // initialize Up*,Uya,Uyp,K*,Po*,P*,A* for this excav. step  
  Setup(); // setup stiff. matrix
  Iter=0;

  do {
    post = Var;
    IterUpdate(); // update A*, P*, Stiff. matrix, RHS vector as the U* changed
    KM.Solve(Var,stHybrid);
    if(!(Iter%PrintStep)) Out();
    Iter++;
  } while(!CheckTol(post,Var) && Iter < MaxIter);

  Out();
  return true;
}
//---------------------------------------------------------------------------
