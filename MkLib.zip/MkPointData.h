//---------------------------------------------------------------------------
#ifndef MkPointDataH
#define MkPointDataH
#include <stdio.h>
#include <Math.h>
#include "MkMisc.h"
#include "MkPoint.h"
#include "MkFloat.h"
#include "MkCube.h"
#include "MkRailWay.h"
#include "MkFault.h"
#include "MkPlane.h"
#include "MkMatrix.h"

struct MkDataPoint : MkPoint {
public:
    float Data;

    __fastcall MkDataPoint();
    __fastcall MkDataPoint(float x,float y);
    __fastcall MkDataPoint(float x,float y,float z);

    MkDataPoint & __fastcall operator=(MkDataPoint rp);
    MkDataPoint & __fastcall operator=(MkPoint rp);
    MkDataPoint & __fastcall operator=(float data){Data = data;return *this;};
    void __fastcall operator+=(MkDataPoint &rp){X += rp.X;Y += rp.Y;Z+=rp.Z;}
    void __fastcall operator+=(float data){Data += data;}
    MkDataPoint __fastcall operator*(MkMatrix4 &rm);
    friend MkDataPoint __fastcall operator+(MkDataPoint a,MkDataPoint b)
            {MkDataPoint c;c.X = a.X + b.X;c.Y = a.Y + b.Y;return c;}
    bool __fastcall operator==(MkDataPoint);
    bool __fastcall operator!=(MkDataPoint);
};

class MkDataPoints {
protected:
    MkDataPoint *FPoint;
    int FSize;
    TColor Color;
public:
    __fastcall MkDataPoints(int size,MkDataPoint *rps);
    __fastcall MkDataPoints(int FSize);
    __fastcall MkDataPoints(){FSize = 0;FPoint = NULL;}
     __fastcall ~MkDataPoints();
    virtual void __fastcall Initialize(int size);
    virtual void __fastcall Initialize(int size,MkDataPoint *);
    int GetSize(){return FSize;};
    int GetNumber(){return FSize;};
    bool __fastcall Add(MkDataPoint point);
//    void __fastcall Delete(MkDataPoint point);
    void __fastcall Grow(int Delta);
//    __fastcall Shrink(int Delta);
    bool __fastcall Clear();
    TColor __fastcall GetColor(){return Color;};
    void __fastcall SetColor(TColor c){Color = c;}
    virtual MkDataPoint & __fastcall operator[](int);

    MkDataPoints & __fastcall operator*(MkMatrix4 &rm);

    MkDataPoints & __fastcall Translate(MkPoint rp);
    MkDataPoints & __fastcall Translate(MkDataPoint rp);
    MkDataPoints & __fastcall Translate(float x,float y,float z);
    MkDataPoints & __fastcall Rotate(float alpha, float beta, float gamma);
    MkDataPoints & __fastcall Scale(float sx,float sy, float sz);

    MkDataPoints & __fastcall operator=(MkDataPoints &points);
    bool __fastcall operator==(MkDataPoints &points);
    virtual void __fastcall Draw(TObject *);
};

extern MkDataPoint NullDataPoint;
extern MkDataPoints NullDataPoints;
//---------------------------------------------------------------------------
#endif
