//---------------------------------------------------------------------------
#ifndef MkAnalyticSectionH
#define MkAnalyticSectionH

#include "MkEntity.h"
#include "MkPile.h"
#include "MkStrut.h"
#include "MkBolt.h"
#include "MkAnchor.h"
#include "MkWale.h"
#include "MkRetainPanel.h"
#include "MkLayer.h"
#include "MkCut.h"
#include "MkFill.h"
#include "MkLoad.h"
#include "MkSubreact.h"
#include "MkAnalysis.h"
//---------------------------------------------------------------------------
class MkAnalyticSection {
protected:
  MkNodes *NodeRef;
  MkAnalyses Ana;
  MkPiles Piles;
  MkStruts Struts;
  MkBolts Bolts;
  MkAnchors Anchors;
  MkWales Wales;
  MkRetainPanels Panels;
  MkLayers Layers;
  MkCuts Cuts;
  MkFills Fills;
  MkLoads Loads;
  MkSubreacts Subreacts;
  MkNodalForce JackingForce;
  MkNodalForce IniForceCorrection;
  char FileName[256];
public: // constructor
  MkAnalyticSection();
  ~MkAnalyticSection();
public: // setting
  void SetFileName(char *fname){strcpy(FileName,fname);}
  void SetLayer(MkLayers &lay){Layers = lay;}
  void SetupLoad();
  void SetupSubreact();
  void SetPiles(MkPiles &pile){Piles = pile;}
  void SetStruts(MkStruts &strut){Struts = strut;}
  void SetBolts(MkBolts &bolt){Bolts = bolt;}
  void SetAnchors(MkAnchors &anchor){Anchors = anchor;}
  void SetCuts(MkCuts &cut){Cuts = cut;}
  void SetFills(MkFills &fill){Fills = fill;}
  void SetLoads(MkLoads &load){Loads = load;}
  void SetNodes(MkNodes &node){NodeRef = &node;}
public:// getting
  MkAnalyses &GetAnalysis(){return Ana;}
  //  float GetSpacing(){return Spacing;}
  MkPiles & GetPiles(){return Piles;}
  MkStruts & GetStruts(){return Struts;}
  MkBolts & GetBolts(){return Bolts;}
  MkAnchors & GetAnchors(){return Anchors;}
  MkCuts & GetCuts(){return Cuts;}
  MkFills & GetFills(){return Fills;}
  MkLoads &GetLoads(){return Loads;}
  MkSubreacts &GetSubreacts(){return Subreacts;}
  MkNodes &GetNodes(){return *NodeRef;}
public: //
  void AddAnalysis(MkAnalysisType at);
  void DelAnalysis(MkAnalysisType at);
public: //
  bool Initialize(MkLayers &);
  bool Install(MkStrut &);
  bool Install(MkAnchor &);
  bool Install(MkBolt &);
  bool Install(MkPile &);
  bool Install(MkStrut &,int div);
  bool Install(MkAnchor &,int div);
  bool Install(MkBolt &,int div);
  bool Install(MkPile &,int div);

  bool Uninstall(MkStrut &);
  bool Uninstall(MkAnchor &);
  bool Uninstall(MkBolt &);
  bool Uninstall(MkPile &);
  bool Initialize();
  bool Solve(MkAnalysisType at);
  void Clear(){} // not yet implemented!!
  void Out();
  void Out(char *fname);
  void OutLoad(char *fname);
  bool Apply(MkLoads &load);
  bool Apply(MkBndConds &bc){for (int i=0;i<Ana.GetSize();i++) Ana[i]->Apply(bc);return true;}
  
  bool operator==(MkAnalyticSection &);
  bool operator!=(MkAnalyticSection &);
  MkAnalyticSection& operator=(MkAnalyticSection &);

#ifdef __BCPLUSPLUS__
  void Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif

//------------------------------------------------ New functions
  void SetupAllNodes();
  bool InstallNew(MkStrut &);
  bool InstallNew(MkAnchor &);
  bool InstallNew(MkBolt &);
  bool InstallNew(MkPile &);
  bool UninstallNew(MkStrut &);
  bool UninstallNew(MkAnchor &);
  bool UninstallNew(MkBolt &);
  bool UninstallNew(MkPile &);
//------------------------------------------------ New functions
};
//---------------------------------------------------------------------------
#endif
