//---------------------------------------------------------------------------
#ifndef MkAnalysisH
#define MkAnalysisH
#include "MkEntity.h"
#include "MkMesh.h"
#include "MkDsgStd.h"
#include "MkLoad.h"
#include "MkStiff.h"
#include "MkSubreact.h"
#include "MkMatrix.h"
#include "MkNodalForce.h"
//---------------------------------------------------------------------------
enum MkAnalysisType {atBase=0, atMori, atBeamSpring, atSimpBeam, atContBeam, atFEA};
enum MkLoadingType {ltNodal, ltDistributal};
enum MkSpringType{stNodal, stDistributal};

class MkAnalysis {
protected: // General
#ifdef __BCPLUSPLUS__
  TMemo *Memo;
#endif
  char FileName[256];
  MkAnalysisType AnalysisType;
  //MaxStep : Maximum iteration
  //CurStep : Current ExcavStep
  //MaxExcavStep : Maximum Excav Step
  int MaxStep, CurStep, MaxExcavStep;
  int PrintStep;
  MkNodes *NodeRef;
  MkElements Elements;
  MkStiff Stiff;
  MkVector Var; // primary variable for solving, it is used only for showing, so useless.
  MkVector RHS; // initially it is right-hand side vector, but after the solve it contains the variable
  MkLines CheckLines;
  MkFloat WallResult; // wall(0) ,depth(1), displacement(2), earth pressure(3), shear force(4), moment(5) Result.Initialize(6,ndata);
  MkFloat AxialResult;//  
  MkLoadingType LoadingType;
  MkSpringType SpringType;
public: // Constructors
  MkAnalysis();
  MkAnalysis(int n);
  ~MkAnalysis(){}
public: // Key functions
  virtual bool Initialize(){MkDebug("MkAnalysis::Initialize is called.\n");return false;}
  virtual bool Setup(){MkDebug("MkAnalysis::Setup is called.\n");return false;}
  virtual bool Post(){MkDebug("MkAnalysis::Post is called.\n");return false;}
  virtual bool Out(){MkDebug("MkAnalysis::Out is called.\n");return false;}
  virtual bool Out(char *fname){MkDebug("MkAnalysis::Out is called.\n");return false;}
  virtual bool OutLoad(char *fname){MkDebug("MkAnalysis::OutLoad is called.\n");return false;}
  virtual bool Solve(){MkDebug("MkAnalysis::Solve is called.\n");return false;}
  virtual bool Apply(MkLayers &lay){MkDebug("MkAnalysis::Apply(MkLayers&) is called.\n");return false;}
  virtual bool Apply(MkStratum &stra){MkDebug("MkAnalysis::Apply(MkStratum&) is called.\n");return false;}
  virtual bool Apply(MkLoads &load){MkDebug("MkAnalysis::Apply(MkLoad&) is called.\n");return false;}
  virtual bool Apply(MkLoads &load,MkLayers &lay){MkDebug("MkAnalysis::Apply(MkLoad&, MkLayer &) is called.\n");return false;}
  virtual bool Apply(MkSubreact &sub){MkDebug("MkAnalysis::Apply(MkSubreacts&) is called.\n");return false;}  
  virtual bool Apply(MkSubreacts &sub){MkDebug("MkAnalysis::Apply(MkSubreact&) is called.\n");return false;}
  virtual bool Apply(MkBndConds &bc){
    MkDebug("MkAnalysis::Apply is performed\n");
    if(NodeRef->GetSize()) {
      MkDebug("MkAnalysis::Apply leaving\n");
      return NodeRef->Apply(bc);
    }
    else {
      MkDebug("MkAnalysis::Apply leaving\n");
      return false;
    }
  }
  virtual bool ApplyJackingForce(MkNodalForce &jack){return false;}
  virtual bool ApplyIniForceCorrect(MkNodalForce &ini){return false;}
  virtual bool Add(MkNodes &nodes){MkDebug("MkAnalysis::Add(Nodes) is called.\n");return NodeRef->Add(nodes);}
  bool Add(MkElements &elems);
  bool AddNew(MkElements &elems);
  bool Delete(MkElements &elems);
  bool Delete(MkElement &elem){return Elements.Delete(&elem);}
  bool CheckElements();

public:  // Setting functions
#ifdef __BCPLUSPLUS__
  void SetMemo(TMemo *memo){Memo = memo;}
#endif
  void SetFileName(char *fname){strcpy(FileName,fname);}
  void SetNodes(MkNodes &node){NodeRef = &node;}
  void SetElements(MkElements &elem){Elements = elem;Elements.SetNodes(*NodeRef);}
  void SetMaxStep(int m){MaxStep = m;}
  void SetCurStep(int s){CurStep = s;}
  void SetMaxExcavStep(int m){MaxExcavStep = m;}
  void SetPrintStep(int m){PrintStep = m;}
  void SetCheckLines(MkLines &l){CheckLines=l;}
  void SetLoadingType(MkLoadingType lt){LoadingType = lt;}
  void SetSpringType(MkSpringType st){SpringType = st;}
public:  // Getting information
  MkAnalysisType &GetAnalysisType(){return AnalysisType;}
  MkNodes &GetNodes(){return *NodeRef;}
  MkElements &GetElements(){return Elements;}
  virtual MkFloat & GetNodalDis(){static MkFloat a(1);a(0) = 0;return a;}
  virtual MkFloat & GetNodalLoad(){static MkFloat a(1);a(0) = 0;return a;}
  virtual MkFloat & GetNodalShear(){static MkFloat a(1);a(0) = 0;return a;}
  virtual MkFloat & GetNodalMom(){static MkFloat a(1);a(0) = 0;return a;}
  virtual MkFloat & GetNodalPress(){static MkFloat a(1);a(0) = 0;return a;}
  virtual MkFloat & GetNodalKh(){static MkFloat a(1);a(0) = 0;return a;}
  virtual MkFloat & GetWallResult(){return WallResult;}
  virtual MkFloat & GetAxialResult(){return AxialResult;}
  int GetMaxStep(){return MaxStep;}
  int GetCurStep(){return CurStep;}
  int GetMaxExcavStep(){return MaxExcavStep;}
  MkLoadingType GetLoadingType(){return LoadingType;}
  MkSpringType GetSpringType(){return SpringType;}
#ifdef __BCPLUSPLUS__
  AnsiString ClassName(){return AnsiString("MkAnalysis");}
#else
  char* ClassName(){return ("MkAnalysis");}
#endif

  bool operator==(MkAnalysis &);
  bool operator!=(MkAnalysis &);

public:  // misc
#ifdef __BCPLUSPLUS__
  void Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif
};

#include "MkBeamSpring.h"
#include "MkMori.h"
#include "MkContBeam.h"

class MkSimpAna : public MkAnalysis {
protected: // Simple method(MkHalfDist, MkLowDist, MkSimpBeam, MkContBeam)
  MkFloat Disp;
  MkFloat Moment;
public: // Simple method(MkHalfDist, MkLowDist, MkSimpBeam, MkContBeam)
  MkSimpAna();
  ~MkSimpAna();
public: // Setting functions

public:  // Getting information
#ifdef __BCPLUSPLUS__
  AnsiString ClassName(){return AnsiString("MkSimpAna");}
#else
  char* ClassName(){return ("MkSimpAna");}
#endif
};

class MkIterAna : public MkAnalysis {
protected: // Iteration method(MkBeamSpring, MkFEA, MkBEA)
  float TOL;
  int Step,MaxStep;
  int Iter,MaxIter;
  int PrintStep;
public: // Iteration method(MkBeamSpring, MkFEA, MkBEA)
  MkIterAna();
  ~MkIterAna();
public: // Setting functions
  void SetTol(float tol){TOL = tol;}
  void SetMaxIter(int mi){MaxIter = mi;}
  void SetPrintStep(int ps){PrintStep = ps;}

public:  // Getting information
#ifdef __BCPLUSPLUS__
  AnsiString ClassName(){return AnsiString("MkIterAna");}
#else
  char* ClassName(){return ("MkIterAna");}
#endif
};
//---------------------------------------------------------------------------
class MkAnalyses { // Analysis Container
protected:
  MkAnalysis **FAnalysis;
  int FSize;
#ifdef __BCPLUSPLUS__
  TColor Color;
#endif
public:
  MkAnalyses(int size,MkAnalysis **ana);
  MkAnalyses(){FSize = 0;FAnalysis = NULL;}
  ~MkAnalyses();
  void Initialize(int size);  
  void Initialize(int size,MkAnalysis **);
  bool Add(MkAnalysis *);
  bool Del(MkAnalysis *);
  int GetSize(){return FSize;};
  int GetNumber(){return FSize;};
  bool Clear();
  MkAnalyses & operator=(MkAnalyses &);
  MkAnalysis * operator[](int);
  bool operator==(MkAnalyses &);
  bool operator!=(MkAnalyses &);
#ifdef __BCPLUSPLUS__
  void Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif
};
//---------------------------------------------------------------------------
extern MkAnalysis NullAnalysis;
#endif
