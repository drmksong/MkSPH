//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#include <vcl.h>
#pragma hdrstop
#endif
#include "MkParseSunex.h"
//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#pragma package(smart_init)
#endif


MkSunexParser::MkSunexParser() : MkParser()
{
  SectionRef=NULL;
  KeyWord.Setup();
  CurState = 0;
}

MkSunexParser::~MkSunexParser() 
{

}

bool MkSunexParser::Parse()
{
  int limit=1000;
  MkKeyKind key;
  MkSunexKeyWord keyword;
  char str[512];
  char *res;

  if (!Open()) return false;
  while (!Eof() && (key!=kkEnd) && (limit>0) && str && res) {
    res = fgets(str,511,FP);
    if(keyword.IsKeyWord(str)) {
      key = keyword.GetKeyKind(str);
    }
    if(!ParseLine(str,key)) break;
    limit--;
  }
  Close();

  if (limit>999) return false;
  return true;
}

bool MkSunexParser::ParseLine(char *str, MkKeyKind key)
{
  char buf[256], *s, *p;
  MkKeyWord keyword;

  if(strlen(str)<1) return false;
  s = new char[256];
  memset(s,255,'\0');
  s = buf;
  TrimLeft(s,str);

  if(keyword.IsKeyWord(s)) {
    p = strchr(s,' ');
  }
  else p = s;

  if((p-s)>255) return false;

  switch(key) {
    case kkProject: return ParsePrj(p);
    case kkLayer: return ParseLay(p);
    case kkProfile: return ParsePrf(p);
    case kkWall: return ParseWall(p);
    case kkStrut: return ParseStrut(p);
    case kkAnchor: return ParseAnchor(p);
    case kkRockbolt: return ParseRockbolt(p);
    case kkSlab: return ParseSlab(p);
    case kkSlabWall: return ParseSlabWall(p);
    case kkDivision: return ParseDiv(p);
    case kkSolution: return ParseSol(p);
    case kkPoint: return ParsePnt(p);
    case kkNoEcho: return ParseNoEcho(p);
    case kkOutput: return ParseOut(p);
    case kkStep: return ParseStep(p);
    case kkEnd: return false;
  }
}

bool MkSunexParser::ParsePrj(char *str)
{
  if(!SectionRef) return false;
  //  SectionRef->projectcontent = str;
}

bool MkSunexParser::ParseLay(char *str)
{
  static int no=0;
  int nparam;
  char *s,*p;
  char name[256];
  float depth,gt,gsub,C_t,phi_t,Ks_t,C_b,phi_b,Ks_b;

  if(!SectionRef) return false;

  memset(name,'\0',255);
  nparam = 0;
  depth=gt=gsub=C_t=phi_t=Ks_t=C_b=phi_b=Ks_b=0;

  MkLayers &lay = SectionRef->GetLayers();

  nparam = NumOfParam(str);
  if(nparam<5) {
    sscanf(str,"%d",&no);
    TrimLeft(p,str);
    s = strchr(p,' ');
    strcpy(name,s);
    if(!lay.Grow(no-lay.GetSize()+1)) return false;
    lay[no].SetEntNum(no);
    lay[no].SetName(name);
  }
  else if(nparam==9) {
    if(no-lay.GetSize()+1<0) return false;
    sscanf(str,"%f %f %f %f %f %f %f %f %f",&depth,&gt,&gsub,&C_t,&phi_t,&Ks_t,&C_b,&phi_b,&Ks_b);

    lay[no].SetDepth(depth);
    lay[no].SetWetUnitWeight(0,gt);
    lay[no].SetSubUnitWeight(0,gsub);
    lay[no].SetCohesion(0,C_t);
    lay[no].SetFriction(0,phi_t);
    lay[no].SetHorSubReact(0,Ks_t);
    lay[no].SetVerSubReact(0,Ks_t);

    lay[no].SetWetUnitWeight(1,gt);
    lay[no].SetSubUnitWeight(1,gsub);
    lay[no].SetCohesion(1,C_b);
    lay[no].SetFriction(1,phi_b);
    lay[no].SetHorSubReact(1,Ks_b);
    lay[no].SetVerSubReact(1,Ks_b);
  }
  else if(nparam==8) {
    if(no-lay.GetSize()+1<0) return false;
    sscanf(str,"%f %f %f %f %f %f %f %f",&gt,&gsub,&C_t,&phi_t,&Ks_t,&C_b,&phi_b,&Ks_b);

    lay[no].SetWetUnitWeight(0,gt);
    lay[no].SetSubUnitWeight(0,gsub);
    lay[no].SetCohesion(0,C_t);
    lay[no].SetFriction(0,phi_t);
    lay[no].SetHorSubReact(0,Ks_t);
    lay[no].SetVerSubReact(0,Ks_t);

    lay[no].SetWetUnitWeight(1,gt);
    lay[no].SetSubUnitWeight(1,gsub);
    lay[no].SetCohesion(1,C_b);
    lay[no].SetFriction(1,phi_b);
    lay[no].SetHorSubReact(1,Ks_b);
    lay[no].SetVerSubReact(1,Ks_b);
  }
  else if(nparam==6) {
    if(no-lay.GetSize()+1<0) return false;
    sscanf(str,"%f %f %f %f %f %f",&depth,&gt,&gsub,&C_t,&phi_t,&Ks_t);

    lay[no].SetDepth(depth);
    lay[no].SetWetUnitWeight(0,gt);
    lay[no].SetSubUnitWeight(0,gsub);
    lay[no].SetCohesion(0,C_t);
    lay[no].SetFriction(0,phi_t);
    lay[no].SetHorSubReact(0,Ks_t);
    lay[no].SetVerSubReact(0,Ks_t);

    lay[no].SetWetUnitWeight(1,gt);
    lay[no].SetSubUnitWeight(1,gsub);
    lay[no].SetCohesion(1,C_t);
    lay[no].SetFriction(1,phi_t);
    lay[no].SetHorSubReact(1,Ks_t);
    lay[no].SetVerSubReact(1,Ks_t);
  }
  else if(nparam==5) {
    if(no-lay.GetSize()+1<0) return false;
    sscanf(str,"%f %f %f %f %f",&gt,&gsub,&C_t,&phi_t,&Ks_t);

    lay[no].SetWetUnitWeight(0,gt);
    lay[no].SetSubUnitWeight(0,gsub);
    lay[no].SetCohesion(0,C_t);
    lay[no].SetFriction(0,phi_t);
    lay[no].SetHorSubReact(0,Ks_t);
    lay[no].SetVerSubReact(0,Ks_t);

    lay[no].SetWetUnitWeight(1,gt);
    lay[no].SetSubUnitWeight(1,gsub);
    lay[no].SetCohesion(1,C_t);
    lay[no].SetFriction(1,phi_t);
    lay[no].SetHorSubReact(1,Ks_t);
    lay[no].SetVerSubReact(1,Ks_t);
  }
}

bool MkSunexParser::ParsePrf(char *str)
{
  int no, nparam, actside_no, passide_no;
  float depth;
  if(!SectionRef) return false;

  MkSunexProfiles &prf = SectionRef->GetSunexProfiles();
  nparam = NumOfParam(str);

  switch(nparam) {
    case 4:
      sscanf(str,"%d %f %d %d", &no, &depth, &actside_no, &passide_no);
      break;
    case 3:
      sscanf(str,"%d %f %d", &no, &depth, &actside_no);
      passide_no = actside_no;
      break;
  }

  if(!prf.Grow(no-prf.GetSize()+1)) return false;
  prf[no].SetEntNum(no);
  prf[no].SetDepth(depth);
  prf[no].SetActiveSoilNumber(actside_no);
  prf[no].SetPassiveSoilNumber(passide_no);
}

bool MkSunexParser::ParseWall(char *str)
{
  int no, nparam;
  float depth, area, i, e, space, pwidth, awidth, myield;
  if(!SectionRef) return false;

  MkPiles &pile = SectionRef->GetPiles();

  nparam = NumOfParam(str);
  switch(nparam) {
    case 9:
      sscanf(str,"%d %f %f %f %f %f %f %f %f", &no, &depth, &area, &i, &e, &space, &pwidth, &awidth, &myield);
      awidth = pwidth;
      break;
    case 8:
      sscanf(str,"%d %f %f %f %f %f %f %f", &no, &depth, &area, &i, &e, &space, &pwidth, &awidth);
      awidth = pwidth;
      myield = 0;
      break;
    case 7:
      sscanf(str,"%d %f %f %f %f %f %f", &no, &depth, &area, &i, &e, &space, &pwidth);
      awidth = pwidth;
      myield = 0;
      break;
    case 6:
      sscanf(str,"%d %f %f %f %f %f", &no, &depth, &area, &i, &e, &space);
      pwidth = 0.6;
      awidth = pwidth;
      myield = 0;
      break;
    case 5:
      sscanf(str,"%d %f %f %f %f", &no, &depth, &area, &i, &e);
      space = 1.0;
      pwidth = 0.6;
      awidth = pwidth;
      myield = 0;
      break;
  }

  if(!pile.Grow(no-pile.GetSize()+1)) return false;
  pile[no].SetEntNum(no);
  pile[no].SetDepth(depth);
  pile[no].SetArea(area);
  pile[no].SetSecMomentY(i);
  pile[no].SetSecMomentZ(i);
  pile[no].SetYoungMod(e);
  pile[no].SetSpacing(space);
  pile[no].SetActiveWidth(awidth);
  pile[no].SetPassiveWidth(pwidth);
  pile[no].SetYieldMom(myield);
}

bool MkSunexParser::ParseStrut(char *str)
{
  int no, nparam;
  float depth, area, length, space, pini, loss, dini;

  if(!SectionRef) return false;

  MkStruts &strut = SectionRef->GetStruts();

  nparam = NumOfParam(str);
  switch(nparam) {
    case 8:
      sscanf(str,"%d %f %f %f %f %f %f %f", &no, &depth, &area, &length, &space, &pini, &loss, &dini);
      break;
    case 7:
      sscanf(str,"%d %f %f %f %f %f %f", &no, &depth, &area, &length, &space, &pini, &loss);
      dini = 0;
      break;
    case 6:
      sscanf(str,"%d %f %f %f %f %f", &no, &depth, &area, &length, &space, &pini);
      loss = 0;
      dini = 0;
      break;
    case 5:
      sscanf(str,"%d %f %f %f %f", &no, &depth, &area, &length, &space);
      pini = 0;
      loss = 0;
      dini = 0;
      break;
    case 4:
      sscanf(str,"%d %f %f %f", &no, &depth, &area, &length);
      space = 1;
      pini = 0;
      loss = 0;
      dini = 0;
      break;
    case 3:
      sscanf(str,"%d %f %f", &no, &depth, &area);
      length = 10;
      space = 1;
      pini = 0;
      loss = 0;
      dini = 0;
      break;
  }

  if(!strut.Grow(no-strut.GetSize()+1)) return false;
  strut[no].SetEntNum(no);
  strut[no].SetDepth(depth);
  strut[no].SetArea(area);
  strut[no].SetLength(length);
  strut[no].SetSpacing(space);
  strut[no].SetJackingForce(pini);
  strut[no].SetStressLoss(loss);
  strut[no].SetIniDisp(dini);
}

bool MkSunexParser::ParseAnchor(char *str)
{
  int no, nparam;
  float depth, area, angle, length, space, pini, loss, dini;

  if(!SectionRef) return false;

  MkAnchors &anchor = SectionRef->GetAnchors();

  nparam = NumOfParam(str);
  switch(nparam) {
    case 9:
      sscanf(str,"%d %f %f %f %f %f %f %f %f", &no, &depth, &area, &angle, &length, &space, &pini, &loss, &dini);
      break;
    case 8:
      sscanf(str,"%d %f %f %f %f %f %f %f", &no, &depth, &area, &angle, &length, &space, &pini, &loss);
      dini = 0;
      break;
    case 7:
      sscanf(str,"%d %f %f %f %f %f %f", &no, &depth, &area, &angle, &length, &space, &pini);
      loss = 0;
      dini = 0;
      break;
    case 6:
      sscanf(str,"%d %f %f %f %f %f", &no, &depth, &area, &angle, &length, &space);
      pini = 0;
      loss = 0;
      dini = 0;
      break;
    case 5:
      sscanf(str,"%d %f %f %f %f", &no, &depth, &area, &angle, &length);
      space = 1;
      pini = 0;
      loss = 0;
      dini = 0;
      break;
    case 4:
      sscanf(str,"%d %f %f %f", &no, &depth, &area, &angle);
      length = 10;
      space = 1;
      pini = 0;
      loss = 0;
      dini = 0;
      break;
  }

  if(!anchor.Grow(no-anchor.GetSize()+1)) return false;
  anchor[no].SetEntNum(no);
  anchor[no].SetDepth(depth);
  anchor[no].SetArea(area);
  anchor[no].SetAngle(angle);
  anchor[no].SetFreeLength(length);
  anchor[no].SetSpacing(space);
  anchor[no].SetJackingForce(pini);
  anchor[no].SetTenLoss(loss);
  anchor[no].SetIniDis(dini);
}

bool MkSunexParser::ParseRockbolt(char *str)
{
  if(!SectionRef) return false;
}

bool MkSunexParser::ParseSlab(char *str)
{
  int no, nparam;
  float depth, thick, length, dini;

  if(!SectionRef) return false;

  MkSlabs &slab = SectionRef->GetSlabs();

  nparam = NumOfParam(str);
  switch(nparam) {
    case 5:
      sscanf(str,"%d %f %f %f %f", &no, &depth, &thick, &length, &dini);
      break;
    case 4:
      sscanf(str,"%d %f %f %f", &no, &depth, &thick, &length);
      dini = 0;
      break;
    case 3:
      sscanf(str,"%d %f %f", &no, &depth, &thick);
      dini = 0;
      length = 10;
      break;
  }

  if(!slab.Grow(no-slab.GetSize()+1)) return false;
  slab[no].SetEntNum(no);
  slab[no].SetDepth(depth);
  slab[no].SetThick(thick);
  slab[no].SetLength(length);
  slab[no].SetIniDis(dini);
}

bool MkSunexParser::ParseSlabWall(char *str)
{
  int no, nparam;
  float dtop, dbot, thick, myield;

  if(!SectionRef) return false;

  MkSlabWalls &slabwall = SectionRef->GetSlabWalls();

  nparam = NumOfParam(str);
  switch(nparam) {
    case 5:
      sscanf(str,"%d %f %f %f %f", &no, &dtop, &dbot, &thick, &myield);
      break;
  }

  if(!slabwall.Grow(no-slabwall.GetSize()+1)) return false;
  slabwall[no].SetEntNum(no);
  slabwall[no].SetDepthTop(dtop);
  slabwall[no].SetDepthBot(dbot);
  slabwall[no].SetThick(thick);
  slabwall[no].SetYieldMom(myield);
}

bool MkSunexParser::ParseDiv(char *str)
{
  float div;
  if(!SectionRef) return false;

  sscanf(str,"%f ",&div);
  SectionRef->SetSpacing(div);
}

bool MkSunexParser::ParseSol(char *str)
{
  int mode;
  if(!SectionRef) return false;

  sscanf(str,"%d ",&mode);
  SectionRef->SetSolMode(mode==0?smElastic:smPlastic);
}

bool MkSunexParser::ParsePnt(char *str)
{
  if(!SectionRef) return false;
}

bool MkSunexParser::ParseNoEcho(char *str)
{
  if(!SectionRef) return false;

  SectionRef->SetEcho(false);
}

bool MkSunexParser::ParseOut(char *str)
{
  if(!SectionRef) return false;
}

bool MkSunexParser::ParseStep(char *str)
{
  int limit=1000,nparam;
  MkKeyKind key;
  MkSunexKeyWord keyword;
  char str[512],dummy[256];
  char *res;

  nparam = NumOfParam(str);
  sscanf(str,"%s %d ", dummy,&CurStep);

  while (!Eof() && (key!=kkEnd) && (limit>0) && str && res) {
    res = fgets(str,511,FP);
    if(keyword.IsKeyWord(str)) {
      key = keyword.GetKeyKind(str);
    }
    if(key==kkStep) sscanf(str,"%s %d ", dummy,&CurStep);
    if(!ParseStepPart(str,key)) break;
    limit--;
  }

  if (limit>999) return false;
  return true;
}

bool MkSunexParser::ParseStepLine(char *str)
{
  if(!SectionRef) return false;

  char buf[256], *s, *p;
  MkKeyKind key;
  MkSunexKeyWord keyword;

  if(strlen(str)<1) return false;
  s = buf;
  TrimLeft(s,str);

  if(keyword.IsKeyWord(s)) {
    p = strchr(s,' ');
    key = keyword.GetKeyKind(s);
  }
  else p = s;

  if((p-s)>255) return false;

  switch(key) {
    case kkBottom: return ParseBot(p);
    case kkRankine: return ParseRankine(p);
    case kkPeck: return ParsePeck(p);
    case kkPeck1: return ParsePeck1(p);
    case kkEarthPress: return ParseEarthPress(p);
    case kkSlope: return ParseSlope(p);
    case kkProfileChange: return ParseProfile(p);
    case kkGWL: return ParseGWL(p);
    case kkWaterPress: return ParseWaterPress(p);
    case kkSurcharge: return ParseSurcharge(p);
    case kkLoad: return ParseLoad(p);
    case kkPress: return ParsePress(p);
    case kkMinAcive: return ParseMinAct(p);
    case kkExcav: return ParseExcav(p);
    case kkConst: return ParseConst(p);
    case kkRemove: return ParseRemove(p);
    case kkInsertCheck: return ParseInsertCheck(p);
    case kkIteration: return ParseInteration(p);
    case kkGroundSettle: return ParseGroundSettle(p);
    case kkSlip: return ParseSlip(p);
    case kkEnd: return false;
  }
}

bool MkSunexParser::ParseBot(char *str)
{
  if(!SectionRef) return false;
}

bool MkSunexParser::ParseRankine(char *str)
{
  if(!SectionRef) return false;
}

bool MkSunexParser::ParsePeck(char *str)
{
  if(!SectionRef) return false;
}

bool MkSunexParser::ParsePeck1(char *str)
{
  if(!SectionRef) return false;
}

bool MkSunexParser::ParseEarthPress(char *str)
{
  if(!SectionRef) return false;
}

bool MkSunexParser::ParseSlope(char *str)
{
  if(!SectionRef) return false;
}

bool MkSunexParser::ParseProfile(char *str)
{
  if(!SectionRef) return false;
}

bool MkSunexParser::ParseGWL(char *str)
{
  if(!SectionRef) return false;
}

bool MkSunexParser::ParseWaterPress(char *str)
{
  if(!SectionRef) return false;
}

bool MkSunexParser::ParseSurcharge(char *str)
{
  if(!SectionRef) return false;
}

bool MkSunexParser::ParseLoad(char *str)
{
  if(!SectionRef) return false;
}

bool MkSunexParser::ParsePress(char *str)
{
  if(!SectionRef) return false;
}

bool MkSunexParser::ParseMinAct(char *str)
{
  if(!SectionRef) return false;
}

bool MkSunexParser::ParseExcav(char *str)
{
  if(!SectionRef) return false;
}

bool MkSunexParser::ParseConst(char *str)
{
  if(!SectionRef) return false;
}

bool MkSunexParser::ParseRemove(char *str)
{
  if(!SectionRef) return false;
}

bool MkSunexParser::ParseInsertCheck(char *str)
{
  if(!SectionRef) return false;
}

bool MkSunexParser::ParseInteration(char *str)
{
  if(!SectionRef) return false;
}

bool MkSunexParser::ParseGroundSettle(char *str)
{
  if(!SectionRef) return false;
}

bool MkSunexParser::ParseSlip(char *str)
{
  if(!SectionRef) return false;
}
