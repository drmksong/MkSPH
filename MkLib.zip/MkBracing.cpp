//---------------------------------------------------------------------------
#include "MkBracing.h"
#ifdef __BCPLUSPLUS__
#include <vcl.h>
#endif
#pragma hdrstop
//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#pragma package(smart_init)
#endif
//---------------------------------------------------------------------------
MkBracing NullMkBracing(0);

MkBracings::MkBracings(int size,MkBracing *bracings)
{
  if (size < 0) {
    MkDebug("::MkBracings - MkBracings(int size)");;
    return;
  }

  FSizeOfArray = FSize = size;
  if (FSize == 0) {
     FBracing = NULL;
     return;
  }

  FBracing = new MkBracing[FSize];
  for (int i=0;i<FSize;i++) (*this)[i] = bracings[i];
}

MkBracings::MkBracings(int size)
{
  if (size < 0) {
    MkDebug("::MkBracings - MkBracings(int size)");;
    return;
  }

  FSize = FSizeOfArray = size;

  if (FSizeOfArray == 0) {
     FBracing = NULL;
     return;
  }

  FBracing = new MkBracing[FSizeOfArray];
}

MkBracings::~MkBracings()
{
  FSizeOfArray = FSize = 0;
  if (FBracing) {
     delete[] FBracing;
     FBracing = NULL;
  }
}

void MkBracings::Initialize(int size)
{
  if (size < 0) {
    MkDebug("::MkBracings - Initialize(int size)");;
    return;
  }
  if (FSizeOfArray == size) return;

  FSize = FSizeOfArray = size;

  if (FSizeOfArray == 0) {
     if (FBracing!=NULL) delete[] (MkBracing*)FBracing;
     FBracing = NULL;
     return;
  }

  if (FBracing!=NULL) delete[] (MkBracing*)FBracing;
  FBracing = new MkBracing[FSizeOfArray];
}

void MkBracings::Initialize(int size,MkBracing *bracings)
{

    if (size < 0 || bracings == NULL) {
      MkDebug("::MkBracings - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSize = FSizeOfArray = size;
    if (FSizeOfArray == 0) {
       if (FBracing!=NULL) delete[] (MkBracing*)FBracing;
       FBracing = NULL;
       return;
    }

    if (FBracing!=NULL) delete[] (MkBracing*)FBracing;
    FBracing = new MkBracing[FSizeOfArray];
    for (int i=0;i<FSizeOfArray;i++) FBracing[i] = bracings[i];
}

int MkBracings::Grow(int delta)
{
    int i;
    MkBracing *bracing=NULL;

    if (!(bracing = new MkBracing[FSizeOfArray+delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        bracing[i] = FBracing[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        bracing[i] = NullMkBracing;
    if (FBracing) {
       delete[] (MkBracing*)FBracing;
       FBracing = NULL;
    }
    FBracing = bracing;
    FSizeOfArray = FSizeOfArray+delta;

    return FSizeOfArray;
}

int MkBracings::Shrink(int delta)
{
    int i;
    MkBracing *bracing=NULL;

    if (!(bracing = new MkBracing[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        bracing[i] = FBracing[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        bracing[i] = NullMkBracing;
    if (FBracing) {
       delete[] (MkBracing*)FBracing;
       FBracing = NULL;
    }
    FBracing = bracing;
    FSizeOfArray = FSizeOfArray-delta;

    return FSizeOfArray;
}

bool MkBracings::Add(MkBracing &bracing)
{
    int tmp=FSizeOfArray;
    bool flag=false;
    for (int i=0;i<FSize;i++) if (FBracing[i]==bracing) flag=true;

    if(flag) return false;
    if (FSize>=FSizeOfArray) {
       Grow(FSize-FSizeOfArray+10);
       if (tmp==FSizeOfArray) return false;
    }
    FSize++;
    FBracing[FSize-1] = bracing;

    return true;
}

bool MkBracings::Add(int index, MkBracing &bracing)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) Grow(FSize-FSizeOfArray+1);
    if(tmp==FSizeOfArray) return false;

    for (int i=FSize-1;i>=index;i--)
      FBracing[i+1] = FBracing[i];
    FSize++;
    FBracing[index] = bracing;
    return true;
}

bool MkBracings::Delete(MkBracing &bracing)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FBracing[i] == bracing) break;
    }
    if(i==FSize) return false;
    if(FBracing[i] == bracing) {
      for (int j=i;j<FSize-1;j++)
        FBracing[j] = FBracing[j+1];
    }
    FSize--;
    FBracing[FSize] = NullMkBracing;
    return true;
}

bool MkBracings::Delete(int index)
{
    for (int j=index;j<FSize-1;j++)
        FBracing[j] = FBracing[j+1];

    FSize--;
    FBracing[FSize] = NullMkBracing;
    return true;
}

bool MkBracings::Clear()
{
   FSizeOfArray = FSize = 0;
   if (FBracing) {
      delete[] FBracing;
      FBracing = NULL;
   }
   return true;
}

MkBracing & MkBracings::operator[](int i)
{
    if (FSizeOfArray == 0) return NullMkBracing;
    if (i >= FSize && i < FSizeOfArray) FSize = i+1;

    if (i >=0 && i < FSize) return FBracing[i];
    else return NullMkBracing;
}

MkBracings & MkBracings::operator=(MkBracings &bracings)
{
    int i;

    Clear();
    FSize = bracings.FSize;
    FSizeOfArray = bracings.FSizeOfArray;
    if (FSize == 0) {
       FBracing = NULL;
       return *this;
    }
    this->FBracing = new MkBracing[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FBracing[i] = bracings.FBracing[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FBracing[i] = NullMkBracing;

    return *this;
}

bool MkBracings::operator==(MkBracings &bracings)
{
  int i;

  if (FSize != bracings.FSize) return false;
  for (i=0;i<FSize;i++)
    if (this->FBracing[i] != bracings.FBracing[i]) return false;

  return true;
}

#ifdef __BCPLUSPLUS__
void MkBracings::Import(MkGlobalVar &globalvar, int sec, int pilesec)
{
  int i;
  Initialize(globalvar.bracing_ea[sec+1][pilesec+1]);
  for (i=0;i<FSize && i<10;i++) {
    FBracing[i].len = globalvar.bracing_len[sec+1][pilesec+1][i+1];
  }
}

void MkBracings::Export(MkGlobalVar &globalvar, int sec, int pilesec)
{
  int i;
  for (i=0;i<FSize && i<10;i++) {
    globalvar.bracing_len[sec+1][pilesec+1][i+1] = FBracing[i].len ;
  }
}
#endif
