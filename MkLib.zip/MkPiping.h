#ifndef MkPipingH
#define MkPipingH
#include "MkMisc.h"

class MkPiping {
 protected:
  float Gamma, GammaWat, Iav;
  float B, H, D, Hw, K, Gamma1, Gamma2;
 public:
  MkPiping();
  ~MkPiping();
  void SetGamma(float g){Gamma = g;}
  void SetGammaWat(float g){GammaWat = g;}
  void SetIav(float i){Iav = i;}
  void SetB(float b){B = b;}
  void SetH(float h){H = h;}
  void SetD(float d){D = d;}
  void SetHw(float h){Hw = h;}
  void SetK(float k){K = k;}
  void SetGamma1(float g){Gamma1 = g;}
  void SetGamma2(float g){Gamma2 = g;}
  float GetFS();
};
#endif
