//---------------------------------------------------------------------------
#include "MkPile.h"
#ifdef __BCPLUSPLUS__
#include <vcl.h>
#endif
#pragma hdrstop
//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#pragma package(smart_init)
#endif
//---------------------------------------------------------------------------
MkPile NullPile(0);
MkPile::MkPile()
{
  Clear();
}

MkPile::MkPile(int n)
{
  Clear();
}

#ifdef __BCPLUSPLUS__
bool MkPile::UpdateFrom()
{
  if(!Grid) return false;

  Number          =Grid->Cells[1][0].ToInt();
  Division        =Grid->Cells[1][1].ToInt();
  Depth           =Grid->Cells[1][2].ToDouble();
  Area            =Grid->Cells[1][3].ToDouble();
  YoungMod        =Grid->Cells[1][4].ToDouble();
  ShearTor        =Grid->Cells[1][5].ToDouble();
  SecMomentY      =Grid->Cells[1][6].ToDouble();
  SecMomentZ      =Grid->Cells[1][7].ToDouble();
  YieldMom        =Grid->Cells[1][8].ToDouble();

  return true;
}
bool MkPile::UpdateTo()
{
  if(!Grid) return false;

  for(int i=0;i<20;i++) {Grid->Cells[0][i] = "";Grid->Cells[1][i]="";}

  Grid->Cells[0][0] = "Number";
  Grid->Cells[0][1] = "Division";
  Grid->Cells[0][2] = "Depth";
  Grid->Cells[0][3] = "Area";
  Grid->Cells[0][4] = "YoungMod";
  Grid->Cells[0][5] = "ShearTor";
  Grid->Cells[0][6] = "SecMomentY";
  Grid->Cells[0][7] = "SecMomentZ";
  Grid->Cells[0][8] = "YieldMom";

  Grid->Cells[1][0] = Number;
  Grid->Cells[1][1] = Division;
  Grid->Cells[1][2] = Depth;
  Grid->Cells[1][3] = Area;
  Grid->Cells[1][4] = YoungMod;
  Grid->Cells[1][5] = ShearTor;
  Grid->Cells[1][6] = SecMomentY;
  Grid->Cells[1][7] = SecMomentZ;
  Grid->Cells[1][8] = YieldMom;

  return true;
}

void MkPile::Out(TObject *Sender)
{

}
#else

#endif

void MkPile::Out(char *fname)
{
  FILE *fp;
  fp = fopen(fname,"a");
  if(!fp) {
    MkDebug(fname); MkDebug(" is not found, so fp is null and return false\n");
    return ;
  }
            //12345678901234567890123456789012345678901234567890123456789012345678901234567890
//fprintf(fp," V-Wall Depth    Area       I        E      Spacing\n");
//fprintf(fp,"   No.   (m)    (m2)      (m4)    (t/m2)     (m)  \n");
  fprintf(fp,"  %3d   %5.2g   %10g %10g %10g %5.2f\n",Number,Depth,Area,SecMomentZ,YoungMod*MPa2Tonf,Spacing);
  fprintf(fp,"               (%10g) (%10g) \n",Area/(Spacing>EPS?Spacing:1),SecMomentZ/(Spacing>EPS?Spacing:1));
  fprintf(fp,"\n");
  fclose(fp);
}

void MkPile::Clear()
{
  Number=0;
  Depth=0;
  PileLoc = plSide;
  SteelType = stHBEAM;
  Height=0;
  Width=0;
  T1=0;
  T2=0;         // tt1, tt2
  Area=0;
  AreaWeb=0; // AA, Aw

  Weight=0;
  SecCoeffY=0;
  SecCoeffZ=0;    // Section coefficient Zx, Zy
  SecMomentY=0;
  SecMomentZ=0;
  SecRadiusY=0;
  SecRadiusZ=0;  // second radius of inertia rx, ry

  YoungMod=0;
  Spacing=0;
  ShearTor=0;
  YieldMom=0;
  ActiveWidth=0;
  PassiveWidth=0;
}

#ifdef __BCPLUSPLUS__
void MkPile::Import(MkGlobalVar &globalvar, int sec)
{
  if(PileLoc==plSide && SteelType != stSHEETPILE) {
    Width=globalvar.sidepile_BB[sec+1];
    Height=globalvar.sidepile_HH[sec+1];
    T1=globalvar.sidepile_tt1[sec+1];
    T2=globalvar.sidepile_tt2[sec+1];
    Area=globalvar.sidepile_AA[sec+1];
    AreaWeb=globalvar.sidepile_Aw[sec+1];
    Weight=globalvar.sidepile_W[sec+1];
    SecCoeffY=globalvar.sidepile_Zx[sec+1];
    SecMomentY=globalvar.sidepile_Ix[sec+1];
    SecRadiusY=globalvar.sidepile_rx[sec+1];
    SecRadiusZ=globalvar.sidepile_ry[sec+1];
  }
  else if(PileLoc==plSide && SteelType == stSHEETPILE) {   // should be changed
    Width=globalvar.sheetpile_BB[sec+1];                  // because the meaning
    Height=globalvar.sheetpile_HH[sec+1];                 // of variable is different
    T1=globalvar.sheetpile_tt1[sec+1];
//    T2=globalvar.sheetpile_tt2[sec+1];
    Area=globalvar.sheetpile_AA[sec+1];
    AreaWeb=globalvar.sheetpile_Aw[sec+1];
    Weight=globalvar.sheetpile_W[sec+1];
    SecCoeffY=globalvar.sheetpile_Zx[sec+1];
//    SecMomentY=globalvar.sheetpile_Ix[sec+1];
//    SecRadiusY=globalvar.sheetpile_rx[sec+1];
//    SecRadiusZ=globalvar.sheetpile_ry[sec+1];
  }
  else if(PileLoc==plMid) {
    Width=globalvar.midpile_BB[sec+1];
    Height=globalvar.midpile_HH[sec+1];
    T1=globalvar.midpile_tt1[sec+1];
    T2=globalvar.midpile_tt2[sec+1];
    Area=globalvar.midpile_AA[sec+1];
    AreaWeb=globalvar.midpile_Aw[sec+1];
    Weight=globalvar.midpile_W[sec+1];
    SecCoeffY=globalvar.midpile_Zx[sec+1];
    SecMomentY=globalvar.midpile_Ix[sec+1];
    SecRadiusY=globalvar.midpile_rx[sec+1];
    SecRadiusZ=globalvar.midpile_ry[sec+1];
  }
}

void MkPile::Export(MkGlobalVar &globalvar, int sec)
{
  if(PileLoc==plSide && SteelType != stSHEETPILE) {
    globalvar.sidepile_BB[sec+1] =Width;
    globalvar.sidepile_HH[sec+1] =Height;
    globalvar.sidepile_tt1[sec+1]=T1;
    globalvar.sidepile_tt2[sec+1]=T2;
    globalvar.sidepile_AA[sec+1] =Area;
    globalvar.sidepile_Aw[sec+1] =AreaWeb;
    globalvar.sidepile_W[sec+1]  =Weight;
    globalvar.sidepile_Zx[sec+1] =SecCoeffY;
    globalvar.sidepile_Ix[sec+1] =SecMomentY;
    globalvar.sidepile_rx[sec+1] =SecRadiusY;
    globalvar.sidepile_ry[sec+1] =SecRadiusZ;
  }
  else if(PileLoc==plSide && SteelType == stSHEETPILE) {
    globalvar.sheetpile_BB[sec+1] =Width;
    globalvar.sheetpile_HH[sec+1] =Height;
    globalvar.sheetpile_tt1[sec+1]=T1;
//    globalvar.sheetpile_tt2[sec+1]=T2;
    globalvar.sheetpile_AA[sec+1] =Area;
    globalvar.sheetpile_Aw[sec+1] =AreaWeb;
    globalvar.sheetpile_W[sec+1]  =Weight ;
//    globalvar.sheetpile_Zx[sec+1] =SecCoeffY;
//    globalvar.sheetpile_Ix[sec+1] =SecMomentY;
//    globalvar.sheetpile_rx[sec+1] =SecRadiusY;
//    globalvar.sheetpile_ry[sec+1] =SecRadiusZ;
  }
  else if(PileLoc==plMid) {
    globalvar.midpile_BB[sec+1]=Width;
    globalvar.midpile_HH[sec+1]=Height;
    globalvar.midpile_tt1[sec+1]=T1;
    globalvar.midpile_tt2[sec+1]=T2;
    globalvar.midpile_AA[sec+1]=Area;
    globalvar.midpile_Aw[sec+1]=AreaWeb;
    globalvar.midpile_W[sec+1]=Weight;
    globalvar.midpile_Zx[sec+1]=SecCoeffY;
    globalvar.midpile_Ix[sec+1]=SecMomentY;
    globalvar.midpile_rx[sec+1]=SecRadiusY;
    globalvar.midpile_ry[sec+1]=SecRadiusZ;
  }
}
#endif

void MkPile::SetBeam(MkBeam beam)
{
  SetSteelType(beam.SteelType);
  SetHeight(beam.HH);
  SetWidth(beam.BB);
  SetT1(beam.tt1);
  SetT2(beam.tt2);
  SetArea(beam.AA);
  SetAreaWeb(beam.Aw);
  SetWeight(beam.W);
  SetSecCoeffY(beam.Zx);
  SetSecCoeffZ(beam.Zx);
  SetSecMomentY(beam.Ix);
  SetSecMomentZ(beam.Ix);
  SetSecRadiusY(beam.rx);
  SetSecRadiusZ(beam.ry);
}

bool MkPile::operator==(MkPile &pile)
{
  bool flag = true;
  flag = flag && MkWall::operator==((MkWall&)pile);
  flag = flag && Depth==pile.Depth;
  flag = flag && PileLoc == pile.PileLoc;
  flag = flag && SteelType == pile.SteelType;
  flag = flag && Height==pile.Height; // H
  flag = flag && Width==pile.Width;  // B
  flag = flag && T1==pile.T1;
  flag = flag && T2==pile.T2;

  flag = flag && Area==pile.Area;
  flag = flag && AreaWeb==pile.AreaWeb;
  flag = flag && Weight==pile.Weight;
  flag = flag && SecCoeffY==pile.SecCoeffY;
  flag = flag && SecCoeffZ==pile.SecCoeffZ;
  flag = flag && SecMomentY==pile.SecMomentY;
  flag = flag && SecMomentZ==pile.SecMomentZ;

  flag = flag && YoungMod==pile.YoungMod;
  flag = flag && Spacing==pile.Spacing;
  flag = flag && ShearTor==pile.ShearTor;
  flag = flag && YieldMom==pile.YieldMom;
  flag = flag && ActiveWidth==pile.ActiveWidth;
  flag = flag && PassiveWidth==pile.PassiveWidth;

  return flag;
}

bool MkPile::operator!=(MkPile &pile)
{
  return !operator==(pile);
}

MkPile& MkPile::operator=(MkPile& pile)
{
  MkWall::operator=((MkWall&)pile);
  Depth=pile.Depth;
  PileLoc = pile.PileLoc;
  SteelType = pile.SteelType;
  Height=pile.Height; // H
  Width=pile.Width;  // B
  T1=pile.T1;
  T2=pile.T2;
  Area=pile.Area;
  AreaWeb=pile.AreaWeb;
  Weight=pile.Weight;
  SecCoeffY=pile.SecCoeffY;
  SecCoeffZ=pile.SecCoeffZ;
  SecMomentY=pile.SecMomentY;
  SecMomentZ=pile.SecMomentZ;
  SecRadiusY=pile.SecRadiusY;
  SecRadiusZ=pile.SecRadiusZ;

  YoungMod=pile.YoungMod;
  Spacing=pile.Spacing;
  ShearTor=pile.ShearTor;
  YieldMom=pile.YieldMom;
  ActiveWidth=pile.ActiveWidth;
  PassiveWidth=pile.PassiveWidth;

  return *this;
}

#ifdef __BCPLUSPLUS__
void  MkPile::Draw(TObject *Sender)
{
  Wall.Draw(Sender);
}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void  MkPile::Draw(MkPaint *pb)
{
  Wall.Draw(pb);
}
#endif
//---------------------------------------------------------------------------
MkPiles::MkPiles(int size,MkPile *piles)
{
    if (size < 0) {
      MkDebug("::MkPiles - MkPiles(int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSize == 0) {
       FPile = NULL;
       return;
    }

    FPile = new MkPile[FSize];
    for (int i=0;i<FSize;i++) (*this)[i] = piles[i];
}

MkPiles::MkPiles(int size)
{
    if (size < 0) {
      MkDebug("::MkPiles - MkPiles(int size)");;
      return;
    }

    FSizeOfArray = size;
    FSize = 0;
    if (FSizeOfArray == 0) {
       FPile = NULL;
       return;
    }

    FPile = new MkPile[FSizeOfArray];
}

MkPiles::~MkPiles()
{
   FSizeOfArray = FSize = 0;
   if (FPile) {
      delete[] FPile;
      FPile = NULL;
   }
}

void MkPiles::Initialize(int size)
{
    int i;
    if (size < 0) {
      MkDebug("::MkPiles - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;

    FSizeOfArray = FSize =size;

    if (FSizeOfArray == 0) {
       if (FPile!=NULL) delete[] (MkPile*)FPile;
       FPile = NULL;
       return;
    }

    if (FPile!=NULL) delete[] (MkPile*)FPile;
    FPile = new MkPile[FSizeOfArray];
    for (i=0;i<FSize;i++) FPile[i].Number = i;
}

void MkPiles::Initialize(int size,MkPile *piles)
{
    int i;
    if (size < 0 || piles == NULL) {
      MkDebug("::MkPiles - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSize = FSizeOfArray = size;
    if (FSizeOfArray == 0) {
       if (FPile!=NULL) delete[] (MkPile*)FPile;
       FPile = NULL;
       return;
    }

    if (FPile!=NULL) delete[] (MkPile*)FPile;
    FPile = new MkPile[FSizeOfArray];
    for (i=0;i<FSizeOfArray;i++) FPile[i] = piles[i];
    for (i=0;i<FSize;i++) FPile[i].Number = i;
}

int MkPiles::Grow(int delta)
{
    int i;
    MkPile *pile=NULL;

    if (!(pile = new MkPile[FSizeOfArray+delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        pile[i] = FPile[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        pile[i] = NullPile;
    if (FPile) {
       delete[] (MkPile*)FPile;
       FPile = NULL;
    }
    FPile = pile;
    FSizeOfArray = FSizeOfArray+delta;
    return FSizeOfArray;
}

int MkPiles::Shrink(int delta)
{
    int i;
    MkPile *pile=NULL;

    if (!(pile = new MkPile[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        pile[i] = FPile[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        pile[i] = NullPile;
    if (FPile) {
       delete[] (MkPile*)FPile;
       FPile = NULL;
    }
    FPile = pile;
    FSizeOfArray = FSizeOfArray-delta;
    return FSizeOfArray;
}

bool MkPiles::Add(MkPile &pile)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    FSize++;
    FPile[FSize-1] = pile;
    return true;
}

bool MkPiles::Add(int index, MkPile &pile)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    for (int i=FSize-1;i>=index;i--)
      FPile[i+1] = FPile[i];
    FSize++;
    FPile[index] = pile;
    return true;
}

bool MkPiles::Delete(MkPile &pile)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FPile[i] == pile) break;
    }
    if(i==FSize) return false;
    if(FPile[i] == pile) {
      for (int j=i;j<FSize-1;j++)
        FPile[j] = FPile[j+1];
    }
    FSize--;
    FPile[FSize] = NullPile;
    return true;
}

bool MkPiles::Delete(int index)
{
    for (int j=index;j<FSize-1;j++)
        FPile[j] = FPile[j+1];

    FSize--;
    FPile[FSize] = NullPile;
    return true;
}

bool MkPiles::Clear()
{
  char str[256];
//  sprintf(str,"FSize of Piles is %d, FSizeOFArray is %d\n",FSize,FSizeOfArray);
//  MkDebug(str);
   FSizeOfArray = FSize = 0;
   if (FPile) {
      delete[] FPile;
      FPile = NULL;
   }
//  sprintf(str,"FSize of Piles is %d, FSizeOFArray is %d\n",FSize,FSizeOfArray);
//  MkDebug(str);
   
   return true;
}

MkPile & MkPiles::operator[](int i)
{
    if (0<=i && i<FSize) return FPile[i];
    else if(FSize<=i && i<FSizeOfArray) {
      FSize=i+1;
      return FPile[i];
    }
    else if (FSizeOfArray <= i) {
      Grow(i-FSizeOfArray+5);
      return NullPile;
    }
    else return NullPile;
}

MkPiles & MkPiles::operator=(MkPiles &piles)
{
    int i;

    Clear();
    FSize = piles.FSize;
    FSizeOfArray = piles.FSizeOfArray;
    if (FSizeOfArray == 0) {
       FPile = NULL;
       return *this;
    }
    this->FPile = new MkPile[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FPile[i] = piles.FPile[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FPile[i] = NullPile;

    return *this;
}

bool MkPiles::operator==(MkPiles &piles)
{
    int i;

    if (FSize != piles.FSize) return false;
    for (i=0;i<FSize;i++)
      if (this->FPile[i] != piles.FPile[i]) return false;

    return true;
}

#ifdef __BCPLUSPLUS__
void MkPiles::Out(TObject *)
{

}
#endif

void MkPiles::Out(char *fname)
{
  FILE *fp;
  fp = fopen(fname,"a");
  if(!fp) {
    return;
  }

  if(FSize==0) return;

            //12345678901234567890123456789012345678901234567890123456789012345678901234567890
  fprintf(fp,"\n");
  fprintf(fp,"                           <Information of Vertical Wall>\n");
  fprintf(fp,"\n");
  fprintf(fp," V-Wall  Depth      Area        I            E     Spacing\n");
  fprintf(fp,"   No.    (m)       (m2)       (m4)        (t/m2)    (m)  \n");
  fclose(fp);

  for(int i=0;i<FSize;i++)
    FPile[i].Out(fname);
}

#ifdef __BCPLUSPLUS__
void MkPiles::Import(MkGlobalVar &globalvar, int sec)
{
  int i;
  Initialize(globalvar.pile_ea[sec+1]);
  
  if(FSize<=0) return;
  FPile[0].SetPileLoc(plSide);
  FPile[FSize-1].SetPileLoc(plSide);

  for(i=1;i<FSize-1;i++)
    FPile[i].SetPileLoc(plMid);

  for(i=0;i<FSize;i++) 
    FPile[i].Import(globalvar, sec);
}

void MkPiles::Export(MkGlobalVar &globalvar, int sec)
{
  int i;
  if(FSize<=0) return;
  globalvar.pile_ea[sec+1] = FSize;

  FPile[0].SetPileLoc(plSide);
  FPile[FSize-1].SetPileLoc(plSide);

  for(i=1;i<FSize-1;i++)
    FPile[i].SetPileLoc(plMid);

  for(i=0;i<FSize;i++)
    FPile[i].Export(globalvar, sec);
}
#endif

#ifdef __BCPLUSPLUS__
void MkPiles::Draw(TObject *Sender)
{
    TColor C;
    float Offset;
    if (FSize == 0) return;
    if (String(Sender->ClassName()) == String("MkPaintBox")) {
       MkPaintBox *pb=(MkPaintBox*)Sender;
       C = pb->Canvas->Pen->Color;
       pb->Canvas->Pen->Color = Color;
       for (int i = 0; i < FSize;i++) {
           Offset = pb->Offset(3);
           FPile[i].Draw(pb);
       }
       pb->Canvas->Pen->Color = C;
    }
}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void MkPiles::Draw(MkPaint *pb)
{

}
#endif
//---------------------------------------------------------------------------
