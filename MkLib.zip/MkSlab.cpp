//---------------------------------------------------------------------------
#include "MkSlab.h"
#ifdef __BCPLUSPLUS__
#include <vcl.h>
#endif
#pragma hdrstop
//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#pragma package(smart_init)
#endif

MkSlab NullSlab(0);
MkSlab::MkSlab()
{
  Number=0;
  Depth=0;
  Thick=0;
  IniDis=0;
//  Area=0;
//  Angle=0;
  Length=0;
}
MkSlab::MkSlab(int n)
{
  Number=0;
  Depth=0;
  Thick=0;
  IniDis=0;
//  Area=0;
//  Angle=0;
  Length=0;
}

#ifdef __BCPLUSPLUS__
bool MkSlab::UpdateFrom()
{
  if(!Grid) return false;

  Number=Grid->Cells[1][0].ToInt();
  Depth =Grid->Cells[1][1].ToDouble();
//  Area  =Grid->Cells[1][2].ToDouble();
//  Angle =Grid->Cells[1][3].ToDouble();
  Length=Grid->Cells[1][4].ToDouble();

  return true;
}

bool MkSlab::UpdateTo()
{
  if(!Grid) return false;

  for(int i=0;i<20;i++) {Grid->Cells[0][i] = "";Grid->Cells[1][i]="";}

  Grid->Cells[0][0] = "Number";
  Grid->Cells[0][1] = "Depth";
  Grid->Cells[0][2] = "Area";
  Grid->Cells[0][3] = "Angle";
  Grid->Cells[0][4] = "Length";
  Grid->Cells[1][0] = Number;
  Grid->Cells[1][1] = Depth;
//  Grid->Cells[1][2] = Area;
//  Grid->Cells[1][3] = Angle;
  Grid->Cells[1][4] = Length;

  return true;
}

void MkSlab::Out(TObject *Sender)
{

}

#else
#endif
void MkSlab::Out(char *fname)
{

}

bool MkSlab::operator==(MkSlab &slab)
{
  bool flag = true;
  flag = flag && MkEntity::operator==((MkEntity&)slab);
  flag = flag && Number==slab.Number;
  flag = flag && Depth==slab.Depth;
//  flag = flag && Area==slab.Area;
//  flag = flag && Angle==slab.Angle;
  flag = flag && Length==slab.Length;

  return flag;
}

bool MkSlab::operator!=(MkSlab &slab)
{
  return !operator==(slab);
}

MkSlab & MkSlab::operator=(MkSlab &slab)
{
  MkEntity::operator=((MkEntity&)slab);
  Number=slab.Number;
  Depth=slab.Depth;
//  Area=slab.Area;
//  Angle=slab.Angle;
  Length=slab.Length;
  return *this;
}

#ifdef __BCPLUSPLUS__
void  MkSlab::Draw(TObject *Sender)
{
  SlabLine.Draw(Sender);
}
#endif
  
#if defined(_MSC_VER) && defined(_WINDOWS_)
void MkSlab::Draw(MkPaint *pb)
{
  SlabLine.Draw(pb);
}
#endif


MkSlabs::MkSlabs(int size,MkSlab *slabs)
{

    if (size < 0) {
      MkDebug("::MkSlabs - MkSlabs(int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSize == 0) {
       FSlab = NULL;
       return;
    }

    FSlab = new MkSlab[FSize];
    for (int i=0;i<FSize;i++) (*this)[i] = slabs[i];
}

MkSlabs::MkSlabs(int size)
{
    if (size < 0) {
      MkDebug("::MkSlabs - MkSlabs(int size)");;
      return;
    }

    FSizeOfArray = size;
    FSize = 0;
    if (FSizeOfArray == 0) {
       FSlab = NULL;
       return;
    }

    FSlab = new MkSlab[FSizeOfArray];
}

MkSlabs::~MkSlabs()
{
   FSizeOfArray = FSize = 0;
   if (FSlab) {
      delete[] FSlab;
      FSlab = NULL;
   }
}


void MkSlabs::Initialize(int size)
{
    int i;
    if (size < 0) {
      MkDebug("::MkSlabs - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;

    FSizeOfArray = FSize = size;

    if (FSizeOfArray == 0) {
       if (FSlab!=NULL) delete[] (MkSlab*)FSlab;
       FSlab = NULL;
       return;
    }

    if (FSlab!=NULL) delete[] (MkSlab*)FSlab;
    FSlab = new MkSlab[FSizeOfArray];
    for (i=0;i<FSize;i++) FSlab[i].Number = i;    
}

void MkSlabs::Initialize(int size,MkSlab *slabs)
{
    int i;
    if (size < 0 || slabs == NULL) {
      MkDebug("::MkSlabs - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSize = FSizeOfArray = size;
    if (FSizeOfArray == 0) {
       if (FSlab!=NULL) delete[] (MkSlab*)FSlab;
       FSlab = NULL;
       return;
    }

    if (FSlab!=NULL) delete[] (MkSlab*)FSlab;
    FSlab = new MkSlab[FSizeOfArray];
    for (i=0;i<FSizeOfArray;i++) FSlab[i] = slabs[i];
    for (i=0;i<FSize;i++) FSlab[i].Number = i;
}

int MkSlabs::Grow(int delta)
{
    int i;
    MkSlab *slab=NULL;

    if (!(slab = new MkSlab[FSizeOfArray+delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        slab[i] = FSlab[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        slab[i] = NullSlab;
    if (FSlab) {
       delete[] (MkSlab*)FSlab;
       FSlab = NULL;
    }
    FSlab = slab;
    FSizeOfArray = FSizeOfArray+delta;
    return FSizeOfArray;
}

int MkSlabs::Shrink(int delta)
{
    int i;
    MkSlab *slab=NULL;

    if (!(slab = new MkSlab[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        slab[i] = FSlab[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        slab[i] = NullSlab;
    if (FSlab) {
       delete[] (MkSlab*)FSlab;
       FSlab = NULL;
    }
    FSlab = slab;
    FSizeOfArray = FSizeOfArray-delta;
    return FSizeOfArray;
}

bool MkSlabs::Add(MkSlab &slab)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    FSize++;
    FSlab[FSize-1] = slab;
    return true;
}

bool MkSlabs::Add(int index, MkSlab &slab)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    for (int i=FSize-1;i>=index;i--)
      FSlab[i+1] = FSlab[i];
    FSize++;
    FSlab[index] = slab;
    return true;
}

bool MkSlabs::Delete(MkSlab &slab)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FSlab[i] == slab) break;
    }
    if(i==FSize) return false;
    if(FSlab[i] == slab) {
      for (int j=i;j<FSize-1;j++)
        FSlab[j] = FSlab[j+1];
    }
    FSize--;
    FSlab[FSize] = NullSlab;
    return true;
}

bool MkSlabs::Delete(int index)
{
    for (int j=index;j<FSize-1;j++)
        FSlab[j] = FSlab[j+1];

    FSize--;
    FSlab[FSize] = NullSlab;
    return true;
}

bool MkSlabs::Clear()
{
   FSizeOfArray = FSize = 0;
   if (FSlab) {
      delete[] FSlab;
      FSlab = NULL;
   }
   return true;
}

MkSlab & MkSlabs::operator[](int i)
{
    if (0<=i && i<FSize) return FSlab[i];
    else if(FSize<=i && i<FSizeOfArray) {
      FSize=i+1;
      return FSlab[i];
    }
    else if (FSizeOfArray <= i) {
      Grow(i-FSizeOfArray+5);
      return NullSlab;
    }
    else return NullSlab;
}

MkSlabs & MkSlabs::operator=(MkSlabs &slabs)
{
    int i;

    Clear();
    FSize = slabs.FSize;
    FSizeOfArray = slabs.FSizeOfArray;
    if (FSizeOfArray == 0) {
       FSlab = NULL;
       return *this;
    }
    this->FSlab = new MkSlab[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FSlab[i] = slabs.FSlab[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FSlab[i] = NullSlab;

    return *this;
}

bool MkSlabs::operator==(MkSlabs &slabs)
{
    int i;

    if (FSize != slabs.FSize) return false;
    for (i=0;i<FSize;i++)
      if (this->FSlab[i] != slabs.FSlab[i]) return false;

    return true;
}
#ifdef __BCPLUSPLUS__
void MkSlabs::Draw(TObject *Sender)
{
    TColor C;
    float Offset;
    if (FSize == 0) return;
    if (String(Sender->ClassName()) == String("MkPaintBox")) {
       MkPaintBox *pb=(MkPaintBox*)Sender;
       C = pb->Canvas->Pen->Color;
       pb->Canvas->Pen->Color = Color;
       for (int i = 0; i < FSize;i++) {
           Offset = pb->Offset(3);
           FSlab[i].Draw(pb);
       }
       pb->Canvas->Pen->Color = C;
    }
}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void MkSlabs::Draw(MkPaint *pb)
{

}
#endif


