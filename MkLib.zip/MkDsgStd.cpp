//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#include <vcl.h>
#endif

#pragma hdrstop
#include "stdafx.h"
#include "MkDsgStd.h"
//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#pragma package(smart_init)
#endif

MkQandA::MkQandA(char *q, char *a, MkAnswerType at)
{
  if(strlen(q)>0 && strlen(a)>0) {
    Question = new char[strlen(q)+1];
    Answer = new char[strlen(a)+1];
    strcpy(Question,q);
    strcpy(Answer,a);
    AnsType = at;
  }
  else {
    Question = Answer = NULL;
    AnsType = atNone;
  }
  NextQandA = NULL;
  PrevQandA = NULL;
}

bool MkQandA::GetAnswer(char *q,char *a, MkAnswerType &at)
{
  if(!strcmp(Question,q)) {
    a = Answer;
    at = AnsType;
    return true;
  }
  else return false;
}

void MkQandA::SetAnswer(const char *q,const char *a, MkAnswerType at)
{
  if(Question) delete Question;
  if(Answer) delete Answer;
  Question = new char[strlen(q)+1];
  Answer = new char[strlen(a)+1];
  strcpy(Question,q);
  strcpy(Answer,a);
  AnsType = at;
}

bool MkQandA::operator==(MkQandA &qna)
{
  bool flag;
  flag = !strcmp(Question,qna.Question) && !strcmp(Answer,qna.Answer) && AnsType == qna.AnsType;
  return flag;
}

MkQandA * MkQandA::operator=(MkQandA *qna)
{
  SetAnswer(qna->Question,qna->Answer,qna->AnsType);
  return this;
}

MkDesignStandard::MkDesignStandard()
{
  FirstQandA=NULL;
  LastQandA=NULL;
  CurrentQandA=NULL;
}

MkDesignStandard::~MkDesignStandard()
{
  while(CurrentQandA) Delete(CurrentQandA->Question,CurrentQandA->Answer,CurrentQandA->AnsType);
  FirstQandA=NULL;
  LastQandA=NULL;
  CurrentQandA=NULL;
}

bool MkDesignStandard::Add(char *question, char *answer, MkAnswerType at)
{
  MkQandA *qna=new MkQandA(question, answer, at);
  if (LastQandA == NULL) {
      FirstQandA = qna;
      FirstQandA->NextQandA = NULL;
      FirstQandA->PrevQandA = NULL;
      CurrentQandA = qna;
      CurrentQandA->NextQandA = NULL;
      CurrentQandA->PrevQandA = NULL;
      LastQandA = qna;
      LastQandA->NextQandA = NULL;
      LastQandA->PrevQandA = NULL;
      return true;
  }
  else LastQandA->NextQandA = qna;

  qna->NextQandA = NULL;
  qna->PrevQandA = LastQandA;
  LastQandA = qna;
  return true;
}

bool MkDesignStandard::Delete(char *question, char *answer, MkAnswerType at)
{
  MkQandA *qna = new MkQandA(question, answer, at);
  MkQandA *cur;

  for (cur = FirstQandA;cur;cur = cur->Next()) {
      if (*cur == *qna) break;
  }
  if (*cur == *qna) {
     if (cur->Prev()) {
        cur->PrevQandA->NextQandA = cur->Next();
     }
     else {
          FirstQandA = cur->Next();
          if (FirstQandA) FirstQandA->PrevQandA = NULL;
     }
     if (cur->Next()) cur->NextQandA->PrevQandA = cur->Prev();
     else {
          LastQandA = cur->Prev();
          if (LastQandA) LastQandA->NextQandA = NULL;
     }
     if (cur == CurrentQandA) {
        if (cur->Prev()) CurrentQandA = cur->Prev();
        else if (cur->Next()) CurrentQandA = cur->Next();
        else CurrentQandA = NULL;
     }

     delete cur;cur = NULL;
     delete qna;qna = NULL;
     return true;
  }
  delete qna;qna = NULL;
  return false;
}

bool MkDesignStandard::Clear()
{
  bool flag=true;
  MkQandA *cur = LastQandA;

  if (!cur) return true;

  while (flag && LastQandA != FirstQandA) {
        flag = Delete(cur->Question,cur->Answer,cur->AnsType);
        cur = LastQandA;
  }
  if (flag) {
     Delete(FirstQandA->Question,FirstQandA->Answer,FirstQandA->AnsType);
     FirstQandA = NULL;
     CurrentQandA = NULL;
     LastQandA = NULL;
     return true;
  }
  else return false;
}

bool MkDesignStandard::Ask(char *question, char *&answer, MkAnswerType &at)
{
  MkQandA *top;
  top = FirstQandA;
  while(top) {
    if(!strcmp(top->Question,question)) {
      answer = top->Answer;
      at = top->AnsType;
      return true;
    }
    else top = top->Next();
  }
  answer = NULL;
  at = atNone;
  return false;
}

bool MkDesignStandard::operator==(MkDesignStandard &ds)
{
  bool flag=true;
  MkQandA *a,*b;
  a = FirstQandA;
  b = ds.FirstQandA;

  do {
    flag = flag && !strcmp(a->Question,b->Question);
    flag = flag && !strcmp(a->Answer,b->Answer);
    if(!flag) return false;
    a=a->Next();
    b=b->Next();
    if(!a || !b) break;
  } while(a->Next() && b->Next());
  return flag;
}

bool MkDesignStandard::operator!=(MkDesignStandard &ds)
{
  return !(*this==ds);
}
