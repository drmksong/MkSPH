//---------------------------------------------------------------------------
// ::new convienient int vector class
// This can be any dimension up to 3.
// Vector can be re-initialized even though
// previous data will be erased.
// But if you want to preserve it, you can do it simply...
// Author : M. K. Song. Seoul, Korea. 1999.2.20
//---------------------------------------------------------------------------
#include "stdafx.h"
#include "MkInt.h"

#ifdef __BCPLUSPLUS__
#pragma package(smart_init)
#endif


MkInt::MkInt(int s_x,int s_y,int s_z)
{
    if (s_x<=0 || s_y<=0 || s_z <=0) {
       printf("Three D::bad MkInt size\n");
       throw Size(s_x,s_y,s_z);
    }
    Zero = 0;
    FDimension = 3;
    FI = FJ = FK = 0;

    long sz = long(s_x)*long(s_y)*long(s_z);
    sz_x = long(s_x);
    sz_y = long(s_y);
    sz_z = long(s_z);

    try {F = new int[sz];}

    catch (std::bad_alloc){
       printf( "Not Enough Memory\n");
       throw Alloc();
    }

    for(int i=0;i<sz;i++) F[i]=0;

}

MkInt::MkInt(int s_x,int s_y)
{
    if (s_x<=0 || s_y<=0) {
       printf( "Two D::bad MkInt size\n");
       throw Size(s_x,s_y);
    }
    Zero = 0;
    FDimension = 2;
    FI = FJ = FK = 0;

    long sz = long(s_x)*long(s_y);
    sz_x = long(s_x);
    sz_y = long(s_y);
    sz_z = 1;

    try {
        F = new int[sz];
    }
    catch (std::bad_alloc){
       printf( "Not Enough Memory\n");
       throw Alloc();
    }
    for(int i=0;i<sz;i++) F[i]=0;
}

MkInt::MkInt(int s_x)
{
    if (s_x<=0) {
       printf( "One D::bad MkInt size\n");
       throw Size(s_x);
    }

    Zero = 0;
    FDimension = 1;
    FI = FJ = FK = 0;

    int sz = s_x;
    sz_x = long(s_x);
    sz_y = 1;
    sz_z = 1;

    try {
        F = new int[sz];
    }
    catch (std::bad_alloc){
       printf( "Not Enough Memory\n");
       throw Alloc();
    }
    for(int i=0;i<sz;i++) F[i]=0;
}

MkInt::MkInt()
{
    Zero = 0;
    FDimension = 0;
    FI = FJ = FK = 0;

    sz_x = 0;
    sz_y = 0;
    sz_z = 0;

    F = NULL;
}

MkInt::~MkInt()
{
    if (F) {
      delete[] F;
      F = NULL;
    }
}

void MkInt::Clear()
{
    if (F!=NULL) {
       delete[] F;
       F = NULL;
    }
    Zero = 0;
    FDimension = 0;
    FI = FJ = FK = 0;

    sz_x = 0;
    sz_y = 0;
    sz_z = 0;
}

void MkInt::Initialize(int s_x,int s_y,int s_z)
{
    if (s_x<=0 || s_y<=0 || s_z <=0) {
       printf("bad MkInt size\n");
       throw Size(s_x,s_y,s_z);
    }

    FDimension = 3;
    FI = FJ = FK = 0;

    long sz = long(s_x)*long(s_y)*long(s_z);
    sz_x = long(s_x);
    sz_y = long(s_y);
    sz_z = long(s_z);

    if (F != (int*)NULL) {
       delete[] F;
       F = (int*)NULL;
    }

    try {
        F = new int[sz];
    }
    catch (std::bad_alloc){
       printf( "Not Enough Memory\n");
       throw Alloc();
    }
    for(int i=0;i<sz;i++) F[i]=0;
}

void MkInt::Initialize(int s_x,int s_y)
{
    if (s_x<=0 || s_y<=0) {
       printf( "bad MkInt size\n");
       throw Size(s_x,s_y);
    }

    FDimension = 2;
    FI = FJ = FK = 0;

    long sz = long(s_x)*long(s_y);
    sz_x = long(s_x);
    sz_y = long(s_y);
    sz_z = 1;

    if (F != (int*)NULL) {
       delete[] F;
       F = (int*)NULL;
    }

    try {
        F = new int[sz];
    }
    catch (std::bad_alloc){
       printf( "Not Enough Memory\n");
       throw Alloc();
    }
    for(int i=0;i<sz;i++) F[i]=0;
}

void MkInt::Initialize(int s_x)
{
    if (s_x<=0) {
       printf( "bad MkInt size\n");
       throw Size(s_x);
    }
    FDimension = 1;
    FI = FJ = FK = 0;

    long sz = long(s_x);
    sz_x = long(s_x);
    sz_y = 1;
    sz_z = 1;

    if (F != (int*)NULL) {
       delete[] F;
       F = (int*)NULL;
    }

    try {
        F = new int[sz];
    }
    catch (std::bad_alloc){
       printf( "Not Enough Memory\n");
       throw Alloc();
    }
    for(int i=0;i<sz;i++) F[i]=0;
}

void MkInt::CopyFrom(MkInt &value)
{
    if (!(value.sz_x*value.sz_y*value.sz_z)) return;
    Initialize(value.sz_x,value.sz_y,value.sz_z);
    FDimension = value.FDimension;

    long sz = long(sz_x)*long(sz_y)*long(sz_z);

    for (long i=0;i<sz;i++)
        F[i] = value.F[i];
}


int & MkInt::operator()(int i,int j,int k)
{
    if ( FDimension <= 0) {
       printf("Possibly Memory dosen't allocated!\n");
       return Zero;
    }

    if (i<0 || sz_x<=i) {
       printf("MkInt index out of range\n");
       throw Range("sz_x",i);
    }
    if (j<0 || sz_y<=j) {
       printf("MkInt index out of range\n");
       throw Range("sz_y",i);
    }
    if (k<0 || sz_z<=k) {
       printf("MkInt index out of range\n");
       throw Range("sz_z",i);
    }
    return F[long(i)+long(j)*sz_x+long(k)*sz_x*sz_y];
}

int  & MkInt::operator()(int i,int j)
{
    if ( FDimension <= 0) {
       printf("Possibly Memory dosen't allocated!\n");
       return Zero;
    }

    if (i<0 || sz_x<=i) {
       printf("MkInt index out of range\n");
       throw Range("sz_x",i);
    }
    if (j<0 || sz_y<=j) {
       printf("MkInt index out of range\n");
       throw Range("sz_y",i);
    }
    return F[long(i)+long(j)*sz_x];
}

int  & MkInt::operator()(int i)
{
    if ( FDimension <= 0) {
       printf("Possibly Memory dosen't allocated!\n");
       return Zero;
    }

    if (i<0 || sz_x<=i) {
       printf("MkInt index out of range\n");
       throw Range("sz_x",i);
    }
    return F[long(i)];
}

MkInt & MkInt::operator+=(MkInt &a)
{
   if (a.sz_x!=sz_x || a.sz_y!=sz_y || a.sz_z!=sz_z) return *this;

   for (int i=0;i<sz_x;i++)
     for (int j=0;j<sz_y;j++)
       for (int k=0;k<sz_z;k++)
         (*this)(i,j,k) += a(i,j,k);

   return *this;
}

MkInt & MkInt::operator-=(MkInt &a)
{
   if (a.sz_x!=sz_x || a.sz_y!=sz_y || a.sz_z!=sz_z) return *this;

   for (int i=0;i<sz_x;i++)
     for (int j=0;j<sz_y;j++)
       for (int k=0;k<sz_z;k++)
         (*this)(i,j,k) -= a(i,j,k);

   return *this;
}

MkInt & MkInt::operator*=(int b)
{
  for (int i=0;i<sz_x;i++)
     for (int j=0;j<sz_y;j++)
       for (int k=0;k<sz_z;k++)
         (*this)(i,j,k)*=b;

  return *this;
}

MkInt & MkInt::operator/=(int b)
{
  if(b<FTOL &&b>-FTOL) return *this;
  for (int i=0;i<sz_x;i++)
     for (int j=0;j<sz_y;j++)
       for (int k=0;k<sz_z;k++)
         (*this)(i,j,k)/=b;

  return *this;
}

bool MkInt::operator==(MkInt &a)
{
  bool flag=true;
  int i,j,k;
  flag=flag && (FDimension==a.FDimension);
  flag=flag && (sz_x==a.sz_x);
  flag=flag && (sz_y==a.sz_y);
  flag=flag && (sz_z==a.sz_z);
  if(!flag) {
    return flag;
  }
  for(i=0;i<sz_x;i++) {
    for(j=0;j<sz_y;j++) {
      for(k=0;k<sz_z;k++) {
	      flag=flag&& ((*this)(i,j,j)==a(i,j,k));
      }
    }
  }
  return flag;
}

bool MkInt::operator!=(MkInt &a)
{
  return !(*this==a);
}

MkInt & operator+(MkInt &a,MkInt &b)
{
   static MkInt c;
   c.Clear();
   if (a.sz_x!=b.sz_x || a.sz_y!=b.sz_y || a.sz_z!=b.sz_z) return c;

   c.Initialize(a.sz_x,a.sz_y,a.sz_z);

   for (int i=0;i<a.sz_x;i++)
     for (int j=0;j<a.sz_y;j++)
       for (int k=0;k<a.sz_z;k++)
         c(i,j,k) = a(i,j,k) + b(i,j,k);

   return c;
}

MkInt & operator-(MkInt &a,MkInt &b)
{
   static MkInt c;
   c.Clear();
   if (a.sz_x!=b.sz_x || a.sz_y!=b.sz_y || a.sz_z!=b.sz_z) return c;

   c.Initialize(a.sz_x,a.sz_y,a.sz_z);

   for (int i=0;i<a.sz_x;i++)
     for (int j=0;j<a.sz_y;j++)
       for (int k=0;k<a.sz_z;k++)
         c(i,j,k) = a(i,j,k) - b(i,j,k);

   return c;
}

MkInt & operator*(MkInt &a,int b)
{
  static MkInt c;
  c.Initialize(a.sz_x,a.sz_y,a.sz_z);
  for (int i=0;i<a.sz_x;i++)
     for (int j=0;j<a.sz_y;j++)
       for (int k=0;k<a.sz_z;k++)
         c(i,j,k) = a(i,j,k)*b;

  return c;
}

MkInt & operator/(MkInt &a,int b)
{
  static MkInt c;
  if(b<FTOL&&b>-FTOL) return a;
  c.Initialize(a.sz_x,a.sz_y,a.sz_z);
  for (int i=0;i<a.sz_x;i++)
     for (int j=0;j<a.sz_y;j++)
       for (int k=0;k<a.sz_z;k++)
         c(i,j,k) = a(i,j,k)/b;

  return c;
}

//---------------------------------------------------------------------------




