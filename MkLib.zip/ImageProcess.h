//---------------------------------------------------------------------------
#ifndef ImageProcessH
#define ImageProcessH
//---------------------------------------------------------------------------
#include <SysUtils.hpp>
#include <Controls.hpp>
#include <Classes.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <stdlib.h>
//---------------------------------------------------------------------------
class PACKAGE TImageProcess : public TImage
{
private:
protected:
public:
        __fastcall TImageProcess(TComponent* Owner);
        __fastcall Smooth();
        __fastcall EdgeDetect();
        __fastcall EdgeDetectL();
        __fastcall EdgeDetectR();
        __fastcall EdgeEnhance();
__published:
};
//---------------------------------------------------------------------------
#endif
