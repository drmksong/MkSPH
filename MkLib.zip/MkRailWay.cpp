// All the member functions are assumed to be closed polygon!!!
//---------------------------------------------------------------------------
// This module is general purposed simple graphic class to store, draw,
// manipulate object. It is well suited to VCL component, but not restricted.
// It forms the base for the higher level class, such as tunnel component.
//
// Copyright (c) 1999 Myung Kyu Song, ESCO Consultant Co., Ltd.
#include "MkRailWay.h"
#include "WorldPaintBox.hpp"
extern MkPoint NullPoint;
extern MkLine NullLine;
MkRailWay::MkRailWay(int size, MkPoint *rp, MkFloat &station)
: MkPolygon(size,rp)
{
     Station.CopyFrom(station);
     if (size == Station.getSzX())Flag = true;
     else false;
}

MkRailWay::MkRailWay(int size, MkPoint *rp)
: MkPolygon(size,rp)
{
     Station.Initialize(size);
     FirstLayerDepth.Initialize(size);
     SecondLayerDepth.Initialize(size);
     ThirdLayerDepth.Initialize(size);
}

MkRailWay::MkRailWay(int size) : MkPolygon(size)
{
     Station.Initialize(size);
     FirstLayerDepth.Initialize(size);
     SecondLayerDepth.Initialize(size);
     ThirdLayerDepth.Initialize(size);
}

MkRailWay::MkRailWay() : MkPolygon()
{

}

MkRailWay::~MkRailWay()
{
}

void MkRailWay::Initialize(int size)
{
     MkPolygon::Initialize(size);
     Station.Initialize(size);
     FirstLayerDepth.Initialize(size);
     SecondLayerDepth.Initialize(size);
     ThirdLayerDepth.Initialize(size);

}

void MkRailWay::Initialize(int size,MkPoint *rps)
{
     MkPolygon::Initialize(size,rps);
     Station.Initialize(size);
     FirstLayerDepth.Initialize(size);
     SecondLayerDepth.Initialize(size);
     ThirdLayerDepth.Initialize(size);
}

void MkRailWay::Initialize(int size,MkPoint *rps,MkFloat &station)
{
     MkPolygon::Initialize(size,rps);
     Station.CopyFrom(station);
     FirstLayerDepth.Initialize(size);
     SecondLayerDepth.Initialize(size);
     ThirdLayerDepth.Initialize(size);

     if (size == Station.getSzX())Flag = true;
     else Flag = false;
}

void MkRailWay::Initialize(MkFloat &station)
{
     Station.CopyFrom(station);
     FirstLayerDepth.Initialize(station.getSzX());
     SecondLayerDepth.Initialize(station.getSzX());
     ThirdLayerDepth.Initialize(station.getSzX());

     if (GetSize() == Station.getSzX())Flag = true;
     else false;
}

void MkRailWay::SetDepth()
{
     for (int i = 0 ; i < Station.getSzX();i++) {
         FirstLayerDepth[i] = 1+random(0.5*1000)/1000.0;
         SecondLayerDepth[i] = 2+random(1*1000)/1000.0;
         ThirdLayerDepth[i] = 4+random(2*1000)/1000.0;
     }
}

MkPoint MkRailWay::FowardDir(int i,float j)  // Extrapolate
// extrapolate the rail way line.
{
    float len;
    len = i*1000+j;
    int low,high;
    long mid;

    if (Station.getSzX()==0) return NullPoint;
    if (len > Station[Station.getSzX()-1]-0.1) {
       mid = Station.getSzX()-2;
       low = 100;
       high = 0;
    }
    else if (len < Station[0]) {
       mid = 0;
       low = 100;
       high = 0;
    }
    else {
       low = 0;
       high = Station.getSzX()-1;
    }

    while(low <= high) {
       mid = (low+high)/2;
       if (len < Station[mid]) high = mid-1;
       else if (len > Station[mid]) low = mid+1;
       else break;
    }
    MkPoint rp( (*this)[mid+1].X-(*this)[mid].X,
                   (*this)[mid+1].Y-(*this)[mid].Y,
                   (*this)[mid+1].Z-(*this)[mid].Z);
    rp.Unify();
    return rp;
}

MkPoint MkRailWay::BackwardDir(int i,float j)
{
    float len;
    len = i*1000+j;
    int low,high,mid;

    if (Station.getSzX()==0) return NullPoint;
    if (len > Station[Station.getSzX()-1]) {
       mid = Station.getSzX()-2;
       low = 100;
       high = 0;
    }
    else if (len < Station[0]) {
       mid = 0;
       low = 100;
       high = 0;
    }
    else {
       low = 0;
       high = Station.getSzX()-1;
    }

    while(low <= high) {
       mid = (low+high)/2;
       if (len < Station[mid]) high = mid-1;
       else if (len > Station[mid]) low = mid+1;
       else break;
    }

    MkPoint rp( (*this)[mid].X-(*this)[mid+1].X,
                   (*this)[mid].Y-(*this)[mid+1].Y,
                   (*this)[mid].Z-(*this)[mid+1].Z);
    rp.Unify();
    return rp;
}

float MkRailWay::GetXMin()
{
    float xmin = 10000000;
    for (int i = 0 ; i < FSize ; i++)
        xmin = xmin > FPoint[i].X ? FPoint[i].X : xmin;
    return xmin;
}

float MkRailWay::GetYMin()
{
    float ymin = 10000000;
    for (int i = 0 ; i < FSize ; i++)
        ymin = ymin > FPoint[i].Y ? FPoint[i].Y : ymin;
    return ymin;
}

MkLine MkRailWay::operator()(int i)
{
    return MkPolygon::operator()(i);
}

MkPoint MkRailWay::operator()(int i,float j) // EXTRAPOLATE IT.
{
    float len;
    len = i*1000+j;
    int low,high,mid; float c;

    if (!Station.getSzX()) return NullPoint;

    if (len > (c = Station[Station.getSzX()-1])) {
       mid = Station.getSzX()-2;
       low = 100;
       high = 0;
    }
    else if (len < (c = Station[0])) {
       mid = 0;
       low = 100;
       high = 0;
    }
    else {
       low = 0;
       high = Station.getSzX()-1;
    }

    while(low <= high) {
       mid = (low+high)/2;
       if (len < (c = Station[mid])) high = mid-1;
       else if (len > (c = Station[mid])) low = mid+1;
       else break;
    }
    if (mid < 0 || mid > Station.getSzX()-1) return NullPoint;
    if (mid == Station.getSzX()-1) mid = Station.getSzX()-2;
    float sublen = len - Station[mid];
    float d = sublen/(*this).MkPolygon::operator()(mid).GetLength();
    MkPoint st,en,cur;
    st = (*this).MkPolygon::operator[](mid);
    en = (*this).MkPolygon::operator[](mid+1);
    cur = (*this).MkPolygon::operator()(mid).GetDivision(d);
    return cur;
//    return (*this).MkPolygon::operator()(mid).GetDivision(d);

}

MkPoint & MkRailWay::operator[](int i)
{
     return MkPolygon::operator[](i);
}

MkRailWay & MkRailWay::operator=(MkRailWay &railway)
{
    int i;

    Clear();
    FSize = railway.FSize;
    if (FSize == 0) {
       this->FPoint = NULL;
       return *this;
    }
    this->FPoint = new MkPoint[FSize];

    for (i=0;i<FSize;i++)
      this->FPoint[i] = railway.FPoint[i];

    Station.CopyFrom(railway.Station);
    return *this;
}

//---------------------------------------------------------------------------
