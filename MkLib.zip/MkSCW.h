//---------------------------------------------------------------------------
#ifndef MkSCWH
#define MkSCWH

#include "MkWall.h"
//---------------------------------------------------------------------------
class MkSCW : public MkWall {
protected:

public:
  MkSCW(){}
  MkSCW(int){}
  ~MkSCW();
#ifdef __BCPLUSPLUS__
  AnsiString ClassName(){return AnsiString("MkSCW");};
#else
  char* ClassName(){return "MkSCW";}
#endif

};

class MkSCWs {
protected:
    MkSCW *FSCW;
    int FSize;//Actual size of scws
    int FSizeOfArray;
#ifdef __BCPLUSPLUS__
    TColor Color;
#endif
public:
    MkSCWs(int size,MkSCW *scw);
    MkSCWs(int size);
    MkSCWs(){FSizeOfArray = FSize = 0;FSCW = NULL;}
     ~MkSCWs();
    virtual void Initialize(int size);
    virtual void Initialize(int size,MkSCW *);
    int GetSize(){return FSize;};
    int GetNumber(){return FSize;};
    bool Add(MkSCW &scw);  // change of size of scw
    bool Add(int index,MkSCW &scw);
    bool Delete(MkSCW &scw);  // change of size of scw
    bool Delete(int index);
    int Grow(int Delta);            // change of size of array
    int Shrink(int Delta);          // change of size of array
    bool Clear();
#ifdef __BCPLUSPLUS__
    TColor GetColor(){return Color;};
    void SetColor(TColor c){Color = c;}
#endif

#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif

    virtual MkSCW & operator[](int);
    MkSCWs & operator=(MkSCWs &scws);
    bool operator==(MkSCWs &scws);
};

//---------------------------------------------------------------------------
#endif
