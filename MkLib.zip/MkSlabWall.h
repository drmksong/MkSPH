//---------------------------------------------------------------------------
#ifndef MkSlabWallH
#define MkSlabWallH
#include "MkEntity.h"
//---------------------------------------------------------------------------
class MkSlabWall : public MkEntity {
protected:
  MkLine SlabWallLine;
  float DepthTop;
  float DepthBot;
  float Thick;
  float YieldMom;

//  float Area;
//  float Angle;
//  float YoungMod;
//  float ShearTor;
//  float SecMomentY, SecMomentZ;  // second moment of inertial
public:
  MkSlabWall();
  MkSlabWall(int n);
  ~MkSlabWall(){};

  void SetSlabWallLine(MkLine &line){SlabWallLine = line;}
  void SetDepthTop(float top){DepthTop = top;}
  void SetDepthBot(float bot){DepthBot = bot;}
  void SetThick(float thick){Thick = thick;}
  void SetYieldMom(float myield){YieldMom = myield;}

  MkLine &GetSlabWallLine(){return SlabWallLine;}
  float GetDepthTop(){return DepthTop;}
  float GetDepthBot(){return DepthBot;}
  float GetThick(){return Thick;}
  float GetYieldMom(){return YieldMom;}

#ifdef __BCPLUSPLUS__
  AnsiString ClassName(){return AnsiString("MkSlabWall");};
  bool UpdateFrom(TStringGrid *grid){Grid = grid;return UpdateFrom();};
  bool UpdateTo(TStringGrid *grid){Grid = grid;return UpdateTo();};
  bool UpdateFrom();
  bool UpdateTo();
  void Out(TObject *);
#else
  char* ClassName(){return "MkSlabWall";}
#endif
  void Out(char *fname);
  void SetLine(MkLine &line){SlabWallLine = line;SlabWallLine.SetFiniteness(true);}
  MkLine &GetLine(){return SlabWallLine;}
  bool operator==(MkSlabWall&);
  bool operator!=(MkSlabWall&);
  MkSlabWall & operator=(MkSlabWall&);

#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif
};

class MkSlabWalls {
protected:
    MkSlabWall *FSlabWall;
    int FSize;//Actual size of entities
    int FSizeOfArray;
#ifdef __BCPLUSPLUS__
    TColor Color;
#endif
public:
    MkSlabWalls(int size,MkSlabWall *ent);
    MkSlabWalls(int size);
    MkSlabWalls(){FSizeOfArray = FSize = 0;FSlabWall = NULL;}
    ~MkSlabWalls();
    virtual void Initialize(int size);
    virtual void Initialize(int size,MkSlabWall *);
    int GetSize(){return FSize;};
    int GetNumber(){return FSize;};
    bool Add(MkSlabWall &slabwall);  // change of size of slabwall
    bool Add(int index,MkSlabWall &slabwall);
    bool Delete(MkSlabWall &slabwall);  // change of size of slabwall
    bool Delete(int index);
    int Grow(int Delta);            // change of size of array
    int Shrink(int Delta);          // change of size of array
    bool Clear();
#ifdef __BCPLUSPLUS__
    TColor GetColor(){return Color;};
    void SetColor(TColor c){Color = c;}
    void Out(TObject *);
#else
#endif

    void Out(char *fname);

#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif

    virtual MkSlabWall & operator[](int);
    MkSlabWalls & operator=(MkSlabWalls &slabwalls);
    bool operator==(MkSlabWalls &slabwalls);
};
//---------------------------------------------------------------------------
extern MkSlabWall NullSlabWall;
//---------------------------------------------------------------------------
#endif
