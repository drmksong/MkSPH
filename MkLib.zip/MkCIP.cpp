//---------------------------------------------------------------------------
#include "MkCIP.h"
#ifdef __BCPLUSPLUS__
#include <vcl.h>
#endif
#pragma hdrstop
//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#pragma package(smart_init)
#endif
//---------------------------------------------------------------------------
void MkCIP::Clear()
{
  BarDia=0;
  Fck=Fy=Fca=Fsa=Vca=Ec=As=0;
  CFck= CFy= CBarDia= CCIPSteel=0;
  CThickDia= CNumOfBar=0;
}

void MkCIP::SetCFck(int c)
{
  CFck = c;
  if(CFck==0) Fck=18.0;
  else if(CFck==1) Fck=21.0;
  else if(CFck==2) Fck=24.0;
  else if(CFck==3) Fck=27.0;
  else Fck = 0;

  Fca=0.4*1.5*Fck;
  Ec=0.043*125000*sqrt(Fck);
}

void MkCIP::SetCFy(int c)
{
  CFy = c;
	if(CFy==0) {
		Fy=300.0;
		Fsa=225.0;
	}
  else if(CFy==1){
		Fy=350.0;
		Fsa=262.5;
	}
  else if(CFy==2){
		Fy=400.0;
		Fsa=270.0;
	}
}

void MkCIP::SetCBarDia(int c)
{
  CBarDia = c;
	if(CBarDia==0){
		BarDia=10;
		As=71.33*CNumOfBar;
	}
  else if(CBarDia==1){
		BarDia=13;
		As=126.7*CNumOfBar;
	}
  else if(CBarDia==2){
		BarDia=16;
		As=195.6*CNumOfBar;
	}
  else if(CBarDia==3){
		BarDia=19;
		As=286.5*CNumOfBar;
	}
  else if(CBarDia==4){
		BarDia=22;
		As=387.1*CNumOfBar;
	}
  else if(CBarDia==5){
		BarDia=25;
		As=506.7*CNumOfBar;
	}
  else if(CBarDia==6){
		BarDia=29;
		As=642.4*CNumOfBar;
	}
  else if(CBarDia==7){
		BarDia=32;
		As=794.2*CNumOfBar;
	}
  else if(CBarDia==8){
		BarDia=35;
		As=956.6*CNumOfBar;
	}
}

void MkCIP::SetCCIPSteel(int c)
{
  CCIPSteel = c;
}

void MkCIP::SetCThickDia(double d)
{
  CThickDia = d;
}

void MkCIP::SetCNumOfBar(double d)
{
  CNumOfBar = d;
}

