//---------------------------------------------------------------------------
#ifndef MkCircleH
#define MkCircleH

#include <math.h>
#include "MkShape.h"
#include "MkPoint.h"
#include "MkTriangle.h"
#ifdef __BCPLUSPLUS__
#include "MkPaintBox.h"
#endif

// It is used for only 2 dimensional geometry operation
// I should upgrade this for 3 dimensional...
//---------------------------------------------------------------------------

class MkCircle : public MkShape {
protected:
    MkPoint FCP;
    float FRadius;
    float FCircleArea;
    MkPoints FRealPoints;
    virtual void  CalArea();
public:
     MkCircle();
     MkCircle(int );
     MkCircle(float cx,float cy,float radius);
     MkCircle(MkPoint cp,float radius);
#ifdef __BCPLUSPLUS__
     MkCircle(float cx,float cy,float radius,TColor C);
     MkCircle(MkPoint cp,float radius,TColor C);
#endif
    void  SetCircle(float cx,float cy,float radius);
    void  SetCircle(MkPoint cp,float radius);
#ifdef __BCPLUSPLUS__
    void  SetCircle(float cx,float cy,float radius,TColor C);
    void  SetCircle(MkPoint cp,float radius,TColor C);
#endif
    virtual void  SetCenter(float cx,float cy);
    virtual void  SetCenter(MkPoint cp);
    virtual void  SetRadius(float radius);

    MkPoint  GetCenter(){return FCP;}     
    float  GetRadius(){return FRadius;}
    float  GetArea(){CalArea();return FCircleArea;}
    MkPoint &  operator[](int);
#ifdef __BCPLUSPLUS__
    AnsiString ClassName(){return AnsiString("MkCircle");}
#else
    char * ClassName(){return "MkCircle";}
#endif

    bool isCircle(){return true;}
    bool IsInSurface(MkPoint &pnt, float thick);
    bool IsInSpace(MkPoint &pnt);

    MkCircle & operator=(MkCircle &rc);
    bool operator&&(MkLine &rl);
    MkPoints operator&(MkLine &rl);
    MkPoints & operator&(MkPoint &rp);

    bool operator==(MkCircle &c);
    bool operator!=(MkCircle &c);

#ifdef __BCPLUSPLUS__
  void Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *); 
#endif

};

class MkCircles : public MkShape {
protected:
    MkCircle *FCircle;
    int FSize;
public:
    MkCircles(int Size);
    MkCircles(){FSize = 0; FCircle = NULL;}
    ~MkCircles(){if (FCircle) {delete (MkCircle*)FCircle;FCircle = NULL;}}
    void Initialize(int Size);
    void Clear();
    int GetSize(){return FSize;}
    virtual MkCircle &  operator[](int);
    MkCircles &  operator=(MkCircles &circles);

#ifdef __BCPLUSPLUS__
  void Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *); 
#endif

};

class MkArc : public MkCircle {
private:
    MkPoint FStartPoint, FEndPoint;
    float FStartAng,FEndAng;
    float FCrownArea;
//    void  CalArea();
    void  CalCrownArea();
    void  CalTriArea();
    void  CalStartPoint();
    void  CalEndPoint();
    void  CalStartAngle();
    void  CalEndAngle();
public:
     MkArc();
     MkArc(int);
     MkArc(MkPoint p1,MkPoint p2,MkLine line);
     MkArc(float cx,float cy,float radius,float start_ang,float end_ang);
     MkArc(MkPoint cp,float radius, float start_ang,float end_ang);
#ifdef __BCPLUSPLUS__
     MkArc(MkPoint cp,float radius, float start_ang,float end_ang,TColor C);
     MkArc(float cx,float cy,float radius,float start_ang,float end_ang,TColor C);
#endif
    void  ReCalcPoint();
    void  ReCalcAng();
    void  SetCenter(float cx,float cy);
    void  SetCenter(MkPoint cp);
    void  SetRadius(float radius);
    void  SetStartAng(float start_ang);
    void  SetEndAng(float end_ang);
    float  GetStartAng();
    float  GetEndAng();
    float  GetArea();
    float  GetAngle(){return FEndAng - FStartAng;};
    float  GetCrownArea();
    float  GetTriArea();
    bool   isWithInArc(MkPoint rp);
    bool   isWithInAng(MkPoint rp);
    float  CrossProduct();
    MkPoint  StartPoint();
    MkPoint  EndPoint();
    MkPoint &  operator[](int);
    MkLine  operator()(int);
#ifdef __BCPLUSPLUS__
    AnsiString ClassName(){return AnsiString("MkArc");}
#else
    char * ClassName(){return "MkArc";}
#endif
    MkArc & operator=(MkArc &ra);

#ifdef __BCPLUSPLUS__
  void Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *); 
#endif

};
extern MkCircle NullCircle;
extern MkArc NullArc;
//---------------------------------------------------------------------------

#endif

