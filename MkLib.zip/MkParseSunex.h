//---------------------------------------------------------------------------
#ifndef ParseSunexH
#define ParseSunexH
//#include "string.h"
#include "MkMisc.h"
#include "MkKeyWord.h"
#include "MkParser.h"
#include "MkEntity.h"
#include "MkSection.h"
//---------------------------------------------------------------------------
class MkSunexParser : public MkParser {
protected:
  MkSection *SectionRef;
  MkSunexKeyWord KeyWord;
  int CurStep;

public:
  MkSunexParser();
  ~MkSunexParser();

  void SetSection(MkSection &sec){SectionRef = &sec;}
  void SetCurStep(int n){CurStep = n;}

  MkSection &GetSection(){return *SectionRef;}
  int GetCurStep(){return CurStep;}

  bool Parse();
  bool ParseLine(char *str, MkKeyKind key);

  bool ParsePrj(char *str);
  bool ParseLay(char *str);
  bool ParsePrf(char *str);
  bool ParseWall(char *str);
  bool ParseStrut(char *str);
  bool ParseAnchor(char *str);
  bool ParseRockbolt(char *str);
  bool ParseSlab(char *str);
  bool ParseSlabWall(char *str);
  bool ParseDiv(char *str);
  bool ParseSol(char *str);
  bool ParsePnt(char *str);
  bool ParseNoEcho(char *str);
  bool ParseOut(char *str);
  bool ParseStep(char *str);
  bool ParseStepLine(char *str);
  bool ParseBot(char *str);
  bool ParseRankine(char *str);
  bool ParsePeck(char *str);
  bool ParsePeck1(char *str);
  bool ParseEarthPress(char *str);
  bool ParseSlope(char *str);
  bool ParseProfile(char *str);  // profile change
  bool ParseGWL(char *str);
  bool ParseWaterPress(char *str);
  bool ParseSurcharge(char *str);
  bool ParseLoad(char *str);
  bool ParsePress(char *str);
  bool ParseMinAct(char *str);
  bool ParseExcav(char *str);
  bool ParseConst(char *str);
  bool ParseRemove(char *str);
  bool ParseInsertCheck(char *str);
  bool ParseInteration(char *str);
  bool ParseGroundSettle(char *str);
  bool ParseSlip(char *str);
};
#endif
