//---------------------------------------------------------------------------
#ifndef MkMainBeamH
#define MkMainBeamH

#ifdef __BCPLUSPLUS__
#include "GlobalVarUnit.h"
#endif

#include "MkObject.h"
#include "MkMisc.h"
#include "MkBeam.h"
//---------------------------------------------------------------------------
class MkMainBeam : public MkObject {
protected:
//HH,BB,tt1, tt2, AA, Aw,W,Zx,Ix,rx,ry for beam
  MkSteelType SteelType;
  float Height;                  // HH
  float Width;                   // BB
  float T1,T2;                   // tt1, tt2
  float Area, AreaWeb;           // AA, Aw
  float Weight;                  // W
  float SecCoeffY, SecCoeffZ;    // Section coefficient Zx, Zy
  float SecMomentY, SecMomentZ;  // second moment of inertial Ix, Iy
  float SecRadiusY, SecRadiusZ;  // second radius of inertia rx, ry
public:
  MkMainBeam(){Clear();}
  MkMainBeam(int ){Clear();};
  ~MkMainBeam(){}

  void SetSteelType(MkSteelType st){SteelType = st;}
  void SetHeight(float h){Height=h;}
  void SetWidth(float w){Width=w;}
  void SetT1(float t){T1 = t;}
  void SetT2(float t){T2 = t;}
  void SetArea(float a){Area=a;}
  void SetAreaWeb(float a){AreaWeb=a;}
  void SetWeight(float w){Weight=w;}
  void SetSecCoeffY(float sm){SecCoeffY=sm;}
  void SetSecCoeffZ(float sm){SecCoeffZ=sm;}
  void SetSecMomentY(float sm){SecMomentY=sm;}
  void SetSecMomentZ(float sm){SecMomentZ=sm;}
  void SetSecRadiusY(float sm){SecRadiusY=sm;}
  void SetSecRadiusZ(float sm){SecRadiusZ=sm;}
  void SetBeam(MkBeam beam);

  MkSteelType GetSteelType(){return SteelType;}
  float GetHeight(){return Height;}
  float GetWidth(){return Width;}
  float GetT1(){return T1;}
  float GetT2(){return T2;}
  float GetArea(){return Area;}
  float GetAreaWeb(){return AreaWeb;}
  float GetWeight(){return Weight;}
  float GetSecCoeffY(){return SecCoeffY;}
  float GetSecCoeffZ(){return SecCoeffZ;}
  float GetSecMomentY(){return SecMomentY;}  // second moment of inertial
  float GetSecMomentZ(){return SecMomentZ;}  // second moment of inertial
  float GetSecRadiusY(){return SecRadiusY;}
  float GetSecRadiusZ(){return SecRadiusZ;}

  void Clear();
#ifdef __BCPLUSPLUS__
  void Import(MkGlobalVar &globalvar, int sec);
  void Export(MkGlobalVar &globalvar, int sec);
#endif
};
//---------------------------------------------------------------------------
#endif
