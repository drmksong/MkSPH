#ifndef MkSubsidH
#define MkSubsidH
#include "MkMisc.h"
#include "MkFloat.h"
#include "MkSpline.h"

enum MkSubsidType {subCaspe=0, subPeck, subORourke};
class MkSubsid {
 protected:
  MkSubsidType SubsidType;
  float Vs, Ht, Hp, ExcavDepth, Width, D, Sw, Si, Friction; // for Caspe
  MkSpline Peck; // for Peck
  MkSpline ORourke;  // for ORourke

 public:
  MkSubsid();
  ~MkSubsid(){}
  void SetSubsidType(MkSubsidType st) {SubsidType = st;}
  void SetDisVolume(float dv){Vs = dv;}
  void SetExcavDepth(float ed){ExcavDepth = ed;}
  void SetWidth(float wid){Width = wid;}
  void SetExcaEfctLength(float el){Ht = el;}
  void SetFriction(float fr){Friction = fr;}
  void SetPeck();
  void SetORourke();
  float GetSubsid(MkSubsidType sub,float x);
  float GetSubsidCaspe(float x);
  float GetSubsidPeck(float x);
  float GetSubsidORourke(float x);
};
#endif
