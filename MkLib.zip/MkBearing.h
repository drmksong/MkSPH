//---------------------------------------------------------------------------
#ifndef MkBearingH
#define MkBearingH
#include <string.h>
#include "MkObject.h"

#ifdef __BCPLUSPLUS__
#include "System.hpp"
#endif
enum MkBearingMethod {bmGoodman, bmTeng, bmQuJoint, bmBridgeRoad, bmStatic, bmEtc};
enum MkBearingType {btRock, btSoil};
//---------------------------------------------------------------------------
class MkBearing : public MkObject {
protected:
  MkBearingMethod Method;
  MkBearingType Type;
#ifdef __BCPLUSPLUS__
  AnsiString Eq;
#else
  char Eq[256];
#endif

public:
  MkBearing();
  ~MkBearing(){}

public:
  void SetType(MkBearingType bt){Type=bt;}
  void SetMethod(MkBearingMethod bm){Method=bm;}
#ifdef __BCPLUSPLUS__
  void SetEq(AnsiString eq){Eq = eq;}
#else
  void SetEq(char *eq){strcpy(Eq,eq);}
#endif

public:
  MkBearingType GetType(){return Type;}
  MkBearingMethod GetMethod(){return Method;}
  int GetBearingMethod();
#ifdef __BCPLUSPLUS__
  AnsiString GetEq(){return Eq;}
#else
  char *GetEq(){return Eq;}
#endif
  float GetBearing();
};
#endif
