//       PROGRAM COKRIG
//       **************************************************************
//
//         PROGRAM COKRIG WAS WRITTEN BY JAMES R. CARR
//         ADDRESS:                      DEPT. OF GEOLOGICAL ENGR.
//                                       UNIVERSITY OF MISSOURI-ROLLA
//                                       ROLLA, MISSOURI U.S.A. 65401
//         TELEPHONE:                    (314) 341-4557/(314) 341-4867
//         IBM 4331 FORTRAN IV VERSION:  SEPTEMBER, 1983
//
//         THIS PROGRAM PERFORMS THE CO-KRIGING PROCEDURE.
//         EQUATION SOLUTION FOLLOWS THE TECHNIQUE DEVELOPED
//         BY K. TANABE(1971), NUMER. MATH., VOL. 17, PP 203-
//         214.  THE GLOBAL LOGIC OF THIS PROGRAM
//         FOLLOWS MYERS, D.E., 1982, MATHEMATICAL GEOLOGY,
//         VOL. 14, NO. 3, PP. 249 - 257.
//
//         THREE COVARIANCE AND CROSS-COVARIANCE modelS ARE
//         AVAILABLE:  SPHERICAL, GAUSSIAN, AND LINEAR. AS
//         PRESENTED, PROGRAM COKRIG IS DIMENSIONED FOR 500
//         DATA SAMPLES AND LOCATIONS, EACH LOCATION LIMITED TO
//         A MAXIMUM OF 5 VARIABLES.
//
//                     GUIDE TO DATA INPUT
//
//         CARD 1.  OPTION INITIALIZATION
//                  COL 1  IKRIG  FULLY SAMPLED (0) OR UNDER-
//                                SAMPLED (1)
//                                FOR THE UNDERSAMPLED CASE,
//                                ZERO DATA VALUES ARE CON-
//                                SIDERED TO INDICATE UNDER-
//                                SAMPLING. SEE STATEMENT 1640
//                                TO CHANGE THIS REQUIREMENT.
//                  COL2   MVAR   NUMBER OF VARIABLES TO BE EST. (1-5)
//                  COL3   ICREAT OPTION FOR FILE CREATION
//                  COL4   ISOLV  OPTION FOR EQUATION SOLUTION
//                         0 = ART ITERATIVE SCHEME
//                         1 = GAUSS DECOMPOSITION
//         CARD 2.  ESTABLISH KRIGING BOUNDARY
//                  COL 1-5  NROW  NUMBER OF ROWS TO BE KRIGED
//                  COL 6-10 NCOL  NUMBER OF COLS TO BE KRIGED
//                  COL11-20 YMAX  MAXIMUM Y-COORDINATE (NORTH)
//                  COL21-30 XMAX  MAXIMUM X-COORDINATE (EAST)
//                  COL31-40 XDIM  INCREMENT IN X BETWEEN COLUMNS
//                  COL41-50 YDIM INCREMENT IN Y BETWEEN ROWS
//         CARD 3.  VARIABLE NAMES (15A4)
//                  COL  1-10 NAME OF VARIABLE 1
//                  COL 11-20 NAME OF VARIABLE 2
//                  COL 21-30 NAME OF VARIABLE 3
//                  COL 31-40 NAME OF VARIABLE 4
//                  COL 41-50 NAME OF VARIABLE 5
//         CARD 4.  VARIOGRAM AND CROSS-VARIOGRAM DATA ENTRY.
//                  VARIOGRAM PARAMETERS FIRST-ONE CARD PER VAR.
//                  COL   1-5  VARIABLE NUMBER (1-MVAR) - J
//                  COL  6-10  model[J) - VARIO. model (1:SPHER;
//                                        2:GAUSS; 3:LINEAR)
//                  COL 11-20  CO[J) - NUGGET VALUE
//                  COL 21-30  C[J)  - SILL OF VARIOGRAM
//                  COL 31-40  RANGE[J) - RANGE OF VARIOGRAM
//                  COL 41-50  ANIS[J) - ANGLE OF ANISOTROPY
//                  COL 51-60  RATIO[J)- RATIO OF MAJ AXIS/MIN AXIS
//                  COL 61-70  RINFLU[J) - RANGE OF INFLUENCE FOR EST.
//                  CROSS-VARIOGRAM ENTRY:  1 CARD PER VARIABLE PAIR.
//                  COL   1-5  J - VARIABLE J
//                  COL  6-10  K - VARIABLE K CROSS CORRELATED WITH J
//                  COL 11-15  cmodel -CROSS-VARIOGRAM model[1:S;2:G;3:L
//                  COL 16-25  CCO    - NUGGET VALUE
//                  COL 26-35  CC     - SILL VALUE
//                  COL 36-45  CRANGE - RANGE OF CROSS-VARIOGRAM
//                  COL 46-55  CANIS  - ANGLE OF ANISOTROPY (DEGREES)
//                  COL 56-65  CRATIO - RATIO OF MAJ AXIS/MIN AXIS
//                  COL 66-70  CRNFLU - RANGE OF INFLUENCE FOR EST.
//         CARD 5.  DATA ENTRY.
//                  COL 1-?    DATA VALUES, FORMAT = MVAR:F10.3
//                  COL ?-?    DEPENDING ON NUMBER OF VARIABLES, COLUMN
//                             LOCATION WILL VARY.  AFTER DATA VALUES:
//                  COL ?-?    Y-COORDINATE OF DATA LOCATION
//                  COL ?-?    X-COORDINATE OF DATA LOCATION
//
//         ************************************************************
//---------------------------------------------------------------------------
// The original file was written in Fortran by James Carr, and
// Converted to C++ class to be used commonly by C++ users.
// No one does have copyright of this code, because the first
// fortran program is freely distributable.
// Date : 1999.7.27
// ESCO Engineers & Consultant Co., LTD.
// Myung Kyu Song.

#include <vcl.h>
#pragma hdrstop

#include "Cokrig.h"

FILE *fp6;

void Krig2D::KrigMain(char *filename)
{
     float DIST[6],TEMP[15],EST[6],AW[6][6];
//     float XTEMP[100][6];
     float TEMP1[6][6],TEMP2[6][6],TEMP3[6][6];
     char *format;

     int i,j;
     int ICREAT,ISOLV,NROW,NCOL;
     float YMAX,XMAX,XDIM,YDIM;
     int K,M2,IMOD;
     float ACCO,ACC,DRANGE,AAN,AR,AFLU;
     int KM,KP,KN,ICOUNT,JK,IJ,ITEMP,IK;
     float CHK,CHK1;
     float XBEGIN,YBEGIN;
     int JROW;
     int JCOL;
     int ISTOP;
     int II,JJ;
     float XCORD,YCORD;
     int ISERCH,IANG;
     float DIFX,DIFY;
     float X2;
     int KOUNT,III;
     int M9,M8,M7,N1,KK,N2;
     float DUM1,DUM2,DUM3,DUM5;
     int J9,KJ;
     float VAR;
     int IC,ID,IA,IB;

     if(!filename) return;

     FILE *fp1,*fp2,*fp3,*fp4,*fp5,*fp7;//,*fp6;

     fp5 = fopen (filename,"r");
     fp1 = fopen ("TEMP.DAT","w");
     fp2 = fopen ("WEIGHT.DAT","w");
     fp3 = fopen ("VARI.DAT","w");
     fp4 = fopen ("CONTOR.DAT","w");
     fp6 = fopen ("Scrout.dat","w");
     fp7 = fopen ("atemp.dat","w");

//.......SET INITIAL DATA

     fscanf(fp5,"%d %d %d %d", &IKRIG,&MVAR,&ICREAT,&ISOLV);
     fscanf(fp5,"%d %d %f %f %f %f", &NROW,&NCOL,&YMAX,&XMAX,&XDIM,&YDIM);

//.......VARIOGRAM AND CROSS-VARIOGRAM DATA ENTRY

     for (i = 1 ; i <= MVAR ; i++) {
         fscanf(fp5,"%d ",&j);
         fscanf(fp5,"%d %f %f %f %f %f %f ",&model[j],&CO[j],&C[j],&RANGE[j],&ANIS[j],&RATIO[j],&RINFLU[j]);
         if (model[j]==3) {
            RINFLU[j] = 0.45 * RANGE[j];
         }
     }

     if (MVAR!=1) {
//.......CROSS-VARIOGRAM DATA ENTRY
        M2 = (MVAR * (MVAR - 1)) / 2;
        for (i = 1;i<=M2;i++) {
            fscanf(fp5,"%d %d %d %f %f %f %f %f %f", &j,&K,&IMOD,&ACCO,&ACC,&DRANGE,&AAN,&AR,&AFLU);
            if (j!=1) {
               KM = j - 1;
               KP = 0;
               for (KN = 1;KN<=KM;KN++) {
                    KP = KP + MVAR - KN;
               }
               KP = KP + K - j;
            }
            else KP = K - j;

            CCO[KP]    =  ACCO;
            CC[KP]     =  ACC;
            CRANGE[KP] =  DRANGE;
            cmodel[KP] =  IMOD;
            CANIS[KP]  =  AAN;
            CRATIO[KP] =  AR;
            CRNFLU[KP] =  AFLU;
        }
     }

//.......DATA ENTRY

     ICOUNT = 0;
     do {
        ICOUNT = ICOUNT + 1;
        for (JK=1;JK<=MVAR;JK++) {
            fscanf(fp5,"%f",&DAT[ICOUNT][JK]);
        }
        fscanf(fp5,"%f %f",&Y[ICOUNT],&X[ICOUNT]);
        CHK  = Y[ICOUNT];
        CHK1 = X[ICOUNT];
     } while (CHK!=0 || CHK1!=0 );

     ICOUNT = ICOUNT - 1;

//.......CHECK FOR UNDERSAMPLED LOCATIONS -- IF IKRIG = 1,
//.......A ZERO DATA VALUE INDICATES UNDERSAMPLING.

     if (IKRIG == 1) {
        KCOUNT = 0;
        for (IJ = 1;IJ<=ICOUNT;IJ++) {
            ITEMP = 0;
            for (IK = 1;IK<=MVAR;IK++) {
                if (fabs(DAT[IJ][IK]) < EPS && ITEMP != 1) {
                   KCOUNT = KCOUNT + 1;
                   ITEMP  = 1;
                   JUNSAM[KCOUNT] = IJ;
                }
            }
        }
     }

//.......ECHO INPUT DATA TO OUTPUT FILE
     format = "  *******************  CO-KRIGING PROGRAM   ***************\n\n";
     fprintf (fp6,format);

     format = "  UNDERSAMPLED CASE\n\n";
     if (IKRIG==1) fprintf (fp6,format);

     format = "  NO OF ROWS IN KRIGED ARRAY =    ,%5d \n NO OF COLS IN KRIGED ARRAY =    ,%5d \n MAXIMUM Y COORDINATE       =  ,%10.3f \n   MAXIMUM X COORDINATE       =   ,%10.3f \n   INCREMENT ON X             =   ,%10.3f \n    INCREMENT ON Y             =   ,%10.3f\n\n";
     fprintf (fp6,format,NROW,NCOL,YMAX,XMAX,XDIM,YDIM);

     format = " A TOTAL OF  %2d  VARIABLE(S) WILL BE ESTIMATED\n\n";
     fprintf (fp6,format,MVAR);

     format =  " ********* VARIOGRAM AND CROSS-VARIOGRAM PARAMETERS  *******\n\n, SINGLE VARIABLE (VARIOGRAM) PARAMETERS \n  VARIABLE    NUGGET   SILL   RANGE   ANGLE     RATIO    INFLUENCE     model\n";
     fprintf (fp6,format);

     for (i = 1;i<=MVAR;i++) {
         format =  "%5d,%10.3f %10.3f %10.3f %10.3f %10.3f %10.3f,%10d";
         fprintf (fp6,format,i,CO[i],C[i],RANGE[i],ANIS[i],RATIO[i],RINFLU[i],model[i]);
     }
     if (MVAR!=1) {
        format =  " \n\n  INTER-VARIABLE (CROSS-VARIOGRAM) PARAMETERS \n"
                  "VARIABLE    NUGGET   SILL   RANGE   ANGLE    RATIO    INFLUENCE      model \n ";
        fprintf (fp6,format);

        for (i = 1;i<=M2;i++) {
            format =  "%5d,%10.3f %10.3f %10.3f %10.3f %10.3f %10.3f ,%10d\n";
            fprintf (fp6,format,i,CCO[i],CC[i],CRANGE[i],CANIS[i],CRATIO[i],CRNFLU[i],cmodel[i]);
        }
     }
     format =  " \n\n  ***  INPUT DATA  *** \n     X-COORD    Y-COORD   DATA VALUES\n\n";
     fprintf (fp6,format);

     for( i = 1;i<=ICOUNT;i++) {
        fprintf (fp6,"%10.3f %10.3f ",X[i],Y[i]);
        for (JK=1;JK<=MVAR;JK++) fprintf (fp6," %10.3f",DAT[i][JK]);
        fprintf (fp6,"\n");
     }
//.......START KRIGING:  INCREMENT COLUMNS, THEN ROWS
     XBEGIN     =  XMAX - XDIM * (FLOAT(NCOL) + 0.5);
     YBEGIN     =  YMAX + (YDIM / 2.0);
     ISTOP      =  10;
     for (II  =  1;II<=MVAR;II++) {
         ANIS[II]   =  ANIS[II] * 0.01745329;
         CANIS[II]  =  CANIS[II]* 0.01745329;
     }

     format =  " \n\n  **** ** ***   KRIGING RESULTS   *** ** **** \n ROW COL   NORTH   WEST  DATA ESTIMATE    VARIANCE \n ";
     fprintf (fp6,format);

     for (JROW = 1;JROW<=NROW;JROW++) {
         YCORD = YBEGIN - FLOAT(JROW) * YDIM;
         for (JCOL = 1;JCOL<=NCOL;JCOL++) {
             XCORD =  XBEGIN + FLOAT(JCOL) * XDIM;
             INIT  =  0;
             for (ISERCH = 1;ISERCH<=ICOUNT;ISERCH++) {
                 DIFX = XCORD - X[ISERCH];
                 DIFY = YCORD - Y[ISERCH];

//.......COMPUTE DISTANCE BETWEEN SAMPLE AND ESTIMATION POINT
                 bool flag;
                 flag = false;
                 for (IANG = 1;IANG<=MVAR;IANG++) {
                     DIST[IANG] = pow(DIFX*cos(ANIS[IANG])+DIFY*sin(ANIS[IANG]),2);
                     DIST[IANG] += pow(RATIO[IANG]*(DIFY*cos(ANIS[IANG])-DIFX * sin(ANIS[IANG])),2);
                     DIST[IANG] =  sqrt(DIST[IANG]);
                     if (DIST[IANG] > RINFLU[IANG]) {
                        flag = true;
                        break;//GO TO 500
                     }
                 }
                 if (flag) continue;
                 if (INIT < ISTOP) {
                    INIT = INIT + 1;

//.......FIND CLOSEST SAMPLES ON THE BASIS OF FIRST VARIABLE.  IT IS
//.......ALREADY GUARANTEED BY THE 200 LOOP THAT ALL DISTANCES ARE
//.......WITHIN THE RANGE OF INFLUENCE OF EACH VARIABLE.

                    TEMP[INIT] =  DIST[1];
                    NHOLE[INIT]=  ISERCH;
                 }
                 else {
                    X2    = 0.0;
                    KOUNT = 0;
                    for (III =  1;III<=INIT;III++) {
                        if (TEMP[III] >= X2) {
                           KOUNT = III;
                           X2    = TEMP[III];
                        }
                    }
                    if (DIST[1] <= X2) {
                       TEMP[KOUNT] =  DIST[1];
                       NHOLE[KOUNT]= ISERCH;
                    }
                 }
             } // 500

             if (INIT > 2) {
                MROW = INIT + 1;
                MCOL = INIT + 1;
                MTOT = MVAR * MCOL;
//csmk---------------------
//before
        for( i=1;i<=100;i++) {
           for ( j=1;j<=100;j++) {
              fprintf(fp7,"%10.5f",ATEMP[i][j]);
              if (j % 10 == 0) fprintf(fp7,"\n");
           }
           fprintf(fp7,"\n");
        }
        fprintf(fp7,"\n\n");
//csmk----------------------

                AFORM(YCORD,XCORD);
                if (ISOLV==1) EQSOLV();
//csmk---------------------
//after
        for( i=1;i<=100;i++) {
           for ( j=1;j<=100;j++) {
              fprintf(fp7,"%10.5f",ATEMP[i][j]);
              if (j % 10 == 0) fprintf(fp7,"\n");
           }
           fprintf(fp7,"\n");
        }
        fprintf(fp7,"\n\n");
//csmk----------------------

//.......COMPUTE CO-KRIGING ESTIMATES
                for (II = 1;II<=MVAR;II++) {
                    EST[II]    =  0.0;
                }
                M9 = MCOL - 1;
                for (II  =  1;II<=M9;II++) {
                    N1 = NHOLE[II];
                    for (JJ  =  1;JJ<=MVAR;JJ++) {
                        for (KK  =  1;KK<=MVAR;KK++) {
                            N2 = (II - 1) * MVAR + KK;
                            EST[JJ]    =  EST[JJ] + DAT[N1][KK] * XTEMP[N2][JJ];
//smk---------------------------------------------
//                            fprintf(fp6,"%d %d %d %d %f %f %f\n",JJ,N1,KK,N2,EST[JJ],DAT[N1][KK],XTEMP[N2][JJ]);
//       fprintf(fp6,"%d %d\n",MTOT,MVAR);
//       for (i=1;i<=MTOT;i++) {
//           for (j=1;j<=MVAR;j++)
//               fprintf(fp6,"%f ",ATEMP[i][j]);
//           fprintf(fp6,"\n");
//       }
//smk---------------------------------------------
                        }
                    }
                }

//.......COMPUTE CO-KRIGING VARIANCE AS:
//.......VAR = TR(C1) - TR(XMEAS*XTEMP) - TR(LAGRANGE)
//...
//.......TR(C1) = SUM OF INDIVIDUAL SILL VALUES
                DUM1       =  0.0;
                for (II  =  1;II<=MVAR;II++) {
                    DUM1       =  DUM1 + C[II];
                }
//.......COMPUTE TRACE(XMEAS*XTEMP)
                RZRO(TEMP3,MVAR,MVAR);
                for (II = 1;II<=M9;II++) {
                    for (JJ = 1;JJ<=MVAR;JJ++) {
                        J9 = (II - 1) * MVAR + JJ;
                        for (KK = 1;KK<=MVAR;KK++) {
                            TEMP1[JJ][KK] = XMEAS[J9][KK];
                            TEMP2[JJ][KK] = XTEMP[J9][KK];
                        }
                    }
                    for (JJ = 1;JJ<=MVAR;JJ++) {
                        for (KK = 1;KK<=MVAR;KK++) {
                            for (KJ = 1;KJ<=MVAR;KJ++) {
                                TEMP3[JJ][KK] = TEMP3[JJ][KK] + TEMP1[JJ][KJ] * TEMP2[KJ][KK];
                            }
                        }
                    }
                }


                DUM2 = TRACE(TEMP3);
//.......COMPUTE TRACE(LAGRANGE)
                M8 = M9 * MVAR;
                for (II  =  1;II<=MVAR;II++) {
                    M7 = M8 + II;
                    for (JJ  =  1;JJ<=MVAR;JJ++) {
                        TEMP2[II][JJ] = XTEMP[M7][JJ];
                    }
                }

                DUM3 = TRACE(TEMP2);
                VAR  = DUM1 - DUM2 - DUM3;
                for (IC  =  1;IC<=MVAR;IC++) {
                    for (ID  =  1;ID<=MVAR;ID++) {
                        AW[IC][ID] = 0.0;
                    }
                }
                for (IA = 1;IA<=M9;IA++) {
                    for (IB = 1;IB<=MVAR;IB++) {
                        IC = (IA - 1) * MVAR + IB;
                        for (ID = 1;ID<=MVAR;ID++) {
                            AW[IB][ID] = AW[IB][ID] + XTEMP[IC][ID];
                        }
                    }
                }

                format =  "%4d %4d,%9.3f %9.3f";
                fprintf (fp6,format,JROW,JCOL,YCORD,XCORD);
                for (JK=1;JK<=MVAR;JK++) fprintf (fp6,"%9.3f ",EST[JK]);
                fprintf (fp6,"%9.3f\n",VAR);

                if (ICREAT == 1) {
                   for (IC = 1;IC<=MVAR;IC++) {
                       for (ID=1;ID<=MVAR;ID++)
                           fprintf(fp2,"%10.3f ",AW[IC][ID]) ;
                       fprintf(fp2,"\n") ;
                   }
                   fprintf(fp2,"\n") ;

                   format =  "%5d %5d";
                   fprintf(fp4,format,JROW,JCOL);
                   for (JK=1;JK<=MVAR;JK++) fprintf(fp4,"%9.3f ",EST[JK]);
                   fprintf(fp4,"%9.3f\n",VAR);

//                   format =  "\n  NO. OF ITERATIONS OF ART =  %5d\n\n";
//                   fprintf(fp2,format,IIT);

                   for (IA = 1;IA<=MVAR;IA++) {
                       DUM5 = C[IA] - TEMP3[IA][IA] - TEMP2[IA][IA];
                       format =  "   ROW =  %5d  COL =  %5d  VARIABLE =  %5d,     VARIANCE =  %10.3f\n";
                       fprintf(fp3,format,JROW,JCOL,IA,DUM5);
                   }
                }
             }
         }
     }
//csmk---------------------
//after
        for( i=1;i<=100;i++) {
           for ( j=1;j<=100;j++) {
              fprintf(fp7,"%10.5f",ATEMP[i][j]);
              if (j % 10 == 0) fprintf(fp7,"\n");
           }
           fprintf(fp7,"\n");
        }
//        fprintf(fp7,"\n\n");
//csmk----------------------

     fclose(fp1);
     fclose(fp2);
     fclose(fp3);
     fclose(fp4);
     fclose(fp5);
     fclose(fp6);
     fclose(fp7);
}

float Krig2D::COVAR(float &DIST,int &K)
{
     float B,DUM1,R3,RAN2,DR,SLOPE;
//...
//.......THIS FUNCTION EVALUATES THE model COVARIANCE ASSOCIATED
//.......WITH THE SEPARATION DISTANCE,DIST.
//...
     if (model[K] == 1) {
//.......SPHERICAL COVARIANCE
        if (DIST < RANGE[K]) {
           B =  C[K] - CO[K];
           DUM1 = CO[K] + B*(1.5*DIST/RANGE[K] - 0.5*pow(DIST/RANGE[K],3));
           if (fabs(DIST)<EPS) DUM1 = 0.0;
           return C[K] - DUM1;
        }
        else {
           return 0.0;
        }
     }
     else if (model[K] == 2) {
//.......GAUSSIAN COVARIANCE
        B    = C[K] - CO[K];
        R3   = 1.732050808;
        RAN2 = RANGE[K]/R3;
        DR   = pow(DIST/RAN2,2);
        DR   =  -DR;
        DUM1 = CO[K] + B*(1.0 - exp(DR));
        if (fabs(DIST)<EPS) DUM1 = 0.0;
        return C[K] - DUM1;
     }
     else if (model[K] == 3) {
//.......LINEAR COVARIANCE
        B     =  C[K] - CO[K];
        SLOPE =  B/RANGE[K];
        DUM1  =  CO[K] + SLOPE*DIST;
        if (fabs(DIST)<EPS) DUM1 = 0.0;
        return C[K] - DUM1;
     }
     return 0; // needless
}

float Krig2D::CROSS(float &DIST,int &K,int &IA,int &IB)
{
     float B,DUM1,DUM2,DUM3,DUM4,R3,RAN2,DR,SLOPE;
//...
//.......THIS FUNCTION EVALUATES THE CROSS-COVARIANCE VALUE
//.......CORRESPONDING TO THE DISTANCE, DIST.
//...
        if (cmodel[K] == 1) {
//.......SPHERICAL CROSS-COVARIANCE
           if (DIST < CRANGE[K]) {
              B =  CC[K] - CCO[K];
              DUM1 = CCO[K] + B*(1.5*DIST/CRANGE[K] - 0.5*pow(DIST/CRANGE[K],3));
              if (fabs(DIST)<EPS) DUM1 = 0.0;
              DUM2 = CC[K] - DUM1;
           }
           else DUM2       =  0.0;
        }
        else if (cmodel[K] == 2) {
//.......GAUSSIAN CROSS-COVARIANCE
           B  =  CC[K] - CCO[K];
           R3 =  1.732050808;
           RAN2 =  CRANGE[K] / R3;
           DR   =  pow(DIST/RAN2,2);
           DR   =  -DR;
           DUM1 =  CCO[K] + B*(1.0 - exp(DR));
           if (fabs(DIST)<EPS)  DUM1 = 0.0;
           DUM2       =  CC[K] - DUM1;
        }
        else if (cmodel[K] == 3) {
//.......LINEAR CROSS-COVARIANCE
           B          =  CC[K] - CCO[K];
           SLOPE      =  B/CRANGE[K];
           DUM1       =  CCO[K] + SLOPE*DIST;
           if (fabs(DIST)<EPS) DUM1 = 0.0;
           DUM2       =  CC[K] - DUM1;
        }

        DUM3 =  COVAR(DIST,IA);
        DUM4 =  COVAR(DIST,IB);

        return 0.5 * (DUM2 - DUM3 - DUM4);
}

//.......THIS SUBROUTINE INITIALIZES REAL ARRAYS
void  Krig2D::RZRO(float A[6][6],int i,int j)
{
        for (int K = 1; K <= i;K++) {
            for (int L = 1;L <= j;L++) {
                A[K][L] = 0.0;
            }
        }
        return;
}

//
//.......THIS FUNCTION COMPUTES THE TRACE OF THE SQUARE MATRIX, A
//
float Krig2D::TRACE(float A[6][6])
{
        float Trace = 0.0;
        for (int i = 1;i<=MVAR;i++) {
            Trace = Trace + A[i][i];
        }
        return Trace;
}

void  Krig2D::AFORM (float YCORD,float XCORD)
{
       int i,j;
       float IPOS[6];

       int M1,M2,II,JJ,KK,LL,MM,M5,NM,M7,NI,I7,K7,M6,KPOS,NK;
       int ITOT,JTOT,NTOT,LTOT;
       float DIFX,DIFY;
       float DISTAN;
       int IAB,IAC,IMOD,NA,IAD,K10,IAE,KZ2,IAF,K12,KZ,KW,K8,N1,N3;
       int JOUNT;
       M1 = INIT;
       M2 = INIT;
//
//      SUBROUTINE TO FORM INTERSAMPLE COVARIANCE MATRIX
//
       for (II = 1;II<=M1;II++) {
           NI = NHOLE[II];
           I7 = (II - 1) * MVAR;
           for (JJ = 1;JJ<=M2;JJ++) {
               if (JJ  >=  II) {
                  KPOS = 0;
                  NK = NHOLE[JJ];
                  DIFX = X[NI] - X[NK];
                  DIFY = Y[NI] - Y[NK];
                  K7 = (JJ - 1) * MVAR;
                  DISTAN = sqrt(pow(DIFX*cos(ANIS[1]) + DIFY*sin(ANIS[1]),2)
                     + pow(RATIO[1]*(DIFY*cos(ANIS[1]) - DIFX * sin(ANIS[1])),2));
                  for (KK = 1;KK<=MVAR;KK++) {
                      ITOT = I7 + KK;
                      JTOT = K7 + KK;
                      for (LL = 1;LL<=MVAR;LL++) {
                          LTOT = I7 + LL;
                          NTOT = K7 + LL;
                          if (LL == KK) {
                             ATEMP[ITOT][NTOT] = COVAR(DISTAN,LL);
                             ATEMP[NTOT][ITOT] = ATEMP[ITOT][NTOT];
                          }
                          else if  (LL  >  KK)  {
                             KPOS = KPOS + 1;
                             ATEMP[ITOT][NTOT] = CROSS(DISTAN,KPOS,KK,LL);
                             ATEMP[LTOT][JTOT] = ATEMP[ITOT][NTOT];
                             ATEMP[NTOT][ITOT] = ATEMP[ITOT][NTOT];
                             ATEMP[JTOT][LTOT] = ATEMP[LTOT][JTOT];
                          }
                      }
                  }
               }
           }

           M5 = INIT * MVAR;                   // FORM THE IDENTITY MATRICES
           for (MM = 1;MM<=MVAR;MM++) {
               M6 = I7 + MM;
               for (NM = 1;NM<=MVAR;NM++) {
                   M7 = M5 + NM;
                   if (MM == NM) ATEMP[M6][M7] = 1.0;
                   if (MM  !=  NM) ATEMP[M6][M7] = 0.0;
                   ATEMP[M7][M6] = ATEMP[M6][M7];
               }
           }
       }
       M5 = INIT * MVAR + 1;
       for (i = M5;i<=MTOT;i++) {
           for (j = M5;j<=MTOT;j++) {
               ATEMP[i][j]  =   0.0;
           }
       }

       if (IKRIG == 1) {   //      MODIFY ATEMP FOR UNDERSAMPLING
          for (IAB = 1;IAB<=M2;IAB++) {
              NK = NHOLE[IAB];
              IMOD = 0;
              for (IAC = 1;IAC<=KCOUNT;IAC++) {
                  NA = JUNSAM[IAC];
                  if (NK == NA) IMOD = 1;
              }
              if (IMOD == 1) {
                 JOUNT = 0;
                 for (IAD = 1;IAD<=MVAR;IAD++) {
                     if (fabs(DAT [NK][IAD]) < EPS) {
                        JOUNT = JOUNT + 1;
                        IPOS[JOUNT] = IAD;
                     }
                 }
                 K10 = (IAB - 1) * MVAR;
                 for (IAE = 1;IAE<=JOUNT;IAE++) {
                     KZ2 = K10 + IPOS[IAE];
                     for (IAF = 1;IAF<=MTOT;IAF++) {
                         ATEMP[KZ2][IAF] = 0.0;
                         ATEMP[IAF][KZ2] = 0.0;
                     }
                 }
                 ATEMP[KZ2][KZ2] = 10000000000.0;
              }
          }
       }

       for (II = 1;II<=M1;II++) { //      FORM THE MEASUREMENT VECTOR
           K7 = NHOLE[II];
           DIFX = XCORD - X[K7];
           DIFY = YCORD - Y[K7];
           KPOS = 0;
           K12 = (II - 1) * MVAR;
           DISTAN = sqrt(pow(DIFX*cos(ANIS[1]) + DIFY*sin(ANIS[1]),2) + pow(RATIO[1]*(DIFY*cos(ANIS[1]) - DIFX * sin(ANIS[1])),2));
           for (JJ = 1;JJ <= MVAR;JJ++) {
               KZ = K12 + JJ;
               for (KK = 1;KK<=MVAR;KK++) {
                   KW = K12 + KK;
                   if (KK == JJ) {
                      XMEAS[KZ][KK] = COVAR(DISTAN,KK);
                   }
                   else if(KK > JJ) {
                      KPOS = KPOS + 1;
                      XMEAS[KZ][KK] = CROSS(DISTAN,KPOS,JJ,KK);
                      XMEAS[KW][JJ] = XMEAS[KZ][KK];
                   }
               }
           }
       }
//
//      MODIFY THE MEASUREMENT VECTOR FOR UNDERSAMPLING
//
       if (IKRIG == 1) {
          for (II = 1;II<=M1;II++) {
              IMOD = 0;
              K7 = NHOLE[II];
              for (JJ = 1;JJ<=KCOUNT;JJ++) {
                  NA = JUNSAM[JJ];
                  if (K7 == NA)IMOD = 1;
              }
              if (IMOD == 1) {
                 JOUNT = 0;
                 for (KK = 1;KK<=MVAR;KK++)
                 if (fabs(DAT[K7][KK]) < EPS) {
                    JOUNT = JOUNT + 1;
                    IPOS[JOUNT] = KK;
                 }
             }
             K12 = (II - 1) * MVAR;
             for (LL = 1;LL<=JOUNT;LL++) {
                 K8 = K12 + IPOS[LL];
                 for (MM = 1;MM<=MVAR;MM++) {
                     XMEAS[K8][MM] = 0.0;
                 }
             }
          }
       }

//
//      LAST ENTRY IN THE MEASUREMENT VECTOR IS AN IDENTITY MATRIX
//
       N1 = M1 * MVAR;
       for (II = 1;II<=MVAR;II++) {
           N3 = N1 + II;
           for (JJ = 1;JJ<=MVAR;JJ++) {
               if (JJ == II) {
                  XMEAS[N3][JJ] = 1.0;
               }
               else if (JJ != II)  {
                  XMEAS[N3][JJ] = 0.0;
               }
           }
       }

       return;
}

void  Krig2D::EQSOLV()
{
       float XSTOR[101][6];//BUF[100],
       int i,j;
       int NSIZE,MBAND,N,LL,K,L,M;
       float P;
//......
//......THIS BANDED GAUSS ELIMINATION EQUATION SOLVER REPLACES
//......SUBROUTINE EQSOLV, CARR, ET. AL., 1985, P. 124.
//......
       for (i = 1;i<=MTOT;i++)
           for (j = 1;j<=MVAR;j++)
               XSTOR[i][j] = XMEAS[i][j];
//smk---------------------------------------------
       fprintf(fp6,"before %d %d\n",MTOT,MVAR);
       for (i=1;i<=MTOT;i++) {
           for (j=1;j<=MVAR;j++) {
               XTEMP[i][j] = 0;
               fprintf(fp6,"%f ",XMEAS[i][j]);
           }
           fprintf(fp6,"\n");
       }
//smk---------------------------------------------

//
//......BEGIN GAUSS DECOMPOSITION
//......STEP 1:  FORWARD REDUCTION
//
       NSIZE = MTOT;
       MBAND = MTOT + 1;
       for (N = 1;N<=NSIZE;N++) {
          LL = N + 1;
          if (fabs(ATEMP[N][N]) > EPS ) {
             for (L = LL;L<=MBAND;L++) {
                 P = ATEMP[N][L] / ATEMP[N][N];
                 j = L - 1;
                 for (K = L;K<=MBAND;K++) {
                     j = j + 1;
                     ATEMP[L][j] = ATEMP[L][j] - P*ATEMP[N][K];
                 }
                 ATEMP[N][L] = P;
             }
          }
       }
//
//......STEP 2:  REDUCE THE MEASUREMENT VECTOR
//
       for (K = 1;K<=MVAR;K++) {
           for (N = 1;N<=NSIZE;N++) {
               LL = N + 1;
               for (L = LL;L<=MBAND;L++) {
                   if (fabs(ATEMP[N][L]) > EPS) {
                      XMEAS[L][K] = XMEAS[L][K] - ATEMP[N][L] *XMEAS[N][K];
                   }
               }
               if (fabs(ATEMP[N][N]) >EPS ) {
                  XMEAS[N][K] = XMEAS[N][K] / ATEMP[N][N];
               }
           }
       }

//smk---------------------------------------------
       fprintf(fp6,"after %d %d\n",MTOT,MVAR);
       for (i=1;i<=MTOT;i++) {
           for (j=1;j<=MVAR;j++)
               fprintf(fp6,"%f ",XMEAS[i][j]);
           fprintf(fp6,"\n");
       }
//smk---------------------------------------------

//
//......STEP 3:  SOLVE FOR COKRIGING WEIGHTS
//
       for (i = 1;i<=NSIZE;i++) {
           for (j = 1;j<=MVAR;j++) {
               XTEMP[i][j] = XMEAS[i][j];
           }
       }

       for (i = 1;i<=MVAR;i++) {
           for (M = 2;M<=NSIZE;M++) {
               N = NSIZE + 1 - M;
               LL = N + 1;
               for (L = LL;L<=MBAND;L++) {
                   if (fabs(ATEMP[N][L]) > EPS) {
                      XTEMP[N][i] = XTEMP[N][i] - ATEMP[N][L] * XTEMP[L][i];
                   }
               }
           }
       }

//
//      RESTORE THE MEASUREMENT VECTOR
//
       for (i = 1;i<=MTOT;i++) {
           for (j = 1;j<=MVAR;j++) {
               XMEAS[i][j] = XSTOR[i][j];
           }
       }
       return;

}

//---------------------------------------------------------------------------
#pragma package(smart_init)

