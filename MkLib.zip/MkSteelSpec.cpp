//---------------------------------------------------------------------------
#include "MkSteelSpec.h"

#ifdef __BCPLUSPLUS__
#include <vcl.h>
#endif

#pragma hdrstop

//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#pragma package(smart_init)
#endif
//---------------------------------------------------------------------------

MkSteel NullMkSteel(0);

MkSteel::MkSteel()
{
  Clear();
}

MkSteel::MkSteel(int)
{
  Clear();
}

void MkSteel::Clear()
{
#ifdef __BCPLUSPLUS__
  steelname="";
  steelkind="";
#else
  memset(steelname,'\0',255);
  memset(steelkind,'\0',255);
#endif
  OldSteel=0;
  LongTimeSteel=0;
  OldSteelReduction=0;
  LongTimeSteelReduction=0;
}

#ifdef __BCPLUSPLUS__
void MkSteel::Import(MkGlobalVar &globalvar,int sec, int tan)
{
  steelname= (LPCTSTR)globalvar.steelname[sec+1][tan+1];
  steelkind= (LPCTSTR)globalvar.steelkind[sec+1][tan+1];
  OldSteel= globalvar.OldSteel[sec+1][tan+1];
  LongTimeSteel= globalvar.LongTimeSteel[sec+1][tan+1];
  OldSteelReduction= globalvar.OldSteelReduction[sec+1][tan+1];
  LongTimeSteelReduction = globalvar.LongTimeSteelReduction[sec+1][tan+1];
}

void MkSteel::Export(MkGlobalVar &globalvar, int sec, int tan)
{
  globalvar.steelname[sec+1][tan+1]= steelname.c_str();
  globalvar.steelkind[sec+1][tan+1]= steelkind.c_str();
  globalvar.OldSteel[sec+1][tan+1]= OldSteel;
  globalvar.LongTimeSteel[sec+1][tan+1]= LongTimeSteel;
  globalvar.OldSteelReduction[sec+1][tan+1]= OldSteelReduction;
  globalvar.LongTimeSteelReduction[sec+1][tan+1] = LongTimeSteelReduction;
}
#endif

MkSteels::MkSteels(int size,MkSteel *steels)
{
    if (size < 0) {
      MkDebug("::MkSteels - MkSteels(int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSize == 0) {
       FSteel = NULL;
       return;
    }

    FSteel = new MkSteel[FSize];
    for (int i=0;i<FSize;i++) (*this)[i] = steels[i];
}

MkSteels::MkSteels(int size)
{
    if (size < 0) {
      MkDebug("::MkSteels - MkSteels(int size)");;
      return;
    }

    FSize = FSizeOfArray = size;

    if (FSizeOfArray == 0) {
       FSteel = NULL;
       return;
    }

    FSteel = new MkSteel[FSizeOfArray];
}

MkSteels::~MkSteels()
{
   FSizeOfArray = FSize = 0;
   if (FSteel) {
      delete[] FSteel;
      FSteel = NULL;
   }
}

void MkSteels::Initialize(int size)
{
    if (size < 0) {
      MkDebug("::MkSteels - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;

    FSize = FSizeOfArray = size;

    if (FSizeOfArray == 0) {
       if (FSteel!=NULL) delete[] (MkSteel*)FSteel;
       FSteel = NULL;
       return;
    }

    if (FSteel!=NULL) delete[] (MkSteel*)FSteel;
    FSteel = new MkSteel[FSizeOfArray];
}

void MkSteels::Initialize(int size,MkSteel *steels)
{

    if (size < 0 || steels == NULL) {
      MkDebug("::MkSteels - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSize = FSizeOfArray = size;
    if (FSizeOfArray == 0) {
       if (FSteel!=NULL) delete[] (MkSteel*)FSteel;
       FSteel = NULL;
       return;
    }

    if (FSteel!=NULL) delete[] (MkSteel*)FSteel;
    FSteel = new MkSteel[FSizeOfArray];
    for (int i=0;i<FSizeOfArray;i++) FSteel[i] = steels[i];
}

int MkSteels::Grow(int delta)
{
    int i;
    MkSteel *steel=NULL;

    if (!(steel = new MkSteel[FSizeOfArray+delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        steel[i] = FSteel[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        steel[i] = NullMkSteel;
    if (FSteel) {
       delete[] (MkSteel*)FSteel;
       FSteel = NULL;
    }
    FSteel = steel;
    FSizeOfArray = FSizeOfArray+delta;

    return FSizeOfArray;
}

int MkSteels::Shrink(int delta)
{
    int i;
    MkSteel *steel=NULL;

    if (!(steel = new MkSteel[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        steel[i] = FSteel[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        steel[i] = NullMkSteel;
    if (FSteel) {
       delete[] (MkSteel*)FSteel;
       FSteel = NULL;
    }
    FSteel = steel;
    FSizeOfArray = FSizeOfArray-delta;

    return FSizeOfArray;
}

bool MkSteels::Add(MkSteel &steel)
{
    int tmp=FSizeOfArray;
    bool flag=false;
    for (int i=0;i<FSize;i++) if (FSteel[i]==steel) flag=true;

    if(flag) return false;
    if (FSize>=FSizeOfArray) {
       Grow(FSize-FSizeOfArray+10);
       if (tmp==FSizeOfArray) return false;
    }
    FSize++;
    FSteel[FSize-1] = steel;

    return true;
}

bool MkSteels::Add(int index, MkSteel &steel)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) Grow(FSize-FSizeOfArray+1);
    if(tmp==FSizeOfArray) return false;

    for (int i=FSize-1;i>=index;i--)
      FSteel[i+1] = FSteel[i];
    FSize++;
    FSteel[index] = steel;
    return true;
}

bool MkSteels::Delete(MkSteel &steel)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FSteel[i] == steel) break;
    }
    if(i==FSize) return false;
    if(FSteel[i] == steel) {
      for (int j=i;j<FSize-1;j++)
        FSteel[j] = FSteel[j+1];
    }
    FSize--;
    FSteel[FSize] = NullMkSteel;
    return true;
}

bool MkSteels::Delete(int index)
{
    for (int j=index;j<FSize-1;j++)
        FSteel[j] = FSteel[j+1];

    FSize--;
    FSteel[FSize] = NullMkSteel;
    return true;
}

bool MkSteels::Clear()
{
   FSizeOfArray = FSize = 0;
   if (FSteel) {
      delete[] FSteel;
      FSteel = NULL;
   }
   return true;
}

MkSteel & MkSteels::operator[](int i)
{
    if (FSizeOfArray == 0) return NullMkSteel;
    if (i >= FSize && i < FSizeOfArray) FSize = i+1;

    if (i >=0 && i < FSize) return FSteel[i];
    else return NullMkSteel;
}

MkSteels & MkSteels::operator=(MkSteels &steels)
{
    int i;

    Clear();
    FSize = steels.FSize;
    FSizeOfArray = steels.FSizeOfArray;
    if (FSize == 0) {
       FSteel = NULL;
       return *this;
    }
    this->FSteel = new MkSteel[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FSteel[i] = steels.FSteel[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FSteel[i] = NullMkSteel;

    return *this;
}

bool MkSteels::operator==(MkSteels &steels)
{
  int i;

  if (FSize != steels.FSize) return false;
  for (i=0;i<FSize;i++)
    if (this->FSteel[i] != steels.FSteel[i]) return false;

  return true;
}

#ifdef __BCPLUSPLUS__
void MkSteels::Import(MkGlobalVar &globalvar, int sec)
{
  int i;
  for (i=0;i<FSize && i<14;i++) {
    FSteel[i].Import(globalvar,sec,i);
  }
}

void MkSteels::Export(MkGlobalVar &globalvar, int sec)
{
  int i;
  for (i=0;i<FSize && i<14;i++) {
    FSteel[i].Export(globalvar,sec,i);
  }
}
#endif
//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
AnsiString MkMainBeamSpec::steelname()
{
  return name;
}

AnsiString MkMainBeamSpec::steelkind()
{
  return kind;
}

void MkMainBeamSpec::ImportFromSteel(MkSteel &steel)
{
  name = steel.steelname;
  kind = steel.steelkind;
}

#else
char* MkMainBeamSpec::steelname()
{
  return name;
}

char* MkMainBeamSpec::steelkind()
{
  return kind;
}

void MkMainBeamSpec::ImportFromSteel(MkSteel &steel)
{
  strcpy(name,steel.steelname);
  strcpy(kind,steel.steelkind);
}
#endif
//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
AnsiString MkSupportBeamSpec::steelname()
{
  return name;
}

AnsiString MkSupportBeamSpec::steelkind()
{
  return kind;
}

void MkSupportBeamSpec::ImportFromSteel(MkSteel &steel)
{
  name = steel.steelname;
  kind = steel.steelkind;
}
#else
char* MkSupportBeamSpec::steelname()
{
  return name;
}

char* MkSupportBeamSpec::steelkind()
{
  return kind;
}

void MkSupportBeamSpec::ImportFromSteel(MkSteel &steel)
{
  strcpy(name,steel.steelname);
  strcpy(kind,steel.steelkind);
}
#endif
//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
AnsiString MkSidePileSpec::steelname()
{
  return name;
}

AnsiString MkSidePileSpec::steelkind()
{
  return kind;
}

void MkSidePileSpec::ImportFromSteel(MkSteel &steel)
{
  name = steel.steelname;
  kind = steel.steelkind;
}
#else
char* MkSidePileSpec::steelname()
{
  return name;
}

char* MkSidePileSpec::steelkind()
{
  return kind;
}

void MkSidePileSpec::ImportFromSteel(MkSteel &steel)
{
  strcpy(name,steel.steelname);
  strcpy(kind,steel.steelkind);
}
#endif
//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
AnsiString MkMidPileSpec::steelname()
{
  return name;
}

AnsiString MkMidPileSpec::steelkind()
{
  return kind;
}

void MkMidPileSpec::ImportFromSteel(MkSteel &steel)
{
  name = steel.steelname;
  kind = steel.steelkind;
}
#else
char* MkMidPileSpec::steelname()
{
  return name;
}

char* MkMidPileSpec::steelkind()
{
  return kind;
}

void MkMidPileSpec::ImportFromSteel(MkSteel &steel)
{
  strcpy(name,steel.steelname);
  strcpy(kind,steel.steelkind);
}
#endif
//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
AnsiString MkStrutSpec::steelname()
{
  return name;
}

AnsiString MkStrutSpec::steelkind()
{
  return kind;
}

void MkStrutSpec::ImportFromSteel(MkSteel &steel)
{
  name = steel.steelname;
  kind = steel.steelkind;
}
#else
char* MkStrutSpec::steelname()
{
  return name;
}

char* MkStrutSpec::steelkind()
{
  return kind;
}

void MkStrutSpec::ImportFromSteel(MkSteel &steel)
{
  strcpy(name,steel.steelname);
  strcpy(kind,steel.steelkind);
}
#endif
//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
AnsiString MkWaleSpec::steelname()
{
  return name;
}

AnsiString MkWaleSpec::steelkind()
{
  return kind;
}

void MkWaleSpec::ImportFromSteel(MkSteel &steel)
{
  name = steel.steelname;
  kind = steel.steelkind;
}
#else
char* MkWaleSpec::steelname()
{
  return name;
}

char* MkWaleSpec::steelkind()
{
  return kind;
}

void MkWaleSpec::ImportFromSteel(MkSteel &steel)
{
  strcpy(name,steel.steelname);
  strcpy(kind,steel.steelkind);
}
#endif
//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
AnsiString MkBracingSpec::steelname()
{
  return name;
}

AnsiString MkBracingSpec::steelkind()
{
  return kind;
}

void MkBracingSpec::ImportFromSteel(MkSteel &steel)
{
  name = steel.steelname;
  kind = steel.steelkind;
}
#else
char* MkBracingSpec::steelname()
{
  return name;
}

char* MkBracingSpec::steelkind()
{
  return kind;
}

void MkBracingSpec::ImportFromSteel(MkSteel &steel)
{
  strcpy(name,steel.steelname);
  strcpy(kind,steel.steelkind);
}
#endif
//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
AnsiString MkBracketSpec::steelname()
{
  AnsiString res = name+" "+lenum;
  return res;
}

AnsiString MkBracketSpec::steelkind()
{
  return kind;
}

void MkBracketSpec::ImportFromSteel(MkSteel &steel)
{
  int pos,len;
  if(steel.steelname.Length()>0) {
    pos = steel.steelname.LastDelimiter(" ");
    len = steel.steelname.Length();

    name = steel.steelname.SubString(0,pos-1);
    lenum = steel.steelname.SubString(pos+1,length-1);
  }
  kind = steel.steelkind;
}
#else
char* MkBracketSpec::steelname()
{
  return NULL;
}

char* MkBracketSpec::steelkind()
{
  return NULL;
}

void MkBracketSpec::ImportFromSteel(MkSteel &steel)
{

}
#endif
//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
AnsiString MkBoltSpec::steelname()
{
  AnsiString res = dia+", L="+len;
  return res;
}

AnsiString MkBoltSpec::steelkind()
{
  return kind;
}

void MkBoltSpec::ImportFromSteel(MkSteel &steel)
{
  int pos,length;
  if(steel.steelname.Length()) {
    pos = steel.steelname.LastDelimiter(" ");
    length = steel.steelname.Length();

    dia = steel.steelname.SubString(1,pos-2);
    len = steel.steelname.SubString(pos+3,length-1).ToDouble();
  }
  kind = steel.steelkind;
}
#else
char* MkBoltSpec::steelname()
{
  return NULL;
}

char* MkBoltSpec::steelkind()
{
  return NULL;
}

void MkBoltSpec::ImportFromSteel(MkSteel &steel)
{

}
#endif
//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
AnsiString MkAnchorSpec::steelname()
{
  AnsiString res = name+" "+num;
  return res;
}

AnsiString MkAnchorSpec::steelkind()
{
  return kind;
}

void MkAnchorSpec::ImportFromSteel(MkSteel &steel)
{
  int pos,len;
  if(steel.steelname.Length()) {
    pos = steel.steelname.LastDelimiter(" ");
    len = steel.steelname.Length();

    name = steel.steelname.SubString(1,pos-1);
    num = steel.steelname.SubString(pos+1,len-1);
  }
  kind = steel.steelkind;
}
#else
char* MkAnchorSpec::steelname()
{
  return NULL;
}

char* MkAnchorSpec::steelkind()
{
  return NULL;
}

void MkAnchorSpec::ImportFromSteel(MkSteel &steel)
{
}
#endif
//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
AnsiString MkTimberSpec::steelname()
{
  AnsiString res = AnsiString("����� ")+type;
  return res;
}

AnsiString MkTimberSpec::steelkind()
{
  AnsiString res = AnsiString("t=")+thick;
  return res;
}

void MkTimberSpec::ImportFromSteel(MkSteel &steel)
{
  int pos,len;
  if(steel.steelname.Length()) {
    pos = steel.steelname.LastDelimiter(" ");
    len = steel.steelname.Length();
    type = steel.steelname.SubString(pos+1,length-1);
  }

  if(steel.steelkind.Length()) {
    pos = steel.steelkind.LastDelimiter("=");
    len = steel.steelkind.Length();
    thick = steel.steelkind.SubString(pos+1,len-1).ToDouble();
  }
}
#else
char* MkTimberSpec::steelname()
{
  return NULL;
}

char* MkTimberSpec::steelkind()
{
  return NULL;
}

void MkTimberSpec::ImportFromSteel(MkSteel &steel)
{
}
#endif
//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
AnsiString MkConcWallSpec::steelname()
{
  AnsiString res = AnsiString("����� ")+type+" "+dia+" "+AnsiString("CTC")+space;
  return res;
}

AnsiString MkConcWallSpec::steelkind()
{
  return strength;
}

void MkConcWallSpec::ImportFromSteel(MkSteel &steel)
{
  int pos,len;
  AnsiString sub;

  if(steel.steelname.Length()) {
    pos = steel.steelname.Pos("CTC");
    len = steel.steelname.Length();

    space = steel.steelname.SubString(pos+3,len-1).ToDouble();

    sub = steel.steelname.SubString(0,pos-1);
    pos = sub.LastDelimiter(" ");
    len = sub.Length();

    dia = sub.SubString(pos+1,len-1);

    sub = steel.steelname.SubString(0,pos-1);
    pos = sub.LastDelimiter(" ");
    len = sub.Length();

    type = sub.SubString(pos+1,len-1);
  }

  strength = steel.steelkind;
}
#else
char* MkConcWallSpec::steelname()
{
  return NULL;
}

char* MkConcWallSpec::steelkind()
{
  return NULL;
}

void MkConcWallSpec::ImportFromSteel(MkSteel &steel)
{

}
#endif
//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
AnsiString MkBeamHangerSpec::steelname()
{
  AnsiString res = type+" "+name;
  return res;
}

AnsiString MkBeamHangerSpec::steelkind()
{
  return kind;
}

void MkBeamHangerSpec::ImportFromSteel(MkSteel &steel)
{
  int pos,len;
  if(steel.steelname.Length()) {
    pos = steel.steelname.LastDelimiter(" ");
    len = steel.steelname.Length();

    name = steel.steelname.SubString(pos+1,len-1);
    type = steel.steelname.SubString(0,pos-1);
  }
  kind = steel.steelkind;
}
#else
char* MkBeamHangerSpec::steelname()
{
  return NULL;
}

char* MkBeamHangerSpec::steelkind()
{
  return NULL;
}

void MkBeamHangerSpec::ImportFromSteel(MkSteel &steel)
{
}
#endif
//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
AnsiString MkSpec::steelname(int i)
{
  switch(i) {
    case 0 : return MainBeam.steelname();
    case 1 : return SupportBeam.steelname();
    case 2 : return SupportBeam_M.steelname();
    case 3 : return SidePile.steelname();
    case 4 : return MidPile.steelname();
    case 5 : return Strut.steelname();
    case 6 : return Wale.steelname();
    case 7 : return Bracing.steelname();
    case 8 : return Bracket.steelname();
    case 9 : return Bracket_M.steelname();
    case 10 : return Bolt.steelname();
    case 11 : return Anchor.steelname();
    case 12 : if(WallType==wtTimber) return Timber.steelname(); else return ConcWall.steelname();
    case 13 : return BeamHanger.steelname();
  }
}

AnsiString MkSpec::steelkind(int i)
{
  switch(i) {
    case 0 : return MainBeam.steelkind();
    case 1 : return SupportBeam.steelkind();
    case 2 : return SupportBeam_M.steelkind();
    case 3 : return SidePile.steelkind();
    case 4 : return MidPile.steelkind();
    case 5 : return Strut.steelkind();
    case 6 : return Wale.steelkind();
    case 7 : return Bracing.steelkind();
    case 8 : return Bracket.steelkind();
    case 9 : return Bracket_M.steelkind();
    case 10 : return Bolt.steelkind();
    case 11 : return Anchor.steelkind();
    case 12 : if(WallType==wtTimber) return Timber.steelkind(); else return ConcWall.steelkind();
    case 13 : return BeamHanger.steelkind();
  }
}

void MkSpec::ExportToSteel(MkSteels &steel)
{
  int i;
  for (i=0;i<14;i++) {
    steel[i].steelname = steelname(i);
    steel[i].steelkind = steelkind(i);
  }
}

void MkSpec::ImportFromSteel(MkSteels &steel)
{
  MainBeam.ImportFromSteel(steel[0]);
  SupportBeam.ImportFromSteel(steel[1]);
  SupportBeam_M.ImportFromSteel(steel[2]);
  SidePile.ImportFromSteel(steel[3]);
  MidPile.ImportFromSteel(steel[4]);
  Strut.ImportFromSteel(steel[5]);
  Wale.ImportFromSteel(steel[6]);
  Bracing.ImportFromSteel(steel[7]);
  Bracket.ImportFromSteel(steel[8]);
  Bracket_M.ImportFromSteel(steel[9]);
  Bolt.ImportFromSteel(steel[10]);
  Anchor.ImportFromSteel(steel[11]);
  if(AnsiString("�����")==steel[12].steelname.SubString(1,6)) WallType=wtTimber;
  else WallType=wtConcWall;
  if(WallType==wtTimber) return Timber.ImportFromSteel(steel[12]); else return ConcWall.ImportFromSteel(steel[12]);
  return BeamHanger.ImportFromSteel(steel[13]);
}
#else
char* MkSpec::steelname(int i)
{
  switch(i) {
    case 0 : return MainBeam.steelname();
    case 1 : return SupportBeam.steelname();
    case 2 : return SupportBeam_M.steelname();
    case 3 : return SidePile.steelname();
    case 4 : return MidPile.steelname();
    case 5 : return Strut.steelname();
    case 6 : return Wale.steelname();
    case 7 : return Bracing.steelname();
    case 8 : return Bracket.steelname();
    case 9 : return Bracket_M.steelname();
    case 10 : return Bolt.steelname();
    case 11 : return Anchor.steelname();
    case 12 : if(WallType==wtTimber) return Timber.steelname(); else return ConcWall.steelname();
    case 13 : return BeamHanger.steelname();
  }
}

char* MkSpec::steelkind(int i)
{
  switch(i) {
    case 0 : return MainBeam.steelkind();
    case 1 : return SupportBeam.steelkind();
    case 2 : return SupportBeam_M.steelkind();
    case 3 : return SidePile.steelkind();
    case 4 : return MidPile.steelkind();
    case 5 : return Strut.steelkind();
    case 6 : return Wale.steelkind();
    case 7 : return Bracing.steelkind();
    case 8 : return Bracket.steelkind();
    case 9 : return Bracket_M.steelkind();
    case 10 : return Bolt.steelkind();
    case 11 : return Anchor.steelkind();
    case 12 : if(WallType==wtTimber) return Timber.steelkind(); else return ConcWall.steelkind();
    case 13 : return BeamHanger.steelkind();
  }
}

void MkSpec::ExportToSteel(MkSteels &steel)
{
  int i;
  for (i=0;i<14;i++) {
    strcpy(steel[i].steelname,steelname(i));
    strcpy(steel[i].steelkind,steelkind(i));
  }
}

void MkSpec::ImportFromSteel(MkSteels &steel)
{
  MainBeam.ImportFromSteel(steel[0]);
  SupportBeam.ImportFromSteel(steel[1]);
  SupportBeam_M.ImportFromSteel(steel[2]);
  SidePile.ImportFromSteel(steel[3]);
  MidPile.ImportFromSteel(steel[4]);
  Strut.ImportFromSteel(steel[5]);
  Wale.ImportFromSteel(steel[6]);
  Bracing.ImportFromSteel(steel[7]);
  Bracket.ImportFromSteel(steel[8]);
  Bracket_M.ImportFromSteel(steel[9]);
  Bolt.ImportFromSteel(steel[10]);
  Anchor.ImportFromSteel(steel[11]);
  if(strcmp("����� ",steel[12].steelname)==0) WallType=wtTimber;
  else WallType=wtConcWall;
  if(WallType==wtTimber) return Timber.ImportFromSteel(steel[12]); else return ConcWall.ImportFromSteel(steel[12]);
  return BeamHanger.ImportFromSteel(steel[13]);
}
#endif
//---------------------------------------------------------------------------

