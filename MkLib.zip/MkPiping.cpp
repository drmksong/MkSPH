#include "stdafx.h"
#include "MkPiping.h"

MkPiping::MkPiping()
{
  Gamma = GammaWat = Iav = 0;
}

float MkPiping::GetFS()
{
  if(fabs(Iav*GammaWat)<EPS) return 0;
  return Gamma/GammaWat/Iav;
}
