//---------------------------------------------------------------------------
#ifndef MkPileSectionH
#define MkPileSectionH

#ifdef __BCPLUSPLUS__
#include "GlobalVarUnit.h"
#endif

#include "MkObject.h"
#include "MkBracing.h"
#include "MkLane.h"
//---------------------------------------------------------------------------
class MkPileSection : public MkObject {
public:
  int bracingtype;
  int bracing_ea;
  int bracingNN;
  double piledist;
  MkBracings bracing;
  MkLanes lane;
public:
  MkPileSection();
  MkPileSection(int);
  ~MkPileSection(){}
  void Clear();
};

class MkPileSections { // ����
protected:
  MkPileSection *FPileSection;
  int FSize;//Actual size of nodes
  int FSizeOfArray;
public:
  MkPileSections(int size,MkPileSection *pilesection);
  MkPileSections(int size);
  MkPileSections(){FSizeOfArray = FSize = 0;FPileSection = NULL;}
  ~MkPileSections();

  virtual void Initialize(int size);
  virtual void Initialize(int size,MkPileSection *);
  int GetSize(){return FSize;};
  int GetNumber(){return FSize;};
  bool Add(MkPileSection &pilesection);  // change of size of pilesection
  bool Add(int index,MkPileSection &pilesection);
  bool Delete(MkPileSection &pilesection);  // change of size of pilesection
  bool Delete(int index);
  int Grow(int Delta);            // change of size of array
  int Shrink(int Delta);          // change of size of array
  bool Clear();
  virtual MkPileSection & operator[](int);
  MkPileSections & operator=(MkPileSections &pilesections);
  bool operator==(MkPileSections &pilesections);
#ifdef __BCPLUSPLUS__
  void Import(MkGlobalVar &globalvar, int sec);
  void Export(MkGlobalVar &globalvar, int sec);
#endif
};
extern MkPileSection NullMkPileSection;
#endif
 
