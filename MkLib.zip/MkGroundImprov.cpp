//---------------------------------------------------------------------------
#include "MkGroundImprov.h"
#ifdef __BCPLUSPLUS__
#include <vcl.h>
#endif
#pragma hdrstop

//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#pragma package(smart_init)
#endif
//---------------------------------------------------------------------------
MkGroundImprov NullMkGroundImprov(0);
MkGroundImprov::MkGroundImprov()
{
  Clear();
}

MkGroundImprov::MkGroundImprov(int)
{
  Clear();
}

void MkGroundImprov::Clear()
{
  width=0;
  ctc=0;
  rctc=0;
  row=0;
  layer=0;
#ifdef __BCPLUSPLUS__
  kind="";
#else
  memset(kind,'\0',255);
#endif

}

#ifdef __BCPLUSPLUS__
void MkGroundImprov::Import(MkGlobalVar &globalvar,int tan)
{
  width=globalvar.jibanbogang_width[tan+1];
  ctc  =globalvar.jibanbogang_ctc[tan+1];
  rctc =globalvar.jibanbogang_rctc[tan+1];
  row  =globalvar.jibanbogang_row[tan+1];
  layer=globalvar.jibanboganglayer;
  kind =(LPCTSTR)globalvar.jibanbogang_kind[tan+1];
}

void MkGroundImprov::Export(MkGlobalVar &globalvar, int tan)
{
  globalvar.jibanbogang_width[tan+1]=width;
  globalvar.jibanbogang_ctc[tan+1]=ctc;
  globalvar.jibanbogang_rctc[tan+1]=rctc;
  globalvar.jibanbogang_row[tan+1]=row;
  globalvar.jibanboganglayer=layer;
  globalvar.jibanbogang_kind[tan+1]=kind.c_str();
}
#endif

MkGroundImprovs::MkGroundImprovs(int size,MkGroundImprov *jibanbogangs)
{
    if (size < 0) {
      MkDebug("::MkGroundImprovs - MkGroundImprovs(int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSize == 0) {
       FGroundImprov = NULL;
       return;
    }

    FGroundImprov = new MkGroundImprov[FSize];
    for (int i=0;i<FSize;i++) (*this)[i] = jibanbogangs[i];
}

MkGroundImprovs::MkGroundImprovs(int size)
{
    if (size < 0) {
      MkDebug("::MkGroundImprovs - MkGroundImprovs(int size)");;
      return;
    }

    FSize = FSizeOfArray = size;

    if (FSizeOfArray == 0) {
       FGroundImprov = NULL;
       return;
    }

    FGroundImprov = new MkGroundImprov[FSizeOfArray];
}

MkGroundImprovs::~MkGroundImprovs()
{
   FSizeOfArray = FSize = 0;
   if (FGroundImprov) {
      delete[] FGroundImprov;
      FGroundImprov = NULL;
   }
}

void MkGroundImprovs::Initialize(int size)
{
    if (size < 0) {
      MkDebug("::MkGroundImprovs - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;

    FSize = FSizeOfArray = size;

    if (FSizeOfArray == 0) {
       if (FGroundImprov!=NULL) delete[] (MkGroundImprov*)FGroundImprov;
       FGroundImprov = NULL;
       return;
    }

    if (FGroundImprov!=NULL) delete[] (MkGroundImprov*)FGroundImprov;
    FGroundImprov = new MkGroundImprov[FSizeOfArray];
}

void MkGroundImprovs::Initialize(int size,MkGroundImprov *jibanbogangs)
{

    if (size < 0 || jibanbogangs == NULL) {
      MkDebug("::MkGroundImprovs - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSize = FSizeOfArray = size;
    if (FSizeOfArray == 0) {
       if (FGroundImprov!=NULL) delete[] (MkGroundImprov*)FGroundImprov;
       FGroundImprov = NULL;
       return;
    }

    if (FGroundImprov!=NULL) delete[] (MkGroundImprov*)FGroundImprov;
    FGroundImprov = new MkGroundImprov[FSizeOfArray];
    for (int i=0;i<FSizeOfArray;i++) FGroundImprov[i] = jibanbogangs[i];
}

int MkGroundImprovs::Grow(int delta)
{
    int i;
    MkGroundImprov *jibanbogang=NULL;

    if (!(jibanbogang = new MkGroundImprov[FSizeOfArray+delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        jibanbogang[i] = FGroundImprov[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        jibanbogang[i] = NullMkGroundImprov;
    if (FGroundImprov) {
       delete[] (MkGroundImprov*)FGroundImprov;
       FGroundImprov = NULL;
    }
    FGroundImprov = jibanbogang;
    FSizeOfArray = FSizeOfArray+delta;

    return FSizeOfArray;
}

int MkGroundImprovs::Shrink(int delta)
{
    int i;
    MkGroundImprov *jibanbogang=NULL;

    if (!(jibanbogang = new MkGroundImprov[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        jibanbogang[i] = FGroundImprov[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        jibanbogang[i] = NullMkGroundImprov;
    if (FGroundImprov) {
       delete[] (MkGroundImprov*)FGroundImprov;
       FGroundImprov = NULL;
    }
    FGroundImprov = jibanbogang;
    FSizeOfArray = FSizeOfArray-delta;

    return FSizeOfArray;
}

bool MkGroundImprovs::Add(MkGroundImprov &jibanbogang)
{
    int tmp=FSizeOfArray;
    bool flag=false;
    for (int i=0;i<FSize;i++) if (FGroundImprov[i]==jibanbogang) flag=true;

    if(flag) return false;
    if (FSize>=FSizeOfArray) {
       Grow(FSize-FSizeOfArray+10);
       if (tmp==FSizeOfArray) return false;
    }
    FSize++;
    FGroundImprov[FSize-1] = jibanbogang;

    return true;
}

bool MkGroundImprovs::Add(int index, MkGroundImprov &jibanbogang)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) Grow(FSize-FSizeOfArray+1);
    if(tmp==FSizeOfArray) return false;

    for (int i=FSize-1;i>=index;i--)
      FGroundImprov[i+1] = FGroundImprov[i];
    FSize++;
    FGroundImprov[index] = jibanbogang;
    return true;
}

bool MkGroundImprovs::Delete(MkGroundImprov &jibanbogang)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FGroundImprov[i] == jibanbogang) break;
    }
    if(i==FSize) return false;
    if(FGroundImprov[i] == jibanbogang) {
      for (int j=i;j<FSize-1;j++)
        FGroundImprov[j] = FGroundImprov[j+1];
    }
    FSize--;
    FGroundImprov[FSize] = NullMkGroundImprov;
    return true;
}

bool MkGroundImprovs::Delete(int index)
{
    for (int j=index;j<FSize-1;j++)
        FGroundImprov[j] = FGroundImprov[j+1];

    FSize--;
    FGroundImprov[FSize] = NullMkGroundImprov;
    return true;
}

bool MkGroundImprovs::Clear()
{
   FSizeOfArray = FSize = 0;
   if (FGroundImprov) {
      delete[] FGroundImprov;
      FGroundImprov = NULL;
   }
   return true;
}

MkGroundImprov & MkGroundImprovs::operator[](int i)
{
    if (FSizeOfArray == 0) return NullMkGroundImprov;
    if (i >= FSize && i < FSizeOfArray) FSize = i+1;

    if (i >=0 && i < FSize) return FGroundImprov[i];
    else return NullMkGroundImprov;
}

MkGroundImprovs & MkGroundImprovs::operator=(MkGroundImprovs &jibanbogangs)
{
    int i;

    Clear();
    FSize = jibanbogangs.FSize;
    FSizeOfArray = jibanbogangs.FSizeOfArray;
    if (FSize == 0) {
       FGroundImprov = NULL;
       return *this;
    }
    this->FGroundImprov = new MkGroundImprov[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FGroundImprov[i] = jibanbogangs.FGroundImprov[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FGroundImprov[i] = NullMkGroundImprov;

    return *this;
}

bool MkGroundImprovs::operator==(MkGroundImprovs &jibanbogangs)
{
  int i;

  if (FSize != jibanbogangs.FSize) return false;
  for (i=0;i<FSize;i++)
    if (this->FGroundImprov[i] != jibanbogangs.FGroundImprov[i]) return false;

  return true;
}

#ifdef __BCPLUSPLUS__
void MkGroundImprovs::Import(MkGlobalVar &globalvar)
{
  int i;
  for(i=0;i<FSize && i<20;i++) {
   FGroundImprov[i].Import(globalvar,i);
  }
}

void MkGroundImprovs::Export(MkGlobalVar &globalvar)
{
  int i;
  for(i=0;i<FSize && i<20;i++) {
    FGroundImprov[i].Export(globalvar,i);
  }
}
#endif
//---------------------------------------------------------------------------
