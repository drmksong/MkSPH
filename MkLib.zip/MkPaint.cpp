#include "stdafx.h"
#include "MkPaint.h"

#if defined(_MSC_VER) && defined(_WINDOWS_)

int ColorToRGB(MkColor Color)
{
  if (Color<0) return GetSysColor(Color && 0x000000ff);
  else return Color;
}

bool MkPaint::LineTo(int xs,int ys)
{
  if(!DC.GetSafeHdc()) return false;
  return TRUE == DC.LineTo(xs,ys) ? true : false;
}

bool MkPaint::MoveTo(int xs,int ys)
{
  if(!DC.GetSafeHdc()) return false;
  DC.MoveTo(xs,ys);
  return true;
}

bool MkPaint::Rectangle(int xs,int ys,int xe,int ye)
{
  if(!DC.GetSafeHdc()) return false;
  return TRUE == DC.Rectangle(xs,ys,xe,ye) ? true : false;
}

bool MkPaint::Ellipse(int xs,int ys,int xe,int ye)
{
  if(!DC.GetSafeHdc()) return false;
  return TRUE == DC.Ellipse(xs,ys,xe,ye) ? true : false;
}

bool MkPaint::Arc(int xs,int ys,int xe,int ye,int xas,int yas,int xae,int yae)
{
  if(!DC.GetSafeHdc()) return false;
  return TRUE == DC.Arc(xs,ys,xe,ye,xas,yas,xae,yae) ? true : false;
}

bool MkPaint::TextOut(int xs,int ys,char *str)
{
  if(!DC.GetSafeHdc()) return false;
  return TRUE == DC.TextOut(xs,ys,(LPSTR)str,strlen(str)) ? true : false;
}

MkPaint::MkPaint()
{
 int i,j;
  for (i = 0; i<4;i++ )
    for (j = 0;i<4;i++)
      Fv[i][j] = 0;
  FEyeDist = 1000;
  FDist = 10;
  FTheta = 270;
  FPhi = 180;
  Coeff();
  FXDif = 0;
  FYDif = 0;

}

MkPaint::MkPaint(HDC dc)
{
  SetDC(dc);
 int i,j;
  for (i = 0; i<4;i++ )
    for (j = 0;i<4;i++)
      Fv[i][j] = 0;
  FEyeDist = 1000;
  FDist = 10;
  FTheta = 270;
  FPhi = 180;
  Coeff();
  FXDif = 0;
  FYDif = 0;
}

MkPaint::MkPaint(CDC dc)
{
  SetDC(dc);
 int i,j;
  for (i = 0; i<4;i++ )
    for (j = 0;i<4;i++)
      Fv[i][j] = 0;
  FEyeDist = 1000;
  FDist = 10;
  FTheta = 270;
  FPhi = 180;
  Coeff();
  FXDif = 0;
  FYDif = 0;
}

void MkPaint::Coeff()
{
  float th, ph, rad;
  rad = (float)3.14159 / 180;
  th = FTheta * rad;
  ph = FPhi * rad;
  Fv[0][0] = -(float)sin(th);;
  Fv[0][1] = -(float)cos(ph)*(float)cos(th);
  Fv[0][2] = -(float)sin(ph)*(float)cos(th);
  Fv[1][0] = (float)cos(th);
  Fv[1][1] = -(float)cos(ph)*(float)sin(th);
  Fv[1][2] = -(float)sin(ph)*(float)sin(th);
  Fv[2][1] = (float)sin(ph);
  Fv[2][2] = -(float)cos(ph);
  Fv[3][2] = FDist;
}

void MkPaint::Viewing()
{
  FXE = Fv[0][0]*FXW + Fv[1][0]*FYW;
  FYE = Fv[0][1]*FXW + Fv[1][1]*FYW + Fv[2][1]*FZW;
  FZE = Fv[0][2]*FXW + Fv[1][2]*FYW + Fv[2][2]*FZW + Fv[3][2];
}

void MkPaint::Projection()
{
  FXScr = int(FEyeDist*FXE/FZE) + int(Width/2) + FXDif;
  FYScr = int(Height/2) + int(FEyeDist*FYE/FZE)+ FYDif;
}

void MkPaint::ClearCanvas(void)
{
  CRect R;
  CBrush b(RGB(255,255,255));

  R.left = 1;
  R.right = Width;
  R.top = 1;
  R.bottom = Height;
  BColor=clWhite;
  DC.FillRect(&R,&b);
}

void MkPaint::DrawAxis(void)
{ 
  MoveTo3D(0,0,0);
  LineTo3D(100,0,0);  //x
  TextOut3D(100,0,0, "X-axis");
  MoveTo3D(0,0,0);
  LineTo3D(0,100,0);  //y
  TextOut3D(0,100,0, "Y-axis");
  MoveTo3D(0,0,0);
  LineTo3D(0,0,100);  //z
  TextOut3D(0,0,100, "Z-axis");
}

void MkPaint::MoveTo3D(float X, float Y, float Z)
{ 
  FXW = X;
  FYW = Y;
  FZW = Z;
  Viewing();
  Projection();
  DC.MoveTo(FXScr, FYScr);
}

void MkPaint::LineTo3D(float X, float Y, float Z)
{ 
  FXW = X;
  FYW = Y;
  FZW = Z;
  Viewing();
  Projection();
  DC.LineTo(FXScr, FYScr);
}

void MkPaint::MoveTo2D(float X, float Y)
{ 
  FXW = X;
  FYW = Y;
  FZW = 0;
  Viewing();
  Projection();
  DC.MoveTo(FXScr, FYScr);

}

void MkPaint::LineTo2D(float X, float Y)
{ 
  FXW = X;
  FYW = Y;
  FZW = 0;
  Viewing();
  Projection();
  DC.LineTo(FXScr, FYScr);

}

void MkPaint::Rectangle2D(float X1, float Y1, float X2, float Y2)
{ 
  int x1scr,y1scr,x2scr,y2scr;

  FXW = X1;
  FYW = Y1;
  FZW = 0;
  Viewing();
  Projection();
  x1scr = FXScr;
  y1scr = FYScr;
  FXW = X2;
  FYW = Y2;
  FZW = 0;
  Viewing();
  Projection();
  x2scr = FXScr;
  y2scr = FYScr;
  DC.Rectangle(x1scr,y1scr,x2scr,y2scr);

}

void MkPaint::Rectangle3D(float X1, float Y1, float Z1, float X2, float Y2, float Z2)
{ 
  int x1scr,y1scr,x2scr,y2scr;

  FXW = X1;
  FYW = Y1;
  FZW = Z1;
  Viewing();
  Projection();
  x1scr = FXScr;
  y1scr = FYScr;
  FXW = X2;
  FYW = Y2;
  FZW = Z2;
  Viewing();
  Projection();
  x2scr = FXScr;
  y2scr = FYScr;
  DC.Rectangle(x1scr,y1scr,x2scr,y2scr);

}

void MkPaint::Circle2D(float X, float Y, float Radius)
{ 
  int X1Scr,Y1Scr,X2Scr,Y2Scr;

  FXW = X-Radius;
  FYW = Y-Radius;
  Viewing();
  Projection();
  X1Scr = FXScr;
  Y1Scr = FYScr;

  FXW = X+Radius;
  FYW = Y+Radius;
  Viewing();
  Projection();
  X2Scr = FXScr;
  Y2Scr = FYScr;
  DC.Ellipse(X1Scr,Y1Scr,X2Scr,Y2Scr);

}

void MkPaint::Arc2D(float X, float Y, float Radius, float SAng, float EAng)
{ 
  int X1Scr,Y1Scr,X2Scr,Y2Scr;
  int X3Scr,Y3Scr,X4Scr,Y4Scr;

  FXW = X-Radius;
  FYW = Y-Radius;
  Viewing();
  Projection();
  X1Scr = FXScr;
  Y1Scr = FYScr;

  FXW = X+Radius;
  FYW = Y+Radius;
  Viewing();
  Projection();
  X2Scr = FXScr;
  Y2Scr = FYScr;

  FXW = X+Radius*(float)cos(SAng*3.141592654/180);
  FYW = Y+Radius*(float)sin(SAng*3.141592654/180);
  Viewing();
  Projection();
  X3Scr = FXScr;
  Y3Scr = FYScr;

  FXW = X+Radius*(float)cos(EAng*3.141592654/180);
  FYW = Y+Radius*(float)sin(EAng*3.141592654/180);
  Viewing();
  Projection();
  X4Scr = FXScr;
  Y4Scr = FYScr;

  DC.Arc(X1Scr,Y1Scr,X2Scr,Y2Scr,X3Scr,Y3Scr,X4Scr,Y4Scr);

}

void MkPaint::Arc3D(const TPoint3D &CP, const TPoint3D &Norm, const TPoint3D &Dir, float Radius, float StartAng, float EndAng)
{ 

}

void MkPaint::TextOut3D(float X, float Y, float Z, char * Text)
{ 
  FXW = X;
  FYW = Y;
  FZW = Z;
  Viewing();
  Projection();
  DC.TextOut(FXScr, FYScr,Text);

}

void MkPaint::Circle3D(const TPoint3D &CP, const TPoint3D &Norm, float Radius)
{ 

}

void MkPaint::Polygon3D(const TPoint3D * A, const int A_Size)
{ 

}

float MkPaint::Offset(int off)
{ 
    return off*Fv[3][2]/(FEyeDist*Fv[0][0]-off*Fv[0][2]);
}

void MkPaint::Scr2Wld(int xs, int ys, float &xw, float &yw)
{ 
  float xe,ye;

    xe = FDist*(xs-Width/2-FXDif)/FEyeDist;
    ye = FDist*(ys-Height/2-FYDif)/FEyeDist;
    xw = (Fv[1][1]*xe - Fv[1][0]*ye)/(Fv[0][0]*Fv[1][1]-Fv[1][0]*Fv[0][1]);
    yw = (Fv[0][0]*ye - Fv[0][1]*xe)/(Fv[0][0]*Fv[1][1]-Fv[1][0]*Fv[0][1]);

}

void MkPaint::Wld2Scr(float xw, float yw, int &xs, int &ys)
{ 
  FXW = xw;
  FYW = yw;
  Viewing();
  Projection();
  xs = FXScr;
  ys = FYScr;

}
#endif
