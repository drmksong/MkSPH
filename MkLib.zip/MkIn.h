//---------------------------------------------------------------------------
#ifndef MkInH
#define MkInH

#ifdef __BCPLUSPLUS__
#include "GlobalVarUnit.h"
#endif

#include "MkObject.h"
//---------------------------------------------------------------------------
class MkIn : public MkObject {
public:
  int liveload, layer_ea, layer, layerdepth, steel, bracing;
  int support_L, support_R, cal, surang, estimate, jibanbogang;
  int Exca_Step, bearing, anchor, Call_data;
  int InputLayerEA, Inputplan,Inputwale, InputBogangjae, SelectLayer, LayerBogang;
public:
  MkIn();
  MkIn(int);
  ~MkIn(){}
  void Clear();
#ifdef __BCPLUSPLUS__
  void Import(MkGlobalVar &globalvar);
  void Export(MkGlobalVar &globalvar);
#endif
  MkIn &operator=(MkIn &in);
};
//---------------------------------------------------------------------------
#endif
