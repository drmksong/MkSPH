//---------------------------------------------------------------------------
//#include "stdafx.h"
#pragma hdrstop
#include "MkNodalForce.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)

void MkNodalForce::Add(int n,float f)
{
  int size;
  MkInt node;
  MkFloat force;

  size = FSize+1;
  node.Initialize(size);
  force.Initialize(size);

  for (int i=0;i<FSize;i++) {
    node(i) = Node(i);
    force(i) = Force(i);
  }
  node(FSize) = n;
  force(FSize) = f;

  FSize = size;
  Node.CopyFrom(node);
  Force.CopyFrom(force);
}

void MkNodalForce::Del(int n,float f)
{
  int size,index=-1,i;
  MkInt node;
  MkFloat force;
  for (i=0;i<FSize;i++) {
    if(Node(i)==n && fabs(Force(i)-f)<EPS) {
      index = i;
      break;
    }
  }
  if (index==-1) return;

  size = FSize-1;
  node.Initialize(size);
  force.Initialize(size);

  for (i=0;i<index;i++) {
    node(i) = Node(i);
    force(i) = Force(i);
  }
  for (i=index+1;i<index;i++) {
    node(i-1) = Node(i);
    force(i-1) = Force(i);
  }

  FSize = size;
  Node.CopyFrom(node);
  Force.CopyFrom(force);
}

MkNodalForce &MkNodalForce::operator=(MkNodalForce &nf)
{
  FSize = nf.FSize;
  Node.CopyFrom(nf.Node);
  Force.CopyFrom(nf.Force);
  return *this;
}

