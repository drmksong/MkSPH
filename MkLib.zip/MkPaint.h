//---------------------------------------------------------------------------
#ifndef MkPaintH
#define MkPaintH
#include <Math.h>
#include <Windows.h>
#include <Wingdi.h>
#if defined(_MSC_VER) && defined(_WINDOWS_)

typedef unsigned int MkColor;//{clMin=-0x7fffffff-1, clMax=0x7fffffff};
static const MkColor clScrollBar = 0x80000000;
static const MkColor clBackground = 0x80000001;
static const MkColor clActiveCaption = 0x80000002;
static const MkColor clInactiveCaption = 0x80000003;
static const MkColor clMenu = 0x80000004;
static const MkColor clWindow = 0x80000005;
static const MkColor clWindowFrame = 0x80000006;
static const MkColor clMenuText = 0x80000007;
static const MkColor clWindowText = 0x80000008;
static const MkColor clCaptionText = 0x80000009;
static const MkColor clActiveBorder = 0x8000000a;
static const MkColor clInactiveBorder = 0x8000000b;
static const MkColor clAppWorkSpace = 0x8000000c;
static const MkColor clHighlight = 0x8000000d;
static const MkColor clHighlightText = 0x8000000e;
static const MkColor clBtnFace = 0x8000000f;
static const MkColor clBtnShadow = 0x80000010;
static const MkColor clGrayText = 0x80000011;
static const MkColor clBtnText = 0x80000012;
static const MkColor clInactiveCaptionText = 0x80000013;
static const MkColor clBtnHighlight = 0x80000014;
static const MkColor cl3DDkShadow = 0x80000015;
static const MkColor cl3DLight = 0x80000016;
static const MkColor clInfoText = 0x80000017;
static const MkColor clInfoBk = 0x80000018;
static const MkColor clBlack = 0x0;
static const MkColor clMaroon = 0x80;
static const MkColor clGreen = 0x8000;
static const MkColor clOlive = 0x8080;
static const MkColor clNavy = 0x800000;
static const MkColor clPurple = 0x800080;
static const MkColor clTeal = 0x808000;
static const MkColor clGray = 0x808080;
static const MkColor clSilver = 0xc0c0c0;
static const MkColor clRed = 0xff;
static const MkColor clLime = 0xff00;
static const MkColor clYellow = 0xffff;
static const MkColor clBlue = 0xff0000;
static const MkColor clFuchsia = 0xff00ff;
static const MkColor clAqua = 0xffff00;
static const MkColor clLtGray = 0xc0c0c0;
static const MkColor clDkGray = 0x808080;
static const MkColor clWhite = 0xffffff;
static const MkColor clNone = 0x1fffffff;
static const MkColor clDefault = 0x20000000;

int ColorToRGB(MkColor Color);

struct TPoint3D
{
	float X;
	float Y;
	float Z;
} ;

class MkPaint {
 private:
  CDC DC;
  CBrush Brush, OldBrush;
  CPen Pen, OldPen;
  int Width, Height;
  MkColor PColor,BColor;

 private:
  bool LineTo(int xs,int ys);
  bool MoveTo(int xs,int ys);
  bool Rectangle(int xs,int ys,int xe,int ye);
  bool Ellipse(int xs,int ys,int xe,int ye);
  bool Arc(int xs,int ys,int xe,int ye,int xas,int yas,int xae,int yae);
  bool TextOut(int xs,int ys,char *str);
  int  FillRect(RECT *r);
 protected:
  float FEyeDist, FDist, FTheta, FPhi;
  float FXW,FYW,FZW;
  float FXE,FYE,FZE;
  int FXScr, FYScr;
  int FXDif;
  int FYDif;
  float Fv[4][4];

 protected:
  void Coeff();
  void Viewing();
  void Projection();

 public:
  MkPaint();
  MkPaint(HDC dc);
  MkPaint(CDC dc);
  ~MkPaint(){}

 public:
  void SetDist(float Dist){FDist = Dist;}
  void SetTheta(float Theta){FTheta = Theta;}
  void SetPhi(float Phi){FPhi = Phi;}
  void SetWidth(int w){Width = w;}
  void SetHeight(int h){Height = h;}
  void SetBColor(MkColor c){BColor = c;}
  void SetPColor(MkColor c){PColor = c;}

  void SetDC(HDC dc){DC.Attach(dc);}
  void SetDC(CDC dc){DC.Attach(dc.GetSafeHdc());}
  void SetBrush(CBrush cb){
	   LOGBRUSH lb;
	   Brush.GetLogBrush(&lb);
	   OldBrush.CreateBrushIndirect(&lb); 
	   cb.GetLogBrush(&lb); 
	   Brush.CreateBrushIndirect(&lb);
  }
  void SetPen(CPen cp){
	   LOGPEN lp;
	   Pen.GetLogPen(&lp);
	   OldPen.CreatePenIndirect(&lp);
	   cp.GetLogPen(&lp);
	   Pen.CreatePenIndirect(&lp);
  }
  void UnSetDC(){UnSetPen();UnSetBrush();DC.Detach();}
  void UnSetBrush(){
	   LOGBRUSH lb;
	   OldBrush.GetLogBrush(&lb);
	   Brush.CreateBrushIndirect(&lb); 
  }
  void UnSetPen(){
	   LOGPEN lp;
	   OldPen.GetLogPen(&lp);
	   Pen.CreatePenIndirect(&lp); 
  }

 public:
  int GetXDif(){return FXDif;}
  int GetYDif(){return FYDif;}

 public:
  void ClearCanvas(void);
  void DrawAxis(void);
  void MoveTo3D(float X, float Y, float Z);
  void LineTo3D(float X, float Y, float Z);
  void MoveTo2D(float X, float Y);
  void LineTo2D(float X, float Y);
  void Rectangle2D(float X1, float Y1, float X2, float Y2);
  void Rectangle3D(float X1, float Y1, float Z1, float X2, float Y2, float Z2);
  void Circle2D(float X, float Y, float Radius);
  void Arc2D(float X, float Y, float Radius, float SAng, float EAng);
  void Arc3D(const TPoint3D &CP, const TPoint3D &Norm, const TPoint3D &Dir, float Radius,
	     float StartAng, float EndAng);
  void TextOut3D(float X, float Y, float Z, char* Text);
  void Circle3D(const TPoint3D &CP, const TPoint3D &Norm, float Radius);
  void Polygon3D(const TPoint3D * A, const int A_Size);
  float Offset(int off);
  void Scr2Wld(int xs, int ys, float &xw, float &yw);
  void Wld2Scr(float xw, float yw, int &xs, int &ys);
};
#endif

#endif
