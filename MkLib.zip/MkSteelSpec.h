//---------------------------------------------------------------------------
#ifndef MkSteelSpecH
#define MkSteelSpecH
#ifdef __BCPLUSPLUS__
#include "GlobalVarUnit.h"
#include "System.hpp"
#endif

#include <string.h>
#include "MkObject.h"
#include "MkMisc.h"
//---------------------------------------------------------------------------
class MkSteel : public MkObject {
public:
#ifdef __BCPLUSPLUS__
  AnsiString steelname;
  AnsiString steelkind;
#else
  char steelname[256];
  char steelkind[256];
#endif
  int OldSteel, LongTimeSteel, OldSteelReduction, LongTimeSteelReduction;
public:
  MkSteel();
  MkSteel(int);
  ~MkSteel(){}
  void Clear();
#ifdef __BCPLUSPLUS__
  void Import(MkGlobalVar &globalvar, int sec,int tan);
  void Export(MkGlobalVar &globalvar, int sec,int tan);
#endif
};
//---------------------------------------------------------------------------
class MkSteels {
protected:
  MkSteel *FSteel;
  int FSize;//Actual size of nodes
  int FSizeOfArray;
public:
  MkSteels(int size,MkSteel *steel);
  MkSteels(int size);
  MkSteels(){FSizeOfArray = FSize = 0;FSteel = NULL;}
  ~MkSteels();
  virtual void Initialize(int size);
  virtual void Initialize(int size,MkSteel *);
  int GetSize(){return FSize;};
  int GetNumber(){return FSize;};
  bool Add(MkSteel &steel);  // change of size of steel
  bool Add(int index,MkSteel &steel);
  bool Delete(MkSteel &steel);  // change of size of steel
  bool Delete(int index);
  int Grow(int Delta);            // change of size of array
  int Shrink(int Delta);          // change of size of array
  bool Clear();
  virtual MkSteel & operator[](int);
  MkSteels & operator=(MkSteels &steels);
  bool operator==(MkSteels &steels);
#ifdef __BCPLUSPLUS__
  void Import(MkGlobalVar &globalvar, int sec);
  void Export(MkGlobalVar &globalvar, int sec);
#endif
};
//---------------------------------------------------------------------------
struct MkMainBeamSpec {
#ifdef __BCPLUSPLUS__
  AnsiString name;
  AnsiString kind;
  AnsiString steelname();
  AnsiString steelkind();
#else
  char name[256];
  char kind[256];
  char* steelname();
  char* steelkind();
#endif

  void ImportFromSteel(MkSteel &steel);
};
//---------------------------------------------------------------------------
struct MkSupportBeamSpec {
#ifdef __BCPLUSPLUS__
  AnsiString name;
  AnsiString kind;
  AnsiString steelname();
  AnsiString steelkind();
#else
  char name[256];
  char kind[256];
  char* steelname();
  char* steelkind();
#endif
  void ImportFromSteel(MkSteel &steel);
};
//---------------------------------------------------------------------------
struct MkSidePileSpec {
#ifdef __BCPLUSPLUS__
  AnsiString name;
  AnsiString kind;
  AnsiString steelname();
  AnsiString steelkind();
#else
  char name[256];
  char kind[256];
  char* steelname();
  char* steelkind();
#endif
  void ImportFromSteel(MkSteel &steel);
};
//---------------------------------------------------------------------------
struct MkMidPileSpec {
#ifdef __BCPLUSPLUS__
  AnsiString name;
  AnsiString kind;
  AnsiString steelname();
  AnsiString steelkind();
#else
  char name[256];
  char kind[256];
  char* steelname();
  char* steelkind();
#endif
  void ImportFromSteel(MkSteel &steel);
};
//---------------------------------------------------------------------------
struct MkStrutSpec {
#ifdef __BCPLUSPLUS__
  AnsiString name;
  AnsiString kind;
  AnsiString steelname();
  AnsiString steelkind();
#else
  char name[256];
  char kind[256];
  char* steelname();
  char* steelkind();
#endif
  void ImportFromSteel(MkSteel &steel);
};
//---------------------------------------------------------------------------
struct MkWaleSpec {
#ifdef __BCPLUSPLUS__
  AnsiString name;
  AnsiString kind;
  AnsiString steelname();
  AnsiString steelkind();
#else
  char name[256];
  char kind[256];
  char* steelname();
  char* steelkind();
#endif
  void ImportFromSteel(MkSteel &steel);
};
//---------------------------------------------------------------------------
struct MkBracingSpec {
#ifdef __BCPLUSPLUS__
  AnsiString name;
  AnsiString kind;
  AnsiString steelname();
  AnsiString steelkind();
#else
  char name[256];
  char kind[256];
  char* steelname();
  char* steelkind();
#endif
  void ImportFromSteel(MkSteel &steel);
};
//---------------------------------------------------------------------------
struct MkBracketSpec {
#ifdef __BCPLUSPLUS__
  AnsiString name;
  AnsiString type;
  AnsiString lenum;
  AnsiString kind;  //SS400

  AnsiString steelname();
  AnsiString steelkind();
#else
  char name[256];
  char type[256];
  char lenum[256];
  char kind[256];  //SS400

  char* steelname();
  char* steelkind();
#endif
  void ImportFromSteel(MkSteel &steel);
};
//---------------------------------------------------------------------------
struct MkBoltSpec {
#ifdef __BCPLUSPLUS__
  AnsiString dia;   //D13
  double len;
  AnsiString kind;  // SD30

  AnsiString steelname();
  AnsiString steelkind();
#else
  char dia[256];   //D13
  double len;
  char kind[256];  // SD30

  char* steelname();
  char* steelkind();
#endif
  void ImportFromSteel(MkSteel &steel);
};
//---------------------------------------------------------------------------
struct MkAnchorSpec {
#ifdef __BCPLUSPLUS__
  AnsiString name;
  AnsiString num;
  AnsiString kind;

  AnsiString steelname();
  AnsiString steelkind();
#else
  char name[256];
  char num[256];
  char kind[256];

  char* steelname();
  char* steelkind();
#endif
  void ImportFromSteel(MkSteel &steel);
};
//---------------------------------------------------------------------------
struct MkTimberSpec {
#ifdef __BCPLUSPLUS__
  AnsiString type;
  double thick;
  AnsiString steelname();
  AnsiString steelkind();
#else
  char type[256];
  double thick;
  char* steelname();
  char* steelkind();
#endif
  void ImportFromSteel(MkSteel &steel);
};
//---------------------------------------------------------------------------
struct MkConcWallSpec {
#ifdef __BCPLUSPLUS__
  AnsiString strength;
  AnsiString type;
  AnsiString dia;
  double space;

  AnsiString steelname();
  AnsiString steelkind();
#else
  char strength[256];
  char type[256];
  char dia[256];
  double space;

  char* steelname();
  char* steelkind();
#endif
  void ImportFromSteel(MkSteel &steel);
};
//---------------------------------------------------------------------------
struct MkBeamHangerSpec {
#ifdef __BCPLUSPLUS__
  AnsiString type;
  AnsiString name;
  AnsiString kind;

  AnsiString steelname();
  AnsiString steelkind();
#else
  char type[256];
  char name[256];
  char kind[256];

  char* steelname();
  char* steelkind();
#endif
  void ImportFromSteel(MkSteel &steel);
};
//---------------------------------------------------------------------------
enum MkWallType {wtTimber, wtConcWall};
class MkSpec : public MkObject {
public:
  MkWallType WallType;
  MkMainBeamSpec MainBeam;
  MkSupportBeamSpec SupportBeam;
  MkSupportBeamSpec SupportBeam_M;
  MkSidePileSpec SidePile;
  MkMidPileSpec MidPile;
  MkStrutSpec Strut;
  MkWaleSpec Wale;
  MkBracingSpec Bracing;
  MkBracketSpec Bracket;
  MkBracketSpec Bracket_M;
  MkBoltSpec Bolt;
  MkAnchorSpec Anchor;
  MkTimberSpec Timber;
  MkConcWallSpec ConcWall;
  MkBeamHangerSpec BeamHanger;
public:
#ifdef __BCPLUSPLUS__
  AnsiString steelname(int i);
  AnsiString steelkind(int i);
#else
  char* steelname(int i);
  char* steelkind(int i);
#endif
  void ExportToSteel(MkSteels &steel);
  void ImportFromSteel(MkSteels &steel);// import from steel, parse the steelname, distribute to sidepile...
};
//---------------------------------------------------------------------------
extern MkSteel NullMkSteel;
//---------------------------------------------------------------------------
#endif
