#ifndef MkHeavH
#define MkHeavH
#include "MkMisc.h"

class MkHeav {
 protected:
  float FS, Cu, D, L, H, Gamma; // Cu : undrained shear strength, D : depth from excav. to datum, 
 public:                        // D, H, Gamma
  MkHeav();
  ~MkHeav(){}

  void SetCu(float cu){Cu = cu;}
  void SetD(float d){D = d;}
  void SetL(float l){L = l;}
  void SetH(float h){H = h;}
  void SetGamma(float g){Gamma = g;}
  float GetFS();
};
#endif
