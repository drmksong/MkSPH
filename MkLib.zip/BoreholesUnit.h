//---------------------------------------------------------------------------
#ifndef BoreholesUnitH
#define BoreholesUnitH
class TBorehole {
private:
   float Station, Offset;

public:
   TBorehole(){;};

};

class TBoreholes {
   TBorehole *FTBorehole;
   int FSize;
   float Station;
public:
   TBoreholes(){FSize = 0;FTBorehole = (TBorehole*)NULL;};
   TBoreholes(int size,TBorehole *pjset);
   TBoreholes(int size);
   ~TBoreholes(){};
   bool Clear();
   bool SetTBoreholes(int size,TBorehole *pjset);
   bool SetTBoreholes(int size);
   bool Initialize(int size,TBorehole *pjset){return SetTBoreholes(size,pjset);}
   bool Initialize(int size){return SetTBoreholes(size);}
   bool Grow(int delta);
   bool AddTBorehole(TBorehole ajset);
   int  GetSize(){return FSize;}
   TBoreholes & operator=(TBoreholes &boreholes){return *this;};
   TBorehole & operator[](int i);

};

//---------------------------------------------------------------------------
#endif
