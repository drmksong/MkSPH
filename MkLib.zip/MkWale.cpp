//---------------------------------------------------------------------------
#include "MkWale.h"
#ifdef __BCPLUSPLUS__
#include <vcl.h>
#endif
#pragma hdrstop
//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#pragma package(smart_init)
#endif
//---------------------------------------------------------------------------
MkWale NullMkWale(0);
//MkWale NullWale(0);
MkWale::MkWale() : MkBeam()
{
  Clear();
}

MkWale::MkWale(int) : MkBeam(0)
{
  Clear();
}

void MkWale::Clear()
{
  MkBeam::Clear();
#ifdef __BCPLUSPLUS__ 
  walename="";
//  walekind="";
#else
  memset(walename,'\0',255);
  //  memset(walekind,'\0',255);
#endif
}

// AA is A/ea
// Aw is A/m
// W is W/ea
// tt2 is W/m
// Ix is I/ea
// rx is I/m
// Zx is Z/ea
// ry is Z/m

#ifdef __BCPLUSPLUS__ 
void MkWale::ExtractSpec(AnsiString &steel)
{
  AnsiString sub;
  bool found = false;
  int i,j,spos,epos,len;

  for(i=0;i<75 && !found;i++)
    if(AnsiString(HBEAM[i][0])==steel) {
      found = true;
      SteelType = stHBEAM;

      sub = AnsiString(HBEAM[i][0]);
      len = sub.Length();
      epos = sub.Pos("��");
      spos = sub.Pos("-");
      AnsiString s1,s2;
      s1 = sub.SubString(spos+1,epos-spos-1);
      s2 = sub.SubString(epos+2,len-epos);

      HH= sub.SubString(spos+1,epos-spos-1).ToDouble();    //H   0
      BB= sub.SubString(epos+2,len-epos).ToDouble();       //B   1
      tt1= AnsiString(HBEAM[i][1]).ToDouble();             //t1  2
      tt2= AnsiString(HBEAM[i][2]).ToDouble();             //t2  3
      AA=  AnsiString(HBEAM[i][3]).ToDouble();             //A   4
      W=   AnsiString(HBEAM[i][4]).ToDouble();             //W   5
      Ix=  AnsiString(HBEAM[i][5]).ToDouble();             //Ix  6
                                                           //Iy  7
      rx=  AnsiString(HBEAM[i][7]).ToDouble();             //fx  8
      ry=  AnsiString(HBEAM[i][8]).ToDouble();             //fy  9
      Zx=  AnsiString(HBEAM[i][9]).ToDouble();             //Zx  10
                                                           //Zy  11
      Aw= tt1*(HH-2*tt2);
      break;
    }

  for(i=0;i<15 && !found;i++)
    if(AnsiString(IBEAM[i][0])==steel) {
      found = true;
      SteelType = stIBEAM;

      sub = AnsiString(IBEAM[i][0]);
      len = sub.Length();
      epos = sub.Pos("��");
      spos = sub.Pos("-");
      AnsiString s1,s2;
      s1 = sub.SubString(spos+1,epos-spos-1);
      s2 = sub.SubString(epos+2,len-epos);

      HH= sub.SubString(spos+1,epos-spos-1).ToDouble();    //H   0
      BB= sub.SubString(epos+2,len-epos).ToDouble();       //B   1
      tt1= AnsiString(IBEAM[i][1]).ToDouble();             //t1  2
      tt2= AnsiString(IBEAM[i][2]).ToDouble();             //t2  3
      AA=  AnsiString(IBEAM[i][3]).ToDouble();             //A   4
      W=   AnsiString(IBEAM[i][4]).ToDouble();             //W   5
      Ix=  AnsiString(IBEAM[i][5]).ToDouble();             //Ix  6
                                                           //Iy  7
      rx=  AnsiString(IBEAM[i][7]).ToDouble();             //fx  8
      ry=  AnsiString(IBEAM[i][8]).ToDouble();             //fy  9
      Zx=  AnsiString(IBEAM[i][9]).ToDouble();             //Zx  10
                                                           //Zy  11
      Aw= tt1*(HH-2*tt2);

      break;
    }

  for(i=0;i<9 && !found;i++)
    if(AnsiString(CHAN[i][0])==steel) {
      found = true;
      SteelType = stCHANNEL;

      sub = AnsiString(CHAN[i][0]);
      len = sub.Length();
      epos = sub.Pos("��");
      spos = sub.Pos("-");
      AnsiString s1,s2;
      s1 = sub.SubString(spos+1,epos-spos-1);
      s2 = sub.SubString(epos+2,len-epos);

      HH= sub.SubString(spos+1,epos-spos-1).ToDouble();    //H   0
      BB= sub.SubString(epos+2,len-epos).ToDouble();       //B   1
      tt1= AnsiString(CHAN[i][1]).ToDouble();             //t1  2
      tt2= AnsiString(CHAN[i][2]).ToDouble();             //t2  3
      AA=  AnsiString(CHAN[i][3]).ToDouble();             //A   4
      W=   AnsiString(CHAN[i][4]).ToDouble();             //W   5
      Ix=  AnsiString(CHAN[i][5]).ToDouble();             //Ix  6
                                                          //Iy  7
      rx=  AnsiString(CHAN[i][7]).ToDouble();             //fx  8
      ry=  AnsiString(CHAN[i][8]).ToDouble();             //fy  9
      Zx=  AnsiString(CHAN[i][9]).ToDouble();             //Zx  10
                                                           //Zy  11
      Aw= tt1*(HH-2*tt2);

      break;
    }

  for(i=0;i<46 && !found;i++)
    if(AnsiString(ANG[i][0])==steel) {
      found = true;
      SteelType = stANGLE;

      sub = AnsiString(ANG[i][0]);
      len = sub.Length();
      epos = sub.Pos("��");
      spos = sub.Pos("-");
      AnsiString s1,s2;
      s1 = sub.SubString(spos+1,epos-spos-1);
      s2 = sub.SubString(epos+2,len-epos);

      HH = sub.SubString(spos+1,epos-spos-1).ToDouble();   //H
      BB = sub.SubString(epos+2,len-epos).ToDouble();      //B
      tt1 = tt2 = AnsiString(ANG[i][1]).ToDouble();       //t
      AA = AnsiString(ANG[i][2]).ToDouble();              //A
      W = AnsiString(ANG[i][3]).ToDouble();               //W
      Ix = AnsiString(ANG[i][4]).ToDouble();         //Ix=Iy
      rx = ry = AnsiString(ANG[i][5]).ToDouble();         //fx=fy
      Zx = AnsiString(ANG[i][6]).ToDouble();         //Zx=Zy
      break;
    }

  for(i=0;i<9 && !found;i++)
    if(AnsiString(S_P[i][0])==steel) {
      found = true;
      SteelType = stSHEETPILE;

      sub = AnsiString(S_P[i][0]);
      len = sub.Length();
      epos = sub.Pos("��");
      spos = sub.Pos("-");
      AnsiString s1,s2;
      s1 = sub.SubString(spos+1,epos-spos-1);
      s2 = sub.SubString(epos+2,len-epos);

      BB = sub.SubString(spos+1,epos-spos-1).ToDouble();   // B
      HH = sub.SubString(epos+2,len-epos).ToDouble();      // H
      tt1 = AnsiString(ANG[i][1]).ToDouble();              // t
      AA = AnsiString(ANG[i][2]).ToDouble();               // A/ea
      Aw = AnsiString(ANG[i][3]).ToDouble();               // A/m
      W = AnsiString(ANG[i][4]).ToDouble();                // W/ea
      tt2 = AnsiString(ANG[i][5]).ToDouble();              // W/m
      Ix = AnsiString(ANG[i][6]).ToDouble();               // I/ea
      rx = AnsiString(ANG[i][7]).ToDouble();               // I/m
      Zx = AnsiString(ANG[i][8]).ToDouble();               // Z/ea
      ry = AnsiString(ANG[i][9]).ToDouble();               // Z/m
      break;
    }
}

void MkWale::ComposeSpec(AnsiString &steel)
{
  steel="";
  switch(SteelType) {
    case stHBEAM: steel=AnsiString("H-")+HH+"��"+BB; break;
    case stIBEAM: steel=AnsiString("I-")+HH+"��"+BB; break;
    case stCHANNEL: steel=AnsiString("C-")+HH+"��"+BB; break;
    case stANGLE: steel=AnsiString("A-")+HH+"��"+BB; break;
    case stSHEETPILE: steel=AnsiString("SP-")+BB+"��"+HH; break;
  }
}

void MkWale::Import(MkGlobalVar &globalvar, int sec, int tan)
{
  walename=(LPCTSTR)globalvar.walename[sec+1][tan+1];
  if(walename.Length()) {
//  walekind=(LPCTSTR)globalvar.walekind[sec+1][tan+1];
    BB=globalvar.wale_BB[sec+1][tan+1];
    HH=globalvar.wale_HH[sec+1][tan+1];
    tt1=globalvar.wale_tt1[sec+1][tan+1];
    tt2=globalvar.wale_tt2[sec+1][tan+1];
    AA=globalvar.wale_AA[sec+1][tan+1];
    W=globalvar.wale_W[sec+1][tan+1];
    Aw=globalvar.wale_Aw[sec+1][tan+1];
    Zx=globalvar.wale_Zx[sec+1][tan+1];
    Ix=globalvar.wale_Ix[sec+1][tan+1];
    rx=globalvar.wale_rx[sec+1][tan+1];
    ry=globalvar.wale_ry[sec+1][tan+1];
  }
  else {
    walename=MajorWale;

    int i, pos,len;
    AnsiString sub,sub2,sub3;
    pos = walename.Pos("��");
    len = walename.Length();

    sub  = walename.SubString(1,pos+1);
    sub2 = walename.SubString(pos+2,len-pos-1);

    pos = sub2.Pos("��");
    len = sub2.Length();
    sub3 = sub2.SubString(1,pos-1);
    sub = sub+sub3;

    ExtractSpec(sub);
  }
}

void MkWale::Export(MkGlobalVar &globalvar, int sec, int tan)
{
  globalvar.walename[sec+1][tan+1]=walename.c_str();
//  globalvar.walekind[sec+1][tan+1]=walekind.c_str();
  globalvar.wale_BB[sec+1][tan+1]=BB;
  globalvar.wale_HH[sec+1][tan+1]=HH;
  globalvar.wale_tt1[sec+1][tan+1]=tt1;
  globalvar.wale_tt2[sec+1][tan+1]=tt2;
  globalvar.wale_AA[sec+1][tan+1]=AA;
  globalvar.wale_W[sec+1][tan+1]=W;
  globalvar.wale_Aw[sec+1][tan+1]=Aw;
  globalvar.wale_Zx[sec+1][tan+1]=Zx;
  globalvar.wale_Ix[sec+1][tan+1]=Ix;
  globalvar.wale_rx[sec+1][tan+1]=rx;
  globalvar.wale_ry[sec+1][tan+1]=ry;
}
#endif

bool MkWale::operator==(MkWale &wale)
{
  bool flag=true;

  flag = flag && SteelType==wale.SteelType;
  flag = flag && BeamType==wale.BeamType;
  flag = flag && BB==wale.BB;
  flag = flag && HH==wale.HH;
  flag = flag && tt1==wale.tt1;
  flag = flag && tt2==wale.tt2;
  flag = flag && AA==wale.AA;
  flag = flag && W==wale.W;
  flag = flag && Aw==wale.Aw;
  flag = flag && Zx==wale.Zx;
  flag = flag && Ix==wale.Ix;
  flag = flag && rx==wale.rx;
  flag = flag && ry==wale.ry;
  flag = flag && walename==wale.walename;

  return flag;
}

bool MkWale::operator!=(MkWale &wale)
{
  return !operator==(wale);
}

MkWale &MkWale::operator=(MkWale &wale)
{
  SteelType=wale.SteelType;
  BeamType=wale.BeamType;

  BB=wale.BB;
  HH=wale.HH;
  tt1=wale.tt1;
  tt2=wale.tt2;
  AA=wale.AA;
  W=wale.W;
  Aw=wale.Aw;
  Zx=wale.Zx;
  Ix=wale.Ix;
  rx=wale.rx;
  ry=wale.ry;
#ifdef __BCPLUSPLUS__ 
  walename=wale.walename;
#else
  strcpy(walename,wale.walename);
#endif
  return *this;
}

//---------------------------------------------------------------------------
MkWales::MkWales(int size,MkWale *wales)
{
    if (size < 0) {
      MkDebug("::MkWales - MkWales(int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSize == 0) {
       FWale = NULL;
       return;
    }

    FWale = new MkWale[FSize];
    for (int i=0;i<FSize;i++) (*this)[i] = wales[i];
}

MkWales::MkWales(int size)
{
    if (size < 0) {
      MkDebug("::MkWales - MkWales(int size)");;
      return;
    }

    FSize = FSizeOfArray = size;

    if (FSizeOfArray == 0) {
       FWale = NULL;
       return;
    }

    FWale = new MkWale[FSizeOfArray];
}

MkWales::~MkWales()
{
   FSizeOfArray = FSize = 0;
   if (FWale) {
      delete[] FWale;
      FWale = NULL;
   }
}

void MkWales::Initialize(int size)
{
    if (size < 0) {
      MkDebug("::MkWales - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;

    FSize = FSizeOfArray = size;

    if (FSizeOfArray == 0) {
       if (FWale!=NULL) delete[] (MkWale*)FWale;
       FWale = NULL;
       return;
    }

    if (FWale!=NULL) delete[] (MkWale*)FWale;
    FWale = new MkWale[FSizeOfArray];
}

void MkWales::Initialize(int size,MkWale *wales)
{

    if (size < 0 || wales == NULL) {
      MkDebug("::MkWales - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSize = FSizeOfArray = size;
    if (FSizeOfArray == 0) {
       if (FWale!=NULL) delete[] (MkWale*)FWale;
       FWale = NULL;
       return;
    }

    if (FWale!=NULL) delete[] (MkWale*)FWale;
    FWale = new MkWale[FSizeOfArray];
    for (int i=0;i<FSizeOfArray;i++) FWale[i] = wales[i];
}

int MkWales::Grow(int delta)
{
    int i;
    MkWale *wale=NULL;

    if (!(wale = new MkWale[FSizeOfArray+delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        wale[i] = FWale[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        wale[i] = NullMkWale;
    if (FWale) {
       delete[] (MkWale*)FWale;
       FWale = NULL;
    }
    FWale = wale;
    FSizeOfArray = FSizeOfArray+delta;

    return FSizeOfArray;
}

int MkWales::Shrink(int delta)
{
    int i;
    MkWale *wale=NULL;

    if (!(wale = new MkWale[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        wale[i] = FWale[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        wale[i] = NullMkWale;
    if (FWale) {
       delete[] (MkWale*)FWale;
       FWale = NULL;
    }
    FWale = wale;
    FSizeOfArray = FSizeOfArray-delta;

    return FSizeOfArray;
}

bool MkWales::Add(MkWale &wale)
{
    int tmp=FSizeOfArray;
    bool flag=false;
    for (int i=0;i<FSize;i++) if (FWale[i]==wale) flag=true;

    if(flag) return false;
    if (FSize>=FSizeOfArray) {
       Grow(FSize-FSizeOfArray+10);
       if (tmp==FSizeOfArray) return false;
    }
    FSize++;
    FWale[FSize-1] = wale;

    return true;
}

bool MkWales::Add(int index, MkWale &wale)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) Grow(FSize-FSizeOfArray+1);
    if(tmp==FSizeOfArray) return false;

    for (int i=FSize-1;i>=index;i--)
      FWale[i+1] = FWale[i];
    FSize++;
    FWale[index] = wale;
    return true;
}

bool MkWales::Delete(MkWale &wale)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FWale[i] == wale) break;
    }
    if(i==FSize) return false;
    if(FWale[i] == wale) {
      for (int j=i;j<FSize-1;j++)
        FWale[j] = FWale[j+1];
    }
    FSize--;
    FWale[FSize] = NullMkWale;
    return true;
}

bool MkWales::Delete(int index)
{
    for (int j=index;j<FSize-1;j++)
        FWale[j] = FWale[j+1];

    FSize--;
    FWale[FSize] = NullMkWale;
    return true;
}

bool MkWales::Clear()
{
   FSizeOfArray = FSize = 0;
   if (FWale) {
      delete[] FWale;
      FWale = NULL;
   }
   return true;
}

MkWale & MkWales::operator[](int i)
{
    if (FSizeOfArray == 0) return NullMkWale;
    if (i >= FSize && i < FSizeOfArray) FSize = i+1;

    if (i >=0 && i < FSize) return FWale[i];
    else return NullMkWale;
}

MkWales & MkWales::operator=(MkWales &wales)
{
    int i;

    Clear();
    FSize = wales.FSize;
    FSizeOfArray = wales.FSizeOfArray;
    if (FSize == 0) {
       FWale = NULL;
       return *this;
    }
    this->FWale = new MkWale[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FWale[i] = wales.FWale[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FWale[i] = NullMkWale;

    return *this;
}

bool MkWales::operator==(MkWales &wales)
{
  int i;

  if (FSize != wales.FSize) return false;
  for (i=0;i<FSize;i++)
    if (this->FWale[i] != wales.FWale[i]) return false;

  return true;
}
#ifdef __BCPLUSPLUS__ 
void MkWales::Import(MkGlobalVar &globalvar, int sec)
{
  int i;
  for(i=0;i<FSize && i<30;i++) {
    FWale[i].Import(globalvar,sec,i);
  }
}

void MkWales::Export(MkGlobalVar &globalvar, int sec)
{
  int i;
  for(i=0;i<FSize && i<30;i++) {
    FWale[i].Export(globalvar,sec,i);
  }
}
#endif
/*
MkWale::MkWale()
{

}
MkWale::MkWale(int n)
{
}
#ifdef __BCPLUSPLUS__
bool MkWale::UpdateFrom()
{
  if(!Grid) return false;

  return true;
}

bool MkWale::UpdateTo()
{
  if(!Grid) return false;

  for(int i=0;i<20;i++) {Grid->Cells[0][i] = "";Grid->Cells[1][i]="";}

  return true;
}

void MkWale::Out(TObject *Sender)
{

}
#endif

void MkWale::Out(char *fname)
{

}

bool MkWale::operator==(MkWale &wale)
{
  bool flag = true;
  flag = flag && MkEntity::operator==((MkEntity&)wale);
  flag = flag && WaleLine == wale.WaleLine;
  return flag;
}
bool MkWale::operator!=(MkWale &wale)
{
  return !operator==(wale);
}

MkWale& MkWale::operator=(MkWale& wale)
{
  MkEntity::operator=((MkEntity&)wale);
  WaleLine = wale.WaleLine;
  return *this;
}

#ifdef __BCPLUSPLUS__
void MkWale::Draw(TObject *Sender)
{
  WaleLine.Draw(Sender);
}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void MkWale::Draw(MkPaint *pb)
{

}
#endif
//---------------------------------------------------------------------------
MkWales::MkWales(int size,MkWale *wales)
{

    if (size < 0) {
      MkDebug("::MkWales - MkWales(int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSize == 0) {
       FWale = NULL;
       return;
    }

    FWale = new MkWale[FSize];
    for (int i=0;i<FSize;i++) (*this)[i] = wales[i];
}

MkWales::MkWales(int size)
{
    if (size < 0) {
      MkDebug("::MkWales - MkWales(int size)");;
      return;
    }

    FSizeOfArray = size;
    FSize = 0;
    if (FSizeOfArray == 0) {
       FWale = NULL;
       return;
    }

    FWale = new MkWale[FSizeOfArray];
}

MkWales::~MkWales()
{
   FSizeOfArray = FSize = 0;
   if (FWale) {
      delete[] FWale;
      FWale = NULL;
   }
}

void MkWales::Initialize(int size)
{
    int i;
    if (size < 0) {
      MkDebug("::MkWales - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;

    FSizeOfArray = FSize = size;

    if (FSizeOfArray == 0) {
       if (FWale!=NULL) delete[] (MkWale*)FWale;
       FWale = NULL;
       return;
    }

    if (FWale!=NULL) delete[] (MkWale*)FWale;
    FWale = new MkWale[FSizeOfArray];
    for (i=0;i<FSize;i++) FWale[i].Number = i;
}

void MkWales::Initialize(int size,MkWale *wales)
{
    int i;
    if (size < 0 || wales == NULL) {
      MkDebug("::MkWales - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSize = FSizeOfArray = size;
    if (FSizeOfArray == 0) {
       if (FWale!=NULL) delete[] (MkWale*)FWale;
       FWale = NULL;
       return;
    }

    if (FWale!=NULL) delete[] (MkWale*)FWale;
    FWale = new MkWale[FSizeOfArray];
    for (i=0;i<FSizeOfArray;i++) FWale[i] = wales[i];
    for (i=0;i<FSize;i++) FWale[i].Number = i;
}

int MkWales::Grow(int delta)
{
    int i;
    MkWale *wale=NULL;

    if (!(wale = new MkWale[FSizeOfArray+delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        wale[i] = FWale[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        wale[i] = NullWale;
    if (FWale) {
       delete[] (MkWale*)FWale;
       FWale = NULL;
    }
    FWale = wale;
    FSizeOfArray = FSizeOfArray+delta;
    return FSizeOfArray;
}

int MkWales::Shrink(int delta)
{
    int i;
    MkWale *wale=NULL;

    if (!(wale = new MkWale[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        wale[i] = FWale[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        wale[i] = NullWale;
    if (FWale) {
       delete[] (MkWale*)FWale;
       FWale = NULL;
    }
    FWale = wale;
    FSizeOfArray = FSizeOfArray-delta;
    return FSizeOfArray;
}

bool MkWales::Add(MkWale &wale)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    FSize++;
    FWale[FSize-1] = wale;
    return true;
}

bool MkWales::Add(int index, MkWale &wale)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    for (int i=FSize-1;i>=index;i--)
      FWale[i+1] = FWale[i];
    FSize++;
    FWale[index] = wale;
    return true;
}

bool MkWales::Delete(MkWale &wale)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FWale[i] == wale) break;
    }
    if(i==FSize) return false;
    if(FWale[i] == wale) {
      for (int j=i;j<FSize-1;j++)
        FWale[j] = FWale[j+1];
    }
    FSize--;
    FWale[FSize] = NullWale;
    return true;
}

bool MkWales::Delete(int index)
{
    for (int j=index;j<FSize-1;j++)
        FWale[j] = FWale[j+1];

    FSize--;
    FWale[FSize] = NullWale;
    return true;
}

bool MkWales::Clear()
{
   FSizeOfArray = FSize = 0;
   if (FWale) {
      delete[] FWale;
      FWale = NULL;
   }
   return true;
}

MkWale & MkWales::operator[](int i)
{
    if (0<=i && i<FSize) return FWale[i];
    else if(FSize<=i && i<FSizeOfArray) {
      FSize=i+1;
      return FWale[i];
    }
    else if (FSizeOfArray <= i) {
      Grow(i-FSizeOfArray+5);
      return NullWale;
    }
    else return NullWale;
}

MkWales & MkWales::operator=(MkWales &wales)
{
    int i;

    Clear();
    FSize = wales.FSize;
    FSizeOfArray = wales.FSizeOfArray;
    if (FSizeOfArray == 0) {
       FWale = NULL;
       return *this;
    }
    this->FWale = new MkWale[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FWale[i] = wales.FWale[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FWale[i] = NullWale;

    return *this;
}

bool MkWales::operator==(MkWales &wales)
{
    int i;

    if (FSize != wales.FSize) return false;
    for (i=0;i<FSize;i++)
      if (this->FWale[i] != wales.FWale[i]) return false;

    return true;
}

#ifdef __BCPLUSPLUS__
void MkWales::Draw(TObject *Sender)
{
    TColor C;
    float Offset;
    if (FSize == 0) return;
    if (String(Sender->ClassName()) == String("MkPaintBox")) {
       MkPaintBox *pb=(MkPaintBox*)Sender;
       C = pb->Canvas->Pen->Color;
       pb->Canvas->Pen->Color = Color;
       for (int i = 0; i < FSize;i++) {
           Offset = pb->Offset(3);
           FWale[i].Draw(pb);
       }
       pb->Canvas->Pen->Color = C;
    }
}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void MkWales::Draw(MkPaint *pb)
{

}
#endif
*/
//---------------------------------------------------------------------------

