//---------------------------------------------------------------------------
#include "MkPileSection.h"

#ifdef __BCPLUSPLUS__
#include <vcl.h>
#endif

#pragma hdrstop
//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#pragma package(smart_init)
#endif

MkPileSection NullMkPileSection(0);
//---------------------------------------------------------------------------
MkPileSection::MkPileSection()
{
  Clear();
}

MkPileSection::MkPileSection(int)
{
  Clear();
}

void MkPileSection::Clear()
{
  bracingtype = bracingtype;
  bracing_ea = bracing_ea;
  bracingNN = bracingNN;
  piledist = piledist;
  bracing.Clear();
  lane.Clear();
}

MkPileSections::MkPileSections(int size,MkPileSection *pilesections)
{
    if (size < 0) {
      MkDebug("::MkPileSections - MkPileSections(int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSize == 0) {
       FPileSection = NULL;
       return;
    }

    FPileSection = new MkPileSection[FSize];
    for (int i=0;i<FSize;i++) (*this)[i] = pilesections[i];
}

MkPileSections::MkPileSections(int size)
{
    if (size < 0) {
      MkDebug("::MkPileSections - MkPileSections(int size)");;
      return;
    }

    FSize = FSizeOfArray = size;

    if (FSizeOfArray == 0) {
       FPileSection = NULL;
       return;
    }

    FPileSection = new MkPileSection[FSizeOfArray];
}

MkPileSections::~MkPileSections()
{
   FSizeOfArray = FSize = 0;
   if (FPileSection) {
      delete[] FPileSection;
      FPileSection = NULL;
   }
}

void MkPileSections::Initialize(int size)
{
    int i;
    MkPileSection *spt;

    if (FSizeOfArray == size) return;

    if(size==0) {
      Clear();
      return;
    }
    if (size < 0) {
      MkDebug("::MkPileSections - Initialize(int size)");;
      return;
    }

    spt = new MkPileSection[size];
    if(!spt) {
      MkDebug("::MkPileSections - Initialize(int size) : Cannot allocate memory\n");;
      return;
    }

    for(i=0;i<min(size,FSize);i++) {
      spt[i] = FPileSection[i];
    }

    for(i=FSize;i<size;i++) {
      spt[i] = NullMkPileSection;
    }

    FSize = FSizeOfArray = size;

    if (FPileSection!=NULL) {
      delete[] (MkPileSection*)FPileSection;
      FPileSection = NULL;
    }
    FPileSection = spt;
}

void MkPileSections::Initialize(int size,MkPileSection *pilesections)
{

    if (size < 0 || pilesections == NULL) {
      MkDebug("::MkPileSections - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSize = FSizeOfArray = size;
    if (FSizeOfArray == 0) {
       if (FPileSection!=NULL) delete[] (MkPileSection*)FPileSection;
       FPileSection = NULL;
       return;
    }

    if (FPileSection!=NULL) delete[] (MkPileSection*)FPileSection;
    FPileSection = new MkPileSection[FSizeOfArray];
    for (int i=0;i<FSizeOfArray;i++) FPileSection[i] = pilesections[i];
}

int MkPileSections::Grow(int delta)
{
    int i;
    MkPileSection *pilesection=NULL;

    if (!(pilesection = new MkPileSection[FSizeOfArray+delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        pilesection[i] = FPileSection[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        pilesection[i] = NullMkPileSection;
    if (FPileSection) {
       delete[] (MkPileSection*)FPileSection;
       FPileSection = NULL;
    }
    FPileSection = pilesection;
    FSizeOfArray = FSizeOfArray+delta;

    return FSizeOfArray;
}

int MkPileSections::Shrink(int delta)
{
    int i;
    MkPileSection *pilesection=NULL;

    if (!(pilesection = new MkPileSection[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        pilesection[i] = FPileSection[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        pilesection[i] = NullMkPileSection;
    if (FPileSection) {
       delete[] (MkPileSection*)FPileSection;
       FPileSection = NULL;
    }
    FPileSection = pilesection;
    FSizeOfArray = FSizeOfArray-delta;

    return FSizeOfArray;
}

bool MkPileSections::Add(MkPileSection &pilesection)
{
    int tmp=FSizeOfArray;
    bool flag=false;
    for (int i=0;i<FSize;i++) if (FPileSection[i]==pilesection) flag=true;

    if(flag) return false;
    if (FSize>=FSizeOfArray) {
       Grow(FSize-FSizeOfArray+10);
       if (tmp==FSizeOfArray) return false;
    }
    FSize++;
    FPileSection[FSize-1] = pilesection;

    return true;
}

bool MkPileSections::Add(int index, MkPileSection &pilesection)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) Grow(FSize-FSizeOfArray+1);
    if(tmp==FSizeOfArray) return false;

    for (int i=FSize-1;i>=index;i--)
      FPileSection[i+1] = FPileSection[i];
    FSize++;
    FPileSection[index] = pilesection;
    return true;
}

bool MkPileSections::Delete(MkPileSection &pilesection)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FPileSection[i] == pilesection) break;
    }
    if(i==FSize) return false;
    if(FPileSection[i] == pilesection) {
      for (int j=i;j<FSize-1;j++)
        FPileSection[j] = FPileSection[j+1];
    }
    FSize--;
    FPileSection[FSize] = NullMkPileSection;
    return true;
}

bool MkPileSections::Delete(int index)
{
    for (int j=index;j<FSize-1;j++)
        FPileSection[j] = FPileSection[j+1];

    FSize--;
    FPileSection[FSize] = NullMkPileSection;
    return true;
}

bool MkPileSections::Clear()
{
   FSizeOfArray = FSize = 0;
   if (FPileSection) {
      delete[] FPileSection;
      FPileSection = NULL;
   }
   return true;
}

MkPileSection & MkPileSections::operator[](int i)
{
    if (FSizeOfArray == 0) return NullMkPileSection;
    if (i >= FSize && i < FSizeOfArray) FSize = i+1;

    if (i >=0 && i < FSize) return FPileSection[i];
    else return NullMkPileSection;
}

MkPileSections & MkPileSections::operator=(MkPileSections &pilesections)
{
    int i;

    Clear();
    FSize = pilesections.FSize;
    FSizeOfArray = pilesections.FSizeOfArray;
    if (FSize == 0) {
       FPileSection = NULL;
       return *this;
    }
    this->FPileSection = new MkPileSection[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FPileSection[i] = pilesections.FPileSection[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FPileSection[i] = NullMkPileSection;

    return *this;
}

bool MkPileSections::operator==(MkPileSections &pilesections)
{
  int i;

  if (FSize != pilesections.FSize) return false;
  for (i=0;i<FSize;i++)
    if (this->FPileSection[i] != pilesections.FPileSection[i]) return false;

  return true;
}

#ifdef __BCPLUSPLUS__
void MkPileSections::Import(MkGlobalVar &globalvar, int sec)
{
  int i;
  Initialize(globalvar.pile_ea[sec+1]<=1?1:globalvar.pile_ea[sec+1]-1);
  for(i=0;i<FSize && i<10;i++) {
    FPileSection[i].bracingtype=globalvar.bracingtype[sec+1][i+1];
    FPileSection[i].bracing_ea=globalvar.bracing_ea[sec+1][i+1];
    FPileSection[i].bracingNN=globalvar.bracingNN[sec+1][i+1];
    FPileSection[i].piledist=globalvar.piledist[sec+1][i+1];
    FPileSection[i].bracing.Import(globalvar,sec,i);
    FPileSection[i].lane.Import(globalvar,sec,i);
  }
}

void MkPileSections::Export(MkGlobalVar &globalvar, int sec)
{
  int i;
  globalvar.pile_ea[sec+1] = FSize+1;
  for(i=0;i<FSize && i<10;i++) {
    globalvar.bracingtype[sec+1][i+1]=FPileSection[i].bracingtype;
    globalvar.bracing_ea[sec+1][i+1]=FPileSection[i].bracing_ea;
    globalvar.bracingNN[sec+1][i+1]=FPileSection[i].bracingNN;
    globalvar.piledist[sec+1][i+1]=FPileSection[i].piledist;
    FPileSection[i].bracing.Export(globalvar,sec,i);
    FPileSection[i].lane.Export(globalvar,sec,i);
  }
}
#endif
//---------------------------------------------------------------------------

