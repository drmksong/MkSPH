//---------------------------------------------------------------------------
#ifndef MkDsgStdH
#define MkDsgStdH
#include <stddef.h>
#include <string.h>
//---------------------------------------------------------------------------
enum MkAnswerType {atNone, atMiligram, atGram, atKilogram, atTon,
                           atMilimeter, atCentimeter, atMeter, atKilometer};
struct MkQandA {
public: // members
  char *Question;
  char *Answer;
  MkAnswerType AnsType;
public: // link-list
  MkQandA *NextQandA;
  MkQandA *PrevQandA;
public: // functions
  MkQandA(char *q, char *a, MkAnswerType at);
  ~MkQandA(){ if (Question) {delete Question; Question = NULL;}
            if (Answer)   {delete Answer; Answer = NULL;}}
  bool GetAnswer(char *q,char *a, MkAnswerType &at);
  void SetAnswer(const char *q,const char *a, MkAnswerType at);
  bool operator==(MkQandA &);
  MkQandA * operator=(MkQandA *);
  MkQandA *Next(){return NextQandA;}
  MkQandA *Prev(){return PrevQandA;}
};

class MkDesignStandard {
protected:
  MkQandA *FirstQandA;
  MkQandA *LastQandA;
  MkQandA *CurrentQandA;    
public:
  MkDesignStandard();
  ~MkDesignStandard();
  bool Add(char *question, char *answer, MkAnswerType at);
  bool Delete(char *question, char *answer, MkAnswerType at);
  bool Clear();
  bool Ask(char *question, char *&answer, MkAnswerType &at);

  bool operator==(MkDesignStandard &);
  bool operator!=(MkDesignStandard &);
};
#endif
