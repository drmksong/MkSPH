//---------------------------------------------------------------------------
#ifndef MkDeckH
#define MkDeckH
#include "MkObject.h"
#include "MkMainBeam.h"
#include "MkLine.h"
#include "MkCube.h"
//---------------------------------------------------------------------------
enum MkDeckType {dtHighGround, dtLowGround, dtNone};
enum MkDeckDir {dtPerpend, dtParallel};
class MkDeck : public MkObject {
protected:
  bool isInstalled;
  MkDeckType DeckType;
  MkDeckDir DeckDir;
  float Height, Width, Thick;// Y,X,Z for each
  MkMainBeam *MainBeam;
  MkCube Deck;
  MkLines Lines;
  //  MkDim Dim;

public:
  MkDeck();
  ~MkDeck(){};

  void SetInstall(bool b){isInstalled = b;}
  void SetDeckType(MkDeckType dt){DeckType = dt;}
  void SetDeckDir(MkDeckDir dd){DeckDir = dd;}
  void SetHeight(float h){Deck.SetYLength(h);Height=h;}
  void SetWidth(float w){Deck.SetXLength(w);Width=w;}
  void SetThick(float t){Deck.SetZLength(t);Thick=t;}
  void SetMainBeam(MkMainBeam &mb){MainBeam=&mb;}

  bool GetInstall(){return isInstalled;}
  MkDeckType GetDeckType(){return DeckType;}
  MkDeckDir GetDeckDir(){return DeckDir;}
  float GetHeight(){return Deck.GetYLength();}
  float GetWidth(){return Deck.GetXLength();}
  float GetThick(){return Deck.GetZLength();}
  MkMainBeam *GetMainBeam(){return MainBeam;}

  void DrawGL();
};
#endif

