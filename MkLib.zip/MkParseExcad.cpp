//---------------------------------------------------------------------------
//#include <vcl.h>
//#pragma hdrstop
//#include "ParseExcad.h"
//---------------------------------------------------------------------------
//#pragma package(smart_init)

bool MkExcadtParser::ParseExcad(char *str, MkKeyKind key)
{
  char s[256], *p;
  MkKeyword keyword;

  if(strlen(str)<1) return false;
  TrimLeft(s,str);

  if(keyword.IsKeyword(s)) p = strchr(s,' ');
  else p = s;

  if((p-s)>255) return false;

  switch(key) {
    case kkProject: return ParseExcadPrj(p); 
    case kkLayer: return ParseExcadLay(p); 
    case kkProfile: return ParseExcadPrf(p); 
    case kkWall: return ParseExcadWall(p); 
    case kkStrut: return ParseExcadStrut(p); 
    case kkAnchor: return ParseExcadAnchor(p); 
    case kkRockbolt: return ParseExcadRockbolt(p); 
    case kkSlab: return ParseExcadSlab(p); 
    case kkSlabWall: return ParseExcadSlabWall(p);
    case kkDivision: return ParseExcadDiv(p); 
    case kkSolution: return ParseExcadSol(p); 
    case kkPoint: return ParseExcadPnt(p); 
    case kkNoEcho: return ParseExcadNoEcho(p);
    case kkOutput: return ParseExcadOut(p); 
    case kkStep: return ParseExcadStep(p);
    case kkBottom: return ParseExcadBot(p); 
    case kkRankine: return ParseExcadRankine(p); 
    case kkPeck: return ParseExcadPeck(p); 
    case kkPeck1: return ParseExcadPeck1(p); 
    case kkEarthPress: return ParseExcadEarthPress(p); 
    case kkSlope: return ParseExcadSlope(p); 
    case kkPropileChange: return ParseExcadPrfChange(p);
    case kkGWL: return ParseExcadGWL(p);
    case kkWaterPress: return ParseExcadWaterPress(p);
    case kkSurcharge: return ParseExcadSurcharge(p);
    case kkLoad: return ParseExcadLoad(p); 
    case kkPress: return ParseExcadPress(p); 
    case kkMinAcive: return ParseExcadMinAct(p);
    case kkExcav: return ParseExcadExcav(p);
    case kkConst: return ParseExcadConst(p);
    case kkRemove: return ParseExcadRemove(p);
    case kkInsertCheck: return ParseExcadInsertCheck(p);
    case kkIteration: return ParseExcadInteration(p);
    case kkGroundSettle: return ParseExcadGroundSettle(p);
    case kkSlip: return ParseExcadSlip(p);
    case kkEnd: return true;
  }
}

bool MkExcadtParser::ParseExcadPrj(char *str)
{
  PrjData.projectcontent = str;
}

bool MkExcadtParser::ParseExcadLay(char *str)
{
  
}

bool MkExcadtParser::ParseExcadPrf(char *str)
{

}

bool MkExcadtParser::ParseExcadWall(char *str)
{

}

bool MkExcadtParser::ParseExcadStrut(char *str)
{

}
bool MkExcadtParser::ParseExcadAnchor(char *str)
{

}

bool MkExcadtParser::ParseExcadRockbolt(char *str)
{

}

bool MkExcadtParser::ParseExcadSlab(char *str)
{

}

bool MkExcadtParser::ParseExcadSlabWall(char *str)
{

}

bool MkExcadtParser::ParseExcadDiv(char *str)
{

}

bool MkExcadtParser::ParseExcadSol(char *str)
{

}

bool MkExcadtParser::ParseExcadPnt(char *str)
{

}

bool MkExcadtParser::ParseExcadNoEcho(char *str)
{

}

bool MkExcadtParser::ParseExcadOut(char *str)
{

}

bool MkExcadtParser::ParseExcadStep(char *str)
{

}

bool MkExcadtParser::ParseExcadBot(char *str)
{

}

bool MkExcadtParser::ParseExcadRankine(char *str)
{

}

bool MkExcadtParser::ParseExcadPeck(char *str)
{

}

bool MkExcadtParser::ParseExcadPeck1(char *str)
{

}

bool MkExcadtParser::ParseExcadEarthPress(char *str)
{

}

bool MkExcadtParser::ParseExcadSlope(char *str)
{

}

bool MkExcadtParser::ParseExcadPropile(char *str)
{

}

bool MkExcadtParser::ParseExcadGWL(char *str)
{

}

bool MkExcadtParser::ParseExcadWaterPress(char *str)
{

}

bool MkExcadtParser::ParseExcadSurcharge(char *str)
{

}

bool MkExcadtParser::ParseExcadLoad(char *str)
{

}

bool MkExcadtParser::ParseExcadPress(char *str)
{

}

bool MkExcadtParser::ParseExcadMinAct(char *str)
{

}

bool MkExcadtParser::ParseExcadExcav(char *str)
{

}

bool MkExcadtParser::ParseExcadConst(char *str)
{

}

bool MkExcadtParser::ParseExcadRemove(char *str)
{

}

bool MkExcadtParser::ParseExcadInsertCheck(char *str)
{

}

bool MkExcadtParser::ParseExcadInteration(char *str)
{

}

bool MkExcadtParser::ParseExcadGroundSettle(char *str)
{

}

bool MkExcadtParser::ParseExcadSlip(char *str)
{

}
