//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#include <vcl.h>
#endif
#pragma hdrstop

#include "MkProfile.h"
//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#pragma package(smart_init)
#endif

MkProfile NullProfile(0);
MkProfile::MkProfile(MkProfType pf, MkPolygon &poly)
{
  SetProfType(pf);
  SetProfile(poly);
  MakeScript();
}

MkProfile::~MkProfile()
{
  ClearScript();
}

void MkProfile::SetBound(float lb, float rb)
{
  int i, npoly=0, n;
  MkPolygon poly;
  MkLine Line;

  if(Polygon.GetSize()<=0) {
    Polygon.Initialize(2);
    Polygon[0].X = lb; Polygon[0].Y = 0;
    Polygon[1].X = rb; Polygon[1].Y = 0;
    return;
  }

  for(i=0;i<Polygon.GetSize();i++) {  // find internal points
    if(lb+EPS < Polygon[i].X && Polygon[i].X < rb-EPS) npoly++;
  }
  npoly+=2; // add 2 edge points
  poly.Initialize(npoly);

  npoly = 1;  // left most point is boundary point
  for(i=0;i<Polygon.GetSize();i++) {  // find internal points
    if(lb+EPS < Polygon[i].X && Polygon[i].X < rb-EPS) {
      poly[npoly] = Polygon[i];
      npoly++;
    }
  }

  Line[0].X = lb;
  Line[0].Y = Polygon[0].Y;
  Line[1].X = Polygon[0].X;
  Line[1].Y = Polygon[0].Y;
  for(i=0;i<Polygon.GetSize()-1;i++) {  // find internal points
    if(Polygon[i].X < lb && lb < Polygon[i+1].X) {
      Line[0] = Polygon[i];
      Line[1] = Polygon[i+1];
    }
  }
  poly[0].X = lb;
  poly[0].Y = (fabs(Line[0].X-lb)<EPS) ? Line[0].Y :
              (fabs(Line[1].X-Line[0].X)<EPS ? Line[0].Y :
              (Line[1].Y-Line[0].Y)*(lb-Line[0].X)/(Line[1].X-Line[0].X)+Line[0].Y);

  n = Polygon.GetSize()-1;
  Line[1].X = rb;
  Line[1].Y = Polygon[n].Y;
  Line[0].X = Polygon[n].X;
  Line[0].Y = Polygon[n].Y;
  for(i=0;i<Polygon.GetSize()-1;i++) {  // find internal points
    if(Polygon[i].X < rb && rb < Polygon[i+1].X) {
      Line[0] = Polygon[i];
      Line[1] = Polygon[i+1];
    }
  }
  poly[poly.GetSize()-1].X = rb;
  poly[poly.GetSize()-1].Y = (fabs(Line[1].X-rb)<EPS) ? Line[1].Y :
              (fabs(Line[1].X-Line[0].X)<EPS ? Line[1].Y :
              (Line[1].Y-Line[0].Y)*(lb-Line[0].X)/(Line[1].X-Line[0].X)+Line[0].Y);

  Polygon = poly;
}

void MkProfile::SetDivision(MkPoints &pnts)
{
  int i,j;

  if(pnts.GetSize()<=0) return;
  MkPolygon poly(pnts.GetSize(),pnts.GetPoints());

  for(i=0;i<poly.GetSize();i++) {
    if(poly[i].X<=Polygon[0].X) {
      poly[i].Y = Polygon[0].Y;
    }
    else if(poly[i].X>=Polygon[Polygon.GetSize()-1].X) {
      poly[i].Y = Polygon[Polygon.GetSize()-1].Y;
    }
    else for(j=0;j<Polygon.GetSize()-1;j++) {
      if(Polygon[j].X <= poly[i].X && poly[i].X < Polygon[j+1].X) {
        float l1,l2;
        l1 = poly[i].X-Polygon[j].X;
        l2 = Polygon[j+1].X - Polygon[j].X;
        if(l2<EPS) poly[i].Y = Polygon[j].Y;
        else poly[i].Y = Polygon(j).GetDivision(l1/l2).Y;
      }
    }
  }
  Polygon = poly;
}

void MkProfile::ClearScript()
{
  if(Script) {
    delete[] Script;
    Script = NULL;
  }
}

bool MkProfile::MakeScript()
{
  char *str,name[30];
  int i, slen=0, tlen=0;

  ClearScript();

  slen = 2*Polygon.GetSize()*15+15;
  str = new char[slen];
  memset(str,'\0',slen-1);

  if(ProfType==pfNone) return false;

  switch(ProfType) {
    case pfLayer:
      strcpy(name,"Layer "); break;
    case pfCut:
      strcpy(name,"Cut "); break;
    case pfFill:
      strcpy(name,"Fill "); break;

  }
  strcat(str, name);
  tlen += strlen(name);

  sprintf(name,"%10d ",ProfNum);
  strcat(str, name);
  tlen += strlen(name);

  for(i=0;i<Polygon.GetSize();i++) {
    sprintf(name,", (%10g, %10g)",Polygon[i].X, Polygon[i].Y);
    tlen += strlen(name);
    if(tlen>slen) break;
    strcat(str,name);

  }
  if(tlen>slen) return false;
  strcat(str,"\n");

  Script = str;
  return true;
}

bool MkProfile::ParseScript(char *str)
{
  int i,num;
  char name[30];
  float x,y;
  Clear();

  Script = new char[strlen(str)+1];
  strcpy(Script,str);
  
  sscanf(Script,"%s %d ",name,&ProfNum);
  if(!strcmp(name,"Layer")) ProfType = pfLayer;
  else if(!strcmp(name,"Cut")) ProfType = pfCut;
  else if(!strcmp(name,"Fill")) ProfType = pfFill;

  num = NumOfParen(str);
  Polygon.Initialize(num);
  for(i=0;i<num;i++) {
    ExtractFromParen(str,i,x,y);
    Polygon[i].X = x;
    Polygon[i].Y = y;
  }
}

bool MkProfile::operator==(MkProfile &prof)
{
  return ProfNum==prof.ProfNum &&
         ProfType==prof.ProfType &&
         Polygon==prof.Polygon;
}

bool MkProfile::operator!=(MkProfile &prof)
{
  return ProfNum!=prof.ProfNum ||
         ProfType!=prof.ProfType ||
         Polygon!=prof.Polygon;
}

MkProfile &MkProfile::operator=(MkProfile &prof)
{
   ProfNum = prof.ProfNum;
   ProfType = prof.ProfType;
   Polygon = prof.Polygon;
   MakeScript();
}
//--------------------------------------------------------------------
MkProfiles::MkProfiles(int size,MkProfile *profs)
{

    if (size < 0) {
      MkDebug("::MkProfiles - MkProfiles(int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSize == 0) {
       FProfile = NULL;
       return;
    }

    FProfile = new MkProfile[FSize];
    for (int i=0;i<FSize;i++) (*this)[i] = profs[i];
}

MkProfiles::MkProfiles(int size)
{
    if (size < 0) {
      MkDebug("::MkProfiles - MkProfiles(int size)");;
      return;
    }

    FSize = FSizeOfArray = size;

    if (FSizeOfArray == 0) {
       FProfile = NULL;
       return;
    }

    FProfile = new MkProfile[FSizeOfArray];
}

MkProfiles::~MkProfiles()
{
   FSizeOfArray = FSize = 0;
   if (FProfile) {
      delete[] FProfile;
      FProfile = NULL;
   }
}

void MkProfiles::Initialize(int size)
{
    if (size < 0) {
      MkDebug("::MkProfiles - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;

    FSize = FSizeOfArray = size;

    if (FSizeOfArray == 0) {
       if (FProfile!=NULL) delete[] (MkProfile*)FProfile;
       FProfile = NULL;
       return;
    }

    if (FProfile!=NULL) delete[] (MkProfile*)FProfile;
    FProfile = new MkProfile[FSizeOfArray];
}

void MkProfiles::Initialize(int size,MkProfile *profs)
{

    if (size < 0 || profs == NULL) {
      MkDebug("::MkProfiles - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSize = FSizeOfArray = size;
    if (FSizeOfArray == 0) {
       if (FProfile!=NULL) delete[] (MkProfile*)FProfile;
       FProfile = NULL;
       return;
    }

    if (FProfile!=NULL) delete[] (MkProfile*)FProfile;
    FProfile = new MkProfile[FSizeOfArray];
    for (int i=0;i<FSizeOfArray;i++) FProfile[i] = profs[i];
}

int MkProfiles::Grow(int delta)
{
    int i;
    MkProfile *prof=NULL;

    if (!(prof = new MkProfile[FSizeOfArray+delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        prof[i] = FProfile[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        prof[i] = NullProfile;
    if (FProfile) {
       delete[] (MkProfile*)FProfile;
       FProfile = NULL;
    }
    FProfile = prof;
    FSizeOfArray = FSizeOfArray+delta;

    return FSizeOfArray;
}

int MkProfiles::Shrink(int delta)
{
    int i;
    MkProfile *prof=NULL;

    if (!(prof = new MkProfile[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        prof[i] = FProfile[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        prof[i] = NullProfile;
    if (FProfile) {
       delete[] (MkProfile*)FProfile;
       FProfile = NULL;
    }
    FProfile = prof;
    FSizeOfArray = FSizeOfArray-delta;

    return FSizeOfArray;
}

bool MkProfiles::Add(MkProfile &prof)
{
    int tmp=FSizeOfArray;
    bool flag=false;
    for (int i=0;i<FSize;i++) if (FProfile[i]==prof) flag=true;

    if(flag) return false;
    if (FSize>=FSizeOfArray) {
       Grow(FSize-FSizeOfArray+10);
       if (tmp==FSizeOfArray) return false;
    }
    FSize++;
    FProfile[FSize-1] = prof;

    return true;
}

bool MkProfiles::Add(int index, MkProfile &prof)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) Grow(FSize-FSizeOfArray+1);
    if(tmp==FSizeOfArray) return false;

    for (int i=FSize-1;i>=index;i--)
      FProfile[i+1] = FProfile[i];
    FSize++;
    FProfile[index] = prof;
    return true;
}

bool MkProfiles::Delete(MkProfile &prof)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FProfile[i] == prof) break;
    }
    if(i==FSize) return false;
    if(FProfile[i] == prof) {
      for (int j=i;j<FSize-1;j++)
        FProfile[j] = FProfile[j+1];
    }
    FSize--;
    FProfile[FSize] = NullProfile;
    return true;
}

bool MkProfiles::Delete(int index)
{
    for (int j=index;j<FSize-1;j++)
        FProfile[j] = FProfile[j+1];

    FSize--;
    FProfile[FSize] = NullProfile;
    return true;
}

bool MkProfiles::Clear()
{
   FSizeOfArray = FSize = 0;
   if (FProfile) {
      delete[] FProfile;
      FProfile = NULL;
   }
   return true;
}

MkProfile & MkProfiles::operator[](int i)
{
    if (FSizeOfArray == 0) return NullProfile;
    if (i >= FSize && i < FSizeOfArray) FSize = i+1;

    if (i >=0 && i < FSize) return FProfile[i];
    else return NullProfile;
}

MkProfiles & MkProfiles::operator=(MkProfiles &profs)
{
    int i;

    Clear();
    FSize = profs.FSize;
    FSizeOfArray = profs.FSizeOfArray;
    if (FSize == 0) {
       FProfile = NULL;
       return *this;
    }
    this->FProfile = new MkProfile[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FProfile[i] = profs.FProfile[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FProfile[i] = NullProfile;

    return *this;
}

bool MkProfiles::operator==(MkProfiles &profs)
{
  int i;

  if (FSize != profs.FSize) return false;
  for (i=0;i<FSize;i++)
    if (this->FProfile[i] != profs.FProfile[i]) return false;

  return true;
}

bool MkProfiles::Open()
{
  int i,n=0;
  FILE *fp;
  char str[512];

  fp = fopen(FileName,"r");
  if(!fp) return false;

  while(fp) {
    fgets(str,511,fp);
    if(strlen(str)) n++;
  }

  Initialize(n);
  
  n=0;
  while(fp) {
    fgets(str,511,fp);
    if(strlen(str)) {
      FProfile[n].ParseScript(str);
      n++;
    }
  }

  fclose(fp);
  return true;
}

bool MkProfiles::Save()
{
  int i;
  FILE *fp;
  char str;

  fp = fopen(FileName,"w");
  if(!fp) return false;
  for(i=0;i<FSize;i++) fprintf(fp,"%s",FProfile[i].GetScript());
  fclose(fp);
  return true;
}

bool MkProfiles::SyncDivision() // GLStrata should have same x points for Top & Bot prof
{
  int i, j, k;
  bool flag;
  MkPoints pnts;
  MkPoint pnt;

  for(i=0;i<FSize;i++) {
    for(j=0;j<FProfile[i].GetProfile().GetSize();j++) {
      flag = true;
      for(k=0;k<pnts.GetSize();k++) {
        if(fabs(pnts[k].X-FProfile[i][j].X)<EPS) flag = false;
      }
      if(flag) {
        pnt.X = FProfile[i][j].X;
        pnt.Y = 0;
        pnts.Add(pnt);
      }
    }
  }

  for(i=0;i<pnts.GetSize()-1;i++) {
    for(j=i+1;j<pnts.GetSize();j++) {
      if(pnts[i].X > pnts[j].X)
        Swap(pnts[i],pnts[j]);
    }
  }

  for(i=0;i<FSize;i++)
    FProfile[i].SetDivision(pnts);

  return true;
}
