//---------------------------------------------------------------------------

#ifndef MkLowDistH
#define MkLowDistH
#include "MkAnalysis.h"
//---------------------------------------------------------------------------
class MkLowDist : public MkAnalysis {

};

#endif
