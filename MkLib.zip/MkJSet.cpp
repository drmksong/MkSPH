//---------------------------------------------------------------------------
#include "MkJSet.h"

MkJSet NullMkJSet(0,0,0,0,0);

MkOrient & MkJSet::Gen()
{
     static MkOrient ori;
     float alpha,beta, psi, theta;
     float m;
     psi = MeanDip*M_PI/180;
     theta = MeanDipDir*M_PI/180;

     float pstd = sin(StdDev*M_PI/180);
     do {m = fabs(RandG(0,pstd)); } while (fabs(m) > 1);

     alpha = asin(m);
     beta = random(1000)/1000.0*2*M_PI;

     bool flag = transcod(psi,theta,alpha,beta);
     if (flag == false){
        alpha = 0;
        beta = 0;
     }

     ori.DipDir = beta;
     ori.Dip = alpha;
     return ori;
}

bool MkJSet::transcod(float alp, float bet, float &psi, float &theta)
{
      float f,x1,y1,z1,y2,z3,x3,y3;
      float theta1,theta2,xx1,xx2;
      x1 = sin(psi) * sin(theta);
      y1 = sin(psi) * cos(theta);
      z1 = cos(psi);

      y2 = cos(alp) * y1 + sin(alp) * z1;
      z3 =-sin(alp) * y1 + cos(alp) * z1;
      x3 = cos(bet) * x1 + sin(bet) * y2;
      y3 =-sin(bet) * x1 + cos(bet) * y2;

      psi = acos(z3);
      if (fabs(psi)<0.0001)
         theta = 0.;
      else {
	    f = y3 / sin(psi);

	    if(f<-1) f = -1.0;
	    if(f>1) f = 1.0;

	    theta1 = acos(f);
	    theta2 = 2 * M_PI - theta1;
	    xx1 = sin(psi) * sin(theta1);
	    xx2 = sin(psi) * sin(theta2);
	    if (fabs(xx1-x3)<0.001)
            theta = theta1;
         else if(fabs(xx2-x3)<0.001)
	       theta = theta2;
         else return false;
      }

      if (psi>M_PI/2) {
	   psi = M_PI - psi;
	   theta = theta + M_PI;
	   if (theta>2*M_PI) {
	      theta = theta - 2 * M_PI;
        }
      }
      return true;
}


MkJSets::MkJSets(int size,MkJSet *pjset)
{
    int i;

    Clear();
    FSize = size;
    if (FSize == 0) {
       FMkJSet = NULL;
    }
    FMkJSet = new MkJSet[FSize];

    for (i=0;i<FSize;i++)
      FMkJSet[i] = pjset[i];
}

MkJSets::MkJSets(int size)
{
    int i;

    Clear();
    FSize = size;
    if (FSize == 0) {
       FMkJSet = NULL;
    }
    FMkJSet = new MkJSet[FSize];
}

MkJSets::~MkJSets()
{
   FSize = 0;
   if (FMkJSet) {
      delete[] (MkJSet*)FMkJSet;
      FMkJSet = NULL;
   }
}

bool MkJSets::Clear()
{
   if (FSize == 0) return false; // I don't know this will be used.         -
   FSize = 0;
   if (FMkJSet) {
      delete[] (MkJSet*)FMkJSet;
      FMkJSet = NULL;
   }
   return true;
}

bool MkJSets::SetMkJSets(int size,MkJSet *pjset)
{
    int i;

    Clear();
    FSize = size;
    if (FSize == 0) {
       FMkJSet = NULL;
       return false;
    }
    FMkJSet = new MkJSet[FSize];

    for (i=0;i<FSize;i++)
      FMkJSet[i] = pjset[i];

    return true;
}

bool MkJSets::SetMkJSets(int size)
{
    int i;

    Clear();
    FSize = size;
    if (FSize == 0) {
       FMkJSet = NULL;
       return false;
    }
    FMkJSet = new MkJSet[FSize];

    return true;
}


bool MkJSets::Grow(int Delta)
{
    int i;
    MkJSet *jset=NULL;

    jset = new MkJSet[FSize+Delta];
    if (!jset) return false;

    for (i = 0; i < FSize;i++)
        jset[i] = FMkJSet[i];
    for (i=FSize; i<FSize+Delta;i++)
        jset[i] = NullMkJSet;
    if (FMkJSet) {
       delete[] (MkJSet*)FMkJSet;
       FMkJSet = NULL;
    }
    FMkJSet = jset;
    FSize = FSize+Delta;
    return true;
}


bool MkJSets::AddMkJSet(MkJSet ajset)
{
    bool flag = Grow(1);
    if (!flag) return flag;
    FMkJSet[FSize-1] = ajset;
    return true;

}

MkJSet & MkJSets::operator[](int i)
{
    if (FSize == 0) return NullMkJSet;
    else if (i >=0 && i < FSize) return FMkJSet[i];
    else return NullMkJSet;
}

MkJSets & MkJSets::operator=(MkJSets &jsets)
{
    int i;

    Clear();
    FSize = jsets.FSize;
    if (FSize == 0) {
       FMkJSet = NULL;
       return *this;
    }
    FMkJSet = new MkJSet[FSize];

    for (i=0;i<FSize;i++)
      FMkJSet[i] = jsets.FMkJSet[i];

    return *this;
}
//---------------------------------------------------------------------------
#pragma package(smart_init)
