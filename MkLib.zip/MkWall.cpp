//---------------------------------------------------------------------------
#include "MkWall.h"
#ifdef __BCPLUSPLUS__
#include <vcl.h>
#endif
#pragma hdrstop
//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#pragma package(smart_init)
#endif

bool MkWall::operator==(MkWall &w)
{
  bool flag;
  flag = MkEntity::operator==((MkEntity &)w);
  flag = flag && (Wall == w.Wall);
  return flag;
}

bool MkWall::operator!=(MkWall &w)
{
  return operator!=(w);
}

MkWall & MkWall::operator=(MkWall &w)
{
  MkEntity::operator=((MkEntity&)w);
  Wall = w.Wall;
  return *this;
}
//---------------------------------------------------------------------------


