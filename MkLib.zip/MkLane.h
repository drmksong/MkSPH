//---------------------------------------------------------------------------
#ifndef MkLaneH
#define MkLaneH

#ifdef __BCPLUSPLUS__
#include "GlobalVarUnit.h"
#endif

#include "MkObject.h"
#include "MkFloat.h"
//---------------------------------------------------------------------------
class MkLane : public MkObject {
public:
  int load_type;
  double load_dist;
  MkFloat load_kind;
public:
  MkLane(){Clear();}
  MkLane(int){Clear();}
  ~MkLane(){}
  void Clear(){load_type=0;load_dist=0;load_kind.Clear();}
};

class MkLanes {
protected:
  MkLane *FLane;
  int FSize;//Actual size of nodes
  int FSizeOfArray;
public:
  MkLanes(int size,MkLane *lane);
  MkLanes(int size);
  MkLanes(){FSizeOfArray = FSize = 0;FLane = NULL;}
  ~MkLanes();

  virtual void Initialize(int size);
  virtual void Initialize(int size,MkLane *);
  int GetSize(){return FSize;};
  int GetNumber(){return FSize;};
  bool Add(MkLane &lane);  // change of size of lane
  bool Add(int index,MkLane &lane);
  bool Delete(MkLane &lane);  // change of size of lane
  bool Delete(int index);
  int Grow(int Delta);            // change of size of array
  int Shrink(int Delta);          // change of size of array
  bool Clear();
  virtual MkLane & operator[](int);
  MkLanes & operator=(MkLanes &lanes);
  bool operator==(MkLanes &lanes);
#ifdef __BCPLUSPLUS__
  void Import(MkGlobalVar &globalvar, int sec, int pilesec);
  void Export(MkGlobalVar &globalvar, int sec, int pilesec);
#endif
};
extern MkLane NullMkLane;
#endif
