//---------------------------------------------------------------------------
#ifndef MyInterPolH
#define MyInterPolH
// interpolating splines and surfaces
class MyInterPol {
private:

protected:

public:

};
//---------------------------------------------------------------------------
#endif
