//---------------------------------------------------------------------------
#ifndef TnlFaceClsH
#define TnlFaceClsH

#include <Stdio.h>
#include <Math.h>
#include "MyFloat.h"
#include "MyCircle.h"
#include "MyPolygon.h"
#include "TTunPart.h"

extern TRealPoint NullPoint;
typedef enum {sLeft=0,sRight,sNone} TSide;
typedef
enum {pStartPoint=0,pEndPoint,pLineCenter,pRoadCenter,pTunnelCenter} TRoadPoint;

struct TRoad {
     bool isExist;
     int  Number;
     TRealPoint StartPoint,EndPoint,LineCenter,RoadCenter,TunnelCenter;
     TRealPolygon Polygon;
               // ����,     ����,   �����߽ɼ�,�����߽ɼ�, �ͳ��߽ɼ�
     float Width,Slope,SlopeAng;  // ���� �ۼ�Ʈ�� �Է�

     TRoad() {Number=0; Width=0; Slope=0; isExist=false;SlopeAng = 0;}
     TRoad(int n, float w, float s) {Number=n; Width=w; Slope = s; isExist=false;SlopeAng = atan2(-Slope,100);}
     float GetWidth(){if (isExist)return Width; else return 0;}
     float GetSlope(){if (isExist)return Slope; else return 0;}
     void GetInformation(TObject *Sender);

     TRealPoint & operator[](int i);
     TRealPoint & operator[](TRoadPoint rp);
     TRoad & operator=(TRoad &rd);
     void Locate(void);
     void MoveAbs(TRealPoint origin);
     void MoveRel(TRealPoint origin);
     void MakePolygon(void); // �������� ����� ���� ������ Ŭ���� ������� �Ǹ��̸�, �ǹ�.
     TRealPolygon &GetPolygon(void);
     void Draw(TObject *Sender);
};

struct TGuideStone{    // ����
     bool isExist;
     TSide Side;
     TRealPoint Origin;
     float Width, Height;  //meter
     TRealPoint StartPoint, MiddlePoint, EndPoint;
     TRealPolygon Polygon;
     TGuideStone(){Width = 0; Height=0;isExist=false;Side = sNone;}
     TGuideStone(TSide side){Width = 0; Height=0;isExist=false;Side = side;}
     TGuideStone(float w,float h){Width = w; Height=h;isExist=false;Side = sNone;}
     TGuideStone(float w,float h,TSide side)
        {Width = w; Height=h;isExist=false;Side = side;}
     void  SetSide(TSide side){Side = side;}
     float GetWidth(){if (isExist)return Width; else return 0;}
     float GetHeight(){if (isExist)return Height; else return 0;}
     void GetInformation(TObject *Sender);

     TGuideStone & operator=(TGuideStone & gs);
     TRealPoint & operator[](int i);
     void Locate(void);
     void MoveAbs(TRealPoint origin);
     void MoveRel(TRealPoint origin);
     void MakePolygon(void);// �������� ����� ���� ������ Ŭ���� ������� �Ǹ��̸�, �ǹ�.
     TRealPolygon &GetPolygon(void);
     void Draw(TObject *sender);
};

struct TInspectWay {    // �˻�� ���
     bool isExist;
     TRealPoint Origin;
     float Width, Height, Elev, InteriorMargin;   // meter
     TRealPolygon Polygon;
     TInspectWay() {Width=0; Height=0; Elev=0; InteriorMargin=0;isExist=false;}
     TInspectWay(float w,float h,float e,float im)
         {Width=w; Height=h; Elev=e; InteriorMargin=im;isExist=false;}
     float GetWidth(){if (isExist)return Width; else return 0;}
     float GetHeight(){if (isExist)return Height; else return 0;}
     float GetElev(){if (isExist)return Elev; else return 0;}
     float GetInteriorMargin(){if (isExist)return InteriorMargin; else return 0;}
     void GetInformation(TObject *Sender);

     TInspectWay & operator=(TInspectWay &iw);
     void Locate(void);
     void MoveAbs(TRealPoint origin);
     void MoveRel(TRealPoint origin);
     void MakePolygon(void);// �������� ����� ���� ������ Ŭ���� ������� �Ǹ��̸�, �ǹ�.
     TRealPolygon &GetPolygon(void);
     void Draw(TObject *sender);
};

struct TConstMargin {  // �ð����� : �����Ѱ���� �ּ�����
     bool isExist;
     float ConstLimit, InspectWay;  // centimeter
     TRealCircle LeftCLCircle,RightCLCircle,LeftIWCircle,RightIWCircle;
     TRealCircles Circles;
     TConstMargin(){ConstLimit=0; InspectWay=0;isExist=false;}
     TConstMargin(float cl,float iw){ConstLimit=cl; InspectWay=iw;isExist=false;}
     float GetCLMargin(){if (isExist)return ConstLimit; else return 0;}
     float GetIWMargin(){if (isExist)return InspectWay; else return 0;}
     void GetInformation(TObject *Sender);

     TConstMargin& operator=(TConstMargin &cm);
     TRealCircles &GetCircles(void){return Circles;};
     void Draw(TObject *sender);
};

struct TSideMarginWidth {    // ���濩��
     bool isExist;
     TSide Side;
     float Width;  // ���༱
     TSideMarginWidth(){Width=0; isExist=false;Side = sNone;}
     TSideMarginWidth(TSide side){Width=0; isExist=false;Side = side;}
     TSideMarginWidth(float w){Width=w; isExist=false;Side = sNone;}
     TSideMarginWidth(float w,TSide side){Width=w; isExist=false;Side = side;}
     void GetInformation(TObject *Sender);

     TSideMarginWidth & operator=(TSideMarginWidth &smw);
     void  SetSide(TSide side){Side = side;}
     float GetWidth(){if (isExist)return Width; else return 0;}
};

struct TDrainage {    // �����
     bool isExist;
     TSide Side;
     TRealPoint Origin;
     float Width, Slope,SlopeAng;  // ���� �ۼ�Ʈ�� �Է�
     TRealPoint StartPoint,EndPoint;
     TRealPolygon Polygon;
     TDrainage(){Width=0; Slope=0; isExist=false;SlopeAng = 0;Side = sNone;}
     TDrainage(TSide side){Width=0; Slope=0; isExist=false;SlopeAng = 0;Side = side;}
     TDrainage(float w,float s)
        {Width=w; Slope=s; isExist=false;SlopeAng = atan2(-Slope,100);Side = sNone;}
     TDrainage(float w,float s,TSide side)
        {Width=w; Slope=s; isExist=false;SlopeAng = atan2(-Slope,100);Side = side;}
     void  SetSide(TSide side){Side = side;}
     float GetWidth(){if (isExist)return Width; else return 0;}
     float GetSlope(){if (isExist)return Slope; else return 0;}
     void GetInformation(TObject *Sender);

     TDrainage & operator=(TDrainage &d);
     TRealPoint & operator[](int i);
     void Locate(void);
     void MoveAbs(TRealPoint origin);
     void MoveRel(TRealPoint origin);
     void MakePolygon(void);// �������� ����� ���� ������ Ŭ���� ������� �Ǹ��̸�, �ǹ�.
     TRealPolygon &GetPolygon(void);
     void Draw(TObject *sender);
};

struct TCheukDae {    // ����
     bool isExist;
     TSide Side;
     TRealPoint Origin;
     float Width, Slope,SlopeAng;
     TRealPoint StartPoint,EndPoint;
     TRealPolygon Polygon;
     TCheukDae(){Width=0;Slope = 0;isExist=false;SlopeAng = 0;Side = sNone;}
     TCheukDae(TSide side){Width=0;Slope = 0;isExist=false;SlopeAng = 0;Side = side;}
     TCheukDae(float w,float s)
         {Width=w;Slope = s; isExist=false;SlopeAng = atan2(-Slope,100);Side = sNone;}
     TCheukDae(float w,float s,TSide side)
         {Width=w;Slope = s; isExist=false;SlopeAng = atan2(-Slope,100);Side = side;}
     void  SetSide(TSide side){Side = side;}
     float GetWidth(){if (isExist)return Width; else return 0;}
     void GetInformation(TObject *Sender);

     TCheukDae & operator=(TCheukDae &d);
     TRealPoint & operator[](int i);
     void Locate(void);
     void MoveAbs(TRealPoint origin);
     void MoveRel(TRealPoint origin);
     void MakePolygon(void);// �������� ����� ���� ������ Ŭ���� ������� �Ǹ��̸�, �ǹ�.
     TRealPolygon &GetPolygon(void);
     void Draw(TObject *sender);
};

struct TGongDongGu {
     bool isExist;
     TSide Side;
     TRealPoint Origin;
     float InHeight, InWidth;  // ���� ũ��
     float CoverHeight, CoverWidth,CoverGap;  //
     float Height,Width;
     TRealPoint StartPoint, MiddlePoint, EndPoint;
     TRealPolygon Polygon;
     TGongDongGu(){ InHeight=0; InWidth=0; CoverHeight=0; CoverWidth=0;
                    CoverGap=0; Height=0; Width=0; isExist=false;Side = sNone;}
     TGongDongGu(TSide side){ InHeight=0; InWidth=0; CoverHeight=0; CoverWidth=0;
                    CoverGap=0; Height=0; Width=0; isExist=false;Side = side;}
     TGongDongGu(float ih,float iw,float ch,float cw,float cg,float h,float w)
         {InHeight=ih; InWidth=iw; CoverHeight=ch; CoverWidth=cw;
          CoverGap=cg; Height=h; Width=w; isExist=false;Side = sNone;}
     TGongDongGu(float ih,float iw,float ch,float cw,float cg,float h,float w,TSide side)
         {InHeight=ih; InWidth=iw; CoverHeight=ch; CoverWidth=cw;
          CoverGap=cg; Height=h; Width=w; isExist=false;Side = side;}
     void  SetSide(TSide side){Side = side;}
     float GetWidth(){if (isExist)return Width; else return 0;}
     float GetHeight(){if (isExist)return Height; else return 0;}
     float GetInWidth(){if (isExist)return InWidth; else return 0;}
     float GetInHeight(){if (isExist)return InHeight; else return 0;}
     float GetCoverWidth(){if (isExist)return CoverWidth; else return 0;}
     float GetCoverHeight(){if (isExist)return CoverHeight; else return 0;}
     float GetCoverGap(){if (isExist)return CoverGap; else return 0;}
     void GetInformation(TObject *Sender);

     TRealPoint & operator[](int i);
     TGongDongGu & operator=(TGongDongGu &gdg);
     void Locate(void);
     void MoveAbs(TRealPoint origin);
     void MoveRel(TRealPoint origin);
     void MakePolygon(void);// �������� ����� ���� ������ Ŭ���� ������� �Ǹ��̸�, �ǹ�.
     TRealPolygon &GetPolygon(void);
     void Draw(TObject *sender);
};

struct TTHP {
     bool isExist;
     TSide Side;
     TRealPoint Origin;
     TRealCircle Circle;
     TTHP(){Origin = NullPoint;Circle = NullCircle;isExist = false;Side = sNone;}
     TTHP(TSide side){Origin = NullPoint;Circle = NullCircle;isExist = false;Side = side;}
     TTHP(float radius)
          {Origin = NullPoint;
          Circle[0] = NullPoint;
          Circle.SetRadius(radius);isExist = false;
          Side = sNone;}
     TTHP(float radius,TSide side)
          {Origin = NullPoint;Circle[0] = NullPoint;
          Circle.SetRadius(radius);isExist = false;
          Side = side;}
     void  SetSide(TSide side){Side = side;}
     float SetCircle(TRealPoint & center, float radius,TSide side);
     float GetRadius(void){if (isExist) return Circle.GetRadius();else return 0;}
     TRealPoint & GetCenter(){if (isExist) return Circle[0];else return NullPoint;}
     TRealCircle GetCircle(){if (isExist) return Circle;else return NullCircle;}
     void GetInformation(TObject *Sender);

     TTHP & operator=(TTHP &thp);
     void Locate(void);
     void MoveAbs(TRealPoint origin);
     void MoveRel(TRealPoint origin);
     void Draw(TObject *sender);
};

struct TSteelPipe {
     bool isExist;
     TSide Side;
     TRealPoint Origin;
     TRealCircle Circle;
     TSteelPipe(){Origin = NullPoint;Circle = NullCircle;isExist = false;Side = sNone;}
     TSteelPipe(TSide side){Origin = NullPoint;Circle = NullCircle;isExist = false;Side = side;}
     TSteelPipe(float radius)
          {Origin = NullPoint;Circle[0] = NullPoint;
          Circle.SetRadius(radius);isExist = false;
          Side = sNone;}
     TSteelPipe(float radius,TSide side)
          {Origin = NullPoint;Circle[0] = NullPoint;
          Circle.SetRadius(radius);isExist = false;
          Side = side;}
     void  SetSide(TSide side){Side = side;}
     float SetCircle(TRealPoint & center, float radius,TSide side);
     float GetRadius(void){if (isExist ) return Circle.GetRadius();else return 0;}
     TRealPoint & GetCenter(){if (isExist) return Circle[0];else return NullPoint;}
     TRealCircle GetCircle(){if (isExist) return Circle;else return NullCircle;}
     void GetInformation(TObject *Sender);

     TSteelPipe & operator=(TSteelPipe &sp);
     void Locate(void);
     void MoveAbs(TRealPoint origin);
     void MoveRel(TRealPoint origin);
     void Draw(TObject *sender);
};

struct TPaveConc {
     bool isExist;
     TRealPoint Origin;
     float Height;
     TRealPolygon Polygon;
     float GetHeight(){if (isExist) return Height; else return 0;}
     void GetInformation(TObject *Sender);

     TPaveConc & operator=(TPaveConc &pc);
     void Locate(void);
     void MoveAbs(TRealPoint origin);
     void MoveRel(TRealPoint origin);
     void MakePolygon(void);// �������� ����� ���� ������ Ŭ���� ������� �Ǹ��̸�, �ǹ�.
     TRealPolygon &GetPolygon(void);
     void Draw(TObject *sender);
};

struct TMixConc {
     bool isExist;
     TRealPoint Origin;
     float Height;
     TRealPolygon Polygon;
     float GetHeight(){if (isExist) return Height; else return 0;}
     TMixConc & operator=(TMixConc &mc);
     void GetInformation(TObject *Sender);

     void Locate(void);
     void MoveAbs(TRealPoint origin);
     void MoveRel(TRealPoint origin);
     void MakePolygon(void);// �������� ����� ���� ������ Ŭ���� ������� �Ǹ��̸�, �ǹ�.
     TRealPolygon &GetPolygon(void);
     void Draw(TObject *sender);
};

struct TSelectLayer {
     bool isExist;
     TRealPoint Origin;
     float Height;
     TRealPolygon Polygon;
     float GetHeight(){if (isExist) return Height; else return 0;}
     void GetInformation(TObject *Sender);

     TSelectLayer & operator=(TSelectLayer &sl);
     void Locate(void);
     void MoveAbs(TRealPoint origin);
     void MoveRel(TRealPoint origin);
     void MakePolygon(void);// �������� ����� ���� ������ Ŭ���� ������� �Ǹ��̸�, �ǹ�.
     TRealPolygon & GetPolygon(void);
     void Draw(TObject *sender);
};

struct TInvert {  // �ι�Ʈ�� �ϴ� �������� ����
     bool isExist;
     bool isInstall;
     void GetInformation(TObject *Sender);
     void Draw(TObject *sender);
};

struct TCorner {  // �����Ѱ� �𼭸�
     bool isExist;
     float Height, Width;
     TCorner(){Height = 0;Width = 0;}
     TCorner(float height, float width){Height = height;Width = width;}
     void GetInformation(TObject *Sender);

     TCorner & operator = (TCorner &con);
};

class TConstLimit : public TRealPolygon {
private:
     bool isMade;
     TRoad Road;
     TGuideStone LeftGuideStone,RightGuideStone;
     TInspectWay InspectWay;
//     TConstMargin ConstMargin;
     TSideMarginWidth LeftSideMarginWidth,RightSideMarginWidth;
     TDrainage LeftDrainage,RightDrainage;
     TCheukDae LeftCheukDae,RightCheukDae;
     TGongDongGu LeftGongDongGu,RightGongDongGu;
     TTHP LeftTHP, RightTHP;
     TSteelPipe LeftSteelPipe,RightSteelPipe;
     TPaveConc PaveConc;
     TMixConc MixConc;
     TSelectLayer SelectLayer;
     TInvert Invert;
     TCorner Corner;

//     TRealPoint CilPoint[4]; // �ͳ��� ���ΰ� �����Ѱ踦 �����ϴ��� �Ǵ��ϴµ�
//     TRealPoint InsPoint[2]; // �ʿ��� �ڷ� CilPoint�� 30cm, ConPoint�� 10cm.
     TRealPoint LeftControlPoint;
     TRealPoint RightControlPoint;
     TRealPoint Center;

     float ShotcreteThickness; // ��ũ��Ʈ �β�
     float Height;     // �����Ѱ� ����
//     float ArchHeight; // �����Ѱ� ��� �����κ� ����
//     float ArchWidth;  // �����Ѱ� ��� �����κ� ����
public:
     __fastcall TConstLimit();
     void Init(TRoad &r);
     void Init(TSide side, TGuideStone &gs);
     void Init(TInspectWay &iw);
     void Init(TConstMargin &cm);
     void Init(TSide side, TSideMarginWidth &smw);
     void Init(TSide side, TDrainage &d);
     void Init(TSide side, TCheukDae &cd);
     void Init(TSide side, TGongDongGu &gdg);
     void InitShotcreteThickness(float lt);
     void InitHeight(float h){Height = h;}
     void Init(TCorner con){Corner = con;}
     void Init(TSide side, TTHP &thp);   // �����Ѱ踦 �����ϴµ���
     void Init(TSide side, TSteelPipe &sp);  // ���� ������� �������
     void Init(TPaveConc &pc);
     void Init(TMixConc &mc);
     void Init(TSelectLayer &sl);
     void Init(TInvert &iv);

     void Disable(TRoad &r);
     void Disable(TSide side, TGuideStone &gs);
     void Disable(TInspectWay &iw);
     void Disable(TConstMargin &cm);
     void Disable(TSide side, TSideMarginWidth &smw);
     void Disable(TSide side, TDrainage &d);
     void Disable(TSide side, TCheukDae &cd);
     void Disable(TSide side, TGongDongGu &gdg);

     void Enable(TRoad &r);
     void Enable(TSide side, TGuideStone &gs);
     void Enable(TInspectWay &iw);
     void Enable(TConstMargin &cm);
     void Enable(TSide side, TSideMarginWidth &smw);
     void Enable(TSide side, TDrainage &d);
     void Enable(TSide side, TCheukDae &cd);
     void Enable(TSide side, TGongDongGu &gdg);

     bool MakeConstLimit();
     bool CanMakeConstLimit();
     TRealPoint GetCenter();
     float GetIniLen();
     float GetIniLen(TRealPoint rp);
     TRealArc GetLeftArc(TRealArc &ra);
     TRealArc GetRightArc(TRealArc &ra);
     TRealPoint GetLeftControlPoint(){return LeftControlPoint;};
     TRealPoint GetRightControlPoint(){return RightControlPoint;};
     TConstLimit & operator=(TConstLimit &cl);
     bool InspectWayisExist(){return InspectWay.isExist;}
     void GetInformation(TObject *Sender);
     void Draw(TObject *Sender);

public:
     TRealPoint CilPoint[4]; // �ͳ��� ���ΰ� �����Ѱ踦 �����ϴ��� �Ǵ��ϴµ�
     TRealPoint InsPoint[2]; // �ʿ��� �ڷ� CilPoint�� 30cm, ConPoint�� 10cm.
     TConstMargin ConstMargin;
};

class TTunnelFace {
private:
     TTunPart InnerPerimeter;
     TTunPart OuterPerimeter;
     TTunPart PaveConc;
     TTunPart MixConc;
     TTunPart SelectLayer; // ������
     TTunPart Lining;
     TTunPart LowConcrete;
     TRealCircles THP;        // T.H.P.
     TRealCircles SteelPipe;  // �ƿ�������
     float BenchHeight;
public:
     __fastcall TTunnelFace(){};
     void  SetInnerPerimeter(TTunPart &ip);
     void  SetOuterPerimeter(TTunPart &op);
     void  SetPaveConc(TTunPart &pc);
     void  SetMixConc(TTunPart &mc);
     void  SetSelectLayer(TTunPart &sl);
     void  SetLowConc(TTunPart &lc);
     void  SetTHP(TRealCircles &thp);
     void  SetSteelPipe(TRealCircles &sp);
     void  SetBenchHeight(float bh);
//     void  SetLining();  // ���̴��� ��� ���� �Էµ� �Ŀ� ���Ǵ� ���
     float GetInnerArea();
     float GetTotalExcavArea();
     float GetPaveConcArea();
     float GetMixConcArea();
     float GetSelectLayerArea();
     float GetLiningArea();
     float GetUpArea();   // ��ݱ�����
     float GetLowArea();  // �Ϲݱ�����
     bool IsFeasible(TConstLimit &cl);
     void Draw(TObject *sender);
};

//---------------------------------------------------------------------------
#endif
