//---------------------------------------------------------------------------
#include "MkProject.h"

#include <vcl.h>
#pragma hdrstop

//---------------------------------------------------------------------------
#pragma package(smart_init)

MkProject::MkProject()
{
  Clear();
}

void MkProject::Clear()
{
  FileName="";
  rpath="";
  projectname="";
  projectcontent="";

  stress_type=0;
  liveloaddirection=0;
  liveload1=0;
  liveload2=0;
  liveload3=0;

  CurSec=0;
  CurrentStep=0;
  AnaType = atMori;
  Modified = false;
  isTanLoaded = false;

  Section.Clear();
  In.Clear();
  GlobalVar.Clear();
  GlobalClear();
  EarthWall.ClearMember();  // initialize the member variable
}

void MkProject::Initialize(int nsec)
{
  Clear();
  Section.Initialize(nsec);
  EarthWall.Initialize(nsec);
}

bool MkProject::Open(char *fname)
{
  int i,j,k,pos,len;
  AnsiString path,ext,name,data,sub,sub2;
  CFile fi;
  FILE *fp;
  bool flag=true;
  char str[256];

  pos = AnsiString(fname).Pos("&");
  len = AnsiString(fname).Length();
  sub = AnsiString(fname).SubString(1,pos-1);
  sub2 = AnsiString(fname).SubString(pos+1,len-1);

  FileName = (pos==0)?AnsiString(fname):sub+sub2;
	if(fi.Open(FileName.c_str(),CFile::modeRead)) {
  	CArchive ar(&fi,CArchive::load);
		ar>>GlobalVar.sectiontype;
		ar>>GlobalVar.InputLayerEA;
		ar>>GlobalVar.Inputplan;
		ar>>GlobalVar.SelectLayer;
		ar>>GlobalVar.Inputwale;
		ar>>GlobalVar.InputBogangjae;
		ar>>GlobalVar.projectcontent;
		ar>>GlobalVar.LayerBogang;

		ar.Close();
		fi.Close();
  }
  path = ExtractFilePath(FileName);
  ext = ExtractFileExt(FileName);
  name = ExtractFileName(FileName);

  strcpy(str,path.c_str());
  strncat(str,name.c_str(),name.Length()-ext.Length());
  strcat(str,".edf");

	if(!fi.Open(str,CFile::modeRead)) {
		ShowMessage("������ ������ �ջ� �Ǿ��ų� �����ϴ�\n\n�Ǵ� �⺻ �����͸� ��������� �⺻������ �ҷ����⸦ �ϼ��� ");
		return false;
	}
  else {
 		num=0;
		In_steel=200;

		CArchive ar(&fi,CArchive::load);

		//�ܸ� ����
		ar>>GlobalVar.section_ea;

		//���� ����
		for(i=0;i<=GlobalVar.section_ea;i++) {
			for(j=1;j<=14;j++) {
				ar>>GlobalVar.steelname[i][j];
				ar>>GlobalVar.steelkind[i][j];

				ar>>GlobalVar.OldSteel[i][j];
				ar>>GlobalVar.LongTimeSteel[i][j];
				ar>>GlobalVar.OldSteelReduction[i][j];
				ar>>GlobalVar.LongTimeSteelReduction[i][j];
			}

			ar>>GlobalVar.mainbeam_BB[i];
			ar>>GlobalVar.mainbeam_HH[i];
			ar>>GlobalVar.mainbeam_tt1[i];
			ar>>GlobalVar.mainbeam_tt2[i];
			ar>>GlobalVar.mainbeam_AA[i];
			ar>>GlobalVar.mainbeam_W[i];
			ar>>GlobalVar.mainbeam_Aw[i];
			ar>>GlobalVar.mainbeam_Zx[i];
			ar>>GlobalVar.mainbeam_Ix[i];
			ar>>GlobalVar.mainbeam_rx[i];
			ar>>GlobalVar.mainbeam_ry[i];

			ar>>GlobalVar.supportbeam_BB[i];
			ar>>GlobalVar.supportbeam_HH[i];
			ar>>GlobalVar.supportbeam_tt1[i];
			ar>>GlobalVar.supportbeam_tt2[i];
			ar>>GlobalVar.supportbeam_AA[i];
			ar>>GlobalVar.supportbeam_W[i];
			ar>>GlobalVar.supportbeam_Aw[i];
			ar>>GlobalVar.supportbeam_Zx[i];
			ar>>GlobalVar.supportbeam_Ix[i];
			ar>>GlobalVar.supportbeam_rx[i];
			ar>>GlobalVar.supportbeam_ry[i];

			ar>>GlobalVar.supportbeam_m_BB[i];
			ar>>GlobalVar.supportbeam_m_HH[i];
			ar>>GlobalVar.supportbeam_m_tt1[i];
			ar>>GlobalVar.supportbeam_m_tt2[i];
			ar>>GlobalVar.supportbeam_m_AA[i];
			ar>>GlobalVar.supportbeam_m_W[i];
			ar>>GlobalVar.supportbeam_m_Aw[i];
			ar>>GlobalVar.supportbeam_m_Zx[i];
			ar>>GlobalVar.supportbeam_m_Ix[i];
			ar>>GlobalVar.supportbeam_m_rx[i];
			ar>>GlobalVar.supportbeam_m_ry[i];

			ar>>GlobalVar.sidepile_BB[i];
			ar>>GlobalVar.sidepile_HH[i];
			ar>>GlobalVar.sidepile_tt1[i];
			ar>>GlobalVar.sidepile_tt2[i];
			ar>>GlobalVar.sidepile_AA[i];
			ar>>GlobalVar.sidepile_W[i];
			ar>>GlobalVar.sidepile_Aw[i];
			ar>>GlobalVar.sidepile_Zx[i];
			ar>>GlobalVar.sidepile_Ix[i];
			ar>>GlobalVar.sidepile_rx[i];
			ar>>GlobalVar.sidepile_ry[i];

			ar>>GlobalVar.midpile_BB[i];
			ar>>GlobalVar.midpile_HH[i];
			ar>>GlobalVar.midpile_tt1[i];
			ar>>GlobalVar.midpile_tt2[i];
			ar>>GlobalVar.midpile_AA[i];
			ar>>GlobalVar.midpile_W[i];
			ar>>GlobalVar.midpile_Aw[i];
			ar>>GlobalVar.midpile_Zx[i];
			ar>>GlobalVar.midpile_Ix[i];
			ar>>GlobalVar.midpile_rx[i];
			ar>>GlobalVar.midpile_ry[i];

			ar>>GlobalVar.strut_BB[i];
			ar>>GlobalVar.strut_HH[i];
			ar>>GlobalVar.strut_tt1[i];
			ar>>GlobalVar.strut_tt2[i];
			ar>>GlobalVar.strut_AA[i];
			ar>>GlobalVar.strut_W[i];
			ar>>GlobalVar.strut_Aw[i];
			ar>>GlobalVar.strut_Zx[i];
			ar>>GlobalVar.strut_Ix[i];
			ar>>GlobalVar.strut_rx[i];
			ar>>GlobalVar.strut_ry[i];

			for(int ry=0;ry<=29;ry++) {
				ar>>GlobalVar.walename[i][ry];
				ar>>GlobalVar.wale_BB[i][ry];
				ar>>GlobalVar.wale_HH[i][ry];
				ar>>GlobalVar.wale_tt1[i][ry];
				ar>>GlobalVar.wale_tt2[i][ry];
				ar>>GlobalVar.wale_AA[i][ry];
				ar>>GlobalVar.wale_W[i][ry];
				ar>>GlobalVar.wale_Aw[i][ry];
				ar>>GlobalVar.wale_Zx[i][ry];
				ar>>GlobalVar.wale_Ix[i][ry];
				ar>>GlobalVar.wale_rx[i][ry];
				ar>>GlobalVar.wale_ry[i][ry];
			}

			ar>>GlobalVar.sheetpile_BB[i];
			ar>>GlobalVar.sheetpile_HH[i];
			ar>>GlobalVar.sheetpile_tt1[i];
			ar>>GlobalVar.sheetpile_AA[i];
			ar>>GlobalVar.sheetpile_Aw[i];
			ar>>GlobalVar.sheetpile_W[i];
			ar>>GlobalVar.sheetpile_Zx[i];

			ar>>GlobalVar.C_Fck[i];
			ar>>GlobalVar.C_Fy[i];
			ar>>GlobalVar.C_BarDia[i];
			ar>>GlobalVar.C_CIPSteel[i];
			ar>>GlobalVar.C_Thick_or_Dia[i];
			ar>>GlobalVar.C_Bar_EA[i];
		}

		ar>>GlobalVar.layer_ea;
		ar>>GlobalVar.In_layer_ea;
		ar>>GlobalVar.In_layerdepth;
		ar>>GlobalVar.In_layer;
		for(i=1;i<=GlobalVar.layer_ea;i++) {
			ar>>GlobalVar.layername[i];
			for(j=0;j<=GlobalVar.section_ea;j++) {
				ar>>GlobalVar.layer_depth_L[j][i];
				ar>>GlobalVar.layer_depth_R[j][i];
				ar>>GlobalVar.Rt[j][i];
				ar>>GlobalVar.Rsub[j][i];
				ar>>GlobalVar.C[j][i];
				ar>>GlobalVar.Pi[j][i];
				ar>>GlobalVar.Ks[j][i];
			}
		}

		for(i=1;i<=GlobalVar.section_ea;i++) {
			ar>>GlobalVar.pile_ea[i];
			ar>>GlobalVar.exca_depth_L[i];
			ar>>GlobalVar.exca_depth_R[i];
			ar>>GlobalVar.deck[i];
			ar>>GlobalVar.ToptoGL[i];
			ar>>GlobalVar.GL_R_minus_GL_L[i];
			ar>>GlobalVar.SidepileCTC[i];
			ar>>GlobalVar.MidpileCTC[i];
			ar>>GlobalVar.SideInsert[i];
			ar>>GlobalVar.MidInsert[i];

			for(j=1;j<=GlobalVar.pile_ea[i]-1;j++) {
				ar>>GlobalVar.piledist[i][j];
				ar>>GlobalVar.bracing_ea[i][j];
				ar>>GlobalVar.bracingtype[i][j];
				ar>>GlobalVar.bracingNN[i][j];

				for(k=1;k<=GlobalVar.bracing_ea[i][j];k++)
					ar>>GlobalVar.bracing_len[i][j][k];
			}

			ar>>GlobalVar.In_support_L;
			ar>>GlobalVar.In_support_R;
			ar>>GlobalVar.supportdan_L[i];
			ar>>GlobalVar.supportdan_R[i];

			for(j=1;j<=GlobalVar.supportdan_L[i];j++) {
				ar>>GlobalVar.support_depth_L[i][j];
				ar>>GlobalVar.support_type_L[i][j];
				ar>>GlobalVar.support_var_L[i][j];
				ar>>GlobalVar.support_freelen_L[i][j];
				ar>>GlobalVar.support_sticklen_L[i][j];
				ar>>GlobalVar.support_jackingforce_L[i][j];
				ar>>GlobalVar.support_tendonEA_L[i][j];
			}

			for(j=1;j<=GlobalVar.supportdan_R[i];j++) {
				ar>>GlobalVar.support_depth_R[i][j];
				ar>>GlobalVar.support_type_R[i][j];
				ar>>GlobalVar.support_var_R[i][j];
				ar>>GlobalVar.support_freelen_R[i][j];
				ar>>GlobalVar.support_sticklen_R[i][j];
				ar>>GlobalVar.support_jackingforce_R[i][j];
				ar>>GlobalVar.support_tendonEA_R[i][j];
			}
		}

		ar>>GlobalVar.stress_type;
		ar>>GlobalVar.liveload1;
		ar>>GlobalVar.liveload2;
		ar>>GlobalVar.liveload3;
		ar>>GlobalVar.In_liveload;
		ar>>GlobalVar.liveloaddirection;
		ar>>GlobalVar.decktype;
		ar>>GlobalVar.water_level_type;
		ar>>GlobalVar.reductionrate;
		ar>>GlobalVar.reductiondepth;

		ar>>GlobalVar.In_jibanbogang;
		if(GlobalVar.In_jibanbogang==100) {
			ar>>GlobalVar.jibanbogang_ea;
			ar>>GlobalVar.jibanboganglayer;
			ar>>GlobalVar.jibanbogangdepth;

			for(i=1;i<=GlobalVar.jibanbogang_ea;i++) {
				ar>>GlobalVar.jibanbogang_kind[i];
				ar>>GlobalVar.jibanbogang_width[i];
				ar>>GlobalVar.jibanbogang_ctc[i];
				ar>>GlobalVar.jibanbogang_rctc[i];
				ar>>GlobalVar.jibanbogang_row[i];
			}
		}
		ar.Close();
		fi.Close();
  }

  Import(GlobalVar);

  path = ExtractFilePath(FileName);
  ext = ExtractFileExt(FileName);
  name = ExtractFileName(FileName);

  strcpy(str,path.c_str());
  strncat(str,name.c_str(),name.Length()-ext.Length());
  strcat(str,".esf");

  fp = fopen(str,"r");
  if(!fp) flag = false;
  else {
    for(i=0;i<Section.GetSize();i++) {
      rewind(fp);
      MkExcavStep &es = Section[i].GetExcavStep();
      flag = es.In(fp) && flag;
      Section[i].SetDepthUnderDan(es.GetDepthUnderDan());
      Section[i].BuildCutnFill();
    }
    fclose(fp);
  }

  strcpy(str,path.c_str());
  strncat(str,name.c_str(),name.Length()-ext.Length());
  strcat(str,".prf");

  fp = fopen(str,"r");
  if(!fp) flag = false;
  else {
    for(i=0;i<Section.GetSize();i++) {
//      MkProfiles &prf = Section[i].GetProfiles();
//      flag = flag && prf.Open(str);
      Section[i].LoadProfile(str);
    }
    fclose(fp);
  }

  strcpy(str,path.c_str());
  strncat(str,name.c_str(),name.Length()-ext.Length());
  strcat(str,".etf");

  fp = fopen(str,"r");
  if(!fp) flag = false;
  else {
    int nsec,nl,nr,tan;
    fgets(str,255,fp);
    sscanf(str,"%d : Number of Section",&nsec);
    if(nsec == GlobalVar.section_ea) {
      for(i=1;i<=GlobalVar.section_ea;i++) {
        fgets(str,255,fp);
        sscanf(str,"  %d : Number of Left Support",&nl);
        if(nl==GlobalVar.supportdan_L[i]) {
  				for(j=1;j<=nl;j++) {
            sscanf(str,"    %d : j-th Support Dan of i-th Section",&tan);
            GlobalVar.support_tan_L[i][j] = tan;
            //smk support_tan_L is newly added variable
			  	}
        }
        fgets(str,255,fp);
        sscanf(str,"  %d : Number of Right Support",&nr);
        if(nr==GlobalVar.supportdan_R[i]) {
  				for(j=1;j<=nr;j++)	{
            sscanf(str,"    %d : j-th Support Dan of i-th Section",&tan);
            GlobalVar.support_tan_R[i][j] = tan;
            //smk support_tan_R is newly added variable
			  	}
        }
      }
    }
    isTanLoaded = true;
    fclose(fp);
  }

  SetupSection();
  EarthWall.Import(Section);
  return flag;
}

bool MkProject::OpenBasic(char *fname)
{
/*	TC_ITEM item,item1;

	CFileDialog dlg(TRUE,_T("EPF"),_T(""),OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT
		|OFN_LONGNAMES,_T("ESCOT Project File(*.EPF)|*.EPF|"));

	if(dlg.DoModal()!=IDOK)
		return;
*/
  AnsiString path,ext,name;
  FILE *fp;
  char str[256];

  FILE *in;
  CString rpath, sss, ss;
  CFile fi;
  char text[200],text1[80],text2[80],txt[15][20],tmptext[30][20];
  int tmp_ea,i,j,k,m;
	In_Call_data=100;
  double tmp,tmp1;
//	ss=dlg.GetPathName();

	fi.Open(fname,CFile::modeRead);
	CArchive ar(&fi,CArchive::load);

	ar>>GlobalVar.sectiontype;  //sectiontype=100 : ���� 1�� , sectiontype=101 : ���� 2�� �̻�
	ar>>GlobalVar.InputLayerEA;
	ar>>GlobalVar.Inputplan;
	ar>>GlobalVar.SelectLayer;
	ar>>GlobalVar.Inputwale;
	ar>>GlobalVar.InputBogangjae;
	ar>>GlobalVar.projectcontent;
	ar>>GlobalVar.LayerBogang;

	ar.Close();
	fi.Close();

	sss.Format("%s",fname);
	ss.TrimRight(sss);
	rpath=ss;
//	projectname=dlg.GetFileTitle();

	//�ܸ鰳�� ������ �б�
	ss.Format("%ssectionpoint.EBF",rpath);
	in=fopen(ss,"r");
	fscanf(in,"%d",&GlobalVar.section_ea);
	fclose(in);

	//���� ������ �б�
	int slength;
	ss.Format("%sstratum.EBF",rpath);
	in=fopen(ss,"r");

	fgets(text,20,in);
	GlobalVar.layer_ea=atoi(text);

	for(i=1;i<=GlobalVar.layer_ea;i++) {
		fgets(text,50,in);
		ss.Format("%s",text);
		if(i!=GlobalVar.layer_ea)	{
			slength=ss.GetLength();
			ss.TrimRight(ss[slength-1]);
		}
		GlobalVar.layername[i]=ss;
	}
	fclose(in);

	if(GlobalVar.sectiontype==100) //���� ����
		ss.Format("%slayer.EBF",rpath);
	else
		ss.Format("%slayer_L.EBF",rpath);

	in=fopen(ss,"r");
	fgets(text,20,in); //�ܸ� ����

	for(i=1;i<=GlobalVar.section_ea;i++){
		fgets(text,20,in); //��ĭ
		fgets(text,80,in); //��ġ

		fgets(text,100,in); //�ѱ��� ����
		sscanf(text,"%s %s",text1,text2);
		R_exca_depth_L[i]=atoi(text2)/1000.0;

		fgets(text,180,in); //���� ����
		sscanf(text,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",text1,tmptext[1],text1,tmptext[2],text1,tmptext[3]
			,text1,tmptext[4],text1,tmptext[5],text1,tmptext[6],text1,tmptext[7],text1,tmptext[8],text1,tmptext[9]);

		for(j=1;j<=GlobalVar.layer_ea-1;j++)
			R_layer_depth_L[i][j]=atoi(tmptext[j])/1000.0;

		R_layer_depth_L[i][j]=99.0;
	}
	fclose(in);
	GlobalVar.In_layerdepth=100;


	if(GlobalVar.sectiontype==101) {//���� 2�� �̻�
		ss.Format("%slayer_R.EBF",rpath);
		in=fopen(ss,"r");
		fgets(text,20,in);

		for(i=1;i<=GlobalVar.section_ea;i++){
			fgets(text,20,in); //��ĭ
			fgets(text,80,in); //��ġ

			fgets(text,100,in); //�ѱ��� ����
			sscanf(text,"%s %s",text1,text2);
			R_exca_depth_R[i]=atoi(text2)/1000.0;

			fgets(text,180,in); //���� ����
			sscanf(text,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",text1,tmptext[1],text1,tmptext[2],text1,tmptext[3]
				,text1,tmptext[4],text1,tmptext[5],text1,tmptext[6],text1,tmptext[7],text1,tmptext[8],text1,tmptext[9]);

			for(j=1;j<=GlobalVar.layer_ea-1;j++)
				R_layer_depth_R[i][j]=atoi(tmptext[j])/1000.0;

			R_layer_depth_R[i][j]=99.0;
		}
		fclose(in);
	}


	if(GlobalVar.sectiontype==101) {//���� 2�� �̻�
		//���� ������ �б�
		ss.Format("%ssectionwidth.EBF",rpath);
		in=fopen(ss,"r");
		fgets(text,80,in);

		for(i=1;i<=GlobalVar.section_ea;i++) {
			fgets(text,80,in);
			fgets(text,80,in);
			fgets(text,80,in);

			GlobalVar.pile_ea[i]=know_pile_ea(text)+1;

			if(GlobalVar.pile_ea[i]==2) {
				sscanf(text,"%s %s",text1,txt[1]);
				GlobalVar.piledist[i][1]=atoi(txt[1])/1000.0;
			}
      else if(GlobalVar.pile_ea[i]==3) {
				sscanf(text,"%s %s %s",text1,txt[2],txt[1]);
				GlobalVar.piledist[i][1]=atoi(txt[1])/1000.0;
				GlobalVar.piledist[i][2]=atoi(txt[2])/1000.0-GlobalVar.piledist[i][1];
			}
      else if(GlobalVar.pile_ea[i]==4) {
				sscanf(text,"%s %s %s %s",text1,txt[3],txt[2],txt[1]);
				GlobalVar.piledist[i][1]=atoi(txt[1])/1000.0;
				GlobalVar.piledist[i][2]=atoi(txt[2])/1000.0-GlobalVar.piledist[i][1];
				GlobalVar.piledist[i][3]=atoi(txt[3])/1000.0-GlobalVar.piledist[i][1]-GlobalVar.piledist[i][2];
			}
      else if(GlobalVar.pile_ea[i]==5) {
				sscanf(text,"%s %s %s %s %s",text1,txt[4],txt[3],txt[2],txt[1]);
				GlobalVar.piledist[i][1]=atoi(txt[1])/1000.0;
				GlobalVar.piledist[i][2]=atoi(txt[2])/1000.0-GlobalVar.piledist[i][1];
				GlobalVar.piledist[i][3]=atoi(txt[3])/1000.0-GlobalVar.piledist[i][1]-GlobalVar.piledist[i][2];
				GlobalVar.piledist[i][4]=atoi(txt[4])/1000.0-GlobalVar.piledist[i][1]-GlobalVar.piledist[i][2]-GlobalVar.piledist[i][3];
			}
      else if(GlobalVar.pile_ea[i]==6) {
				sscanf(text,"%s %s %s %s %s %s",text1,txt[5],txt[4],txt[3],txt[2],txt[1]);
				GlobalVar.piledist[i][1]=atoi(txt[1])/1000.0;
				GlobalVar.piledist[i][2]=atoi(txt[2])/1000.0-GlobalVar.piledist[i][1];
				GlobalVar.piledist[i][3]=atoi(txt[3])/1000.0-GlobalVar.piledist[i][1]-GlobalVar.piledist[i][2];
				GlobalVar.piledist[i][4]=atoi(txt[4])/1000.0-GlobalVar.piledist[i][1]-GlobalVar.piledist[i][2]-GlobalVar.piledist[i][3];
				GlobalVar.piledist[i][5]=atoi(txt[5])/1000.0-GlobalVar.piledist[i][1]-GlobalVar.piledist[i][2]-GlobalVar.piledist[i][3]-GlobalVar.piledist[i][4];
			}
      else if(GlobalVar.pile_ea[i]==7) {
				sscanf(text,"%s %s %s %s %s %s %s",text1,txt[6],txt[5],txt[4],txt[3],txt[2],txt[1]);
				GlobalVar.piledist[i][1]=atoi(txt[1])/1000.0;
				GlobalVar.piledist[i][2]=atoi(txt[2])/1000.0-GlobalVar.piledist[i][1];
				GlobalVar.piledist[i][3]=atoi(txt[3])/1000.0-GlobalVar.piledist[i][1]-GlobalVar.piledist[i][2];
				GlobalVar.piledist[i][4]=atoi(txt[4])/1000.0-GlobalVar.piledist[i][1]-GlobalVar.piledist[i][2]-GlobalVar.piledist[i][3];
				GlobalVar.piledist[i][5]=atoi(txt[5])/1000.0-GlobalVar.piledist[i][1]-GlobalVar.piledist[i][2]-GlobalVar.piledist[i][3]-GlobalVar.piledist[i][4];
				GlobalVar.piledist[i][6]=atoi(txt[6])/1000.0-GlobalVar.piledist[i][1]-GlobalVar.piledist[i][2]-GlobalVar.piledist[i][3]-GlobalVar.piledist[i][4]-GlobalVar.piledist[i][5];
			}
      else if(GlobalVar.pile_ea[i]==8) {
				sscanf(text,"%s %s %s %s %s %s %s %s",text1,txt[7],txt[6],txt[5],txt[4],txt[3],txt[2],txt[1]);
				GlobalVar.piledist[i][1]=atoi(txt[1])/1000.0;
				GlobalVar.piledist[i][2]=atoi(txt[2])/1000.0-GlobalVar.piledist[i][1];
				GlobalVar.piledist[i][3]=atoi(txt[3])/1000.0-GlobalVar.piledist[i][1]-GlobalVar.piledist[i][2];
				GlobalVar.piledist[i][4]=atoi(txt[4])/1000.0-GlobalVar.piledist[i][1]-GlobalVar.piledist[i][2]-GlobalVar.piledist[i][3];
				GlobalVar.piledist[i][5]=atoi(txt[5])/1000.0-GlobalVar.piledist[i][1]-GlobalVar.piledist[i][2]-GlobalVar.piledist[i][3]-GlobalVar.piledist[i][4];
				GlobalVar.piledist[i][6]=atoi(txt[6])/1000.0-GlobalVar.piledist[i][1]-GlobalVar.piledist[i][2]-GlobalVar.piledist[i][3]-GlobalVar.piledist[i][4]-GlobalVar.piledist[i][5];
				GlobalVar.piledist[i][7]=atoi(txt[7])/1000.0-GlobalVar.piledist[i][1]-GlobalVar.piledist[i][2]-GlobalVar.piledist[i][3]-GlobalVar.piledist[i][4]-GlobalVar.piledist[i][5]-GlobalVar.piledist[i][6];
			}
		}
		fclose(in);



		//���� �극�̽� ������ �б�
		ss.Format("%sRSM.EBF",rpath);
		in=fopen(ss,"r");
		fgets(text,50,in); //�ܸ� ����

		for(i=1;i<=GlobalVar.section_ea;i++) {
			fgets(text,20,in); //��ĭ
			fgets(text,80,in); //��ġ
			fgets(text,20,in); //�극�̽� ����
			tmp_ea=atoi(text);

			fgets(text,199,in); //�극�̽� ����
			sscanf(text,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",tmptext[1],tmptext[2]
				,tmptext[3],tmptext[4],tmptext[5],tmptext[6],tmptext[7],tmptext[8],tmptext[9],tmptext[10],tmptext[11]
				,tmptext[12],tmptext[13],tmptext[14],tmptext[15],tmptext[16],tmptext[17],tmptext[18],tmptext[19],tmptext[20]
				,tmptext[21],tmptext[22],tmptext[23],tmptext[24],tmptext[25]);

			m=1;

			tmp=0.0;
			tmp1=0.0;

			for(j=1;j<GlobalVar.pile_ea[i];j++) {
				tmp1+=GlobalVar.piledist[i][j];
				tmp=tmp1-GlobalVar.piledist[i][j];

				for(k=1;;k++) {
					if(atoi(tmptext[m])/1000.0>tmp1) {
						GlobalVar.bracing_len[i][j][k]=tmp1-atoi(tmptext[m-1])/1000.0;
						GlobalVar.bracing_ea[i][j]=k;
						break;
					}

					if(k==1)
						GlobalVar.bracing_len[i][j][1]=atoi(tmptext[m])/1000.0-tmp;
					else
						GlobalVar.bracing_len[i][j][k]=atoi(tmptext[m])/1000.0-atoi(tmptext[m-1])/1000.0;

					m++;

					if(m>tmp_ea) {
						GlobalVar.bracing_len[i][j][k+1]=tmp1-atoi(tmptext[m-1])/1000.0;
						GlobalVar.bracing_ea[i][j]=k+1;
						break;
					}
				}
			}
		}
		In_bracing=100;
		fclose(in);
	}
  else {
		for(i=1;i<=GlobalVar.section_ea;i++)
			GlobalVar.pile_ea[i]=1;
	}


	//���� ������ ������ �б�
	if(GlobalVar.sectiontype==100) //���� 1��
		ss.Format("%ssupport.EBF",rpath);
	else
		ss.Format("%ssupport_L.EBF",rpath);

	in=fopen(ss,"r");
	fgets(text,50,in); //�ܸ� ����
	fgets(text,20,in); //��ĭ

	for(i=1;i<=GlobalVar.section_ea;i++) {
		fgets(text,199,in); //��ġ

		for(j=1;;j++) {
			fgets(text,199,in); //����TYPE , ����
			sscanf(text,"%s %s %s",tmptext[1],tmptext[2],tmptext[3]);

			if(atoi(tmptext[1])!=j) {
				GlobalVar.supportdan_L[i]=j-1;
				break;
			}

			GlobalVar.support_type_L[i][j].Format("%s",tmptext[2]);
			R_support_depth_L[i][j]=atoi(tmptext[3])/1000.0;
		}
	}
	GlobalVar.In_support_L=100;
	fclose(in);

	if(GlobalVar.sectiontype==101) {//���� 2�� �̻�
		//���� ������ ������ �б�
		ss.Format("%ssupport_R.EBF",rpath);
		in=fopen(ss,"r");
		fgets(text,50,in); //�ܸ� ����
		fgets(text,20,in); //��ĭ

		for(i=1;i<=GlobalVar.section_ea;i++) {
			fgets(text,199,in); //��ġ
			sscanf(text,"%s %s %s",text1,text2,text1);
			GlobalVar.GL_R_minus_GL_L[i]=atof(text1);

			for(j=1;;j++) {
				fgets(text,199,in); //����TYPE , ����
				sscanf(text,"%s %s %s",tmptext[1],tmptext[2],tmptext[3]);

				if(atoi(tmptext[1])!=j) {
					GlobalVar.supportdan_R[i]=j-1;
					break;
				}

				GlobalVar.support_type_R[i][j].Format("%s",tmptext[2]);
				R_support_depth_R[i][j]=atoi(tmptext[3])/1000.0;
			}
		}
		GlobalVar.In_support_R=100;
		fclose(in);
	}

	if(GlobalVar.sectiontype==101) //���� 2�� �̻�
	{
		if(GlobalVar.decktype==0) //���� ������ ����
		{
			for(i=1;i<=GlobalVar.section_ea;i++)
			{
				if(GlobalVar.GL_R_minus_GL_L[i]>=0)
				{
					GlobalVar.exca_depth_L[i]=R_exca_depth_L[i]+GlobalVar.GL_R_minus_GL_L[i];
					GlobalVar.exca_depth_R[i]=R_exca_depth_R[i];

					for(j=1;j<=30;j++)
					{
						GlobalVar.layer_depth_L[i][j]=R_layer_depth_L[i][j]+GlobalVar.GL_R_minus_GL_L[i];
						GlobalVar.layer_depth_R[i][j]=R_layer_depth_R[i][j];

						GlobalVar.support_depth_L[i][j]=R_support_depth_L[i][j]+GlobalVar.GL_R_minus_GL_L[i];
						GlobalVar.support_depth_R[i][j]=R_support_depth_R[i][j];
					}
				}else
				{
					GlobalVar.exca_depth_L[i]=R_exca_depth_L[i];
					GlobalVar.exca_depth_R[i]=R_exca_depth_R[i]-GlobalVar.GL_R_minus_GL_L[i];

					for(j=1;j<=30;j++)
					{
						GlobalVar.layer_depth_L[i][j]=R_layer_depth_L[i][j];
						GlobalVar.layer_depth_R[i][j]=R_layer_depth_R[i][j]-GlobalVar.GL_R_minus_GL_L[i];

						GlobalVar.support_depth_L[i][j]=R_support_depth_L[i][j];
						GlobalVar.support_depth_R[i][j]=R_support_depth_R[i][j]-GlobalVar.GL_R_minus_GL_L[i];
					}
				}
			}
		}else if(GlobalVar.decktype==1) //���� ������ ����
		{
			for(i=1;i<=GlobalVar.section_ea;i++)
			{
				if(GlobalVar.GL_R_minus_GL_L[i]>=0)
				{
					GlobalVar.exca_depth_L[i]=R_exca_depth_L[i];
					GlobalVar.exca_depth_R[i]=R_exca_depth_R[i]-GlobalVar.GL_R_minus_GL_L[i];

					for(j=1;j<=30;j++)
					{
						GlobalVar.layer_depth_L[i][j]=R_layer_depth_L[i][j];
						GlobalVar.layer_depth_R[i][j]=R_layer_depth_R[i][j]-GlobalVar.GL_R_minus_GL_L[i];

						GlobalVar.support_depth_L[i][j]=R_support_depth_L[i][j];
						GlobalVar.support_depth_R[i][j]=R_support_depth_R[i][j]-GlobalVar.GL_R_minus_GL_L[i];
					}
				}else
				{
					GlobalVar.exca_depth_L[i]=R_exca_depth_L[i]+GlobalVar.GL_R_minus_GL_L[i];
					GlobalVar.exca_depth_R[i]=R_exca_depth_R[i];

					for(j=1;j<=30;j++)
					{
						GlobalVar.layer_depth_L[i][j]=R_layer_depth_L[i][j]+GlobalVar.GL_R_minus_GL_L[i];
						GlobalVar.layer_depth_R[i][j]=R_layer_depth_R[i][j];

						GlobalVar.support_depth_L[i][j]=R_support_depth_L[i][j]+GlobalVar.GL_R_minus_GL_L[i];
						GlobalVar.support_depth_R[i][j]=R_support_depth_R[i][j];
					}
				}
			}
		}else if(GlobalVar.decktype==2) //������ ������ ����
		{
			for(i=1;i<=GlobalVar.section_ea;i++)
			{
				if(GlobalVar.GL_R_minus_GL_L[i]>=0)
				{
					GlobalVar.exca_depth_L[i]=R_exca_depth_L[i];
					GlobalVar.exca_depth_R[i]=R_exca_depth_R[i];

					for(j=1;j<=30;j++)
					{
						GlobalVar.layer_depth_L[i][j]=R_layer_depth_L[i][j];
						GlobalVar.layer_depth_R[i][j]=R_layer_depth_R[i][j];

						GlobalVar.support_depth_L[i][j]=R_support_depth_L[i][j];
						GlobalVar.support_depth_R[i][j]=R_support_depth_R[i][j];
					}
				}else
				{
					GlobalVar.exca_depth_L[i]=R_exca_depth_L[i];
					GlobalVar.exca_depth_R[i]=R_exca_depth_R[i];

					for(j=1;j<=30;j++)
					{
						GlobalVar.layer_depth_L[i][j]=R_layer_depth_L[i][j];
						GlobalVar.layer_depth_R[i][j]=R_layer_depth_R[i][j];

						GlobalVar.support_depth_L[i][j]=R_support_depth_L[i][j];
						GlobalVar.support_depth_R[i][j]=R_support_depth_R[i][j];
					}
				}
			}
		}
	}


	////////////////////////////////////////////////////
	//////////////////////////////////////////
	////////////////////////////////////////////
	///////////////////////////////////////////////
	///////////////////////////////////////
	/////////////////////////////////////////
	/////////////////////////////////////////
	////////////////////////////////////////////
	/////////////////////////////////////////////
	///////////////////////////////////////////////

	//���� �ʱⰪ���� ���� ����
	for(i=1;i<=GlobalVar.section_ea;i++)
	{
		for(j=1;j<=13;j++)
		{
			GlobalVar.steelname[i][j]=GlobalVar.steelname[0][j];
			GlobalVar.steelkind[i][j]=GlobalVar.steelkind[0][j];
		}
	}
	//���� �ʱⰪ���� ���� ��

	//�������� �ʱⰪ���� ���� ����
	GlobalVar.In_layer=100;

	for(i=1;i<=GlobalVar.layer_ea;i++)
	{
		if(GlobalVar.layername[i]=="���")
		{
			GlobalVar.Rt[0][i]=2200;
			GlobalVar.Rsub[0][i]=1200;
			GlobalVar.C[0][i]=75;
			GlobalVar.Pi[0][i]=40.0;
			GlobalVar.Ks[0][i]=80000;
		}else if(GlobalVar.layername[i]=="�����")
		{
			GlobalVar.Rt[0][i]=2100;
			GlobalVar.Rsub[0][i]=1100;
			GlobalVar.C[0][i]=50;
			GlobalVar.Pi[0][i]=37.0;
			GlobalVar.Ks[0][i]=60000;
		}else if(GlobalVar.layername[i]=="����")
		{
			GlobalVar.Rt[0][i]=2000;
			GlobalVar.Rsub[0][i]=1000;
			GlobalVar.C[0][i]=25;
			GlobalVar.Pi[0][i]=35.0;
			GlobalVar.Ks[0][i]=45000;
		}else if(GlobalVar.layername[i]=="ǳȭ��")
		{
			GlobalVar.Rt[0][i]=1900;
			GlobalVar.Rsub[0][i]=900;
			GlobalVar.C[0][i]=15;
			GlobalVar.Pi[0][i]=33.0;
			GlobalVar.Ks[0][i]=30000;
		}else if(GlobalVar.layername[i]=="ǳȭ��")
		{
			GlobalVar.Rt[0][i]=1800;
			GlobalVar.Rsub[0][i]=800;
			GlobalVar.C[0][i]=10;
			GlobalVar.Pi[0][i]=32.0;
			GlobalVar.Ks[0][i]=25000;
		}else //���
		{
			GlobalVar.Rt[0][i]=1800;
			GlobalVar.Rsub[0][i]=800;
			GlobalVar.C[0][i]=0;
			GlobalVar.Pi[0][i]=30.0;
			GlobalVar.Ks[0][i]=9600;
		}
	}

	for(i=1;i<=GlobalVar.section_ea;i++)
	{
		for(j=1;j<=GlobalVar.layer_ea;j++)
		{
			GlobalVar.Rt[i][j]=GlobalVar.Rt[0][j];
			GlobalVar.Rsub[i][j]=GlobalVar.Rsub[0][j];
			GlobalVar.C[i][j]=GlobalVar.C[0][j];
			GlobalVar.Pi[i][j]=GlobalVar.Pi[0][j];
			GlobalVar.Ks[i][j]=GlobalVar.Ks[0][j];
		}
	}
	//�������� �ʱⰪ���� ���� ��

	GlobalVar.In_layer_ea=100;
/*
	if(GlobalVar.section_ea>0)
	{
		GetDlgItem(IDC_TAB_SECTION)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_TAB_PROPERTY)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_PROPERTY_GRID)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_STATIC_BORDER1)->ShowWindow(SW_SHOW);

		item.mask=TCIF_TEXT|TCIF_IMAGE;

		m_Tabsection.DeleteAllItems();

		for(i=1;i<=GlobalVar.section_ea;i++)
		{
			sprintf(text,"SECTION %d",i);
			item.pszText=text;
			item.iImage=i-1;
			m_Tabsection.InsertItem(i-1,&item);
		}

		item1.mask=TCIF_TEXT|TCIF_IMAGE;

		m_Tabproperty.DeleteAllItems();

		item1.pszText="�����Է�";
		item1.iImage=0;
		m_Tabproperty.InsertItem(0,&item1);

		item1.pszText="���缱��";
		item1.iImage=1;
		m_Tabproperty.InsertItem(1,&item1);

		item1.mask=TCIF_TEXT|TCIF_IMAGE;
		item1.pszText="�����ġ";
		item1.iImage=2;
		m_Tabproperty.InsertItem(2,&item1);
	}else
	{
		GetDlgItem(IDC_TAB_SECTION)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_TAB_PROPERTY)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_PROPERTY_GRID)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_BORDER1)->ShowWindow(SW_HIDE);
	}
*/

	for(i=1;i<=GlobalVar.section_ea;i++)
	{
		GlobalVar.deck[i]=0;
		GlobalVar.ToptoGL[i]=0.0;
		GlobalVar.SidepileCTC[i]=2.0;
		GlobalVar.MidpileCTC[i]=3.0;
		GlobalVar.SideInsert[i]=1.5;
		GlobalVar.MidInsert[i]=1.0;
	}

	num=0;
	num1=0;

/*
	if(deck[num+1]==1)
	{
		m_SHeight="�� ������� --  GL (m) =";
		m_SBracing="�� ���� �극�̽� ���� (m)";
	}else
	{
		m_SHeight="�� ���һ�� --  GL (m) =";
		m_SBracing="�� ���� ������ ���� (m)";
	}

	Invalidate();
*/

//  PrjData.Import(GlobalVar);
  Import(GlobalVar);
  SetupSection();

  strcpy(str,path.c_str());
  strncat(str,name.c_str(),name.Length()-ext.Length());
  strcat(str,".prf");

  fp = fopen(str,"r");
// if there is profile, then load, else generate with depth
  if(!fp) {
    Section.GenProfile();
  }
  else {
    for(i=0;i<Section.GetSize();i++) {
//      MkProfiles &prf = Section[i].GetProfiles();
//      flag = flag && prf.Open(str);
      Section[i].LoadProfile(str);
    }
    fclose(fp);
  }

  EarthWall.Import(Section);
}

bool MkProject::Save()
{
//  PrjData.Export(GlobalVar);
  Export(GlobalVar);

  CFile fo;
  FILE *fp;
	int slen;
  int i,j,k,m;
  bool flag=true;

	if(fo.Open(FileName.c_str(),CFile::modeCreate|CFile::modeWrite)) {
 		CArchive ar(&fo,CArchive::store);

		ar<<GlobalVar.sectiontype;
		ar<<GlobalVar.InputLayerEA;
		ar<<GlobalVar.Inputplan;
		ar<<GlobalVar.SelectLayer;
		ar<<GlobalVar.Inputwale;
		ar<<GlobalVar.InputBogangjae;
		ar<<GlobalVar.projectcontent;
		ar<<GlobalVar.LayerBogang;
    ar<<GlobalVar.decktype;

    ar.Close();
    fo.Close();
  }

  int pos;
  AnsiString filename, ext;
  filename = FileName;
  ext = ExtractFileExt(filename);
  if(!ext.Length()) filename = filename+".edf";
  else if(ext!=".edf") {
    pos = filename.Pos(".");
    filename = filename.SubString(1,pos-1)+".edf";
  }

  if(fo.Open(filename.c_str(),CFile::modeCreate|CFile::modeWrite)) {
		CArchive ar(&fo,CArchive::store);

		//�ܸ� ����
		ar<<GlobalVar.section_ea;

		//���� ����
		for(i=0;i<=GlobalVar.section_ea;i++)
		{
			for(j=1;j<=14;j++)
			{
				ar<<GlobalVar.steelname[i][j];
				ar<<GlobalVar.steelkind[i][j];

				ar<<GlobalVar.OldSteel[i][j];
				ar<<GlobalVar.LongTimeSteel[i][j];
				ar<<GlobalVar.OldSteelReduction[i][j];
				ar<<GlobalVar.LongTimeSteelReduction[i][j];
			}

			ar<<GlobalVar.mainbeam_BB[i];
			ar<<GlobalVar.mainbeam_HH[i];
			ar<<GlobalVar.mainbeam_tt1[i];
			ar<<GlobalVar.mainbeam_tt2[i];
			ar<<GlobalVar.mainbeam_AA[i];
			ar<<GlobalVar.mainbeam_W[i];
			ar<<GlobalVar.mainbeam_Aw[i];
			ar<<GlobalVar.mainbeam_Zx[i];
			ar<<GlobalVar.mainbeam_Ix[i];
			ar<<GlobalVar.mainbeam_rx[i];
			ar<<GlobalVar.mainbeam_ry[i];

			ar<<GlobalVar.supportbeam_BB[i];
			ar<<GlobalVar.supportbeam_HH[i];
			ar<<GlobalVar.supportbeam_tt1[i];
			ar<<GlobalVar.supportbeam_tt2[i];
			ar<<GlobalVar.supportbeam_AA[i];
			ar<<GlobalVar.supportbeam_W[i];
			ar<<GlobalVar.supportbeam_Aw[i];
			ar<<GlobalVar.supportbeam_Zx[i];
			ar<<GlobalVar.supportbeam_Ix[i];
			ar<<GlobalVar.supportbeam_rx[i];
			ar<<GlobalVar.supportbeam_ry[i];

			ar<<GlobalVar.supportbeam_m_BB[i];
			ar<<GlobalVar.supportbeam_m_HH[i];
			ar<<GlobalVar.supportbeam_m_tt1[i];
			ar<<GlobalVar.supportbeam_m_tt2[i];
			ar<<GlobalVar.supportbeam_m_AA[i];
			ar<<GlobalVar.supportbeam_m_W[i];
			ar<<GlobalVar.supportbeam_m_Aw[i];
			ar<<GlobalVar.supportbeam_m_Zx[i];
			ar<<GlobalVar.supportbeam_m_Ix[i];
			ar<<GlobalVar.supportbeam_m_rx[i];
			ar<<GlobalVar.supportbeam_m_ry[i];

			ar<<GlobalVar.sidepile_BB[i];
			ar<<GlobalVar.sidepile_HH[i];
			ar<<GlobalVar.sidepile_tt1[i];
			ar<<GlobalVar.sidepile_tt2[i];
			ar<<GlobalVar.sidepile_AA[i];
			ar<<GlobalVar.sidepile_W[i];
			ar<<GlobalVar.sidepile_Aw[i];
			ar<<GlobalVar.sidepile_Zx[i];
			ar<<GlobalVar.sidepile_Ix[i];
			ar<<GlobalVar.sidepile_rx[i];
			ar<<GlobalVar.sidepile_ry[i];

			ar<<GlobalVar.midpile_BB[i];
			ar<<GlobalVar.midpile_HH[i];
			ar<<GlobalVar.midpile_tt1[i];
			ar<<GlobalVar.midpile_tt2[i];
			ar<<GlobalVar.midpile_AA[i];
			ar<<GlobalVar.midpile_W[i];
			ar<<GlobalVar.midpile_Aw[i];
			ar<<GlobalVar.midpile_Zx[i];
			ar<<GlobalVar.midpile_Ix[i];
			ar<<GlobalVar.midpile_rx[i];
			ar<<GlobalVar.midpile_ry[i];

			ar<<GlobalVar.strut_BB[i];
			ar<<GlobalVar.strut_HH[i];
			ar<<GlobalVar.strut_tt1[i];
			ar<<GlobalVar.strut_tt2[i];
			ar<<GlobalVar.strut_AA[i];
			ar<<GlobalVar.strut_W[i];
			ar<<GlobalVar.strut_Aw[i];
			ar<<GlobalVar.strut_Zx[i];
			ar<<GlobalVar.strut_Ix[i];
			ar<<GlobalVar.strut_rx[i];
			ar<<GlobalVar.strut_ry[i];

			for(int ry=0;ry<=29;ry++)
			{
				ar<<GlobalVar.walename[i][ry];
				ar<<GlobalVar.wale_BB[i][ry];
				ar<<GlobalVar.wale_HH[i][ry];
				ar<<GlobalVar.wale_tt1[i][ry];
				ar<<GlobalVar.wale_tt2[i][ry];
				ar<<GlobalVar.wale_AA[i][ry];
				ar<<GlobalVar.wale_W[i][ry];
				ar<<GlobalVar.wale_Aw[i][ry];
				ar<<GlobalVar.wale_Zx[i][ry];
				ar<<GlobalVar.wale_Ix[i][ry];
				ar<<GlobalVar.wale_rx[i][ry];
				ar<<GlobalVar.wale_ry[i][ry];
			}

			ar<<GlobalVar.sheetpile_BB[i];
			ar<<GlobalVar.sheetpile_HH[i];
			ar<<GlobalVar.sheetpile_tt1[i];
			ar<<GlobalVar.sheetpile_AA[i];
			ar<<GlobalVar.sheetpile_Aw[i];
			ar<<GlobalVar.sheetpile_W[i];
			ar<<GlobalVar.sheetpile_Zx[i];

			ar<<GlobalVar.C_Fck[i];
			ar<<GlobalVar.C_Fy[i];
			ar<<GlobalVar.C_BarDia[i];
			ar<<GlobalVar.C_CIPSteel[i];
			ar<<GlobalVar.C_Thick_or_Dia[i];
			ar<<GlobalVar.C_Bar_EA[i];
		}

		ar<<GlobalVar.layer_ea;
		ar<<GlobalVar.In_layer_ea;
		ar<<GlobalVar.In_layerdepth;
		ar<<GlobalVar.In_layer;
		for(i=1;i<=GlobalVar.layer_ea;i++)
		{
			ar<<GlobalVar.layername[i];

			for(j=0;j<=GlobalVar.section_ea;j++)
			{
				ar<<GlobalVar.layer_depth_L[j][i];
				ar<<GlobalVar.layer_depth_R[j][i];
				ar<<GlobalVar.Rt[j][i];
				ar<<GlobalVar.Rsub[j][i];
				ar<<GlobalVar.C[j][i];
				ar<<GlobalVar.Pi[j][i];
				ar<<GlobalVar.Ks[j][i];
			}
		}

		for(i=1;i<=GlobalVar.section_ea;i++)
		{
			ar<<GlobalVar.pile_ea[i];
			ar<<GlobalVar.exca_depth_L[i];
			ar<<GlobalVar.exca_depth_R[i];
			ar<<GlobalVar.deck[i];
			ar<<GlobalVar.ToptoGL[i];
			ar<<GlobalVar.GL_R_minus_GL_L[i];
			ar<<GlobalVar.SidepileCTC[i];
			ar<<GlobalVar.MidpileCTC[i];
			ar<<GlobalVar.SideInsert[i];
			ar<<GlobalVar.MidInsert[i];

			for(j=1;j<=GlobalVar.pile_ea[i]-1;j++)
			{
				ar<<GlobalVar.piledist[i][j];
				ar<<GlobalVar.bracing_ea[i][j];
				ar<<GlobalVar.bracingtype[i][j];
				ar<<GlobalVar.bracingNN[i][j];

				for(k=1;k<=GlobalVar.bracing_ea[i][j];k++)
					ar<<GlobalVar.bracing_len[i][j][k];
			}

			ar<<GlobalVar.In_support_L;
			ar<<GlobalVar.In_support_R;
			ar<<GlobalVar.supportdan_L[i];
			ar<<GlobalVar.supportdan_R[i];

			for(j=1;j<=GlobalVar.supportdan_L[i];j++)
			{
				ar<<GlobalVar.support_depth_L[i][j];
				ar<<GlobalVar.support_type_L[i][j];
				ar<<GlobalVar.support_var_L[i][j];
				ar<<GlobalVar.support_freelen_L[i][j];
				ar<<GlobalVar.support_sticklen_L[i][j];
				ar<<GlobalVar.support_jackingforce_L[i][j];
				ar<<GlobalVar.support_tendonEA_L[i][j];
			}

			for(j=1;j<=GlobalVar.supportdan_R[i];j++)
			{
				ar<<GlobalVar.support_depth_R[i][j];
				ar<<GlobalVar.support_type_R[i][j];
				ar<<GlobalVar.support_var_R[i][j];
				ar<<GlobalVar.support_freelen_R[i][j];
				ar<<GlobalVar.support_sticklen_R[i][j];
				ar<<GlobalVar.support_jackingforce_R[i][j];
				ar<<GlobalVar.support_tendonEA_R[i][j];
			}
		}

		ar<<GlobalVar.stress_type;
		ar<<GlobalVar.liveload1;
		ar<<GlobalVar.liveload2;
		ar<<GlobalVar.liveload3;
		ar<<GlobalVar.In_liveload;
		ar<<GlobalVar.liveloaddirection;
		ar<<GlobalVar.decktype;
		ar<<GlobalVar.water_level_type;
		ar<<GlobalVar.reductionrate;
		ar<<GlobalVar.reductiondepth;

		ar<<GlobalVar.In_jibanbogang;
		if(GlobalVar.In_jibanbogang==100)
		{
			ar<<GlobalVar.jibanbogang_ea;
			ar<<GlobalVar.jibanboganglayer;
			ar<<GlobalVar.jibanbogangdepth;

			for(i=1;i<=GlobalVar.jibanbogang_ea;i++)
			{
				ar<<GlobalVar.jibanbogang_kind[i];
				ar<<GlobalVar.jibanbogang_width[i];
				ar<<GlobalVar.jibanbogang_ctc[i];
				ar<<GlobalVar.jibanbogang_rctc[i];
				ar<<GlobalVar.jibanbogang_row[i];
			}
		}
		ar.Close();
		fo.Close();
  }

  ext = ExtractFileExt(filename);
  if(!ext.Length()) filename = filename+".esf";
  else if(ext!=".esf") {
    pos = filename.Pos(".");
    filename = filename.SubString(1,pos-1)+".esf";
  }

  fp = fopen(filename.c_str(),"w");
  if(!fp) return false;
  for(i=0;i<Section.GetSize();i++) {
    MkExcavStep &es = Section[i].GetExcavStep();
    flag = es.Out(fp) && flag;
  }
  fclose(fp);

  ext = ExtractFileExt(filename);
  if(!ext.Length()) filename = filename+".prf";
  else if(ext!=".prf") {
    pos = filename.Pos(".");
    filename = filename.SubString(1,pos-1)+".prf";
  }

  fp = fopen(filename.c_str(),"w");
  if(!fp) flag = false;
  else {
//    for(i=0;i<Section.GetSize();i++) {
//      MkProfiles &prf = Section[i].GetProfiles();
//      flag = flag && prf.Open(str);
      i=0;
      Section[i].SaveProfile(filename.c_str());
//    }
    fclose(fp);
  }

  ext = ExtractFileExt(filename);
  if(!ext.Length()) filename = filename+".etf";  // escot tan file
  else if(ext!=".etf") {
    pos = filename.Pos(".");
    filename = filename.SubString(1,pos-1)+".etf";
  }

  fp = fopen(filename.c_str(),"w");
  if(!fp) flag = false;
  else {
    fprintf(fp,"%d : Number of Section\n",GlobalVar.section_ea);
    for(i=1;i<=GlobalVar.section_ea;i++) {
      fprintf(fp,"  %d : Number of Left Support\n",GlobalVar.supportdan_L[i]);
			for(j=1;j<=GlobalVar.supportdan_L[i];j++) {
        fprintf(fp,"    %d : %d-th Support Dan of %d-th Section\n",GlobalVar.support_tan_L[i][j],j,i);
        //smk support_tan_L is newly added variable
			}
      fprintf(fp,"  %d : Number of Right Support\n",GlobalVar.supportdan_R[i]);
			for(j=1;j<=GlobalVar.supportdan_R[i];j++)	{
        fprintf(fp,"    %d : %d-th Support Dan of %d-th Section\n",GlobalVar.support_tan_R[i][j],j,i);
        //smk support_tan_R is newly added variable
			}
    }
    fclose(fp);
  }

  Modified = false;
  return flag;
}

bool MkProject::SaveAs(char *fname)
{
  int pos;
  AnsiString ext;
  FileName = fname;
  ext = ExtractFileExt(FileName);
  if(!ext.Length()) FileName = FileName+".epf";
  else if(ext!=".epf") {
    pos = FileName.Pos(".");
    FileName = FileName.SubString(1,pos-1)+".epf";
  }
  return Save();
}

void MkProject::Import(MkGlobalVar &globalvar)
{
  rpath=(LPCTSTR)globalvar.rpath;
  projectname=(LPCTSTR)globalvar.projectname;
  projectcontent=(LPCTSTR)globalvar.projectcontent;
  stress_type=globalvar.stress_type;
  liveloaddirection=globalvar.liveloaddirection;
  liveload1=globalvar.liveload1;
  liveload2=globalvar.liveload2;
  liveload3=globalvar.liveload3;

  In.Import(globalvar);
  Section.Import(globalvar);
  for(int i=0;i<Section.GetSize();i++)
    Section[i].SetSectionLength(10);
//  EarthWall.Import(globalvar);
}

void MkProject::Export(MkGlobalVar &globalvar)
{
  globalvar.rpath=rpath.c_str();
  globalvar.projectname=projectname.c_str();
  globalvar.projectcontent=projectcontent.c_str();
  globalvar.stress_type=stress_type;
  globalvar.liveloaddirection=liveloaddirection;
  globalvar.liveload1=liveload1;
  globalvar.liveload2=liveload2;
  globalvar.liveload3=liveload3;

  In.Export(globalvar);
  Section.Export(globalvar);
}

bool MkProject::Import(char *fname)
{

}

bool MkProject::Export(char *fname)
{

}

bool MkProject::SetupSection()
{
//  int cursec = PrjData.CurSec;
//  PrjData.Sec[cursec].Export(Section[cursec]);

  for(int i=0;i<Section.GetSize();i++) {
    Section[i].BuildSupport();
    if(!isTanLoaded) Section[i].BuildTan();
  }
  isTanLoaded = true; // equivelent effect of Tan File loading...
}

bool MkProject::Draw(TObject *Sender)
{
//  int &cursec = PrjData.CurSec;
//  KoSection &sec = PrjData.Sec[cursec];
//  return sec.DrawGL();
}

bool MkProject::UpdateGLEntity()
{
  if(!Section.GetSize()) return false;
  if(!EarthWall.GetSize()) return false;

  MkSection &sec = GetSection(CurSec);
  GLEarthWall &ew = GetEarthWall(CurSec);
  GLPiles &glpile = ew.GetPiles();
  GLWales &glwale = ew.GetWales();
  GLStruts &glstrut = ew.GetStruts();
  GLAnchors &glanc = ew.GetAnchors();
  GLRockBolts &glbolt = ew.GetBolts();
  GLStratum &glstratum = ew.GetStratum();

  if(glpile.GetSize()) {
    glpile.Import(sec);
  }
  ew.Initialize();

  if(glwale.GetSize()) {
    glwale.Import(sec);
  }
  ew.Initialize();
  if(glwale.GetSize()) {  // have to do it one more time
    glwale.Import(sec);
  }

  glstrut.Import(sec);
  ew.Initialize();

  if(glanc.GetSize()) {
    glanc.Import(sec);
  }
  ew.Initialize();

  if(glbolt.GetSize()) {
    glbolt.Import(sec);
  }
  ew.Initialize();

  if(glstratum.GetSize()) {
    glstratum.Import(sec);
  }
  ew.Initialize();

  return true;
}

bool MkProject::UpdateTo(TObject *Sender)
{
  TMainForm *mform = dynamic_cast<TMainForm*>(Sender);
  if(mform) return UpdateToMain(Sender);

  TAnaCondForm *aform = dynamic_cast<TAnaCondForm*>(Sender);
  if(aform) return UpdateToCond(Sender);

  TExcavStepForm *eform = dynamic_cast<TExcavStepForm*>(Sender);
  if(eform) return UpdateToExcavStep(Sender);

  TPrjSettingForm *pform = dynamic_cast<TPrjSettingForm *>(Sender);
  if(pform) return UpdateToPrjSetting(Sender);

  TProfForm *rform = dynamic_cast<TProfForm *>(Sender);
  if(rform) return UpdateToProf(Sender);

  TTreeList *ov = dynamic_cast<TTreeList *>(Sender);
  if(ov) return UpdateOverView(ov);
}

bool MkProject::UpdateToMain(TObject *&Sender)
{
  TMainForm *form = dynamic_cast<TMainForm*>(Sender);
  if(!form) return false;

  int i,j,&cursec = GetCurSec();
  MkSection &sec = GetSection(cursec);
  MkPileSections &psec = sec.GetPileSections();
  MkSupports &spt = sec.GetSupports();
  MkSpec &spec = GetSection(cursec).GetSpec();
  MkLayers &lay = sec.GetLayers();
//  MkLayers &llay = sec.lay_L;
//  MkLayers &rlay = sec.lay_R;

  form->InitScreen();
  form->InitGeomSet();
  form->InitLayerProp();

//------------- geom
// change the order of brace and pile number to get rid of side effects
  form->BraceNumEdit->Value = psec.GetSize()?max(psec[0].bracing_ea,1):1;

  form->BraceSpaceGrid->RowCount = max(psec.GetSize()+1,2);
  form->BraceSpaceGrid->ColCount = max(psec[0].bracing_ea+1,2);
  for(i=0;i<psec.GetSize();i++) {
    for(j=0;j<(psec.GetSize()?psec[i].bracing_ea:0);j++) {
      form->BraceSpaceGrid->Cells[j+1][i+1] = psec[i].bracing[j].len;
    }
  }

  form->NPileEdit->Text = psec.GetSize()+1;
  form->SidePileSpacingEdit->Text = sec.GetSidepileCTC();
  form->MidPileSpacingEdit->Text = sec.GetMidpileCTC();

  form->LenPileGrid->RowCount = max(psec.GetSize()+1,2);
  for(i=0;i<psec.GetSize();i++) {
    form->LenPileGrid->Cells[1][i+1] = psec[i].piledist;
  }

  form->DeckCheckBox->Checked = sec.GetDeck().GetInstall()?true:false;
  form->DeckLevelEdit->Text = sec.GetToptoGL();

  form->PlaceSptEdit->Text = max(spt.GetSize(),1);
  form->PlaceSupportGrid->RowCount = max(spt.GetSize()+1,2);

  for(i=0;i<spt.GetSize();i++) {
    form->PlaceSupportGrid->Cells[1][i+1] = (spt[i].type=="������")?"Strut":((spt[i].type=="��Ŀ")?"Anchor":"Rockbolt");
    form->PlaceSupportGrid->Cells[2][i+1] = spt[i].depth;
    if(spt[i].type=="������")
      form->PlaceSupportGrid->Cells[3][i+1] = " - ";
    else {
      form->PlaceSupportGrid->Cells[3][i+1] = ((spt[i].side==mkLeft)?"Left":"Right");
    }

    form->PlaceSupportGrid->Cells[4][i+1] = spt[i].GetInfo();
  }
  form->SortBySideDepthExecute(NULL);

//------------- geom
//------------- steel
  form->SteelSettingGrid->AllCells[1][2 ] = spec.steelname(0);//"�԰�";                //����
  form->SteelSettingGrid->AllCells[1][3 ] = spec.steelkind(0);//"����";

  form->SteelSettingGrid->AllCells[1][5 ] = spec.steelname(1);//"�԰�";                //����������(����)
  form->SteelSettingGrid->AllCells[1][6 ] = spec.steelkind(1);//"����";

  form->SteelSettingGrid->AllCells[1][8 ] = spec.steelname(2);//"�԰�";                //����������(�߰�)
  form->SteelSettingGrid->AllCells[1][9 ] = spec.steelkind(2);//"����";

  form->SteelSettingGrid->AllCells[1][11] = spec.steelname(3);//"�԰�";                //���鸻��
  form->SteelSettingGrid->AllCells[1][12] = spec.steelkind(3);//"����";

  form->SteelSettingGrid->AllCells[1][14] = spec.steelname(4);//"�԰�";                //�߰�����
  form->SteelSettingGrid->AllCells[1][15] = spec.steelkind(4);//"����";

  form->SteelSettingGrid->AllCells[1][17] = spec.steelname(5);//"�԰�";                //������
  form->SteelSettingGrid->AllCells[1][18] = spec.steelkind(5);//"����";

  form->SteelSettingGrid->AllCells[1][20] = spec.steelname(6);//"�԰�";                //����
  form->SteelSettingGrid->AllCells[1][21] = spec.steelkind(6);//"����";

  form->SteelSettingGrid->AllCells[1][23] = spec.steelname(7);//"�԰�";                //���򺸰���
  form->SteelSettingGrid->AllCells[1][24] = spec.steelkind(7);//"����";

  form->SteelSettingGrid->AllCells[1][26] = spec.Bracket.name; //"�԰�";                //�ǽ������(����)
  form->SteelSettingGrid->AllCells[1][27] = spec.Bracket.type; //"����";
  form->SteelSettingGrid->AllCells[1][28] = spec.Bracket.lenum;//"����";
  form->SteelSettingGrid->AllCells[1][29] = spec.Bracket.kind; //"����";

  form->SteelSettingGrid->AllCells[1][31] = spec.Bracket_M.name; ;//"�԰�";                //�ǽ������(�߰�)
  form->SteelSettingGrid->AllCells[1][32] = spec.Bracket_M.type; ;//"����";
  form->SteelSettingGrid->AllCells[1][33] = spec.Bracket_M.lenum;;//"����";
  form->SteelSettingGrid->AllCells[1][34] = spec.Bracket_M.kind; ;//"����";

  form->SteelSettingGrid->AllCells[1][36] = spec.Bolt.dia;//"����";                //�Ϻ�Ʈ
  form->SteelSettingGrid->AllCells[1][37] = spec.Bolt.len;//"����";
  form->SteelSettingGrid->AllCells[1][38] = spec.Bolt.kind;//"����";

  form->SteelSettingGrid->AllCells[1][40] = spec.Anchor.num;//"����";                //���Ŀ
  form->SteelSettingGrid->AllCells[1][41] = spec.Anchor.name;//"�԰�";
  form->SteelSettingGrid->AllCells[1][42] = spec.Anchor.kind;//"����";

  form->SteelSettingGrid->AllCells[1][44] = spec.BeamHanger.type;//"����";                //������
  form->SteelSettingGrid->AllCells[1][45] = spec.BeamHanger.name;//"�԰�";
  form->SteelSettingGrid->AllCells[1][46] = spec.BeamHanger.kind;//"����";

  if(spec.WallType==wtTimber) {
    form->SteelSettingGrid->AllCells[1][48] = "�����";//"���";                //������
    form->SteelSettingGrid->AllCells[1][49] = spec.Timber.type;//"����";
    form->SteelSettingGrid->AllCells[1][50] = spec.Timber.thick;//"�β�";
  }
  else if(spec.WallType==wtConcWall) {
    form->SteelSettingGrid->AllCells[1][48] = "�����";//"���";                //������
    form->SteelSettingGrid->AllCells[1][49] = spec.ConcWall.strength;//"����";
    form->SteelSettingGrid->AllCells[1][50] = spec.ConcWall.space;//"����";
    form->SteelSettingGrid->AllCells[1][51] = spec.ConcWall.type;//"����";
    form->SteelSettingGrid->AllCells[1][52] = spec.ConcWall.dia;//"����";
  }
  form->UpdateSteel();
//------------- steel
//------------- layer
  form->NumLayEdit->Text = max(lay.GetSize(),1);
  form->LayerPropGrid->RowCount = max(lay.GetSize(),1)+1;

  for(i=0;i<lay.GetSize();i++) {
    form->LayerPropGrid->AllCells[0][i+1] = lay[i].GetName();
    form->LayerPropGrid->AllCells[1][i+1] = lay[i].GetDepth();
    form->LayerPropGrid->AllCells[2][i+1] = lay[i].GetWetUnitWeight(0);
    form->LayerPropGrid->AllCells[3][i+1] = lay[i].GetSubUnitWeight(0);
    form->LayerPropGrid->AllCells[4][i+1] = lay[i].GetCohesion(0);
    form->LayerPropGrid->AllCells[5][i+1] = lay[i].GetFriction(0);
    form->LayerPropGrid->AllCells[6][i+1] = lay[i].GetHorSubReact(0);
  }
//------------- layer
//------------- menu
  if(Project.GetStressType()==AType) {
    form->ATypeStress->Checked = true;
    form->BTypeStress->Checked = false;
  }
  else {
    form->ATypeStress->Checked = false;
    form->BTypeStress->Checked = true;
  }
//------------- menu
}

bool MkProject::UpdateToCond(TObject *Sender)
{
  TAnaCondForm *form = dynamic_cast<TAnaCondForm*>(Sender);
  if(!form) return false;
/*
  int cursec = PrjData.CurSec;
  MkSection &sec=PrjData.Sec[cursec];

  //int
  form->acDeckType = sec.decktype;
  form->acDirection = PrjData.liveloaddirection;
  form->acEarthPressType = sec.EarthPressType;
  form->acHydPressType = sec.HydPressType;
  form->acWaterTabType = sec.WaterTabType;

  //AnsiString
  form->acLoadLane1 = acLoadStr[PrjData.liveload1];
  form->acLoadLane2 = acLoadStr[PrjData.liveload2];
  form->acLoadLane3 = acLoadStr[PrjData.liveload3];
//  form->acLoadLane4 = ;
//  form->acLoadLane5 = ;

  //float
  form->acWaterLevel = sec.water.first_water_level;;
  form->acReductRatio = sec.water.reductionrate;
  form->acSoilBearing = sec.soil_bearing_method;
  form->acRockBearing = sec.rock_bearing_method;

  //int
  form->acSubsidType = sec.SubsidType;
  form->acGrdType = sec.GrdType;
  form->acNumMeas = sec.NumMeas;

  //float
  form->acExcaWidth = sec.ExcaWidth;
  form->acIntFricAng = sec.IntFricAng;

  //MkFloat
  form->acMeasValue = sec.MeasValue;

  //float
  form->acImpearmUnitWeight = sec.ImpearmUnitWeight;
  form->acPearmUnitWeight = sec.PearmUnitWeight;
  form->acImpearmThick = sec.ImpearmThick;
  form->acPearmThick = sec.PearmThick;
  form->acBotHead = sec.BotHead;

  //float
  form->acShearStrength = sec.ShearStrength;
  form->acUnitWeightAboveDatum = sec.UnitWeightAboveDatum;
  form->acHeightFromExcavLevel = sec.HeightFromExcavLevel; //D
  form->acLongLen = sec.LongLen;//L

  //int
  form->acGeoType = sec.GeoType;

  //float
  form->acTotalUnitWeight = sec.TotalUnitWeight;
  form->acSubUnitWeight = sec.SubUnitWeight;
  form->acHeadGradient = sec.HeadGradient;*/
}

bool MkProject::UpdateToExcavStep(TObject *Sender)
{
  TExcavStepForm *form = dynamic_cast<TExcavStepForm*>(Sender);
  if(!form) return false;

  int i,cursec = CurSec;
  MkSection &sec=Section[cursec];

  form->Section = sec;
  form->Section.SetExcavStep(Section[cursec].GetExcavStep());
  form->Section.SetStruts(Section[cursec].GetStruts());
  form->Section.SetAnchors(Section[cursec].GetAnchors());
  form->Section.SetBolts(Section[cursec].GetBolts());
  form->Section.SetCuts(Section[cursec].GetCuts());
  form->Section.SetFills(Section[cursec].GetFills());

  //float
  form->acLeftExcaDepth = sec.GetJunk().exca_depth_L;
  form->acRightExcaDepth = sec.GetJunk().exca_depth_R;
  form->acSideRootDepth = sec.GetJunk().SideInsert;
  form->acMidRootDepth = sec.GetJunk().MidInsert;
  form->acDepthUnderDan = sec.GetJunk().DepthUnderDan;

}

bool MkProject::UpdateToPrjSetting(TObject *Sender)
{
  TPrjSettingForm *form = dynamic_cast<TPrjSettingForm *>(Sender);
  if(!form) return false;

/*  form->PrjName = PrjData.projectname;
  form->PrjDesc = PrjData.projectcontent;
  form->NSec = Project.GetSection().GetSize();
*/
}

bool MkProject::UpdateToProf(TObject *Sender)
{
  TProfForm *form = dynamic_cast<TProfForm *>(Sender);
  if(!form) return false;

}

bool MkProject::UpdateOverView(TTreeList *ov)
{
  int i;

  TTreeNode *Node1;

  ov->Items->Clear(); // remove any existing nodes
  ov->Items->Add(NULL, "Project");

  Node1 = ov->Items->Item[0];
  ov->Items->AddChild(Node1,"Section 1");
  ov->Items->AddChild(Node1,"Section 2");
  ov->Items->AddChild(Node1,"Section 3");
  ov->Items->AddChild(Node1,"Section 4");

  Node1 = find(ov,"Section 1");
  if(Node1) {
    ov->Items->AddChild(Node1,"Layers");
    ov->Items->AddChild(Node1,"Section Type");
  }

  Node1 = find(ov,"Section 2");
  if(Node1) {
    ov->Items->AddChild(Node1,"Layers");
    ov->Items->AddChild(Node1,"Section Type");
  }

  Node1 = find(ov,"Section 3");
  if(Node1) {
    ov->Items->AddChild(Node1,"Layers");
    ov->Items->AddChild(Node1,"Section Type");
  }

  Node1 = find(ov,"Section 4");
  if(Node1) {
    ov->Items->AddChild(Node1,"Layers");
    ov->Items->AddChild(Node1,"Section Type");
  }

  Node1 = find(ov,"Section 1", "Section 2","Layers");
  if(Node1) {
    ov->Items->AddChild(Node1,"Layer 1");
    ov->Items->AddChild(Node1,"Layer 2");
    ov->Items->AddChild(Node1,"Layer 3");
  }

  Node1 = find(ov,"Section 2", "Section 3","Layers");
  if(Node1) {
    ov->Items->AddChild(Node1,"Layer 1");
    ov->Items->AddChild(Node1,"Layer 2");
    ov->Items->AddChild(Node1,"Layer 3");
  }

  Node1 = find(ov,"Section 3", "Section 4","Layers");
  if(Node1) {
    ov->Items->AddChild(Node1,"Layer 1");
    ov->Items->AddChild(Node1,"Layer 2");
    ov->Items->AddChild(Node1,"Layer 3");
  }

  Node1 = find(ov,"Section 4", "","Layers");
  if(Node1) {
    ov->Items->AddChild(Node1,"Layer 1");
    ov->Items->AddChild(Node1,"Layer 2");
    ov->Items->AddChild(Node1,"Layer 3");
  }

  Node1 = find(ov,"Section 1", "Section 2",("Layer 1"));
  if(Node1) {
    ov->Items->AddChild(Node1,"Name;I do know;modified");
    ov->Items->AddChild(Node1,"Total unit weight;2.1;unchanged");
    ov->Items->AddChild(Node1,"Sub unit weight ");
    ov->Items->AddChild(Node1,"Cohesion");
    ov->Items->AddChild(Node1,"Friction");
    ov->Items->AddChild(Node1,"Subreaction");
  }

  Node1 = find(ov,"Section 1", "Section 2",("Layer 2"));
  if(Node1) {
    ov->Items->AddChild(Node1,"Name;I do know;modified");
    ov->Items->AddChild(Node1,"Total unit weight;2.1;unchanged");
    ov->Items->AddChild(Node1,"Sub unit weight ");
    ov->Items->AddChild(Node1,"Cohesion");
    ov->Items->AddChild(Node1,"Friction");
    ov->Items->AddChild(Node1,"Subreaction");
  }

  Node1 = find(ov,"Section 1", "Section 2",("Layer 3"));
  if(Node1) {
    ov->Items->AddChild(Node1,"Name;I do know;modified");
    ov->Items->AddChild(Node1,"Total unit weight;2.1;unchanged");
    ov->Items->AddChild(Node1,"Sub unit weight ");
    ov->Items->AddChild(Node1,"Cohesion");
    ov->Items->AddChild(Node1,"Friction");
    ov->Items->AddChild(Node1,"Subreaction");
  }
}

bool MkProject::UpdateFrom(TObject *Sender)
{
  TMainForm *mform = dynamic_cast<TMainForm*>(Sender);
  if(mform) return UpdateFromMain(Sender);

  TAnaCondForm *aform = dynamic_cast<TAnaCondForm*>(Sender);
  if(aform) return UpdateFromCond(Sender);

  TExcavStepForm *eform = dynamic_cast<TExcavStepForm*>(Sender);
  if(eform) return UpdateFromExcavStep(Sender);

  TPrjSettingForm *pform = dynamic_cast<TPrjSettingForm *>(Sender);
  if(pform) return UpdateFromPrjSetting(Sender);

  TProfForm *rform = dynamic_cast<TProfForm *>(Sender);
  if(rform) return UpdateFromProf(Sender);
}

bool MkProject::UpdateFromMain(TObject *Sender)
{
  Modified = true;
}

bool MkProject::UpdateFromCond(TObject *Sender)
{
  TAnaCondForm *form = dynamic_cast<TAnaCondForm*>(Sender);
  if(!form) return false;
/*
  int i,cursec = PrjData.CurSec;
  MkSection &sec=PrjData.Sec[cursec];

  //int
  sec.decktype = form->acDeckType;
  PrjData.liveloaddirection = form->acDirection;
  sec.EarthPressType = form->acEarthPressType;
  sec.HydPressType = form->acHydPressType;
  sec.WaterTabType = form->acWaterTabType;

  //AnsiString
  for(i=0;i<3;i++) {
    if(acLoadStr[i] == form->acLoadLane1) PrjData.liveload1=i;
    if(acLoadStr[i] == form->acLoadLane2) PrjData.liveload2=i;
    if(acLoadStr[i] == form->acLoadLane3) PrjData.liveload3=i;
  }

  //float
  sec.water.first_water_level=form->acWaterLevel;
  sec.water.reductionrate    =form->acReductRatio;
  sec.soil_bearing_method    =form->acSoilBearing;
  sec.rock_bearing_method    =form->acRockBearing;

  //int
  sec.SubsidType = form->acSubsidType;
  sec.GrdType = form->acGrdType;
  sec.NumMeas = form->acNumMeas ;

  //float
  sec.ExcaWidth = form->acExcaWidth;
  sec.IntFricAng = form->acIntFricAng;

  //MkFloat
  sec.MeasValue = form->acMeasValue;

  //float
  sec.ImpearmUnitWeight = form->acImpearmUnitWeight;
  sec.PearmUnitWeight = form->acPearmUnitWeight;
  sec.ImpearmThick = form->acImpearmThick;
  sec.PearmThick = form->acPearmThick;
  sec.BotHead = form->acBotHead;

  //float
  sec.ShearStrength = form->acShearStrength;
  sec.UnitWeightAboveDatum = form->acUnitWeightAboveDatum;
  sec.HeightFromExcavLevel = form->acHeightFromExcavLevel; //D
  sec.LongLen = form->acLongLen; //L

  //int
  sec.GeoType = form->acGeoType;

  //float
  sec.TotalUnitWeight = form->acTotalUnitWeight;
  sec.SubUnitWeight = form->acSubUnitWeight;
  sec.HeadGradient = form->acHeadGradient;
  Modified = true;
*/
}

bool MkProject::UpdateFromExcavStep(TObject *Sender)
{
  TExcavStepForm *form = dynamic_cast<TExcavStepForm*>(Sender);
  if(!form) return false;

  int i,cursec = CurSec;
  MkSection &sec=Section[cursec];
  MkExcavStep &es = Section[cursec].GetExcavStep();
  MkCuts &cuts = Section[cursec].GetCuts();
  MkFills &fills = Section[cursec].GetFills();

  es = form->Section.GetExcavStep();
  cuts = form->Section.GetCuts();
  fills = form->Section.GetFills();

  //float
  sec.GetJunk().exca_depth_L   = form->acLeftExcaDepth;
  sec.GetJunk().exca_depth_R   = form->acRightExcaDepth;
  sec.GetJunk().SideInsert     = form->acSideRootDepth;
  sec.GetJunk().MidInsert      = form->acMidRootDepth;
  sec.GetJunk().DepthUnderDan  = form->acDepthUnderDan;

  Modified = true;

}

bool MkProject::UpdateFromPrjSetting(TObject *Sender)
{
  TPrjSettingForm *form = dynamic_cast<TPrjSettingForm *>(Sender);
  if(!form) return false;

  projectname = form->PrjName;
  projectcontent = form->PrjDesc;

  Modified = true;
}

bool MkProject::UpdateFromProf(TObject *Sender)
{
  TProfForm *form = dynamic_cast<TProfForm *>(Sender);
  if(!form) return false;

  Modified = true;
}

TTreeNode *find(TTreeList *list, char * astr)
{
  for(int i=0;i<list->Items->Count;i++)
    if(list->Items->Item[i]->Text==astr) {
      return list->Items->Item[i];
    }
  return NULL;
}

TTreeNode *find(TTreeList *list, char * st, char * end, char * astr)
{
  int i, si, ei;

  si = 0;
  ei = list->Items->Count;
  for(i=0;i<list->Items->Count;i++)
    if(list->Items->Item[i]->Text==st) {
      si = i;
    }

  for(i=0;i<list->Items->Count;i++)
    if(list->Items->Item[i]->Text==end) {
      ei = i;
    }

  for(i=si;i<ei;i++)
    if(list->Items->Item[i]->Text==astr) {
      return list->Items->Item[i];
    }
  return NULL;
}

int know_pile_ea(char txt[80])
{
	char kt[10][100];
	int a;

	sscanf(txt,"%s %s %s %s %s %s %s %s %s %s",kt[1],kt[2],kt[3],kt[4],kt[5],kt[6],kt[7],kt[8],kt[9],kt[10]);

	if(atof(kt[3])<1.0)
		a=1;
	else if(atof(kt[4])<1.0)
		a=2;
	else if(atof(kt[5])<1.0)
		a=3;
	else if(atof(kt[6])<1.0)
		a=4;
	else if(atof(kt[7])<1.0)
		a=5;
	else if(atof(kt[8])<1.0)
		a=6;
	else if(atof(kt[9])<1.0)
		a=7;
	else if(atof(kt[0])<1.0)
		a=8;

	return a;
}

AnsiString acLoadStr[]={"DB240","DB180","DB135"};
MkProject Project; // global and only one project can be accessed.
