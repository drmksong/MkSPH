//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#include <vcl.h>
#endif
#pragma hdrstop

#include "MkBearing.h"

//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#pragma package(smart_init)
#endif

//------------------------------------------------------------------------------
// Name of System     : ESCOT
// Job Description    : Strutural Caculation of Retaining Wall
// ID of Program      : 04-00
// Type of Program    : Borland C++ 
// Purpose of Program : 
//
// Functions          :
//   1. 
//   2.
//
// Variables :
//   - Input 
//
//   - Output
//
//
//
// History of change :
//------------------------------------------------------------------------------
//   Author  |   Department   |     Date     |      Description of Contents
//------------------------------------------------------------------------------
// M.K. Song | R&D Institute  | 2005.5.30    |  First use of this coment form
//------------------------------------------------------------------------------
//
//------------------------------------------------------------------------------

MkBearing::MkBearing()
{
  Method = bmGoodman;
  Type = btRock;
#ifdef __BCPLUSPLUS__
  Eq = "";
#else
  memset(Eq,'\0',255);
#endif
}

int MkBearing::GetBearingMethod()
{
  if(Type==btSoil) {
    switch(Method) {
      case bmBridgeRoad: return 0;
      case bmStatic: return 1;
      default: return 2;
    }
  }
  else {
    switch(Method) {
      case bmGoodman: return 0;
      case bmTeng: return 1;
      case bmQuJoint: return 2;
      default: return 3;
    }
  }
}

float MkBearing::GetBearing()
{
  return 0;
}
