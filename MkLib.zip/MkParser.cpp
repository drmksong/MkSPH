#ifdef __BCPLUSPLUS__
//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#endif
#include "MkParser.h"
//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#pragma package(smart_init)
#endif

MkParser::MkParser()
{
  FP=NULL;
  memset(FileName,'\0',255);
}

MkParser::MkParser(char *fname)
{
  FP=NULL;
  strncpy(FileName,fname,255);
}

MkParser::~MkParser()
{
  if(FP) Close();
}

bool MkParser::Create()
{

}

bool MkParser::Delete()
{

}

bool MkParser::Open()
{
  Close();
  if(strlen(FileName)<1) return false;
  FP = fopen(FileName,"r");
  if(!FP) return false;
  else return true;
}

bool MkParser::Close()
{
  int res;
  if(FP) {
    res = fclose(FP);
    FP = NULL;
  }
  return (res==0);
}

bool MkParser::Parse()
{

}

