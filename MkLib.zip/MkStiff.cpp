//---------------------------------------------------------------------------
#pragma hdrstop
#include "stdafx.h"
#include "MkStiff.h"

#ifdef __BCPLUSPLUS__
#include <vcl.h>
#endif

//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#pragma package(smart_init)
#endif
//--------------------------------------------------------------------
void MkStiff::Init()
{
  if(Steer.GetSize()==0) return;
  if(Stiff.GetFI()==0) return;

  assert(Steer.GetSize()==Stiff.GetFJ());
  assert(Stiff.GetFI()==Stiff.GetFJ());

  for (int i=0;i<Steer.GetSize();i++) {
    Steer.Node(i) = 0;Steer.NDof(i) = 0;
    for (int j=0;j<Steer.GetSize();j++) {
      Stiff(i,j) = 0;
    }
  }
}

void MkStiff::Assemble(MkElement &elem)
{
  int i,j;
  int cnt;
  MkMatrix stiff; // local stiffness matrix
  MkInt steer;

  assert(Steer.GetSize());
  assert(Steer.GetSize()==Stiff.GetFI());
  assert(Steer.GetSize()==Stiff.GetFJ());  //global stifness matrix

  stiff = elem.GetStiff();

  assert(stiff.GetFI()*stiff.GetFJ());
  assert(stiff.GetFI()==stiff.GetFJ());

  cnt=0;
  steer.Initialize(stiff.GetFI());
  for (i=0;i<elem.GetNumberOfNode();i++) {
    MkNode &node = elem.GetElemNode(i);
    MkDOFs &dofs = node.GetDOFs();
    for (j=0;j<dofs.GetSize();j++) {
      steer(cnt) = dofs[j].SteerNum;
      cnt++;
    }
  }

  assert(cnt==steer.getSzX());

  for (i=0;i<stiff.GetFI();i++) {
    for (j=0;j<stiff.GetFJ();j++) {
//      ShowMessage(AnsiString("I:")+AnsiString(steer(i))+AnsiString("J:")+AnsiString(steer(j)));
      if(steer(i)>=0&&steer(j)>=0) Stiff(steer(i),steer(j)) += stiff(i,j);
    }
  }
}

#ifdef __BCPLUSPLUS__
void MkStiff::Assemble(MkElement &elem,TMemo *memo)
{
  int i,j;
  int cnt;
  MkMatrix stiff; // local stiffness matrix
  MkMatrix tran;
  MkInt steer;

  assert(Steer.GetSize());
  assert(Steer.GetSize()==Stiff.GetFI());
  assert(Steer.GetSize()==Stiff.GetFJ());  //global stifness matrix

  stiff = elem.GetStiff();
  elem.SetupTrans();
  tran = elem.GetTrans();
  stiff *= tran;

  stiff.Out(memo);
  tran.Out(memo);
  
  assert(stiff.GetFI()*stiff.GetFJ());
  assert(stiff.GetFI()==stiff.GetFJ());

  cnt=0;
  steer.Initialize(stiff.GetFI());
  for (i=0;i<elem.GetNumberOfNode();i++) {
    MkNode &node = elem.GetElemNode(i);
    MkDOFs &dofs = node.GetDOFs();
    for (j=0;j<dofs.GetSize();j++) {
      steer(cnt) = dofs[j].SteerNum;
      cnt++;
    }
  }

  assert(cnt==steer.getSzX());

  for (i=0;i<stiff.GetFI();i++) {
    for (j=0;j<stiff.GetFJ();j++) {
      if(steer(i)>=0&&steer(j)>=0) Stiff(steer(i),steer(j)) += stiff(i,j);
    }
  }
}
#endif

void MkStiff::SetupMatrix(MkNodes &nodes)
{
  Steer.SetupSteer(nodes);
  Stiff.Initialize(Steer.GetSize(),Steer.GetSize());
  for (int i=0;i<Steer.GetSize();i++)
    for (int j=0;j<Steer.GetSize();j++)
      Stiff(i,j) = 0;
}

void MkStiff::SetupMatrix(MkSteer &steer)
{
  assert(steer.GetSize());
  Steer = steer;
  Stiff.Initialize(Steer.GetSize(),Steer.GetSize());
}

#ifdef __BCPLUSPLUS__
void MkStiff::Out(TMemo *memo)
{
  char str[256],s[256];
  memo->Lines->Add("Output of Stiffness ");
  sprintf(str,"A-th row [%10.3f %10.3f %10.3f %10.3f %10.3f %10.3f %10.3f %10.3f %10.3f %10.3f]",0.0,1.0,2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0);
  memo->Lines->Add(str);
  for (int i=0;i<Stiff.GetFI();i++) {
    sprintf(str,"%d-th row [",i);
    for (int j=0;j<Stiff.GetFJ();j++) {
      sprintf(s,"%10.3f ",Stiff(i,j));
      strcat(str,s);
    }
    sprintf(s,"]");
    strcat(str,s);
    memo->Lines->Add(str);
  }

}
#endif
void MkStiff::Out(char *fname)
{
  FILE *fp;
  char str[512],s[512];

  fp=fopen(fname,"a");
  if(!fp) return;

  fprintf(fp,"Output of Stiffness ");
  sprintf(str,"A-th row [%10.3f %10.3f %10.3f %10.3f %10.3f %10.3f %10.3f %10.3f %10.3f %10.3f]\n",0.0,1.0,2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0);
  fprintf(fp,str);
  for (int i=0;i<Stiff.GetFI();i++) {
    sprintf(str,"%d-th row [",i);
    for (int j=0;j<Stiff.GetFJ();j++) {
      sprintf(s,"%10.3f ",Stiff(i,j));
      strcat(str,s);
    }
    sprintf(s,"]\n");
    strcat(str,s);
    fprintf(fp,str);
  }
  fclose(fp);
}
//--------------------------------------------------------------------
