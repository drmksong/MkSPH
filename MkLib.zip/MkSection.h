//---------------------------------------------------------------------------
#ifndef MkSectionH
#define MkSectionH
#include "MkMesh.h"
#include "MkMisc.h"
#include "MkEntity.h"
#include "MkLayer.h"
#include "MkAnalyticSection.h"
#include "MkDeck.h"
#include "MkPile.h"
#include "MkPileSection.h"
#include "MkMainBeam.h"
#include "MkMainBeamProp.h"
#include "MkSunexProfile.h"
#include "MkSlab.h"
#include "MkSlabWall.h"
#include "MkAnchor.h"
#include "MkBolt.h"
#include "MkSupport.h"
#include "MkRetainPanel.h"
#include "MkCut.h"
#include "MkFill.h"
#include "MkExcavStep.h"
#include "MkProfile.h"
#include "MkBearing.h"
#include "MkGroundImprov.h"
#include "MkWater.h"
#include "MkSteelSpec.h"
#include "MkCIP.h"
#include "MkJunk.h"
//---------------------------------------------------------------------------
enum MkSolMode {smElastic, smPlastic};
enum MkSectionType {stSingleWall, stDoubleWall};

class MkSection {
public:
  MkSupports support_L;
  MkSupports support_R;
protected: // entities
  char      FileName[256]; // output file
  char      scFileName[256];
  char      prfFileName[256]; // profile name
  char      iFileName[256]; // internal use
  bool      Selected;

  float SectionLength;
  MkSectionType SectionType;
  float     Spacing;
  MkSolMode SolMode;
  bool      Echo;

  MkNodes   Nodes;
  MkLayers  Layers;
  MkPiles   Piles, StepPiles;
  MkStruts  Struts, StepStruts;
  MkAnchors Anchors, StepAnchors;
  MkBolts   Bolts, StepBolts;
  MkSupports Supports; // internal use only
//  MkWales   Wales;   // ������ �������� ��Ŀ�� �μ����� �����ϹǷ� ������ ��¡�� �ʿ����.
  MkSlabs   Slabs;
  MkSlabWalls SlabWalls;
  MkRetainPanels RetainPanels;
  MkExcavStep ExcavStep;
  MkCuts Cuts;
  MkCut StepCut;
  MkFills Fills;
  MkFill StepFill;
  MkBndConds BndConds;
  MkAnalyticSection AnaSection;
//  MkProfiles Profiles;  // Profile�� Layer, Cut, Fill���� ���� ������.
  MkSunexProfiles SunexProfiles;
  MkMainBeam MainBeam;
  MkMainBeamProp MidMainBeamProp, SideMainBeamProp;

  MkGroundImprovs GroundImprov;
  MkWater Water;
  MkPileSections PileSections; // new class
  MkSteels Steel;             // interconnected with Spec
  MkSpec Spec;                // new class
  MkDeck Deck;
  MkCIP CIP;
  MkBearing SoilBearing;
  MkBearing RockBearing;
  MkJunk Junk;

  MkFloat WallResult; // stepnum/data num/(wall(0) ,depth(1), displacement(2), left earth pressure (3) shear force(4), moment(5) Result.Initialize(nsec,6,ndata))
  MkFloat AxialResult;// stepnum/data num/(x-coord(0), y-coord(1), force(2))
  MkFloat StrutAxial; // stepnum/strut dan/(strut num(0), axial force(1))
  MkFloat AnchorAxial;// stepnum/anchor dan/(anchor num(0), axial force(1))
  MkFloat BoltAxial;  // stepnum/bolt dan/(bolt num(0), axial force(1))
protected:
  // controls
#ifdef __BCPLUSPLUS__
  TStringGrid *Grid;
  MkPaintBox *PaintBox;
#endif

public:
  MkSection();
  MkSection(int );
  ~MkSection(){}
#ifdef __BCPLUSPLUS__
  AnsiString ClassName(){return AnsiString("MkSection");}
#else
  char* ClassName(){return ("MkSection");}
#endif
public: //getting function
  float GetSectionLength(){return SectionLength;}
  MkSectionType &GetSectionType(){return SectionType;}
  MkLayers &GetLayers(){return Layers;}
  MkSunexProfiles &GetSunexProfiles(){return SunexProfiles;}
  MkPiles &GetPiles(){return Piles;}
  MkPiles &GetStepPiles(){return StepPiles;}
  MkPileSections &GetPileSections(){return PileSections;}
  MkStruts &GetStruts(){return Struts;}
  MkStruts &GetStepStruts(){return StepStruts;}
//  MkWales &GetWales(){return Wales;}
  MkSlabs &GetSlabs(){return Slabs;}
  MkSlabWalls &GetSlabWalls(){return SlabWalls;}
  MkAnchors &GetAnchors(){return Anchors;}
  MkAnchors &GetStepAnchors(){return StepAnchors;}
  MkBolts &GetBolts(){return Bolts;}
  MkBolts &GetStepBolts(){return StepBolts;}
  MkSupports &GetSupports(){return Supports;}
  MkSupport &GetSupports(int i){return i<Supports.GetSize()?Supports[i]:NullSupport;}
  MkRetainPanels &GetRetainPanels(){return RetainPanels;}
  MkCuts &GetCuts(){return Cuts;}
  MkFills &GetFills(){return Fills;}
  MkCut &GetStepCut(){return StepCut;}
  MkFill &GetStepFill(){return StepFill;}
  MkExcavStep &GetExcavStep(){return ExcavStep;}
  MkBndConds &GetBndConds(){return BndConds;}
  MkAnalyticSection &GetAnalyticSection(){return AnaSection;}
  bool GetSelected(){return Selected;}
  bool isSelected(){return Selected;}
  float GetSpacing(){return Spacing;}
  MkNodes &GetNodes(){return Nodes;}
  MkFloat &GetWallResult(){return WallResult;}
  MkFloat &GetStrutAxial(){return StrutAxial;}
  MkFloat &GetAnchorAxial(){return AnchorAxial;}
  MkFloat &GetBoltAxial(){return BoltAxial;}
  char * GetFileName(){return FileName;}
  char * GetScriptFileName(){return scFileName;}
  char * GetPrfFileName(){return prfFileName;}
  char * GetDataFileName(){return iFileName;}
  MkSolMode GetSolMode(){return SolMode;}
  bool   GetEcho(){return Echo;}
//  MkProfiles &GetProfiles(){return Profiles;}
  int GetSidePileNum() // number of side pile (number of wall, single wall or two side wall?)
  {
    int n=0;
    for(int i=0;i<Piles.GetSize();i++) if(Piles[i].GetPileLoc()!=plMid) n++;
    return min(n,2);
  }
  
  MkDeck &GetDeck(){return Deck;}
  MkSpec &GetSpec(){return Spec;}
  MkBearing &GetSoilBearing(){return SoilBearing;}
  MkBearing &GetRockBearing(){return RockBearing;}
  MkCIP &GetCIP(){return CIP;}

  MkMainBeam &GetMainBeam(){return MainBeam;}
  MkMainBeamProp &GetMidMainBeamProp(){return MidMainBeamProp;}
  MkMainBeamProp &GetSideMainBeamProp(){return SideMainBeamProp;}

  MkJunk &GetJunk(){return Junk;}
  float GetSidepileCTC(){return Junk.GetSidepileCTC();}
  float GetMidpileCTC(){return Junk.GetMidpileCTC();}
  float GetSideInsert(){return Junk.GetSideInsert();}
  float GetToptoGL(){return Junk.GetToptoGL();}
  float GetExcaDepthL(){return Junk.Getexca_depth_L();}
  float GetExcaDepthR(){return Junk.Getexca_depth_R();}
  float GetDepthUnderDan(){return Junk.GetDepthUnderDan();}
  MkPile &GetSidePile();
  MkPile &GetMidPile();
  bool hasMidPile();
  bool hasSidePile();

public: //setting function
  void SetSectionLength(float l){SectionLength = l;}
  void SetSectionType(MkSectionType st){SectionType = st;}
  void SetLayers(MkLayers &lay){Layers=lay;}
  void SetSunexProfiles(MkSunexProfiles &prof){SunexProfiles = prof;}
  void SetPiles(MkPiles &pile){Piles=pile;}
  void SetStepPiles(MkPiles &pile){StepPiles=pile;}
  void SetStruts(MkStruts &strut){Struts=strut;}
  void SetStepStruts(MkStruts &strut){StepStruts=strut;}
//  void SetWales(MkWales &wale){Wales=wale;}
  void SetSlabs(MkSlabs &slab){Slabs=slab;}
  void SetSlabWalls(MkSlabWalls &swall){SlabWalls=swall;}
  void SetAnchors(MkAnchors &anch){Anchors=anch;}
  void SetStepAnchors(MkAnchors &anch){StepAnchors=anch;}
  void SetBolts(MkBolts &bolt){Bolts=bolt;}
  void SetStepBolts(MkBolts &bolt){StepBolts=bolt;}
  void SetRetainPanels(MkRetainPanels &pan){RetainPanels=pan;}
  void SetCuts(MkCuts &cut){Cuts = cut;}
  void SetFills(MkFills &fill){Fills = fill;}
  void SetStepCut(MkCut &cut){StepCut = cut;}
  void SetStepFill(MkFill &fill){StepFill = fill;}
  void SetExcavStep(MkExcavStep &step){ExcavStep=step;}
  void SetBndConds(MkBndConds &bc){BndConds = bc;}
  void SetAnalyticSection(MkAnalyticSection &anasec){AnaSection=anasec;}
  void SetSelected(bool sel){Selected = sel;}
  void SetSpacing(float s){Spacing = s;}
  void SetNodes(MkNodes &node){Nodes = node;}
  bool SetupAllNodes(); // setup all the nodes of entire system
  void SetFileName(char *fname){strcpy(FileName,fname);}
  void SetScriptFileName(char *fname){strcpy(scFileName,fname);}
  void SetPrfFileName(char *fname){strcpy(prfFileName,fname);}
  void SetDataFileName(char *fname){strcpy(iFileName,fname);}
  void SetSolMode(MkSolMode solmode){SolMode = solmode;}
  void SetEcho(bool echo){Echo = echo;}
//  void SetProfiles(MkProfiles &prf){Profiles = prf;}

  void SetDeck(MkDeck &deck){Deck=deck;}
  void SetSpec(MkSpec &spec){Spec=spec;}
  void SetSoilBearing(MkBearing &b){SoilBearing=b;}
  void SetRockBearing(MkBearing &b){RockBearing=b;}
  void SetCIP(MkCIP &cip){CIP = cip;}
  void SetJunk(MkJunk &junk){Junk = junk;}
  void SetSidepileCTC(float a){Junk.SetSidepileCTC(a);}
  void SetMidpileCTC(float a){Junk.SetMidpileCTC(a);}
  void SetSideInsert(float a){Junk.SetSideInsert(a);}
  void SetToptoGL(float a){Junk.SetToptoGL(a);}
  void SetDepthUnderDan(float a){Junk.SetDepthUnderDan(a);}

  void SetSidePile(MkBeam &beam);
  void SetMidPile(MkBeam &beam);
  void SetMainBeam(MkBeam &beam);
  void SetMidMainBeamProp(MkBeam &beam);
  void SetSideMainBeamProp(MkBeam &beam);
  void SetStrut(MkBeam &beam);

public:
  bool operator==(MkSection&);
  bool operator!=(MkSection&);
  MkSection &operator=(MkSection &sec);
#ifdef __BCPLUSPLUS__
  void SetPaintBox(MkPaintBox *pb){PaintBox = pb;}
  bool UpdateFrom(TStringGrid *grid){Grid = grid;return UpdateFrom();};
  bool UpdateTo(TStringGrid *grid){Grid = grid;return UpdateTo();};
  bool UpdateFrom(){return false;}
  bool UpdateTo(){return false;}
#endif
  bool LoadScrFromFile();
  bool LoadProfile();
  bool LoadProfile(char *fname){SetPrfFileName(fname);LoadProfile();}
  bool GenProfile();
  bool LoadDatFromFile();
  bool Out(char *fname);
  bool ResultOut(char *fname);
  bool MaxResultOut(char *fname);  
  bool StepResultOut(char *fname);  
  bool SaveScrToFile();
  bool SaveDatToFile();
  bool SaveProfile();
  bool SaveProfile(char *fname){SetPrfFileName(fname); return SaveProfile();}
  bool Apply(MkSteps &);
  bool ApplyNew(MkSteps &);
//  bool ApplyProfile();  // ���������ϹǷ� �ʿ����.
  bool Solve(int step,MkAnalysisType at);
  bool Post();
  bool CheckNodes();
  bool CheckElements();
  bool CheckElements(MkElements &elem);
  bool AddAnalysis(MkAnalysisType at){AnaSection.AddAnalysis(at); return true;}
  void BuildSupport();
  void BuildTan();
  void BuildCutnFill();
  bool BuildStepEntity(int stepnum);
  void AnalSupport();

#ifdef __BCPLUSPLUS__
  void Import(MkGlobalVar &globalvar, int sec);
  void Export(MkGlobalVar &globalvar, int sec);
#endif
  void Clear();

#ifdef __BCPLUSPLUS__
  void Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif
};

class MkSections {
protected:
  MkSection *FSection;
  int FSize;//Actual size of entities
  int FSizeOfArray;
#ifdef __BCPLUSPLUS__
  TColor Color;
#endif
public:
  MkSections(int size,MkSection *ent);
  MkSections(int size);
  MkSections(){FSizeOfArray = FSize = 0;FSection = NULL;}
  ~MkSections();
  virtual void Initialize(int size);
  virtual void Initialize(int size,MkSection *);
  int GetSize(){return FSize;};
  int GetNumber(){return FSize;};
  bool Add(MkSection &section);  // change of size of section
  bool Add(int index,MkSection &section);
  bool Delete(MkSection &section);  // change of size of section
  bool Delete(int index);
  int Grow(int Delta);            // change of size of array
  int Shrink(int Delta);          // change of size of array
  bool Clear();
#ifdef __BCPLUSPLUS__
  void Import(MkGlobalVar &globalvar);
  void Export(MkGlobalVar &globalvar);
#endif

#ifdef __BCPLUSPLUS__
  TColor GetColor(){return Color;};
  void SetColor(TColor c){Color = c;}
#endif
  virtual MkSection & operator[](int);
  MkSections & operator=(MkSections &sections);
  bool operator==(MkSections &sections);

#ifdef __BCPLUSPLUS__
  void Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif

  bool GenProfile()
    {
      for(int i=0;i<FSize;i++) FSection[i].GenProfile();
    }

};
extern MkSection NullSection;
//---------------------------------------------------------------------------
#endif
