//---------------------------------------------------------------------------
#ifndef MkTriangleH
#define MkTriangleH

#include <Stdio.h>
#include "MkPoint.h"
#include "MkLine.h"
#include "MkShape.h"

float frandom(float f);

class MkTriangle : public MkShape {
private:
  MkPoint StartPoint, MidPoint, EndPoint;
  float FArea;
  float FRadius;
  MkVector FNormal;
  float A[3],B[3],C[3],AR2,GradX,GradY;
  
  void  CalArea();
  void  CalGrad();
  void  CalRadius();
  void  CalNormal();
#ifdef __BCPLUSPLUS__
  TColor Color;
#endif

public:
  MkTriangle();
  MkTriangle(int);
  MkTriangle(MkPoint sp, MkPoint mp, MkPoint ep);
  ~MkTriangle();

  void  Reset(MkPoint sp, MkPoint mp, MkPoint ep);
  void  Reset(MkPoint rps[3]);

  void Translate(MkPoint rp);
  void Translate(float x,float y,float z);
  float  GetArea();
  float  GetXGrad(); // x-direction gradient to z value
  float  GetYGrad(); // y-direction gradient to z value
  float  GetRadius();
  MkVector &GetNormal();
#ifdef __BCPLUSPLUS__
  void SetColor(TColor c){Color=c;}
  TColor GetColor(){return Color;}
  virtual AnsiString ClassName(){return AnsiString("MkTriangle");}
#else
  virtual char* ClassName(){return "MkTriangle";}
#endif
  bool  isIntersect(MkTriangle &rt);
  bool  isValid();
  bool  isIn(float x,float y);
  bool  isIn(MkPoint);
  bool  isInside(MkPoint);
  bool isTriangle(){return true;}

  MkLine  FirstLine();
  MkLine  SecondLine();
  MkLine  LastLine();

  MkPoint &operator[](int);
  MkLine operator()(int);
  float operator()(float,float);
  bool operator &&(MkTriangle &rt);
  bool operator ==(MkTriangle &rt);
  bool operator!=(MkTriangle &rt);
  MkTriangle &operator =(MkTriangle &rt);
  float  CrossProduct();

#ifdef __BCPLUSPLUS__
  void Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif
};

class MkTriangles {
protected:
  MkTriangle *FTriangle;
  int FSize;
  int FSizeOfArray;  
#ifdef __BCPLUSPLUS__
  TColor Color;
#endif
public:
  MkTriangles(int Size);
  MkTriangles(){FSize = 0; FSizeOfArray = 0; FTriangle = NULL;}
  ~MkTriangles(){if (FTriangle) {delete (MkTriangle*)FTriangle;FTriangle = NULL;}}
  void Initialize(int Size);
  void Clear();

  bool Add(MkTriangle tri);  // change of size of tri
  bool Delete(MkTriangle tri);  // change of size of tri
  int Grow(int Delta);            // change of size of array
  int Shrink(int Delta);          // change of size of array

  int GetSize(){return FSize;}
  int SaveUCD(char *filename);
  int SaveLID(char *filename); // Auto-CAD Lisp Input Data file

#ifdef __BCPLUSPLUS__
  void SetColor(TColor c){Color=c;}
  TColor GetColor(){return Color;}
#endif

  virtual MkTriangle &  operator[](int);
  MkTriangles &  operator=(MkTriangles &Triangles);

#ifdef __BCPLUSPLUS__
  void Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif
};
//---------------------------------------------------------------------------
extern MkTriangle NullTriangle;
//---------------------------------------------------------------------------
#endif
