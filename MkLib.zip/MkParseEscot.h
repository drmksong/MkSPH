//---------------------------------------------------------------------------
#ifndef ParseEscotH
#define ParseEscotH
#include "MkParser.h"
//---------------------------------------------------------------------------
class MkEscotParser : public MkParser {
protected:



public:



};
#endif

/*
  bool ParseEscot(char *str, MkKeyKind key);
  bool ParseSunex(char *str, MkKeyKind key);
  bool ParseExcad(char *str, MkKeyKind key);

  bool ParseEscotPrj(char *str);
  bool ParseEscotLay(char *str);
  bool ParseEscotPrf(char *str);
  bool ParseEscotWall(char *str);
  bool ParseEscotStrut(char *str);
  bool ParseEscotAnchor(char *str);
  bool ParseEscotRockbolt(char *str);
  bool ParseEscotSlab(char *str);
  bool ParseEscotSlabWall(char *str);
  bool ParseEscotDiv(char *str);
  bool ParseEscotSol(char *str);
  bool ParseEscotPnt(char *str);
  bool ParseEscotNoEcho(char *str);
  bool ParseEscotOut(char *str);
  bool ParseEscotStep(char *str);
  bool ParseEscotBot(char *str);
  bool ParseEscotRankine(char *str);
  bool ParseEscotPeck(char *str);
  bool ParseEscotPeck1(char *str);
  bool ParseEscotEarthPress(char *str);
  bool ParseEscotSlope(char *str);
  bool ParseEscotPrfChange(char *str);
  bool ParseEscotGWL(char *str);
  bool ParseEscotWaterPress(char *str);
  bool ParseEscotSurcharge(char *str);
  bool ParseEscotLoad(char *str);
  bool ParseEscotPress(char *str);
  bool ParseEscotMinAct(char *str);
  bool ParseEscotExcav(char *str);
  bool ParseEscotConst(char *str);
  bool ParseEscotRemove(char *str);
  bool ParseEscotInsertCheck(char *str);
  bool ParseEscotInteration(char *str);
  bool ParseEscotGroundSettle(char *str);
  bool ParseEscotSlip(char *str);

  bool ParseExcadPrj(char *str);
  bool ParseExcadLay(char *str);
  bool ParseExcadPrf(char *str);
  bool ParseExcadWall(char *str);
  bool ParseExcadStrut(char *str);
  bool ParseExcadAnchor(char *str);
  bool ParseExcadRockbolt(char *str);
  bool ParseExcadSlab(char *str);
  bool ParseExcadSlabWall(char *str);
  bool ParseExcadDiv(char *str);
  bool ParseExcadSol(char *str);
  bool ParseExcadPnt(char *str);
  bool ParseExcadNoEcho(char *str);
  bool ParseExcadOut(char *str);
  bool ParseExcadStep(char *str);
  bool ParseExcadBot(char *str);
  bool ParseExcadRankine(char *str);
  bool ParseExcadPeck(char *str);
  bool ParseExcadPeck1(char *str);
  bool ParseExcadEarthPress(char *str);
  bool ParseExcadSlope(char *str);
  bool ParseExcadPrfChange(char *str);
  bool ParseExcadGWL(char *str);
  bool ParseExcadWaterPress(char *str);
  bool ParseExcadSurcharge(char *str);
  bool ParseExcadLoad(char *str);
  bool ParseExcadPress(char *str);
  bool ParseExcadMinAct(char *str);
  bool ParseExcadExcav(char *str);
  bool ParseExcadConst(char *str);
  bool ParseExcadRemove(char *str);
  bool ParseExcadInsertCheck(char *str);
  bool ParseExcadInteration(char *str);
  bool ParseExcadGroundSettle(char *str);
  bool ParseExcadSlip(char *str);
*/
