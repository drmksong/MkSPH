//---------------------------------------------------------------------------
#ifndef MkSunexProfileH
#define MkSunexProfileH
#include "MkEntity.h"
//---------------------------------------------------------------------------
class MkSunexProfile : public MkEntity {
protected:
  int ActiveSoilNumber, PassiveSoilNumber;
public:
  MkSunexProfile(){ActiveSoilNumber = PassiveSoilNumber = 0;}
  MkSunexProfile(int ){ActiveSoilNumber = PassiveSoilNumber = 0;}
  ~MkSunexProfile(){}
  
  void SetActiveSoilNumber(int no){ActiveSoilNumber = no;}
  void SetPassiveSoilNumber(int no){PassiveSoilNumber = no;}

  int GetActiveSoilNumber(){return ActiveSoilNumber;}
  int GetPassiveSoilNumber(){return PassiveSoilNumber;}
};

class MkSunexProfiles {
protected:
    MkSunexProfile *FSunexProfile;
    int FSize;//Actual size of entities
    int FSizeOfArray;
#ifdef __BCPLUSPLUS__
    TColor Color;
#endif
public:
    MkSunexProfiles(int size,MkSunexProfile *ent);
    MkSunexProfiles(int size);
    MkSunexProfiles(){FSizeOfArray = FSize = 0;FSunexProfile = NULL;}
     ~MkSunexProfiles();
    virtual void Initialize(int size);
    virtual void Initialize(int size,MkSunexProfile *);
    int GetSize(){return FSize;};
    int GetNumber(){return FSize;};
    bool Add(MkSunexProfile &prof);  // change of size of prof
    bool Add(int index,MkSunexProfile &prof);
    bool Delete(MkSunexProfile &prof);  // change of size of prof
    bool Delete(int index);
    int Grow(int Delta);            // change of size of array
    int Shrink(int Delta);          // change of size of array
    bool Clear();
#ifdef __BCPLUSPLUS__
    TColor GetColor(){return Color;};
    void SetColor(TColor c){Color = c;}
    void Out(TObject *);
#else
#endif
    void Out(char *fname);
#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif

    virtual MkSunexProfile & operator[](int);
    MkSunexProfiles & operator=(MkSunexProfiles &profs);
    bool operator==(MkSunexProfiles &profs);
};
//---------------------------------------------------------------------------
extern MkSunexProfile NullSunexProfile;
//---------------------------------------------------------------------------
#endif
