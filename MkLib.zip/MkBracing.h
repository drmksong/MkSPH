//---------------------------------------------------------------------------
#ifndef MkBracingH
#define MkBracingH

#ifdef __BCPLUSPLUS__
#include "GlobalVarUnit.h"
#endif

#include <string.h>
#include "MkObject.h"
#include "MkMisc.h"
//---------------------------------------------------------------------------
class MkBracing : public MkObject {
public:
  double len;
public:
  MkBracing(){Clear();}
  MkBracing(int){Clear();}
  ~MkBracing(){}
  void Clear(){len=0;}
};

class MkBracings {
protected:
  MkBracing *FBracing;
  int FSize;//Actual size of nodes
  int FSizeOfArray;
public:
  MkBracings(int size,MkBracing *bracing);
  MkBracings(int size);
  MkBracings(){FSizeOfArray = FSize = 0;FBracing = NULL;}
  ~MkBracings();

  virtual void Initialize(int size);
  virtual void Initialize(int size,MkBracing *);
  int GetSize(){return FSize;};
  int GetNumber(){return FSize;};
  bool Add(MkBracing &bracing);  // change of size of bracing
  bool Add(int index,MkBracing &bracing);
  bool Delete(MkBracing &bracing);  // change of size of bracing
  bool Delete(int index);
  int Grow(int Delta);            // change of size of array
  int Shrink(int Delta);          // change of size of array
  bool Clear();
  virtual MkBracing & operator[](int);
  MkBracings & operator=(MkBracings &bracings);
  bool operator==(MkBracings &bracings);
#ifdef __BCPLUSPLUS__
  void Import(MkGlobalVar &globalvar, int sec, int pilesec);
  void Export(MkGlobalVar &globalvar, int sec, int pilesec);
#endif
};
extern MkBracing NullMkBracing;
#endif
