//---------------------------------------------------------------------------
#ifndef MkBeamH
#define MkBeamH

#ifdef __BCPLUSPLUS__
#include "GlobalVarUnit.h"
#endif

#include "MkMisc.h"
#include "MkObject.h"

enum MkBeamType {btSidePile, btMidPile, btMainBeam, btSupportBeam,
                 btSupportBeam_M, btStrut, btWale, btSheetPile};
//---------------------------------------------------------------------------
class MkBeam : public MkObject {
public:
  MkSteelType SteelType;
  MkBeamType BeamType;
  double BB, HH;
  double tt1,
         tt2/*= W/m for sheet pile */,
         AA/*= A/ea for sheet pile */,
         Aw/*= A/m for sheet pile */,
         W/*= W/ea for sheet pile */,
         Zx/*= Z/ea for sheet pile */,
         Ix/*= I/ea for sheet pile */,
         rx/*= Z/m for sheet pile */,
         ry/*= I/m for sheet pile */;
public:
  MkBeam();
  MkBeam(int);
  ~MkBeam(){}
  void Clear();
  void SetBeamType(MkBeamType bt){BeamType = bt;}
#ifdef __BCPLUSPLUS__
  void Import(MkGlobalVar &globalvar, int sec);
  void Export(MkGlobalVar &globalvar, int sec);
#endif

  bool operator==(MkBeam &);
  bool operator!=(MkBeam &);
  MkBeam &operator=(MkBeam &);

};

class MkBeams {
public:
  MkBeamType BeamType;
  MkBeam *FBeam;
  int FSize;//Actual size of nodes
  int FSizeOfArray;
public:
  MkBeams(int size,MkBeam *beam);
  MkBeams(int size);
  MkBeams(){FSizeOfArray = FSize = 0;FBeam = NULL;}
  ~MkBeams();

  virtual void Initialize(int size);
  virtual void Initialize(int size,MkBeam *);
  int GetSize(){return FSize;};
  int GetNumber(){return FSize;};
  bool Add(MkBeam &beam);  // change of size of beam
  bool Add(int index,MkBeam &beam);
  bool Delete(MkBeam &beam);  // change of size of beam
  bool Delete(int index);
  int Grow(int Delta);            // change of size of array
  int Shrink(int Delta);          // change of size of array
  bool Clear();
  virtual MkBeam & operator[](int);
  MkBeams & operator=(MkBeams &beams);
  bool operator==(MkBeams &beams);
};
//---------------------------------------------------------------------------
extern MkBeam NullMkBeam;
#endif
