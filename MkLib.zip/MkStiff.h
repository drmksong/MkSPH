//---------------------------------------------------------------------------
#ifndef MkStiffH
#define MkStiffH
#include "MkMesh.h"
#include "MkSteer.h"

//---------------------------------------------------------------------------
class MkStiff {    // Only Structure System Stiffness, not include ground reaction
protected:         // It is used to calculate and contain system matrix,
  MkSteer Steer;   //  and not used directly
  MkMatrix Stiff;
public:
  MkStiff(){}
  MkStiff(MkNodes &nodes){SetupMatrix(nodes);}
  MkStiff(MkSteer &steer){SetupMatrix(steer);}
  ~MkStiff(){}
  void Init();
  void Clear(){Steer.Clear(); Stiff.Clear();}
#ifdef __BCPLUSPLUS__
  void Assemble(MkElement &elem,TMemo *memo);
#endif
  void Assemble(MkNodes &nodes, MkElements &elems)
    { 
      static int NofElem=0;
      if(NofElem==elems.GetSize()) return;
      SetupMatrix(nodes);
      Assemble(elems);
      NofElem = elems.GetSize();
      return;
    }
  void Assemble(MkElement &elem);
  void Assemble(MkElements &elems)
    {  
      for(int i=0;i<elems.GetSize();i++) 
	Assemble(elems[i]);
    }
  bool Solve(MkVector &rhs){return Stiff.Solve(rhs);}
  bool Solve(MkVector &rhs,SolveType st){return Stiff.Solve(rhs,st);}
  void SetupSteer(MkNodes &nodes){Steer.SetupSteer(nodes);}
  void SetupMatrix(MkNodes &nodes);
  void SetupMatrix(MkSteer &steer);
  void SetStiffMatrix(MkMatrix &m){Stiff = m;}
  MkMatrix & GetStiffMatrix(){return Stiff;}
  MkSteer & GetSteer(){return Steer;}
#ifdef __BCPLUSPLUS__
  void Out(TMemo *);
#endif
  void Out(char *);
};
//--------------------------------------------------------------------
#endif
