#ifndef MkPiapH
#define MkPiapH
#include "MkMisc.h"
class MkPiap {
 protected:
  float Gamma1, Gamma2, H, D, Hw;
 public:
  MkPiap();
  ~MkPiap();

  void SetGamma1(float g){Gamma1 = g;}
  void SetGamma2(float g){Gamma2 = g;}
  void SetH(float h){H = h;}
  void SetD(float d){D = d;}
  void SetHw(float h){Hw = h;}
  float GetFS();
};

#endif
