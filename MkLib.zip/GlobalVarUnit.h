//---------------------------------------------------------------------------
#ifndef GlobalVarUnitH
#define GlobalVarUnitH

#ifdef __BCPLUSPLUS__
#include <afx.h>
#endif
#include <stdio.h>
#include "MkDimUnit.h"

class MkGlobalVar 
{
public:
  CString projectcontent;
  CString rpath,projectname;
  int stress_type;
  int section_ea,sectiontype;

  int decktype,deck[15];
  double GL_R_minus_GL_L[15],ToptoGL[15];

  CString layername[10];
  int In_layer_ea,In_layer,In_layerdepth;
  int layer_ea;
  double layer_depth_L[15][10],layer_depth_R[15][10];
  int Rt[15][10],Rsub[15][10],C[15][10];
  long Ks[15][10];
  double Pi[15][10];
  int InputLayerEA, SelectLayer, Inputplan;

  CString steelname[15][15],steelkind[15][15];
  int OldSteel[15][15],LongTimeSteel[15][15];
  int OldSteelReduction[15][15],LongTimeSteelReduction[15][15];

  int    mainbeam_BB[15],mainbeam_HH[15];
  double mainbeam_tt1[15],mainbeam_tt2[15],mainbeam_AA[15],mainbeam_W[15];
  double mainbeam_Aw[15],mainbeam_Zx[15],mainbeam_Ix[15];
  double mainbeam_rx[15],mainbeam_ry[15];

  int    supportbeam_BB[15],supportbeam_HH[15];
  double supportbeam_tt1[15],supportbeam_tt2[15],supportbeam_AA[15];
  double supportbeam_W[15],supportbeam_Aw[15],supportbeam_Zx[15];
  double supportbeam_Ix[15],supportbeam_rx[15],supportbeam_ry[15];

  int    supportbeam_m_BB[15],supportbeam_m_HH[15];
  double supportbeam_m_tt1[15],supportbeam_m_tt2[15],supportbeam_m_AA[15];
  double supportbeam_m_W[15],supportbeam_m_Aw[15],supportbeam_m_Zx[15];
  double supportbeam_m_Ix[15],supportbeam_m_rx[15],supportbeam_m_ry[15];

  double SidepileCTC[15],SideInsert[15];
  int    sidepile_BB[15],sidepile_HH[15];
  double sidepile_tt1[15],sidepile_tt2[15],sidepile_AA[15],sidepile_W[15];
  double sidepile_Aw[15],sidepile_Zx[15];
  double sidepile_Ix[15],sidepile_rx[15],sidepile_ry[15];

  double MidpileCTC[15],MidInsert[15];
  int    midpile_BB[15],midpile_HH[15];
  double midpile_tt1[15],midpile_tt2[15],midpile_AA[15],midpile_W[15];
  double midpile_Aw[15],midpile_Zx[15],midpile_Ix[15],
         midpile_rx[15],midpile_ry[15];

  int    strut_BB[15],strut_HH[15];
  double strut_tt1[15],strut_tt2[15],strut_AA[15],strut_W[15];
  double strut_Aw[15],strut_Zx[15],strut_Ix[15],strut_rx[15],strut_ry[15];

  int    Inputwale;
  CString walename[15][30];
  int    wale_BB[15][30],wale_HH[15][30];
  double wale_tt1[15][30],wale_tt2[15][30],wale_AA[15][30],wale_W[15][30];
  double wale_Aw[15][30],wale_Zx[15][30],wale_Ix[15][30],
         wale_rx[15][30],wale_ry[15][30];

  int    sheetpile_BB[15],sheetpile_HH[15];
  double sheetpile_tt1[15],sheetpile_AA[15],sheetpile_Aw[15];
  double sheetpile_W[15],sheetpile_Zx[15];

  int In_support_L, In_support_R;
  int supportdan_L[15],supportdan_R[15],support_tendonEA_L[15][30];
  int support_tendonEA_R[15][30];
  int support_tan_L[15][30], support_tan_R[15][30];  //smk support_tan_L is newly added variable
  CString support_type_L[15][30],support_type_R[15][30];
  double support_depth_L[15][30],support_depth_R[15][30];
  double support_var_L[15][30],support_freelen_L[15][30];
  double support_sticklen_L[15][30],support_jackingforce_L[15][30];
  double support_var_R[15][30],support_freelen_R[15][30];
  double support_sticklen_R[15][30],support_jackingforce_R[15][30];
  double support_inidis_L[15][30],support_inidis_R[15][30]; //smk newly added variable
  double support_strloss_L[15][30],support_strloss_R[15][30]; //smk newly added variable

  double exca_depth_L[15],exca_depth_R[15];

  int In_liveload;
  int liveload1,liveload2,liveload3;
  int liveloaddirection;

  int pile_ea[10];
  double piledist[15][10];

  int bracing_ea[15][10];
  int bracingtype[15][10],bracingNN[15][10];
  double bracing_len[15][10][10];

  int water_level_type,reductionrate;
  double reductiondepth;

  int InputBogangjae,LayerBogang;
  int In_jibanbogang;
  int jibanbogang_ea,jibanboganglayer,jibanbogang_width[20];
  int jibanbogang_ctc[20],jibanbogang_rctc[20],jibanbogang_row[20];
	CString jibanbogang_kind[20];
  double jibanbogangdepth;
  int C_Fck[15],C_Fy[15],C_BarDia[15],C_CIPSteel[15];
  double C_Thick_or_Dia[15],C_Bar_EA[15];

public:

public:
  MkGlobalVar();
  void Clear();
};

void GlobalClear();
//escotview
extern FILE *in,*out,*out1;
//  CFile fi,fo,fi1,fi2,fi3,fi4,fi5,fi6;

//extern CString tss,ss,ss1,ss2,ss3,ss4,sss;
//extern CString rpath,projectname;

//extern   CString walekind[15][30];

extern double tmp,tmp1,tmp2,tmp3;
extern int itmp,itmp2,mouse_X,mouse_Y,screen,midpile_sec,mouse_click;
extern char text[200],text1[80],text2[80],text3[80],text4[80],txt[15][20],tmptext[30][20];

//  int i,j,k,l,m,n,tmp_ea;
extern int In_steel,In_bracing;
extern int In_cal,In_surang,In_estimate;
extern int In_Exca_Step,In_bearing,In_anchor,In_Call_data;
extern int num,num1;

extern int soil_bearing_method,rock_bearing_method,TypeExcaStep[15];
extern int load_ea[15][10],load_type[15][10][10];
extern double load_dist[15][10][10],load_kind[15][10][10][20];

extern int first_water_level;
extern double waterlevel_l[15][10],waterlevel_r[15][10],W_GL_minus;
extern double bearing[10];
extern double R_layer_depth_L[15][10],R_layer_depth_R[15][10];

extern int    GL;
extern double GL_L,GL_R,exca_W;

extern double R_exca_depth_L[15];
extern double R_exca_depth_R[15];
extern double R_support_depth_L[15][30],R_support_depth_R[15][30],maxdepth;

extern int    midpile_loading_ea[15][10];
extern double side_Pmax[15][3];
extern double Md_max[10],Ml_max[10],M_max[10],Vd_max[10],Vl_max[10];
extern double V_max[10],PP[15][20],PPP[15][20],distance,RMax[15];
extern double FS_bearing,friction[10];

extern double EA_SF,EA_Fpu,EA_Fpy,EA_Tau_Soil,EA_Tau_Rock;

extern double DepthUnderDan;
extern int    left_X,right_X,up_Y,down_Y,cX,cY,TX,TY;

//-------------------------------------------------------------SMK 2004.9.26, 30
extern double res_dis_L[15][60][100],res_dis_R[15][60][100],
        res_pres_L[15][60][100],res_pres_R[15][60][100],
        res_mom_L[15][60][100],res_mom_R[15][60][100],
        res_shr_L[15][60][100],res_shr_R[15][60][100];
extern double res_depth_L[15][60][100],res_depth_R[15][60][100];
extern int    res_cnt_L[15],res_cnt_R[15];
//-------------------------------------------------------------SMK 2004.9.26, 30
//bokgong
extern double deadload,impact,Impact[10],length,Length[10];
extern double p1f,p1r,p2f,p2r,p3f,p3r;
extern double Ml_mainbeam,Md_mainbeam,Vl_mainbeam,Vd_mainbeam,M_mainbeam,V_mainbeam;
extern double p1,p2,p3,p4,p5,p6,p7,p8,d1,d2,d3,d4,d5,d6,d7,d8,RA,M1,maxdist;
extern double bracingdist,L_per_B,L_per_B_m;

extern int    Earthpressure_N,Deflection_N,Moment_N,Shear_N,Earthpressure_N_R,
              Deflection_N_R,Moment_N_R,Shear_N_R;

extern double Earthpressure_depth[100],Deflection_depth[100],
              Moment_depth[100],Shear_depth[100];
extern double Earthpressure[100],Deflection[100],Moment[100],Shear[100];
extern double Earthpressure_depth_R[100],Deflection_depth_R[100],
              Moment_depth_R[100],Shear_depth_R[100];
extern double Earthpressure_R[100],Deflection_R[100],Moment_R[100],Shear_R[100];

//=============================================================================
extern double PILE_Mmax[15][2][30],PILE_Vmax[15][2][30],STRUT_Force[15][30],
              ANCHOR_Force[15][2][30],ROCKBOLT_Force[15][2][30];
//=============================================================================
//lateral
//extern char Text[200];
//extern CString Lss;

extern CString HBEAM[75][11],IBEAM[15][11],CHAN[9][11],ANG[46][7],S_P[9][10];

extern float E;  // Young's Modulus, don't use E as a variable
extern MkDimUnit DimUnit;
#endif
