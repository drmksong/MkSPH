//---------------------------------------------------------------------------
#ifndef CokrigH
#define CokrigH

#include <stdio.h>
#include <math.h>

#define EPS 1.0e-6

class Krig2D {
private:
//    6,11,500,100;

    float CO[6],C[6],RANGE[6],ANIS[6],RATIO[6],RINFLU[6];
    int model[6];
    float CCO[11],CC[11],CRANGE[11],CANIS[11],CRNFLU[11],CRATIO[11];
    int   MROW, MCOL, MVAR, MTOT;
    float X[501],Y[501],DAT[501][6];
    int   IKRIG,JUNSAM[501],KCOUNT;
    float XMEAS[101][6],ATEMP[101][101];
    int   cmodel[11];
    int   NHOLE[16];
    int   INIT;
    float XTEMP[101][6];
public:
    Krig2D(){;}
    ~Krig2D(){;}
    void KrigMain(char *fname);
    void  AFORM (float YCORD,float XCORD);
    float COVAR(float &DIST,int &K);
    float CROSS(float &DIST,int &K,int &IA,int &IB);
    void  RZRO(float A[6][6],int i,int j);
    float TRACE(float A[6][6]);
    void  EQSOLV();
};
//---------------------------------------------------------------------------
#endif
