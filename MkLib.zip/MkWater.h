//---------------------------------------------------------------------------
#ifndef MkWaterH
#define MkWaterH
#ifdef __BCPLUSPLUS__
#include "GlobalVarUnit.h"
#endif

#include "MkObject.h"
#include "MkFloat.h"
//---------------------------------------------------------------------------
class MkWater : public MkObject {
public:
  int first_water_level;
  int water_level_type;
  int reductionrate;
  double reductiondepth;
  double W_GL_minus;
  MkFloat level_l;
  MkFloat level_r;
public:
  MkWater();
  MkWater(int);
  ~MkWater(){}
  void Clear();
#ifdef __BCPLUSPLUS__
  void Import(MkGlobalVar &globalvar, int sec);
  void Export(MkGlobalVar &globalvar, int sec);
#endif
};

#endif
