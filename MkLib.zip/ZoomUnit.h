//---------------------------------------------------------------------------
#ifndef ZoomUnitH
#define ZoomUnitH
//---------------------------------------------------------------------------
#endif
#include <math.h>

void zoom(int sx_f,int sy_f,int ex_f,int ey_f,int sx_t,int sy_t,int ex_t,int ey_t);
void box(TCanvas *canvas,int sx,int sy,int ex,int ey);
void Gambak(TObject *sender);
void delay(int d);
extern int NumOfSec;
