//---------------------------------------------------------------------------
#pragma hdrstop

#include "stdafx.h"
#include "MkEntity.h"

//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#pragma package(smart_init)
#endif
//---------------------------------------------------------------------------
MkEntity NullEntity(0);
MkLayer NullLayer(0);
MkStrata NullStrata(0);
MkLayers NullLayers(0);
MkStratum NullStratum(0);
MkPile NullPile(0);
MkStrut NullStrut(0);
MkWale NullWale(0);
MkAnchor NullAnchor(0);
MkBolt NullBolt(0);
MkCut  NullCut(0);
MkFill NullFill(0);
MkSlab NullSlab(0);
MkRetainPanel NullRetainPanel(0);

MkEntities::MkEntities(int size,MkEntity *ents)
{
    if (size < 0) {
      MkDebug("::MkEntities - MkEntities(int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSize == 0) {
       FEntity = NULL;
       return;
    }

    FEntity = new MkEntity[FSizeOfArray];
    for (int i=0;i<FSizeOfArray;i++) (*this)[i] = ents[i];
}

MkEntities::MkEntities(int size)
{
    if (size < 0) {
      MkDebug("::MkEntities - MkEntities(int size)");;
      return;
    }

    FSizeOfArray = size;
    FSize = 0;
    if (FSizeOfArray == 0) {
       FEntity = NULL;

       return;
    }

    FEntity = new MkEntity[FSizeOfArray];
}

MkEntities::~MkEntities()
{
   FSizeOfArray = FSize = 0;
   if (FEntity) {
      delete[] FEntity;
      FEntity = NULL;
   }
}

void MkEntities::Initialize(int size)
{
    if (size < 0) {
      MkDebug("::MkEntities - Initialize(int size)");
      return;
    }
    if (FSizeOfArray == size) return;

    FSizeOfArray = size;
    FSize = 0;

    if (FSizeOfArray == 0) {
       if (FEntity!=NULL) delete[] (MkEntity*)FEntity;
       FEntity = NULL;
       return;
    }

    if (FEntity!=NULL) delete[] (MkEntity*)FEntity;
    FEntity = new MkEntity[FSizeOfArray];
}

void MkEntities::Initialize(int size,MkEntity *ents)
{

    if (size < 0 || ents == NULL) {
      MkDebug("::MkEntities - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSize = FSizeOfArray = size;
    if (FSizeOfArray == 0) {
       if (FEntity!=NULL) delete[] (MkEntity*)FEntity;
       FEntity = NULL;
       return;
    }

    if (FEntity!=NULL) delete[] (MkEntity*)FEntity;
    FEntity = new MkEntity[FSizeOfArray];
    for (int i=0;i<FSizeOfArray;i++) FEntity[i] = ents[i];
}

int MkEntities::Grow(int delta)
{
    int i;
    MkEntity *ent=NULL;

    if (!(ent = new MkEntity[FSizeOfArray+delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        ent[i] = FEntity[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        ent[i] = NullEntity;
    if (FEntity) {
       delete[] (MkEntity*)FEntity;
       FEntity = NULL;
    }
    FEntity = ent;
    FSizeOfArray = FSizeOfArray+delta;
    return FSizeOfArray;
}

int MkEntities::Shrink(int delta)
{
    int i;
    MkEntity *ent=NULL;

    if (!(ent = new MkEntity[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        ent[i] = FEntity[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        ent[i] = NullEntity;
    if (FEntity) {
       delete[] (MkEntity*)FEntity;
       FEntity = NULL;
    }
    FEntity = ent;
    FSizeOfArray = FSizeOfArray-delta;
    return FSizeOfArray;
}

bool MkEntities::Add(MkEntity &ent)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    FSize++;
    FEntity[FSize-1] = ent;
    return true;
}

bool MkEntities::Add(int index, MkEntity &ent)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    for (int i=FSize-1;i>=index;i--)
      FEntity[i+1] = FEntity[i];
    FSize++;
    FEntity[index] = ent;
    return true;
}

bool MkEntities::Delete(MkEntity &ent)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FEntity[i] == ent) break;
    }
    if(i==FSize) return false;
    if(FEntity[i] == ent) {
      for (int j=i;j<FSize-1;j++)
        FEntity[j] = FEntity[j+1];
    }
    FSize--;
    FEntity[FSize] = NullEntity;
    return true;
}

bool MkEntities::Delete(int index)
{
    for (int j=index;j<FSize-1;j++)
        FEntity[j] = FEntity[j+1];

    FSize--;
    FEntity[FSize] = NullEntity;
    return true;
}

bool MkEntities::Clear()
{
   FSizeOfArray = FSize = 0;
   if (FEntity) {
      delete[] FEntity;
      FEntity = NULL;
   }
   return true;
}

MkEntity & MkEntities::operator[](int i)
{
    if (0<=i && i<FSize) return FEntity[i];
    else if(FSize<=i && i<FSizeOfArray) {
      FSize=i+1;
      return FEntity[i];
    }
    else if (FSizeOfArray <= i) {
      Grow(i-FSizeOfArray+5);
      return NullEntity;
    }
    else return NullEntity;
}

MkEntities & MkEntities::operator=(MkEntities &ents)
{
    int i;

    Clear();
    FSize = ents.FSize;
    FSizeOfArray = ents.FSizeOfArray;
    if (FSizeOfArray == 0) {
       FEntity = NULL;
       return *this;
    }
    this->FEntity = new MkEntity[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FEntity[i] = ents.FEntity[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FEntity[i] = NullEntity;

    return *this;
}

bool MkEntities::operator==(MkEntities &ents)
{
    int i;

    if (FSize != ents.FSize) return false;
    for (i=0;i<FSize;i++)
      if (this->FEntity[i] != ents.FEntity[i]) return false;

    return true;
}
//---------------------------------------------------------------------------

bool MkWall::operator==(MkWall &w)
{
  bool flag;
  flag = MkEntity::operator==((MkEntity &)w);
  flag = flag && (Wall == w.Wall);
  return flag;
}

bool MkWall::operator!=(MkWall &w)
{
  return operator!=(w);
}

MkWall & MkWall::operator=(MkWall &w)
{
  MkEntity::operator=((MkEntity&)w);
  Wall = w.Wall;
  return *this;
}
//---------------------------------------------------------------------------

MkStrata::MkStrata()
{
  Number=0;
#ifdef __BCPLUSPLUS__
  Name=" ";
#else
  memset(Name,'\0',255);
#endif

  WetUnitWeight[0]=0;
  SubUnitWeight[0]=0;
  Cohesion[0]=0;
  Friction[0]=0;
  HorSubReact[0]=0;
  VerSubReact[0]=0;
  WetUnitWeight[1]=0;
  SubUnitWeight[1]=0;
  Cohesion[1]=0;
  Friction[1]=0;
  HorSubReact[1]=0;
  VerSubReact[1]=0;
  Burden=0;
  K0 = 1;
  Ka = 0;
  Kp = 0;
}

MkStrata::MkStrata(int n)
{
  Number=0;
#ifdef __BCPLUSPLUS__
  Name=" ";
#else
  memset(Name,'\0',255);
#endif


  WetUnitWeight[0]=0;
  SubUnitWeight[0]=0;
  Cohesion[0]     =0;
  Friction[0]     =0;
  HorSubReact[0]  =0;
  VerSubReact[0]  =0;
  WetUnitWeight[1]=0;
  SubUnitWeight[1]=0;
  Cohesion[1]     =0;
  Friction[1]     =0;
  HorSubReact[1]  =0;
  VerSubReact[1]  =0;
  Burden          =0;
  K0=1;
  Ka = 0;
  Kp = 0;
}

#ifdef __BCPLUSPLUS__
bool MkStrata::UpdateFrom()
{
  if(!Grid) return false;

  Number          =Grid->Cells[1][0].ToInt();
  Name            =Grid->Cells[1][1];
  WetUnitWeight[0]=Grid->Cells[1][2].ToDouble();
  SubUnitWeight[0]=Grid->Cells[1][3].ToDouble();
  Cohesion[0]     =Grid->Cells[1][4].ToDouble();
  Friction[0]     =Grid->Cells[1][5].ToDouble();
  HorSubReact[0]  =Grid->Cells[1][6].ToDouble();
  VerSubReact[0]  =Grid->Cells[1][7].ToDouble();
  WetUnitWeight[1]=Grid->Cells[1][8].ToDouble();
  SubUnitWeight[1]=Grid->Cells[1][9].ToDouble();
  Cohesion[1]     =Grid->Cells[1][10].ToDouble();
  Friction[1]     =Grid->Cells[1][11].ToDouble();
  HorSubReact[1]  =Grid->Cells[1][12].ToDouble();
  VerSubReact[1]  =Grid->Cells[1][13].ToDouble();

  return true;
}

bool MkStrata::UpdateTo()
{
  if(!Grid) return false;

  for(int i=0;i<20;i++) {Grid->Cells[0][i] = "";Grid->Cells[1][i]="";}

  Grid->Cells[0][0] =  "Number";
  Grid->Cells[0][1] =  "Name";
  Grid->Cells[0][2] =  "WetUnitWeight[0]";
  Grid->Cells[0][3] =  "SubUnitWeight[0]";
  Grid->Cells[0][4] =  "Cohesion[0]";
  Grid->Cells[0][5] =  "Friction[0]";
  Grid->Cells[0][6] =  "HorSubReact[0]";
  Grid->Cells[0][7] =  "VerSubReact[0]";
  Grid->Cells[0][8] =  "WetUnitWeight[1]";
  Grid->Cells[0][9] =  "SubUnitWeight[1]";
  Grid->Cells[0][10] = "Cohesion[1]";
  Grid->Cells[0][11] = "Friction[1]";
  Grid->Cells[0][12] = "HorSubReact[1]";
  Grid->Cells[0][13] = "VerSubReact[1]";

  Grid->Cells[1][0] =  Number;
  Grid->Cells[1][1] =  Name;
  Grid->Cells[1][2] =  WetUnitWeight[0];
  Grid->Cells[1][3] =  SubUnitWeight[0];
  Grid->Cells[1][4] =  Cohesion[0];
  Grid->Cells[1][5] =  Friction[0];
  Grid->Cells[1][6] =  HorSubReact[0];
  Grid->Cells[1][7] =  VerSubReact[0];
  Grid->Cells[1][8] =  WetUnitWeight[1];
  Grid->Cells[1][9] =  SubUnitWeight[1];
  Grid->Cells[1][10] = Cohesion[1];
  Grid->Cells[1][11] = Friction[1];
  Grid->Cells[1][12] = HorSubReact[1];
  Grid->Cells[1][13] = VerSubReact[1];

  return true;
}
#endif


float MkStrata::GetWetUnitWeight(MkPoint &pnt)
{
  return 0;
}

float MkStrata::GetCohesion(MkPoint &pnt)
{
  return 0;
}

float MkStrata::GetFriction(MkPoint &pnt)
{
  return 0;
}

float MkStrata::GetHorSubReact(MkPoint &pnt)
{
  return 0;
}

float MkStrata::GetVerSubReact(MkPoint &pnt)
{
  return 0;
}


float MkStrata::GetWetUnitWeight(MkLine &line)
{
  return 0;
}

float MkStrata::GetCohesion(MkLine &line)
{
  return 0;
}

float MkStrata::GetFriction(MkLine &line)
{
  return 0;
}

float MkStrata::GetHorSubReact(MkLine &line)
{
  return 0;
}

float MkStrata::GetVerSubReact(MkLine &line)
{
  return 0;
}

float MkStrata::InLen(MkLine &line)
{
  return 0;
}

MkLine MkStrata::InLine(MkLine &line)
{
  return NullLine;
}

bool MkStrata::operator==(MkStrata&)
{
  return false;
}

bool MkStrata::operator!=(MkStrata&)
{
  return false;
}

#ifdef __BCPLUSPLUS__
void  MkStrata::Draw(TObject *Sender)
{

}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void MkStrata::Draw(MkPaint *pb)
{

}
#endif
//---------------------------------------------------------------------------
MkStratum::MkStratum(int size,MkStrata *stratum)
{
    if (size < 0) {
      MkDebug("::MkStratum - MkStratum(int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSize == 0) {
       FStrata = NULL;
       return;
    }

    FStrata = new MkStrata[FSizeOfArray];
    for (int i=0;i<FSizeOfArray;i++) (*this)[i] = stratum[i];
}

MkStratum::MkStratum(int size)
{
    if (size < 0) {
      MkDebug("::MkStratum - MkStratum(int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSize == 0) {
       FStrata = NULL;
       return;
    }

    FStrata = new MkStrata[FSizeOfArray];
}

MkStratum::~MkStratum()
{
   FSizeOfArray = FSize = 0;
   if (FStrata) {
      delete[] FStrata;
      FStrata = NULL;
   }
}

void MkStratum::Initialize(int size)
{
    int i;
    if (size < 0) {
      MkDebug("::MkStratum - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray== size) return;

    FSizeOfArray=FSize=size;

    if (FSizeOfArray== 0) {
       if (FStrata!=NULL) delete[] (MkStrata*)FStrata;
       FStrata = NULL;
       return;
    }

    if (FStrata!=NULL) delete[] (MkStrata*)FStrata;
    FStrata = new MkStrata[FSizeOfArray];
    for(i=0;i<FSize;i++) FStrata[i].Number = i;
}

void MkStratum::Initialize(int size,MkStrata *stratum)
{
    int i;
    if (size < 0 || stratum == NULL) {
      MkDebug("::MkStratum - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSize= size;

    if (FSizeOfArray== 0) {
       if (FStrata!=NULL) delete[] (MkStrata*)FStrata;
       FStrata = NULL;
       return;
    }

    if (FStrata!=NULL) delete[] (MkStrata*)FStrata;
    FStrata = new MkStrata[FSizeOfArray];
    for(i=0;i<FSizeOfArray;i++) FStrata[i] = stratum[i];
    for(i=0;i<FSize;i++) FStrata[i].Number = i;
}

int MkStratum::Grow(int delta)
{
    int i;
    MkStrata *strata=NULL;

    if (!(strata = new MkStrata[FSizeOfArray+delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        strata[i] = FStrata[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        strata[i] = NullStrata;
    if (FStrata) {
       delete[] (MkStrata*)FStrata;
       FStrata = NULL;
    }
    FStrata = strata;
    FSizeOfArray = FSizeOfArray+delta;
    return FSizeOfArray;
}

int MkStratum::Shrink(int delta)
{
    int i;
    MkStrata *strata=NULL;

    if (!(strata = new MkStrata[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        strata[i] = FStrata[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        strata[i] = NullStrata;
    if (FStrata) {
       delete[] (MkStrata*)FStrata;
       FStrata = NULL;
    }
    FStrata = strata;
    FSizeOfArray = FSizeOfArray-delta;
    return FSizeOfArray;
}

bool MkStratum::Add(MkStrata &strata)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    FSize++;
    FStrata[FSize-1] = strata;
    return true;
}

bool MkStratum::Add(int index, MkStrata &strata)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    for (int i=FSize-1;i>=index;i--)
      FStrata[i+1] = FStrata[i];
    FSize++;
    FStrata[index] = strata;
    return true;
}

bool MkStratum::Delete(MkStrata &strata)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FStrata[i] == strata) break;
    }
    if(i==FSize) return false;
    if(FStrata[i] == strata) {
      for (int j=i;j<FSize-1;j++)
        FStrata[j] = FStrata[j+1];
    }
    FSize--;
    FStrata[FSize] = NullStrata;
    return true;
}

bool MkStratum::Delete(int index)
{
    for (int j=index;j<FSize-1;j++)
        FStrata[j] = FStrata[j+1];

    FSize--;
    FStrata[FSize] = NullStrata;
    return true;
}

bool MkStratum::Clear()
{
   FSize = 0;
   if (FStrata) {
      delete[] FStrata;
      FStrata = NULL;
   }
   return true;
}

MkStrata & MkStratum::operator[](int i)
{
    if (0<=i && i<FSize) return FStrata[i];
    else if(FSize<=i && i<FSizeOfArray) {
      FSize=i+1;
      return FStrata[i];
    }
    else if (FSizeOfArray <= i) {
      Grow(i-FSizeOfArray+5);
      return NullStrata;
    }
    else return NullStrata;
}

MkStratum & MkStratum::operator=(MkStratum &stratum)
{
    int i;

    Clear();
    FSize = stratum.FSize;
    FSizeOfArray = stratum.FSizeOfArray;

    if (FSizeOfArray == 0) {
       FStrata = NULL;
       return *this;
    }
    this->FStrata = new MkStrata[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FStrata[i] = stratum.FStrata[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FStrata[i] = NullStrata;

    return *this;
}

bool MkStratum::operator==(MkStratum &stratum)
{
    int i;

    if (FSize != stratum.FSize) return false;
    for (i=0;i<FSize;i++)
      if (this->FStrata[i] != stratum.FStrata[i]) return false;

    return true;
}

#ifdef __BCPLUSPLUS__
void MkStratum::Draw(TObject *Sender)
{
    TColor C;
    float Offset;
    if (FSize == 0) return;
    if (String(Sender->ClassName()) == String("MkPaintBox")) {
       MkPaintBox *pb=(MkPaintBox*)Sender;
       C = pb->Canvas->Pen->Color;
       pb->Canvas->Pen->Color = Color;
       for (int i = 0; i < FSize;i++) {
           Offset = pb->Offset(3);
           FStrata[i].Draw(pb);
       }
       pb->Canvas->Pen->Color = C;
    }
}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void MkStratum::Draw(MkPaint *pb)
{

}
#endif
//---------------------------------------------------------------------------
MkLayer::MkLayer()
{
  Number=0;
#ifdef __BCPLUSPLUS__
  Name=" ";
#else
  memset(Name,'\0',255);
#endif

  WetUnitWeight[0]=0;
  SubUnitWeight[0]=0;
  Cohesion[0]=0;
  Friction[0]=0;
  HorSubReact[0]=0;
  VerSubReact[0]=0;
  WetUnitWeight[1]=0;
  SubUnitWeight[1]=0;
  Cohesion[1]=0;
  Friction[1]=0;
  HorSubReact[1]=0;
  VerSubReact[1]=0;
  Burden=0;
  K0 = 1;
  Ka = 0;
  Kp = 0;
}

MkLayer::MkLayer(int n)
{
  Number=0;
#ifdef __BCPLUSPLUS__
  Name=" ";
#else
  memset(Name,'\0',255);
#endif

  WetUnitWeight[0]=0;
  SubUnitWeight[0]=0;
  Cohesion[0]     =0;
  Friction[0]     =0;
  HorSubReact[0]  =0;
  VerSubReact[0]  =0;
  WetUnitWeight[1]=0;
  SubUnitWeight[1]=0;
  Cohesion[1]     =0;
  Friction[1]     =0;
  HorSubReact[1]  =0;
  VerSubReact[1]  =0;
  Burden          =0;
  K0=1;
  Ka = 0;
  Kp = 0;
}
#ifdef __BCPLUSPLUS__
bool MkLayer::UpdateFrom()
{
  if(!Grid) return false;

  Number          =Grid->Cells[1][0].ToInt();
  Name            =Grid->Cells[1][1];
  WetUnitWeight[0]=Grid->Cells[1][2].ToDouble();
  SubUnitWeight[0]=Grid->Cells[1][3].ToDouble();
  Cohesion[0]     =Grid->Cells[1][4].ToDouble();
  Friction[0]     =Grid->Cells[1][5].ToDouble();
  HorSubReact[0]  =Grid->Cells[1][6].ToDouble();
  VerSubReact[0]  =Grid->Cells[1][7].ToDouble();
  WetUnitWeight[1]=Grid->Cells[1][8].ToDouble();
  SubUnitWeight[1]=Grid->Cells[1][9].ToDouble();
  Cohesion[1]     =Grid->Cells[1][10].ToDouble();
  Friction[1]     =Grid->Cells[1][11].ToDouble();
  HorSubReact[1]  =Grid->Cells[1][12].ToDouble();
  VerSubReact[1]  =Grid->Cells[1][13].ToDouble();

  return true;
}

bool MkLayer::UpdateTo()
{
  if(!Grid) return false;

  for(int i=0;i<20;i++) {Grid->Cells[0][i] = "";Grid->Cells[1][i]="";}

  Grid->Cells[0][0] =  "Number";
  Grid->Cells[0][1] =  "Name";
  Grid->Cells[0][2] =  "WetUnitWeight[0]";
  Grid->Cells[0][3] =  "SubUnitWeight[0]";
  Grid->Cells[0][4] =  "Cohesion[0]";
  Grid->Cells[0][5] =  "Friction[0]";
  Grid->Cells[0][6] =  "HorSubReact[0]";
  Grid->Cells[0][7] =  "VerSubReact[0]";
  Grid->Cells[0][8] =  "WetUnitWeight[1]";
  Grid->Cells[0][9] =  "SubUnitWeight[1]";
  Grid->Cells[0][10] = "Cohesion[1]";
  Grid->Cells[0][11] = "Friction[1]";
  Grid->Cells[0][12] = "HorSubReact[1]";
  Grid->Cells[0][13] = "VerSubReact[1]";

  Grid->Cells[1][0] =  Number;
  Grid->Cells[1][1] =  Name;
  Grid->Cells[1][2] =  WetUnitWeight[0];
  Grid->Cells[1][3] =  SubUnitWeight[0];
  Grid->Cells[1][4] =  Cohesion[0];
  Grid->Cells[1][5] =  Friction[0];
  Grid->Cells[1][6] =  HorSubReact[0];
  Grid->Cells[1][7] =  VerSubReact[0];
  Grid->Cells[1][8] =  WetUnitWeight[1];
  Grid->Cells[1][9] =  SubUnitWeight[1];
  Grid->Cells[1][10] = Cohesion[1];
  Grid->Cells[1][11] = Friction[1];
  Grid->Cells[1][12] = HorSubReact[1];
  Grid->Cells[1][13] = VerSubReact[1];

  return true;
}
#endif

float MkLayer::GetActivPress(MkPoint &pnt)
{
  if(!IsIn(pnt)) return -1;
  float y,ymax,p,t;
  float f,c;

  ymax = max(Rect.GetOrigin().Y,Rect.GetOrigin().Y+Rect.GetHeight());
  y = ymax - pnt.Y;
  f = Friction[0]+(Friction[1]-Friction[0])*y/Rect.GetHeight();
  c = Cohesion[0]+(Cohesion[1]-Cohesion[0])*y/Rect.GetHeight();

  if(Ka>0&&Kp>0) {
    p = (WetUnitWeight[0]*y+(WetUnitWeight[1]-WetUnitWeight[0])*y*y/2/Rect.GetHeight()+Burden);
    assert(Ka>0);
    return p*Ka-2*c*sqrt(Ka);
  }
  else {
    t = tan((45-f/2)*M_PI/180.0);
    p = (WetUnitWeight[0]*y+(WetUnitWeight[1]-WetUnitWeight[0])*y*y/2/Rect.GetHeight()+Burden)*K0;
    return p*t*t-2*c*t;
  }
}

float MkLayer::GetPassivPress(MkPoint &pnt)
{
  if(!IsIn(pnt)) return -1;
  float y,ymax,p,t;
  float f,c;

  ymax = max(Rect.GetOrigin().Y,Rect.GetOrigin().Y+Rect.GetHeight());
  y = ymax - pnt.Y;

  f = Friction[0]+(Friction[1]-Friction[0])*y/Rect.GetHeight();
  c = Cohesion[0]+(Cohesion[1]-Cohesion[0])*y/Rect.GetHeight();

  if(Ka>0&&Kp>0) {
    p = (WetUnitWeight[0]*y+(WetUnitWeight[1]-WetUnitWeight[0])*y*y/2/Rect.GetHeight()+Burden);
    assert(Kp>0);
    return p*Kp+2*c*sqrt(Kp);
  }
  else {
    t = tan((45+f/2)*M_PI/180.0);
    p = (WetUnitWeight[0]*y+(WetUnitWeight[1]-WetUnitWeight[0])*y*y/2/Rect.GetHeight()+Burden)*K0;
    return p*t*t+2*c*t;
  }
}

float MkLayer::GetStopPress(MkPoint &pnt)
{
  if(!IsIn(pnt)) return -1;
  float ymax,y;
  ymax = max(Rect.GetOrigin().Y,Rect.GetOrigin().Y+Rect.GetHeight());
  y = ymax - pnt.Y;
  return (WetUnitWeight[0]*y+(WetUnitWeight[1]-WetUnitWeight[0])*y*y/2/Rect.GetHeight()+Burden)*K0;
}

float MkLayer::GetWetUnitWeight(MkPoint &pnt)
{
  if(!IsIn(pnt)) return -1;
  float ymax,y,value;
  ymax = max(Rect.GetOrigin().Y,Rect.GetOrigin().Y+Rect.GetHeight());
  y = ymax - pnt.Y;
  value = (WetUnitWeight[1]-WetUnitWeight[0])*y/Rect.GetHeight()+WetUnitWeight[0];
  return value;
}

float MkLayer::GetCohesion(MkPoint &pnt)
{
  if(!IsIn(pnt)) return -1;
  float ymax,y;
  ymax = max(Rect.GetOrigin().Y,Rect.GetOrigin().Y+Rect.GetHeight());
  y = ymax - pnt.Y;
  return (Cohesion[1]-Cohesion[0])*y/Rect.GetHeight()+Cohesion[0];
}

float MkLayer::GetFriction(MkPoint &pnt)
{
  if(!IsIn(pnt)) return -1;
  float ymax,y;
  ymax = max(Rect.GetOrigin().Y,Rect.GetOrigin().Y+Rect.GetHeight());
  y = ymax - pnt.Y;
  return (Friction[1]-Friction[0])*y/Rect.GetHeight()+Friction[0];
}

float MkLayer::GetHorSubReact(MkPoint &pnt)
{
  if(!IsIn(pnt)) return -1;
  float ymax,y;
  ymax = max(Rect.GetOrigin().Y,Rect.GetOrigin().Y+Rect.GetHeight());
  y = ymax - pnt.Y;
  return (HorSubReact[1]-HorSubReact[0])*y/Rect.GetHeight()+HorSubReact[0];
}

float MkLayer::GetVerSubReact(MkPoint &pnt)
{
  if(!IsIn(pnt)) return -1;
  float ymax,y;
  ymax = max(Rect.GetOrigin().Y,Rect.GetOrigin().Y+Rect.GetHeight());
  y = ymax - pnt.Y;
  return (VerSubReact[1]-VerSubReact[0])*y/Rect.GetHeight()+VerSubReact[0];
}

float MkLayer::GetK0(MkPoint &pnt)
{
  if(!IsIn(pnt)) return -1;
  return K0;
}

float MkLayer::GetKa(MkPoint &pnt)
{
  if(!IsIn(pnt)) return -1;
  return Ka;
}

float MkLayer::GetKp(MkPoint &pnt)
{
  if(!IsIn(pnt)) return -1;
  return Kp;
}

float MkLayer::GetWetUnitWeight(MkLine &line)
{
  if(InLen(line)<0.0001) return -1;
  MkLine l=InLine(line);

  float uw,lw;
  uw = GetWetUnitWeight(l[1]);
  lw = GetWetUnitWeight(l[0]);

  return (uw+lw)/2;
}

float MkLayer::GetCohesion(MkLine &line)
{
  if(InLen(line)<0.0001) return -1;
  MkLine l=InLine(line);

  return (GetCohesion(l[1])+GetCohesion(l[0]))/2;
}

float MkLayer::GetFriction(MkLine &line)
{
  if(InLen(line)<0.0001) return -1;
  MkLine l=InLine(line);

  return (GetFriction(l[1])+GetFriction(l[0]))/2;
}

float MkLayer::GetHorSubReact(MkLine &line)
{
  if(InLen(line)<0.0001) return -1;
  MkLine l=InLine(line);

  return (GetHorSubReact(l[1])+GetHorSubReact(l[0]))*l.GetLength()/2;
}

float MkLayer::GetVerSubReact(MkLine &line)
{
  if(InLen(line)<0.0001) return -1;
  MkLine l=InLine(line);

  return (GetVerSubReact(l[1])+GetVerSubReact(l[0]))*l.GetLength()/2;
}

float MkLayer::GetK0(MkLine &line)
{
  if(InLen(line)<0.0001) return -1;
  MkLine l=InLine(line);

  return (GetK0(l[1])+GetK0(l[0]))*l.GetLength()/2;
}

float MkLayer::GetKa(MkLine &line)
{
  if(InLen(line)<0.0001) return -1;
  MkLine l=InLine(line);

  return (GetKa(l[1])+GetKa(l[0]))*l.GetLength()/2;
}

float MkLayer::GetKp(MkLine &line)
{
  if(InLen(line)<0.0001) return -1;
  MkLine l=InLine(line);

  return (GetKp(l[1])+GetKp(l[0]))*l.GetLength()/2;
}

float MkLayer::InLen(MkLine &line)
{
  MkPoints pnts;
  Rect.GetCross(line,pnts);

  if(IsIn(line[0])&&IsIn(line[1])) return line.GetLength();
  if(!pnts.GetSize()) return 0;
  if(pnts.GetSize()==2) return MkLine(pnts[0],pnts[1]).GetLength();
  if(pnts.GetSize()==1 && IsIn(line[0])) return MkLine(line[0],pnts[0]).GetLength();
  if(pnts.GetSize()==1 && IsIn(line[1])) return MkLine(line[1],pnts[0]).GetLength();
  return 0;
}

MkLine MkLayer::InLine(MkLine &line)
{
  MkPoints pnts;
  Rect.GetCross(line,pnts);

  if(IsIn(line[0])&&IsIn(line[1])) return line;
  if(!pnts.GetSize()) return NullLine;
  if(pnts.GetSize()==2) return MkLine(pnts[0],pnts[1]);
  if(pnts.GetSize()==1 && IsIn(line[0])) return MkLine(line[0],pnts[0]);
  if(pnts.GetSize()==1 && IsIn(line[1])) return MkLine(line[1],pnts[0]);
  return NullLine;
}

void MkLayer::CalcCoeff()  // need to be update to consider variation in a layer
{
  K0 = 1-sin(Friction[0]*3.141592/180.0);
  Ka = (1+sin(Friction[0]*3.141592/180.0))/(1-sin(Friction[0]*3.141592/180.0));
  Kp = (1-sin(Friction[0]*3.141592/180.0))/(1+sin(Friction[0]*3.141592/180.0));
}

#ifdef __BCPLUSPLUS__
void MkLayer::Out(TObject *)
{

}
#endif

void MkLayer::Out(char *fname)
{
  FILE *fp;
  fp = fopen(fname,"a");
  if(!fp) {
    MkDebug(fname); MkDebug(" is not found, so fp is null and return false\n");
    return ;
  }
            //12345678901234567890123456789012345678901234567890123456789012345678901234567890
//fprintf(fp,"  Layer  G.L.    rt     rsub Cohesion  Friction    Ks\n");
//fprintf(fp,"   No.   (m)   (t/m3)  (t/m3) (t/m2)   (degree)  (t/m3)\n");
  fprintf(fp,"  %3d Top:%5.2f %5.2f  %5.2f   %5.2f     %5.2f    %10.3f\n",Number,Rect.GetTop(),WetUnitWeight[0]*MPa2Tonf,SubUnitWeight[0]*MPa2Tonf,Cohesion[0]*MPa2Tonf,Friction[0],HorSubReact[0]*MPa2Tonf);
  fprintf(fp,"      Bot:%5.2f %5.2f  %5.2f   %5.2f     %5.2f    %10.3f\n",       Rect.GetBot(),WetUnitWeight[1]*MPa2Tonf,SubUnitWeight[1]*MPa2Tonf,Cohesion[1]*MPa2Tonf,Friction[1],HorSubReact[1]*MPa2Tonf);
  fprintf(fp,"\n");
  fclose(fp);
}

bool MkLayer::operator==(MkLayer& lay)
{
  bool flag;
  flag = MkEntity::operator==((MkEntity &)lay);
  flag = flag && Rect == lay.Rect;
  flag = flag && WetUnitWeight[0] == lay.WetUnitWeight[0];
  flag = flag && SubUnitWeight[0] == lay.SubUnitWeight[0];
  flag = flag && Cohesion[0] == lay.Cohesion[0];
  flag = flag && Friction[0] == lay.Friction[0];
  flag = flag && HorSubReact[0] == lay.HorSubReact[0];
  flag = flag && VerSubReact[0] == lay.VerSubReact[0];
  flag = flag && WetUnitWeight[1] == lay.WetUnitWeight[1];
  flag = flag && SubUnitWeight[1] == lay.SubUnitWeight[1];
  flag = flag && Cohesion[1] == lay.Cohesion[1];
  flag = flag && Friction[1] == lay.Friction[1];
  flag = flag && HorSubReact[1] == lay.HorSubReact[1];
  flag = flag && VerSubReact[1] == lay.VerSubReact[1];
  flag = flag && Burden == lay.Burden;
  flag = flag && K0 == lay.K0;
  flag = flag && Ka == lay.Ka;
  flag = flag && Kp == lay.Kp;
  return flag;
}

bool MkLayer::operator!=(MkLayer& lay)
{
  return !operator==(lay);
}

MkLayer & MkLayer::operator=(MkLayer &lay)
{
  MkEntity::operator=((MkEntity &)lay);
  Rect = lay.Rect;
  WetUnitWeight[0] = lay.WetUnitWeight[0];
  SubUnitWeight[0] = lay.SubUnitWeight[0];
  Cohesion[0] = lay.Cohesion[0];
  Friction[0] = lay.Friction[0];
  HorSubReact[0] = lay.HorSubReact[0];
  VerSubReact[0] = lay.VerSubReact[0];
  WetUnitWeight[1] = lay.WetUnitWeight[1];
  SubUnitWeight[1] = lay.SubUnitWeight[1];
  Cohesion[1] = lay.Cohesion[1];
  Friction[1] = lay.Friction[1];
  HorSubReact[1] = lay.HorSubReact[1];
  VerSubReact[1] = lay.VerSubReact[1];
  Burden = lay.Burden;
  K0 = lay.K0;
  Ka = lay.Ka;
  Kp = lay.Kp;
  return *this;
}

#ifdef __BCPLUSPLUS__
void  MkLayer::Draw(TObject *Sender)
{

}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void  MkLayer::Draw(MkPaint *pb)
{

}
#endif
//---------------------------------------------------------------------------
MkLayers::MkLayers(int size,MkLayer *layers)
{
    if (size < 0) {
      MkDebug("::MkLayers - MkLayers (int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSizeOfArray == 0) {
       FLayer= NULL;
       return;
    }

    FLayer= new MkLayer[FSizeOfArray];
    for (int i=0;i<FSizeOfArray;i++) (*this)[i] = layers[i];
}

MkLayers::MkLayers(int size)
{
    if (size < 0) {
      MkDebug("::MkLayers - MkLayers (int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSizeOfArray == 0) {
       FLayer= NULL;
       return;
    }

    FLayer= new MkLayer[FSizeOfArray];
}

MkLayers::~MkLayers()
{
   FSizeOfArray = FSize = 0;
   if (FLayer) {
      delete[] FLayer;
      FLayer = NULL;
   }
}

void MkLayers::SetupPress()
{
  float burden,xm,ym,xmin,ymin,xmax,ymax;
  for(int i=0;i<FSize;i++) {
    MkRect &rect = FLayer[i].GetRect();
    burden = 0;
    xmin = min(rect.GetOrigin().X,rect.GetOrigin().X+rect.GetWidth());
    xmax = max(rect.GetOrigin().X,rect.GetOrigin().X+rect.GetWidth());
    ymin = min(rect.GetOrigin().Y,rect.GetOrigin().Y+rect.GetHeight());
    ymax = max(rect.GetOrigin().Y,rect.GetOrigin().Y+rect.GetHeight());

    for(int j=0;j<FSize;j++) {
      MkRect &rec = FLayer[j].GetRect();
      xm = rec.GetOrigin().X+rec.GetWidth()/2.0;
      ym = rec.GetOrigin().Y+rec.GetHeight()/2.0;
      if((xmin<xm&&xm<xmax)&&(ymax<ym))
        burden+=FLayer[j].GetWetUnitWeight(rec.GetOrigin());// should be reimplemented.2004.08.09
    }
    FLayer[i].SetBurden(burden);
  }
}

void MkLayers::Initialize(int size)
{
    int i;
    if (size < 0) {
      MkDebug("::MkLayers - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray== size) return;

    FSizeOfArray= FSize=size;

    if (FSizeOfArray== 0) {
       if (FLayer!=NULL) delete[] (MkLayer*)FLayer;
       FLayer = NULL;
       return;
    }

    if (FLayer!=NULL) delete[] (MkLayer*)FLayer;
    FLayer = new MkLayer[FSizeOfArray];
    for (i=0;i<FSize;i++) FLayer[i].Number = i;
}

void MkLayers::Initialize(int size,MkLayer *layers)
{
    int i;
    if (size < 0 || layers == NULL) {
      MkDebug("::MkLayers - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSizeOfArray = size;
    FSize = size;

    if (FSizeOfArray== 0) {
       if (FLayer!=NULL) delete[] (MkLayer*)FLayer;
       FLayer = NULL;
       return;
    }

    if (FLayer!=NULL) delete[] (MkLayer*)FLayer;
    FLayer = new MkLayer[FSizeOfArray];
    for (i=0;i<FSizeOfArray;i++) FLayer[i] = layers[i];
    for (i=0;i<FSize;i++) FLayer[i].Number = i;
}

int MkLayers::Grow(int delta)
{
    int i;
    MkLayer *layer=NULL;

    if (!(layer = new MkLayer[FSizeOfArray+delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        layer[i] = FLayer[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        layer[i] = NullLayer;
    if (FLayer) {
       delete[] (MkLayer*)FLayer;
       FLayer = NULL;
    }
    FLayer = layer;
    FSizeOfArray = FSizeOfArray+delta;
    return FSizeOfArray;
}

int MkLayers::Shrink(int delta)
{
    int i;
    MkLayer *layer=NULL;

    if (!(layer = new MkLayer[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        layer[i] = FLayer[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        layer[i] = NullLayer;
    if (FLayer) {
       delete[] (MkLayer*)FLayer;
       FLayer = NULL;
    }
    FLayer = layer;
    FSizeOfArray = FSizeOfArray-delta;
    return FSizeOfArray;
}

bool MkLayers::Add(MkLayer &layer)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }
    
    FSize++;
    FLayer[FSize-1] = layer;
    return true;
}

bool MkLayers::Add(int index, MkLayer &layer)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    for (int i=FSize-1;i>=index;i--)
      FLayer[i+1] = FLayer[i];
    FSize++;
    FLayer[index] = layer;
    return true;
}

bool MkLayers::Delete(MkLayer &layer)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FLayer[i] == layer) break;
    }
    if(i==FSize) return false;
    if(FLayer[i] == layer) {
      for (int j=i;j<FSize-1;j++)
        FLayer[j] = FLayer[j+1];
    }
    FSize--;
    FLayer[FSize] = NullLayer;
    return true;
}

bool MkLayers::Delete(int index)
{
    for (int j=index;j<FSize-1;j++)
        FLayer[j] = FLayer[j+1];

    FSize--;
    FLayer[FSize] = NullLayer;
    return true;
}

bool MkLayers::Clear()
{
   FSize = 0;
   if (FLayer) {
      delete[] FLayer;
      FLayer = NULL;
   }
   return true;
}

bool MkLayers::Apply(MkCut &cut)
{
  return false;
}

bool MkLayers::Apply(MkFill &fill)
{
  return false;
}

MkLayer & MkLayers::operator[](int i)
{
    if (0<=i && i<FSize) return FLayer[i];
    else if(FSize<=i && i<FSizeOfArray) {
      FSize=i+1;
      return FLayer[i];
    }
    else if (FSizeOfArray <= i) {
      Grow(i-FSizeOfArray+5);
      return NullLayer;
    }
    else return NullLayer;
}

MkLayers & MkLayers::operator=(MkLayers &layers)
{
    int i;

    Clear();
    FSize = layers.FSize;
    FSizeOfArray = layers.FSizeOfArray;

    if (FSizeOfArray == 0) {
       FLayer = NULL;
       return *this;
    }
    this->FLayer = new MkLayer[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FLayer[i] = layers.FLayer[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FLayer[i] = NullLayer;


    return *this;
}

bool MkLayers::operator==(MkLayers &layers)
{
    int i;

    if (FSize != layers.FSize) return false;
    for (i=0;i<FSize;i++)
      if (this->FLayer[i] != layers.FLayer[i]) return false;

    return true;
}

#ifdef __BCPLUSPLUS__
void MkLayers::Out(TObject *Sender)
{

}
#endif

void MkLayers::Out(char *fname)
{
  FILE *fp;
  fp = fopen(fname,"a");
  if(!fp) {
    return;
  }
  if(FSize==0) return;

            //12345678901234567890123456789012345678901234567890123456789012345678901234567890
  fprintf(fp,"\n");
  fprintf(fp,"                           <Information of Layers>\n");
  fprintf(fp,"\n");
  fprintf(fp,"  Layer  G.L.  rt    rsub    Cohesion    Friction    Ks\n");
  fprintf(fp,"   No.   (m) (t/m3) (t/m3)    (t/m2)     (degree)  (t/m3)\n");
  fclose(fp);

  for(int i=0;i<FSize;i++)
    FLayer[i].Out(fname);
}

#ifdef __BCPLUSPLUS__
void MkLayers::Draw(TObject *Sender)
{
    TColor C;
    float Offset;
    if (FSize == 0) return;
    if (String(Sender->ClassName()) == String("MkPaintBox")) {
       MkPaintBox *pb=(MkPaintBox*)Sender;
       C = pb->Canvas->Pen->Color;
       pb->Canvas->Pen->Color = Color;
       for (int i = 0; i < FSize;i++) {
           Offset = pb->Offset(3);
           FLayer[i].Draw(pb);
       }
       pb->Canvas->Pen->Color = C;
    }
}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void MkLayers::Draw(MkPaint *pb)
{

}
#endif

//---------------------------------------------------------------------------

MkCut::MkCut()
{
  Depth=0;
  Wall[0]=NULL;
  Wall[1]=NULL;
}

MkCut::MkCut(int n)
{
  Depth=0;
  Wall[0]=NULL;
  Wall[1]=NULL;
}
#ifdef __BCPLUSPLUS__
bool MkCut::UpdateFrom()
{
  if(!Grid) return false;

  Number          =Grid->Cells[1][0].ToInt();
  Depth     =Grid->Cells[1][1].ToDouble();

  return true;
}
bool MkCut::UpdateTo()
{
  if(!Grid) return false;

  Grid->Cells[0][0] = "Number";
  Grid->Cells[0][1] = "Ground Level";

  Grid->Cells[1][0] = Number;
  Grid->Cells[1][1] = Depth;

  return true;
}

void MkCut::Out(TObject *Sender)
{

}
#endif

void MkCut::Out(char *fname)
{
  FILE *fp;
  fp = fopen(fname,"a");
  if(!fp) {
    MkDebug(fname); MkDebug(" is not found, so fp is null and return false\n");
    return;
  }
            //12345678901234567890123456789012345678901234567890123456789012345678901234567890
//fprintf(fp,"  Cut    G.L.\n");
//fprintf(fp,"  No.   (m) \n");
  fprintf(fp,"  %3d   %5.2f\n",Number,Depth);
  fclose(fp);
}

bool MkCut::operator==(MkCut &cut)
{
  return Depth==cut.Depth && *Wall[0] == *cut.Wall[0] && *Wall[1] == *cut.Wall[1];

}
bool MkCut::operator!=(MkCut &cut)
{
  return !operator==(cut);
}

MkCut& MkCut::operator=(MkCut& cut)
{
  Depth = cut.Depth;
  Wall[0] = cut.Wall[0];
  Wall[1] = cut.Wall[1];
  return *this;
}

#ifdef __BCPLUSPLUS__
void  MkCut::Draw(TObject *Sender)
{

}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void  MkCut::Draw(MkPaint *pb)
{

}
#endif
//---------------------------------------------------------------------------
MkCuts::MkCuts(int size,MkCut *cuts)
{
    if (size < 0) {
      MkDebug("::MkCuts - MkCuts(int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSize == 0) {
       FCut = NULL;
       return;
    }

    FCut = new MkCut[FSize];
    for (int i=0;i<FSize;i++) (*this)[i] = cuts[i];
}

MkCuts::MkCuts(int size)
{
    if (size < 0) {
      MkDebug("::MkCuts - MkCuts(int size)");;
      return;
    }

    FSizeOfArray = size;
    FSize = 0;
    if (FSizeOfArray == 0) {
       FCut = NULL;
       return;
    }

    FCut = new MkCut[FSizeOfArray];
}

MkCuts::~MkCuts()
{
   FSizeOfArray = FSize = 0;
   if (FCut) {
      delete[] FCut;
      FCut = NULL;
   }
}

void MkCuts::Initialize(int size)
{
    int i;
    if (size < 0) {
      MkDebug("::MkCuts - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;

    FSizeOfArray = FSize =size;

    if (FSizeOfArray == 0) {
       if (FCut!=NULL) delete[] (MkCut*)FCut;
       FCut = NULL;
       return;
    }

    if (FCut!=NULL) delete[] (MkCut*)FCut;
    FCut = new MkCut[FSizeOfArray];
    for (i=0;i<FSize;i++) FCut[i].Number = i;
}

void MkCuts::Initialize(int size,MkCut *cuts)
{
    int i;
    if (size < 0 || cuts == NULL) {
      MkDebug("::MkCuts - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSize = FSizeOfArray = size;
    if (FSizeOfArray == 0) {
       if (FCut!=NULL) delete[] (MkCut*)FCut;
       FCut = NULL;
       return;
    }

    if (FCut!=NULL) delete[] (MkCut*)FCut;
    FCut = new MkCut[FSizeOfArray];
    for (i=0;i<FSizeOfArray;i++) FCut[i] = cuts[i];
    for (i=0;i<FSize;i++) FCut[i].Number = i;
}

int MkCuts::Grow(int delta)
{
    int i;
    MkCut *cut=NULL;

	cut = new MkCut[FSizeOfArray+delta];
    if (!(cut)) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        cut[i] = FCut[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        cut[i] = NullCut;
    if (FCut) {
       delete[] (MkCut*)FCut;
       FCut = NULL;
    }
    FCut = cut;
    FSizeOfArray = FSizeOfArray+delta;
    return FSizeOfArray;
}

int MkCuts::Shrink(int delta)
{
    int i;
    MkCut *cut=NULL;

    if (!(cut = new MkCut[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        cut[i] = FCut[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        cut[i] = NullCut;
    if (FCut) {
       delete[] (MkCut*)FCut;
       FCut = NULL;
    }
    FCut = cut;
    FSizeOfArray = FSizeOfArray-delta;
    return FSizeOfArray;
}

bool MkCuts::Add(MkCut &cut)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    FSize++;
    FCut[FSize-1] = cut;
    return true;
}

bool MkCuts::Add(int index, MkCut &cut)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    for (int i=FSize-1;i>=index;i--)
      FCut[i+1] = FCut[i];
    FSize++;
    FCut[index] = cut;
    return true;
}

bool MkCuts::Delete(MkCut &cut)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FCut[i] == cut) break;
    }
    if(i==FSize) return false;
    if(FCut[i] == cut) {
      for (int j=i;j<FSize-1;j++)
        FCut[j] = FCut[j+1];
    }
    FSize--;
    FCut[FSize] = NullCut;
    return true;
}

bool MkCuts::Delete(int index)
{
    for (int j=index;j<FSize-1;j++)
        FCut[j] = FCut[j+1];

    FSize--;
    FCut[FSize] = NullCut;
    return true;
}

bool MkCuts::Clear()
{
   FSizeOfArray = FSize = 0;
   if (FCut) {
      delete[] FCut;
      FCut = NULL;
   }
   return true;
}

void MkCuts::Out(char *fname)
{
  FILE *fp;
  fp = fopen(fname,"a");
  if(!fp) {
    return;
  }

  if(FSize==0) return;
    
            //12345678901234567890123456789012345678901234567890123456789012345678901234567890
  fprintf(fp,"\n");
  fprintf(fp,"                           <Information of Cut Stage>\n");
  fprintf(fp,"\n");
  fprintf(fp,"  Cut    G.L.\n");
  fprintf(fp,"  No.   (m) \n");
  fclose(fp);

  for(int i=0;i<FSize;i++) 
    FCut[i].Out(fname);
}

MkCut & MkCuts::operator[](int i)
{
    if (0<=i && i<FSize) return FCut[i];
    else if(FSize<=i && i<FSizeOfArray) {
      FSize=i+1;
      return FCut[i];
    }
    else if (FSizeOfArray <= i) {
      Grow(i-FSizeOfArray+5);
      return NullCut;
    }
    else return NullCut;
}

MkCuts & MkCuts::operator=(MkCuts &cuts)
{
    int i;

    Clear();
    FSize = cuts.FSize;
    FSizeOfArray = cuts.FSizeOfArray;
    if (FSizeOfArray == 0) {
       FCut = NULL;
       return *this;
    }
    this->FCut = new MkCut[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FCut[i] = cuts.FCut[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FCut[i] = NullCut;

    return *this;
}

bool MkCuts::operator==(MkCuts &cuts)
{
    int i;

    if (FSize != cuts.FSize) return false;
    for (i=0;i<FSize;i++)
      if (this->FCut[i] != cuts.FCut[i]) return false;

    return true;
}

#ifdef __BCPLUSPLUS__
void MkCuts::Draw(TObject *Sender)
{
    TColor C;
    float Offset;
    if (FSize == 0) return;
    if (String(Sender->ClassName()) == String("MkPaintBox")) {
       MkPaintBox *pb=(MkPaintBox*)Sender;
       C = pb->Canvas->Pen->Color;
       pb->Canvas->Pen->Color = Color;
       for (int i = 0; i < FSize;i++) {
           Offset = pb->Offset(3);
           FCut[i].Draw(pb);
       }
       pb->Canvas->Pen->Color = C;
    }
}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void  MkCuts::Draw(MkPaint *pb)
{

}
#endif

//---------------------------------------------------------------------------
MkFill::MkFill()
{
  Depth=0;
  Wall[0]=NULL;
  Wall[1]=NULL;
}

MkFill::MkFill(int n)
{
  Depth=0;
  Wall[0]=NULL;
  Wall[1]=NULL;
}
#ifdef __BCPLUSPLUS__
bool MkFill::UpdateFrom()
{
  if(!Grid) return false;

  Number = Grid->Cells[1][0].ToInt();
  Depth  = Grid->Cells[1][1].ToDouble();

  return true;
}
bool MkFill::UpdateTo()
{
  if(!Grid) return false;

  Grid->Cells[0][0] = "Number";
  Grid->Cells[0][1] = "Ground Level";

  Grid->Cells[1][0] = Number;
  Grid->Cells[1][1] = Depth;

  return true;
}


void MkFill::Out(TObject *Sender)
{
}
#else

#endif

void MkFill::Out(char *fname)
{
  FILE *fp;
  fp = fopen(fname,"a");
  if(!fp) {
    MkDebug(fname); MkDebug(" is not found, so fp is null and return false\n");
    return ;
  }
            //12345678901234567890123456789012345678901234567890123456789012345678901234567890
//fprintf(fp,"  Fill    G.L.\n");
//fprintf(fp,"   No.   (m) \n");
  fprintf(fp,"  %3d   %5.2f\n",Number,Depth);
  fclose(fp);
}

bool MkFill::operator==(MkFill &fill)
{
  return Depth==fill.Depth && *Wall[0] == *fill.Wall[0] && *Wall[1] == *fill.Wall[1];
}
bool MkFill::operator!=(MkFill &fill)
{
  return !operator==(fill);
}

MkFill& MkFill::operator=(MkFill& fill)
{
  Depth = fill.Depth;
  Wall[0] = fill.Wall[0];
  Wall[1] = fill.Wall[1];
  return *this;
}

#ifdef __BCPLUSPLUS__
void  MkFill::Draw(TObject *Sender)
{

}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void  MkFill::Draw(MkPaint *pb)
{

}
#endif
//---------------------------------------------------------------------------
MkFills::MkFills(int size,MkFill *fills)
{
    if (size < 0) {
      MkDebug("::MkFills - MkFills(int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSize == 0) {
       FFill = NULL;
       return;
    }

    FFill = new MkFill[FSize];
    for (int i=0;i<FSize;i++) (*this)[i] = fills[i];
}

MkFills::MkFills(int size)
{
    if (size < 0) {
      MkDebug("::MkFills - MkFills(int size)");;
      return;
    }

    FSizeOfArray = size;
    FSize = 0;
    if (FSizeOfArray == 0) {
       FFill = NULL;
       return;
    }

    FFill = new MkFill[FSizeOfArray];
}

MkFills::~MkFills()
{
   FSizeOfArray = FSize = 0;
   if (FFill) {
      delete[] FFill;
      FFill = NULL;
   }
}

void MkFills::Initialize(int size)
{
    int i;
    if (size < 0) {
      MkDebug("::MkFills - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;

    FSizeOfArray = FSize = size;

    if (FSizeOfArray == 0) {
       if (FFill!=NULL) delete[] (MkFill*)FFill;
       FFill = NULL;
       return;
    }

    if (FFill!=NULL) delete[] (MkFill*)FFill;
    FFill = new MkFill[FSizeOfArray];
    for (i=0;i<FSize;i++) FFill[i].Number = i;
}

void MkFills::Initialize(int size,MkFill *fills)
{
    int i;
    if (size < 0 || fills == NULL) {
      MkDebug("::MkFills - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSize = FSizeOfArray = size;
    if (FSizeOfArray == 0) {
       if (FFill!=NULL) delete[] (MkFill*)FFill;
       FFill = NULL;
       return;
    }

    if (FFill!=NULL) delete[] (MkFill*)FFill;
    FFill = new MkFill[FSizeOfArray];
    for (i=0;i<FSizeOfArray;i++) FFill[i] = fills[i];
    for (i=0;i<FSize;i++) FFill[i].Number = i;
}

int MkFills::Grow(int delta)
{
    int i;
    MkFill *fill=NULL;

    if (!(fill = new MkFill[FSizeOfArray+delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        fill[i] = FFill[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        fill[i] = NullFill;
    if (FFill) {
       delete[] (MkFill*)FFill;
       FFill = NULL;
    }
    FFill = fill;
    FSizeOfArray = FSizeOfArray+delta;
    return FSizeOfArray;
}

int MkFills::Shrink(int delta)
{
    int i;
    MkFill *fill=NULL;

    if (!(fill = new MkFill[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        fill[i] = FFill[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        fill[i] = NullFill;
    if (FFill) {
       delete[] (MkFill*)FFill;
       FFill = NULL;
    }
    FFill = fill;
    FSizeOfArray = FSizeOfArray-delta;
    return FSizeOfArray;
}

bool MkFills::Add(MkFill &fill)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    FSize++;
    FFill[FSize-1] = fill;
    return true;
}

bool MkFills::Add(int index, MkFill &fill)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    for (int i=FSize-1;i>=index;i--)
      FFill[i+1] = FFill[i];
    FSize++;
    FFill[index] = fill;
    return true;
}

bool MkFills::Delete(MkFill &fill)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FFill[i] == fill) break;
    }
    if(i==FSize) return false;
    if(FFill[i] == fill) {
      for (int j=i;j<FSize-1;j++)
        FFill[j] = FFill[j+1];
    }
    FSize--;
    FFill[FSize] = NullFill;
    return true;
}

bool MkFills::Delete(int index)
{
    for (int j=index;j<FSize-1;j++)
        FFill[j] = FFill[j+1];

    FSize--;
    FFill[FSize] = NullFill;
    return true;
}

bool MkFills::Clear()
{
   FSizeOfArray = FSize = 0;
   if (FFill) {
      delete[] FFill;
      FFill = NULL;
   }
   return true;
}

void MkFills::Out(char *fname)
{
  FILE *fp;
  fp = fopen(fname,"a");
  if(!fp) {
    return;
  }

  if(FSize==0) return;
    
            //12345678901234567890123456789012345678901234567890123456789012345678901234567890
  fprintf(fp,"\n");
  fprintf(fp,"                           <Information of Fill Stage>\n");
  fprintf(fp,"\n");
  fprintf(fp,"  Fill    G.L.\n");
  fprintf(fp,"   No.   (m) \n");
  fclose(fp);

  for(int i=0;i<FSize;i++)
    FFill[i].Out(fname);
}

MkFill & MkFills::operator[](int i)
{
    if (0<=i && i<FSize) return FFill[i];
    else if(FSize<=i && i<FSizeOfArray) {
      FSize=i+1;
      return FFill[i];
    }
    else if (FSizeOfArray <= i) {
      Grow(i-FSizeOfArray+5);
      return NullFill;
    }
    else return NullFill;
}

MkFills & MkFills::operator=(MkFills &fills)
{
    int i;

    Clear();
    FSize = fills.FSize;
    FSizeOfArray = fills.FSizeOfArray;
    if (FSizeOfArray == 0) {
       FFill = NULL;
       return *this;
    }
    this->FFill = new MkFill[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FFill[i] = fills.FFill[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FFill[i] = NullFill;

    return *this;
}

bool MkFills::operator==(MkFills &fills)
{
    int i;

    if (FSize != fills.FSize) return false;
    for (i=0;i<FSize;i++)
      if (this->FFill[i] != fills.FFill[i]) return false;

    return true;
}

#ifdef __BCPLUSPLUS__
void MkFills::Draw(TObject *Sender)
{
    TColor C;
    float Offset;
    if (FSize == 0) return;
    if (String(Sender->ClassName()) == String("MkPaintBox")) {
       MkPaintBox *pb=(MkPaintBox*)Sender;
       C = pb->Canvas->Pen->Color;
       pb->Canvas->Pen->Color = Color;
       for (int i = 0; i < FSize;i++) {
           Offset = pb->Offset(3);
           FFill[i].Draw(pb);
       }
       pb->Canvas->Pen->Color = C;
    }
}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void  MkFills::Draw(MkPaint *pb)
{

}
#endif

//---------------------------------------------------------------------------
MkPile::MkPile()
{
  Number=0;
  Depth=0;
  Area=0;
  YoungMod=0;
  ShearTor=0;
  SecMomentY=0;
  SecMomentZ=0;
  YieldMom=0;
}

MkPile::MkPile(int n)
{
  Number=0;
  Depth=0;
  Area=0;
  YoungMod=0;
  ShearTor=0;
  SecMomentY=0;
  SecMomentZ=0;
  YieldMom=0;
}
#ifdef __BCPLUSPLUS__
bool MkPile::UpdateFrom()
{
  if(!Grid) return false;

  Number          =Grid->Cells[1][0].ToInt();
  Division        =Grid->Cells[1][1].ToInt();
  Depth           =Grid->Cells[1][2].ToDouble();
  Area            =Grid->Cells[1][3].ToDouble();
  YoungMod        =Grid->Cells[1][4].ToDouble();
  ShearTor        =Grid->Cells[1][5].ToDouble();
  SecMomentY      =Grid->Cells[1][6].ToDouble();
  SecMomentZ      =Grid->Cells[1][7].ToDouble();
  YieldMom        =Grid->Cells[1][8].ToDouble();

  return true;
}
bool MkPile::UpdateTo()
{
  if(!Grid) return false;

  for(int i=0;i<20;i++) {Grid->Cells[0][i] = "";Grid->Cells[1][i]="";}

  Grid->Cells[0][0] = "Number";
  Grid->Cells[0][1] = "Division";
  Grid->Cells[0][2] = "Depth";
  Grid->Cells[0][3] = "Area";
  Grid->Cells[0][4] = "YoungMod";
  Grid->Cells[0][5] = "ShearTor";
  Grid->Cells[0][6] = "SecMomentY";
  Grid->Cells[0][7] = "SecMomentZ";
  Grid->Cells[0][8] = "YieldMom";

  Grid->Cells[1][0] = Number;
  Grid->Cells[1][1] = Division;
  Grid->Cells[1][2] = Depth;
  Grid->Cells[1][3] = Area;
  Grid->Cells[1][4] = YoungMod;
  Grid->Cells[1][5] = ShearTor;
  Grid->Cells[1][6] = SecMomentY;
  Grid->Cells[1][7] = SecMomentZ;
  Grid->Cells[1][8] = YieldMom;

  return true;
}

void MkPile::Out(TObject *Sender)
{

}
#else

#endif

void MkPile::Out(char *fname)
{
  FILE *fp;
  fp = fopen(fname,"a");
  if(!fp) {
    MkDebug(fname); MkDebug(" is not found, so fp is null and return false\n");
    return ;
  }
            //12345678901234567890123456789012345678901234567890123456789012345678901234567890
//fprintf(fp," V-Wall Depth    Area       I        E      Spacing\n");
//fprintf(fp,"   No.   (m)    (m2)      (m4)    (t/m2)     (m)  \n");
  fprintf(fp,"  %3d   %5.2g   %10g %10g %10g %5.2f\n",Number,Depth,Area,SecMomentZ,YoungMod*MPa2Tonf,Spacing);
  fprintf(fp,"               (%10g) (%10g) \n",Area/(Spacing>EPS?Spacing:1),SecMomentZ/(Spacing>EPS?Spacing:1));
  fprintf(fp,"\n");
  fclose(fp);
}

bool MkPile::operator==(MkPile &pile)
{
  bool flag = true;  
  flag == flag && MkWall::operator==((MkWall&)pile);
  flag == flag && Depth==pile.Depth;
  flag == flag && Area==pile.Area;
  flag == flag && YoungMod==pile.YoungMod;
  flag == flag && Spacing==pile.Spacing;
  flag == flag && ShearTor==pile.ShearTor;
  flag == flag && SecMomentY==pile.SecMomentY;
  flag == flag && SecMomentZ==pile.SecMomentZ;
  return flag;
}
bool MkPile::operator!=(MkPile &pile)
{
  return !operator==(pile);
}

MkPile& MkPile::operator=(MkPile& pile)
{
  MkWall::operator=((MkWall&)pile);
  Depth=pile.Depth;
  Area=pile.Area;
  Spacing=pile.Spacing;
  T1=pile.T1;
  T2=pile.T2;
  Weight=pile.Weight;
  Height=pile.Height; // H
  Width=pile.Width;  // B
  YoungMod=pile.YoungMod;
  ShearTor=pile.ShearTor;
  SecMomentY=pile.SecMomentY;
  SecMomentZ=pile.SecMomentZ;

  return *this;
}

#ifdef __BCPLUSPLUS__
void  MkPile::Draw(TObject *Sender)
{
  Wall.Draw(Sender);
}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void  MkPile::Draw(MkPaint *pb)
{
  Wall.Draw(pb);
}
#endif
//---------------------------------------------------------------------------
MkPiles::MkPiles(int size,MkPile *piles)
{
    if (size < 0) {
      MkDebug("::MkPiles - MkPiles(int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSize == 0) {
       FPile = NULL;
       return;
    }

    FPile = new MkPile[FSize];
    for (int i=0;i<FSize;i++) (*this)[i] = piles[i];
}

MkPiles::MkPiles(int size)
{
    if (size < 0) {
      MkDebug("::MkPiles - MkPiles(int size)");;
      return;
    }

    FSizeOfArray = size;
    FSize = 0;
    if (FSizeOfArray == 0) {
       FPile = NULL;
       return;
    }

    FPile = new MkPile[FSizeOfArray];
}

MkPiles::~MkPiles()
{
   FSizeOfArray = FSize = 0;
   if (FPile) {
      delete[] FPile;
      FPile = NULL;
   }
}

void MkPiles::Initialize(int size)
{
    int i;
    if (size < 0) {
      MkDebug("::MkPiles - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;

    FSizeOfArray = FSize =size;

    if (FSizeOfArray == 0) {
       if (FPile!=NULL) delete[] (MkPile*)FPile;
       FPile = NULL;
       return;
    }

    if (FPile!=NULL) delete[] (MkPile*)FPile;
    FPile = new MkPile[FSizeOfArray];
    for (i=0;i<FSize;i++) FPile[i].Number = i;
}

void MkPiles::Initialize(int size,MkPile *piles)
{
    int i;
    if (size < 0 || piles == NULL) {
      MkDebug("::MkPiles - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSize = FSizeOfArray = size;
    if (FSizeOfArray == 0) {
       if (FPile!=NULL) delete[] (MkPile*)FPile;
       FPile = NULL;
       return;
    }

    if (FPile!=NULL) delete[] (MkPile*)FPile;
    FPile = new MkPile[FSizeOfArray];
    for (i=0;i<FSizeOfArray;i++) FPile[i] = piles[i];
    for (i=0;i<FSize;i++) FPile[i].Number = i;
}

int MkPiles::Grow(int delta)
{
    int i;
    MkPile *pile=NULL;

    if (!(pile = new MkPile[FSizeOfArray+delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        pile[i] = FPile[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        pile[i] = NullPile;
    if (FPile) {
       delete[] (MkPile*)FPile;
       FPile = NULL;
    }
    FPile = pile;
    FSizeOfArray = FSizeOfArray+delta;
    return FSizeOfArray;
}

int MkPiles::Shrink(int delta)
{
    int i;
    MkPile *pile=NULL;

    if (!(pile = new MkPile[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        pile[i] = FPile[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        pile[i] = NullPile;
    if (FPile) {
       delete[] (MkPile*)FPile;
       FPile = NULL;
    }
    FPile = pile;
    FSizeOfArray = FSizeOfArray-delta;
    return FSizeOfArray;
}

bool MkPiles::Add(MkPile &pile)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    FSize++;
    FPile[FSize-1] = pile;
    return true;
}

bool MkPiles::Add(int index, MkPile &pile)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    for (int i=FSize-1;i>=index;i--)
      FPile[i+1] = FPile[i];
    FSize++;
    FPile[index] = pile;
    return true;
}

bool MkPiles::Delete(MkPile &pile)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FPile[i] == pile) break;
    }
    if(i==FSize) return false;
    if(FPile[i] == pile) {
      for (int j=i;j<FSize-1;j++)
        FPile[j] = FPile[j+1];
    }
    FSize--;
    FPile[FSize] = NullPile;
    return true;
}

bool MkPiles::Delete(int index)
{
    for (int j=index;j<FSize-1;j++)
        FPile[j] = FPile[j+1];

    FSize--;
    FPile[FSize] = NullPile;
    return true;
}

bool MkPiles::Clear()
{
  char str[256];
  sprintf(str,"FSize of Piles is %d, FSizeOFArray is %d\n",FSize,FSizeOfArray);
  MkDebug(str);
   FSizeOfArray = FSize = 0;
   if (FPile) {
      delete[] FPile;
      FPile = NULL;
   }
  sprintf(str,"FSize of Piles is %d, FSizeOFArray is %d\n",FSize,FSizeOfArray);
  MkDebug(str);
   
   return true;
}

MkPile & MkPiles::operator[](int i)
{
    if (0<=i && i<FSize) return FPile[i];
    else if(FSize<=i && i<FSizeOfArray) {
      FSize=i+1;
      return FPile[i];
    }
    else if (FSizeOfArray <= i) {
      Grow(i-FSizeOfArray+5);
      return NullPile;
    }
    else return NullPile;
}

MkPiles & MkPiles::operator=(MkPiles &piles)
{
    int i;

    Clear();
    FSize = piles.FSize;
    FSizeOfArray = piles.FSizeOfArray;
    if (FSizeOfArray == 0) {
       FPile = NULL;
       return *this;
    }
    this->FPile = new MkPile[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FPile[i] = piles.FPile[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FPile[i] = NullPile;

    return *this;
}

bool MkPiles::operator==(MkPiles &piles)
{
    int i;

    if (FSize != piles.FSize) return false;
    for (i=0;i<FSize;i++)
      if (this->FPile[i] != piles.FPile[i]) return false;

    return true;
}

#ifdef __BCPLUSPLUS__
void MkPiles::Out(TObject *)
{

}
#endif

void MkPiles::Out(char *fname)
{
  FILE *fp;
  fp = fopen(fname,"a");
  if(!fp) {
    return;
  }

  if(FSize==0) return;

            //12345678901234567890123456789012345678901234567890123456789012345678901234567890
  fprintf(fp,"\n");
  fprintf(fp,"                           <Information of Vertical Wall>\n");
  fprintf(fp,"\n");
  fprintf(fp," V-Wall  Depth      Area        I            E     Spacing\n");
  fprintf(fp,"   No.    (m)       (m2)       (m4)        (t/m2)    (m)  \n");
  fclose(fp);

  for(int i=0;i<FSize;i++)
    FPile[i].Out(fname);
}

#ifdef __BCPLUSPLUS__
void MkPiles::Draw(TObject *Sender)
{
    TColor C;
    float Offset;
    if (FSize == 0) return;
    if (String(Sender->ClassName()) == String("MkPaintBox")) {
       MkPaintBox *pb=(MkPaintBox*)Sender;
       C = pb->Canvas->Pen->Color;
       pb->Canvas->Pen->Color = Color;
       for (int i = 0; i < FSize;i++) {
           Offset = pb->Offset(3);
           FPile[i].Draw(pb);
       }
       pb->Canvas->Pen->Color = C;
    }
}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void MkPiles::Draw(MkPaint *pb)
{

}
#endif
//---------------------------------------------------------------------------

MkStrut::MkStrut()
{
  Number=0;
  Depth=0;
  Area=0;
  Length=0;
  Spacing=0;
  JackingForce=0;
  IniDisp=0;
  StressLoss=0;
  RakerAng=0;

}
MkStrut::MkStrut(int n)
{
  Number=0;
  Depth=0;
  Area=0;
  Length=0;
  Spacing=0;
  JackingForce=0;
  IniDisp=0;
  StressLoss=0;
  RakerAng=0;
}
#ifdef __BCPLUSPLUS__
bool MkStrut::UpdateFrom()
{
  if(!Grid) return false;

  Number          = Grid->Cells[1][0].ToInt();
  Depth           = Grid->Cells[1][1].ToDouble();
  Area            = Grid->Cells[1][2].ToDouble();
  Length          = Grid->Cells[1][3].ToDouble();
  Spacing      = Grid->Cells[1][4].ToDouble();
  JackingForce       = Grid->Cells[1][5].ToDouble();
  IniDisp         = Grid->Cells[1][6].ToDouble();
  StressLoss      = Grid->Cells[1][7].ToDouble();
  RakerAng        = Grid->Cells[1][8].ToDouble();

  return true;
}

bool MkStrut::UpdateTo()
{
  if(!Grid) return false;

  for(int i=0;i<20;i++) {Grid->Cells[0][i] = "";Grid->Cells[1][i]="";}

  Grid->Cells[0][0] = "Number";
  Grid->Cells[0][1] = "Depth";
  Grid->Cells[0][2] = "Area";
  Grid->Cells[0][3] = "Length";
  Grid->Cells[0][4] = "Spacing";
  Grid->Cells[0][5] = "JackingForce";
  Grid->Cells[0][6] = "IniDisp";
  Grid->Cells[0][7] = "StressLoss";
  Grid->Cells[0][8] = "RakerAng";
  Grid->Cells[1][0] = Number;
  Grid->Cells[1][1] = Depth;
  Grid->Cells[1][2] = Area;
  Grid->Cells[1][3] = Length;
  Grid->Cells[1][4] = Spacing;
  Grid->Cells[1][5] = JackingForce;
  Grid->Cells[1][6] = IniDisp;
  Grid->Cells[1][7] = StressLoss;
  Grid->Cells[1][8] = RakerAng;

  return true;
}


void MkStrut::Out(TObject *Sender)
{

}
#endif


void MkStrut::Out(char *fname)
{
  FILE *fp;
  fp = fopen(fname,"a");
  if(!fp) {
    MkDebug(fname); MkDebug(" is not found, so fp is null and return false\n");
    return;
  }
            //12345678901234567890123456789012345678901234567890123456789012345678901234567890
//fprintf(fp," Strut Depth   Length  Area     I       E    Spacing  \n");
//fprintf(fp,"   No.   (m)    (m)    (m2)    (m4)   (t/m2)   (m)  \n");
  fprintf(fp,"  %3d   %5.2f   %5.2f  %5.2f   %5.2f   %5.2f  %5.2f\n",Number,Depth,Length,Area,SecMomentZ,YoungMod*MPa2Tonf,Spacing);
  fprintf(fp,"                      (%5.2f) (%5.2f) \n",Area/(Spacing>EPS?Spacing:1),SecMomentZ/(Spacing>EPS?Spacing:1));
  fprintf(fp,"\n");
  fclose(fp);
}

bool MkStrut::operator==(MkStrut &strut)
{
  bool flag = true;
  flag = flag && MkEntity::operator==((MkEntity&)strut);
  flag = flag && Depth==strut.Depth;
  flag = flag && Area==strut.Area;
  flag = flag && Length==strut.Length;
  flag = flag && Spacing==strut.Spacing;
  flag = flag && JackingForce==strut.JackingForce;
  flag = flag && IniDisp==strut.IniDisp;
  flag = flag && StressLoss==strut.StressLoss;
  flag = flag && RakerAng==strut.RakerAng;
  flag = flag && T1==strut.T1;
  flag = flag && T2==strut.T2;
  flag = flag && Weight==strut.Weight; 
  flag = flag && Height==strut.Height; // H
  flag = flag && Width==strut.Width;  // B
  flag = flag && YoungMod==strut.YoungMod;
  flag = flag && ShearTor==strut.ShearTor;
  flag = flag && SecMomentY==strut.SecMomentY;
  flag = flag && SecMomentZ==strut.SecMomentZ;
  flag = flag && RadX==strut.RadX;  
  flag = flag && RadY==strut.RadY;

  return flag;
}

bool MkStrut::operator!=(MkStrut &strut)
{
  return !operator==(strut);
}

MkStrut& MkStrut::operator=(MkStrut& strut)
{
  MkEntity::operator=((MkEntity&)strut);
  Depth=strut.Depth;
  Area=strut.Area;
  Length=strut.Length;
  Spacing=strut.Spacing;
  JackingForce=strut.JackingForce;
  IniDisp=strut.IniDisp;
  StressLoss=strut.StressLoss;
  RakerAng=strut.RakerAng;
  T1=strut.T1;
  T2=strut.T2;
  Weight=strut.Weight; 
  Height=strut.Height; // H
  Width=strut.Width;  // B
  YoungMod=strut.YoungMod;
  ShearTor=strut.ShearTor;
  SecMomentY=strut.SecMomentY;
  SecMomentZ=strut.SecMomentZ;
  RadX=strut.RadX;  
  RadY=strut.RadY;

  return *this;
}

#ifdef __BCPLUSPLUS__
void MkStrut::Draw(TObject *Sender)
{
  StrutLine.Draw(Sender);
}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void MkStrut::Draw(MkPaint *pb)
{

}
#endif
//---------------------------------------------------------------------------
MkStruts::MkStruts(int size,MkStrut *struts)
{
    if (size < 0) {
      MkDebug("::MkStruts - MkStruts(int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSize == 0) {
       FStrut = NULL;
       return;
    }

    FStrut = new MkStrut[FSize];
    for (int i=0;i<FSize;i++) (*this)[i] = struts[i];
}

MkStruts::MkStruts(int size)
{
    if (size < 0) {
      MkDebug("::MkStruts - MkStruts(int size)");;
      return;
    }

    FSizeOfArray = size;
    FSize = 0;
    if (FSizeOfArray == 0) {
       FStrut = NULL;
       return;
    }

    FStrut = new MkStrut[FSizeOfArray];
}

MkStruts::~MkStruts()
{
   FSizeOfArray = FSize = 0;
   if (FStrut) {
      delete[] FStrut;
      FStrut = NULL;
   }
}

void MkStruts::Initialize(int size)
{
    int i;
    if (size < 0) {
      MkDebug("::MkStruts - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;

    FSizeOfArray = FSize = size;

    if (FSizeOfArray == 0) {
       if (FStrut!=NULL) delete[] (MkStrut*)FStrut;
       FStrut = NULL;
       return;
    }

    if (FStrut!=NULL) delete[] (MkStrut*)FStrut;
    FStrut = new MkStrut[FSizeOfArray];
    for (i=0;i<FSize;i++) FStrut[i].Number = i;
}

void MkStruts::Initialize(int size,MkStrut *struts)
{
    int i;
    if (size < 0 || struts == NULL) {
      MkDebug("::MkStruts - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSize = FSizeOfArray = size;
    if (FSizeOfArray == 0) {
       if (FStrut!=NULL) delete[] (MkStrut*)FStrut;
       FStrut = NULL;
       return;
    }

    if (FStrut!=NULL) delete[] (MkStrut*)FStrut;
    FStrut = new MkStrut[FSizeOfArray];
    for (i=0;i<FSizeOfArray;i++) FStrut[i] = struts[i];
    for (i=0;i<FSize;i++) FStrut[i].Number = i;
}

int MkStruts::Grow(int delta)
{
    int i;
    MkStrut *strut=NULL;

    if (!(strut = new MkStrut[FSizeOfArray+delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        strut[i] = FStrut[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        strut[i] = NullStrut;
    if (FStrut) {
       delete[] (MkStrut*)FStrut;
       FStrut = NULL;
    }
    FStrut = strut;
    FSizeOfArray = FSizeOfArray+delta;
    return FSizeOfArray;
}

int MkStruts::Shrink(int delta)
{
    int i;
    MkStrut *strut=NULL;

    if (!(strut = new MkStrut[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        strut[i] = FStrut[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        strut[i] = NullStrut;
    if (FStrut) {
       delete[] (MkStrut*)FStrut;
       FStrut = NULL;
    }
    FStrut = strut;
    FSizeOfArray = FSizeOfArray-delta;
    return FSizeOfArray;
}

bool MkStruts::Add(MkStrut &strut)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    FSize++;
    FStrut[FSize-1] = strut;
    return true;
}

bool MkStruts::Add(int index, MkStrut &strut)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    for (int i=FSize-1;i>=index;i--)
      FStrut[i+1] = FStrut[i];
    FSize++;
    FStrut[index] = strut;
    return true;
}

bool MkStruts::Delete(MkStrut &strut)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FStrut[i] == strut) break;
    }
    if(i==FSize) return false;
    if(FStrut[i] == strut) {
      for (int j=i;j<FSize-1;j++)
        FStrut[j] = FStrut[j+1];
    }
    FSize--;
    FStrut[FSize] = NullStrut;
    return true;
}

bool MkStruts::Delete(int index)
{
    for (int j=index;j<FSize-1;j++)
        FStrut[j] = FStrut[j+1];

    FSize--;
    FStrut[FSize] = NullStrut;
    return true;
}

bool MkStruts::Clear()
{
   FSizeOfArray = FSize = 0;
   if (FStrut) {
      delete[] FStrut;
      FStrut = NULL;
   }
   return true;
}

MkStrut & MkStruts::operator[](int i)
{
    if (0<=i && i<FSize) return FStrut[i];
    else if(FSize<=i && i<FSizeOfArray) {
      FSize=i+1;
      return FStrut[i];
    }
    else if (FSizeOfArray <= i) {
      Grow(i-FSizeOfArray+5);
      return NullStrut;
    }
    else return NullStrut;
}

MkStruts & MkStruts::operator=(MkStruts &struts)
{
    int i;

    Clear();
    FSize = struts.FSize;
    FSizeOfArray = struts.FSizeOfArray;
    if (FSizeOfArray == 0) {
       FStrut = NULL;
       return *this;
    }
    this->FStrut = new MkStrut[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FStrut[i] = struts.FStrut[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FStrut[i] = NullStrut;

    return *this;
}

bool MkStruts::operator==(MkStruts &struts)
{
    int i;

    if (FSize != struts.FSize) return false;
    for (i=0;i<FSize;i++)
      if (this->FStrut[i] != struts.FStrut[i]) return false;

    return true;
}

#ifdef __BCPLUSPLUS__
void MkStruts::Out(TObject *)
{

}
#endif

void MkStruts::Out(char *fname)
{
  FILE *fp;
  fp = fopen(fname,"a");
  if(!fp) {
    return;
  }

  if(FSize==0) return;
    
            //12345678901234567890123456789012345678901234567890123456789012345678901234567890
  fprintf(fp,"\n");
  fprintf(fp,"                           <Information of Struts>\n");
  fprintf(fp,"\n");
  fprintf(fp," Strut Depth   Length  Area     I       E    Spacing  \n");
  fprintf(fp,"   No.   (m)    (m)    (m2)    (m4)   (t/m2)   (m)  \n");
  fclose(fp);

  for(int i=0;i<FSize;i++) 
    FStrut[i].Out(fname);
}

#ifdef __BCPLUSPLUS__
void MkStruts::Draw(TObject *Sender)
{
    TColor C;
    float Offset;
    if (FSize == 0) return;
    if (String(Sender->ClassName()) == String("MkPaintBox")) {
       MkPaintBox *pb=(MkPaintBox*)Sender;
       C = pb->Canvas->Pen->Color;
       pb->Canvas->Pen->Color = Color;
       for (int i = 0; i < FSize;i++) {
           Offset = pb->Offset(3);
           FStrut[i].Draw(pb);
       }
       pb->Canvas->Pen->Color = C;
    }
}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void MkStruts::Draw(MkPaint *pb)
{

}
#endif

//---------------------------------------------------------------------------

MkWale::MkWale()
{

}
MkWale::MkWale(int n)
{
}
#ifdef __BCPLUSPLUS__
bool MkWale::UpdateFrom()
{
  if(!Grid) return false;

  return true;
}

bool MkWale::UpdateTo()
{
  if(!Grid) return false;

  for(int i=0;i<20;i++) {Grid->Cells[0][i] = "";Grid->Cells[1][i]="";}

  return true;
}

void MkWale::Out(TObject *Sender)
{

}
#endif

void MkWale::Out(char *fname)
{

}

bool MkWale::operator==(MkWale &wale)
{
  bool flag = true;
  flag = flag && MkEntity::operator==((MkEntity&)wale);
  flag = flag && WaleLine == wale.WaleLine;
  return flag;
}
bool MkWale::operator!=(MkWale &wale)
{
  return !operator==(wale);
}

MkWale& MkWale::operator=(MkWale& wale)
{
  MkEntity::operator=((MkEntity&)wale);
  WaleLine = wale.WaleLine;
  return *this;
}

#ifdef __BCPLUSPLUS__
void MkWale::Draw(TObject *Sender)
{
  WaleLine.Draw(Sender);
}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void MkWale::Draw(MkPaint *pb)
{

}
#endif
//---------------------------------------------------------------------------
MkWales::MkWales(int size,MkWale *wales)
{

    if (size < 0) {
      MkDebug("::MkWales - MkWales(int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSize == 0) {
       FWale = NULL;
       return;
    }

    FWale = new MkWale[FSize];
    for (int i=0;i<FSize;i++) (*this)[i] = wales[i];
}

MkWales::MkWales(int size)
{
    if (size < 0) {
      MkDebug("::MkWales - MkWales(int size)");;
      return;
    }

    FSizeOfArray = size;
    FSize = 0;
    if (FSizeOfArray == 0) {
       FWale = NULL;
       return;
    }

    FWale = new MkWale[FSizeOfArray];
}

MkWales::~MkWales()
{
   FSizeOfArray = FSize = 0;
   if (FWale) {
      delete[] FWale;
      FWale = NULL;
   }
}

void MkWales::Initialize(int size)
{
    int i;
    if (size < 0) {
      MkDebug("::MkWales - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;

    FSizeOfArray = FSize = size;

    if (FSizeOfArray == 0) {
       if (FWale!=NULL) delete[] (MkWale*)FWale;
       FWale = NULL;
       return;
    }

    if (FWale!=NULL) delete[] (MkWale*)FWale;
    FWale = new MkWale[FSizeOfArray];
    for (i=0;i<FSize;i++) FWale[i].Number = i;
}

void MkWales::Initialize(int size,MkWale *wales)
{
    int i;
    if (size < 0 || wales == NULL) {
      MkDebug("::MkWales - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSize = FSizeOfArray = size;
    if (FSizeOfArray == 0) {
       if (FWale!=NULL) delete[] (MkWale*)FWale;
       FWale = NULL;
       return;
    }

    if (FWale!=NULL) delete[] (MkWale*)FWale;
    FWale = new MkWale[FSizeOfArray];
    for (i=0;i<FSizeOfArray;i++) FWale[i] = wales[i];
    for (i=0;i<FSize;i++) FWale[i].Number = i;
}

int MkWales::Grow(int delta)
{
    int i;
    MkWale *wale=NULL;

    if (!(wale = new MkWale[FSizeOfArray+delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        wale[i] = FWale[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        wale[i] = NullWale;
    if (FWale) {
       delete[] (MkWale*)FWale;
       FWale = NULL;
    }
    FWale = wale;
    FSizeOfArray = FSizeOfArray+delta;
    return FSizeOfArray;
}

int MkWales::Shrink(int delta)
{
    int i;
    MkWale *wale=NULL;

    if (!(wale = new MkWale[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        wale[i] = FWale[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        wale[i] = NullWale;
    if (FWale) {
       delete[] (MkWale*)FWale;
       FWale = NULL;
    }
    FWale = wale;
    FSizeOfArray = FSizeOfArray-delta;
    return FSizeOfArray;
}

bool MkWales::Add(MkWale &wale)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    FSize++;
    FWale[FSize-1] = wale;
    return true;
}

bool MkWales::Add(int index, MkWale &wale)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    for (int i=FSize-1;i>=index;i--)
      FWale[i+1] = FWale[i];
    FSize++;
    FWale[index] = wale;
    return true;
}

bool MkWales::Delete(MkWale &wale)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FWale[i] == wale) break;
    }
    if(i==FSize) return false;
    if(FWale[i] == wale) {
      for (int j=i;j<FSize-1;j++)
        FWale[j] = FWale[j+1];
    }
    FSize--;
    FWale[FSize] = NullWale;
    return true;
}

bool MkWales::Delete(int index)
{
    for (int j=index;j<FSize-1;j++)
        FWale[j] = FWale[j+1];

    FSize--;
    FWale[FSize] = NullWale;
    return true;
}

bool MkWales::Clear()
{
   FSizeOfArray = FSize = 0;
   if (FWale) {
      delete[] FWale;
      FWale = NULL;
   }
   return true;
}

MkWale & MkWales::operator[](int i)
{
    if (0<=i && i<FSize) return FWale[i];
    else if(FSize<=i && i<FSizeOfArray) {
      FSize=i+1;
      return FWale[i];
    }
    else if (FSizeOfArray <= i) {
      Grow(i-FSizeOfArray+5);
      return NullWale;
    }
    else return NullWale;
}

MkWales & MkWales::operator=(MkWales &wales)
{
    int i;

    Clear();
    FSize = wales.FSize;
    FSizeOfArray = wales.FSizeOfArray;
    if (FSizeOfArray == 0) {
       FWale = NULL;
       return *this;
    }
    this->FWale = new MkWale[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FWale[i] = wales.FWale[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FWale[i] = NullWale;

    return *this;
}

bool MkWales::operator==(MkWales &wales)
{
    int i;

    if (FSize != wales.FSize) return false;
    for (i=0;i<FSize;i++)
      if (this->FWale[i] != wales.FWale[i]) return false;

    return true;
}

#ifdef __BCPLUSPLUS__
void MkWales::Draw(TObject *Sender)
{
    TColor C;
    float Offset;
    if (FSize == 0) return;
    if (String(Sender->ClassName()) == String("MkPaintBox")) {
       MkPaintBox *pb=(MkPaintBox*)Sender;
       C = pb->Canvas->Pen->Color;
       pb->Canvas->Pen->Color = Color;
       for (int i = 0; i < FSize;i++) {
           Offset = pb->Offset(3);
           FWale[i].Draw(pb);
       }
       pb->Canvas->Pen->Color = C;
    }
}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void MkWales::Draw(MkPaint *pb)
{

}
#endif

//---------------------------------------------------------------------------
MkAnchor::MkAnchor()
{
  Number=0;            
  Depth=0;             
  Area=0;              
  Angle=0;             
  Length=0;            
  JackingForce=0;
  TenLoss=0;           
  IniDis=0;
}
MkAnchor::MkAnchor(int n)
{
  Number=0;
  Depth=0;
  Area=0;
  Angle=0;
  Length=0;
  JackingForce=0;
  TenLoss=0;
  IniDis=0;
}

#ifdef __BCPLUSPLUS__
bool MkAnchor::UpdateFrom()
{
  if(!Grid) return false;

  Number  =Grid->Cells[1][0].ToInt();
  Depth   =Grid->Cells[1][1].ToDouble();
  Area    =Grid->Cells[1][2].ToDouble();
  Angle   =Grid->Cells[1][3].ToDouble();
  Length  =Grid->Cells[1][4].ToDouble();
  JackingForce  =Grid->Cells[1][5].ToDouble();
  TenLoss =Grid->Cells[1][6].ToDouble();
  IniDis  =Grid->Cells[1][7].ToDouble();
  
  return true;
}
bool MkAnchor::UpdateTo()
{
  if(!Grid) return false;

  for(int i=0;i<20;i++) {Grid->Cells[0][i] = "";Grid->Cells[1][i]="";}

  Grid->Cells[0][0] = "Number";
  Grid->Cells[0][1] = "Depth";
  Grid->Cells[0][2] = "Area";
  Grid->Cells[0][3] = "Angle";
  Grid->Cells[0][4] = "Length";
  Grid->Cells[0][5] = "JackingForce";
  Grid->Cells[0][6] = "TenLoss";
  Grid->Cells[0][7] = "IniDis";

  Grid->Cells[1][0] = Number;
  Grid->Cells[1][1] = Depth ;
  Grid->Cells[1][2] = Area  ;
  Grid->Cells[1][3] = Angle ;
  Grid->Cells[1][4] = Length;
  Grid->Cells[1][5] = JackingForce;
  Grid->Cells[1][6] = TenLoss;
  Grid->Cells[1][7] = IniDis;
  return true;
}

void MkAnchor::Out(TObject *Sender)
{

}
#endif
void MkAnchor::Out(char *fname)
{
  FILE *fp;
  fp = fopen(fname,"a");
  if(!fp) {
    MkDebug(fname); MkDebug(" is not found, so fp is null and return false\n");
    return;
  }
            //12345678901234567890123456789012345678901234567890123456789012345678901234567890
//fprintf(fp," Anchor Depth   Length  Area  Angle   Spacing  Pini  Loss\n");
//fprintf(fp,"   No.   (m)    (m)    (m2)   (deg)    (m)    (t/m)  (%)\n");
  fprintf(fp,"  %3d   %5.2f   %5.2f  %5.2f   %5.2f   %5.2f  %5.2f  %5.2f\n",Number,Depth,Length,Area,Angle,Spacing,JackingForce*MPa2Tonf, TenLoss);
  fprintf(fp,"                      (%5.2f)                (%5.2f) \n",Area/(Spacing>EPS?Spacing:1),JackingForce*MPa2Tonf/(Spacing>EPS?Spacing:1));
  fprintf(fp,"\n");
  fclose(fp);
}

#ifdef __BCPLUSPLUS__
void MkAnchor::Draw(TObject *Sender)
{
  AnchorLine.Draw(Sender);
}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void MkAnchor::Draw(MkPaint *pb)
{

}
#endif


bool MkAnchor::operator==(MkAnchor &anchor)
{
  bool flag = true;
  flag = flag && MkEntity::operator==((MkEntity&)anchor);
  flag = flag && Number==anchor.Number;
  flag = flag && Depth==anchor.Depth;
  flag = flag && Area==anchor.Area;
  flag = flag && Angle==anchor.Angle;
  flag = flag && Spacing==anchor.Spacing;
  flag = flag && Length==anchor.Length;            
  flag = flag && JackingForce==anchor.JackingForce;            
  flag = flag && TenLoss==anchor.TenLoss;           
  flag = flag && IniDis==anchor.IniDis;
  flag = flag && WireNum==anchor.WireNum;
  flag = flag && FreeLength==anchor.FreeLength;
  flag = flag && StickLength==anchor.StickLength;
  flag = flag && JackForce==anchor.JackForce;
  flag = flag && YoungMod==anchor.YoungMod;
  flag = flag && ShearTor==anchor.ShearTor;
  flag = flag && SecMomentY==anchor.SecMomentY, 
  flag = flag && SecMomentZ==anchor.SecMomentZ;  // second moment of inertial
  flag = flag && InstallSide==anchor.InstallSide;

  return flag;
}

bool MkAnchor::operator!=(MkAnchor &anchor)
{
  return !operator==(anchor);
}

MkAnchor& MkAnchor::operator=(MkAnchor& anchor)
{
  MkEntity::operator=((MkEntity&)anchor);
  AnchorLine=anchor.AnchorLine;
  Number=anchor.Number;
  Depth=anchor.Depth;
  Area=anchor.Area;
  Angle=anchor.Angle;
  Spacing=anchor.Spacing;
  Length=anchor.Length;
  JackingForce=anchor.JackingForce;            
  TenLoss=anchor.TenLoss;           
  IniDis=anchor.IniDis;
  WireNum=anchor.WireNum;
  FreeLength=anchor.FreeLength;
  StickLength=anchor.StickLength;
  JackForce=anchor.JackForce;
  YoungMod=anchor.YoungMod;
  ShearTor=anchor.ShearTor;
  SecMomentY=anchor.SecMomentY, 
  SecMomentZ=anchor.SecMomentZ;  // second moment of inertial
  InstallSide=anchor.InstallSide;

  return *this;
}

MkAnchors::MkAnchors(int size,MkAnchor *anchors)
{
    if (size < 0) {
      MkDebug("::MkAnchors - MkAnchors(int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSize == 0) {
       FAnchor = NULL;
       return;
    }

    FAnchor = new MkAnchor[FSize];
    for (int i=0;i<FSize;i++) (*this)[i] = anchors[i];
}

MkAnchors::MkAnchors(int size)
{
    if (size < 0) {
      MkDebug("::MkAnchors - MkAnchors(int size)");;
      return;
    }

    FSizeOfArray = size;
    FSize = 0;
    if (FSizeOfArray == 0) {
       FAnchor = NULL;
       return;
    }

    FAnchor = new MkAnchor[FSizeOfArray];
}

MkAnchors::~MkAnchors()
{
   FSizeOfArray = FSize = 0;
   if (FAnchor) {
      delete[] FAnchor;
      FAnchor = NULL;
   }
}

void MkAnchors::Initialize(int size)
{
    int i;
    if (size < 0) {
      MkDebug("::MkAnchors - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;

    FSizeOfArray = FSize = size;

    if (FSizeOfArray == 0) {
       if (FAnchor!=NULL) delete[] (MkAnchor*)FAnchor;
       FAnchor = NULL;
       return;
    }

    if (FAnchor!=NULL) delete[] (MkAnchor*)FAnchor;
    FAnchor = new MkAnchor[FSizeOfArray];
    for (i=0;i<FSize;i++) FAnchor[i].Number = i;
}

void MkAnchors::Initialize(int size,MkAnchor *anchors)
{
    int i;
    if (size < 0 || anchors == NULL) {
      MkDebug("::MkAnchors - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSize = FSizeOfArray = size;
    if (FSizeOfArray == 0) {
       if (FAnchor!=NULL) delete[] (MkAnchor*)FAnchor;
       FAnchor = NULL;
       return;
    }

    if (FAnchor!=NULL) delete[] (MkAnchor*)FAnchor;
    FAnchor = new MkAnchor[FSizeOfArray];
    for (i=0;i<FSizeOfArray;i++) FAnchor[i] = anchors[i];
    for (i=0;i<FSize;i++) FAnchor[i].Number = i;
}

int MkAnchors::Grow(int delta)
{
    int i;
    MkAnchor *anchor=NULL;

    if (!(anchor = new MkAnchor[FSizeOfArray+delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        anchor[i] = FAnchor[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        anchor[i] = NullAnchor;
    if (FAnchor) {
       delete[] (MkAnchor*)FAnchor;
       FAnchor = NULL;
    }
    FAnchor = anchor;
    FSizeOfArray = FSizeOfArray+delta;
    return FSizeOfArray;
}

int MkAnchors::Shrink(int delta)
{
    int i;
    MkAnchor *anchor=NULL;

    if (!(anchor = new MkAnchor[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        anchor[i] = FAnchor[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        anchor[i] = NullAnchor;
    if (FAnchor) {
       delete[] (MkAnchor*)FAnchor;
       FAnchor = NULL;
    }
    FAnchor = anchor;
    FSizeOfArray = FSizeOfArray-delta;
    return FSizeOfArray;
}

bool MkAnchors::Add(MkAnchor &anchor)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    FSize++;
    FAnchor[FSize-1] = anchor;
    return true;
}

bool MkAnchors::Add(int index, MkAnchor &anchor)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    for (int i=FSize-1;i>=index;i--)
      FAnchor[i+1] = FAnchor[i];
    FSize++;
    FAnchor[index] = anchor;
    return true;
}

bool MkAnchors::Delete(MkAnchor &anchor)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FAnchor[i] == anchor) break;
    }
    if(i==FSize) return false;
    if(FAnchor[i] == anchor) {
      for (int j=i;j<FSize-1;j++)
        FAnchor[j] = FAnchor[j+1];
    }
    FSize--;
    FAnchor[FSize] = NullAnchor;
    return true;
}

bool MkAnchors::Delete(int index)
{
    for (int j=index;j<FSize-1;j++)
        FAnchor[j] = FAnchor[j+1];

    FSize--;
    FAnchor[FSize] = NullAnchor;
    return true;
}

bool MkAnchors::Clear()
{
   FSizeOfArray = FSize = 0;
   if (FAnchor) {
      delete[] FAnchor;
      FAnchor = NULL;
   }
   return true;
}

MkAnchor & MkAnchors::operator[](int i)
{
    if (0<=i && i<FSize) return FAnchor[i];
    else if(FSize<=i && i<FSizeOfArray) {
      FSize=i+1;
      return FAnchor[i];
    }
    else if (FSizeOfArray <= i) {
      Grow(i-FSizeOfArray+5);
      return NullAnchor;
    }
    else return NullAnchor;
}

MkAnchors & MkAnchors::operator=(MkAnchors &anchors)
{
    int i;

    Clear();
    FSize = anchors.FSize;
    FSizeOfArray = anchors.FSizeOfArray;
    if (FSizeOfArray == 0) {
       FAnchor = NULL;
       return *this;
    }
    this->FAnchor = new MkAnchor[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FAnchor[i] = anchors.FAnchor[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FAnchor[i] = NullAnchor;

    return *this;
}

bool MkAnchors::operator==(MkAnchors &anchors)
{
    int i;

    if (FSize != anchors.FSize) return false;
    for (i=0;i<FSize;i++)
      if (this->FAnchor[i] != anchors.FAnchor[i]) return false;

    return true;
}

#ifdef __BCPLUSPLUS__
void MkAnchors::Out(TObject *Sender)
{

}

#endif
void MkAnchors::Out(char *fname)
{
  FILE *fp;
  fp = fopen(fname,"a");
  if(!fp) {
    return;
  }

  if(FSize==0) return;
    
            //12345678901234567890123456789012345678901234567890123456789012345678901234567890
  fprintf(fp,"\n");
  fprintf(fp,"                           <Information of Anchorss>\n");
  fprintf(fp,"\n");
  fprintf(fp," Anchor Depth   Length  Area  Angle   Spacing  Pini  Loss\n");
  fprintf(fp,"   No.   (m)    (m)    (m2)   (deg)    (m)    (t/m)  (%)\n");
  fclose(fp);

  for(int i=0;i<FSize;i++) 
    FAnchor[i].Out(fname);
}

#ifdef __BCPLUSPLUS__
void MkAnchors::Draw(TObject *Sender)
{
    TColor C;
    float Offset;
    if (FSize == 0) return;
    if (String(Sender->ClassName()) == String("MkPaintBox")) {
       MkPaintBox *pb=(MkPaintBox*)Sender;
       C = pb->Canvas->Pen->Color;
       pb->Canvas->Pen->Color = Color;
       for (int i = 0; i < FSize;i++) {
           Offset = pb->Offset(3);
           FAnchor[i].Draw(pb);
       }
       pb->Canvas->Pen->Color = C;
    }
}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void MkAnchors::Draw(MkPaint *pb)
{

}
#endif

//---------------------------------------------------------------------------

MkBolt::MkBolt()
{
  Number=0;
  Depth=0;
  Area=0;
  Angle=0;
  Length=0;
}
MkBolt::MkBolt(int n)
{
  Number=0;
  Depth=0;
  Area=0;
  Angle=0;
  Length=0;
}
#ifdef __BCPLUSPLUS__
bool MkBolt::UpdateFrom()
{
  if(!Grid) return false;

  Number=Grid->Cells[1][0].ToInt();
  Depth =Grid->Cells[1][1].ToDouble();
  Area  =Grid->Cells[1][2].ToDouble();
  Angle =Grid->Cells[1][3].ToDouble();
  Length=Grid->Cells[1][4].ToDouble();

  return true;
}

bool MkBolt::UpdateTo()
{
  if(!Grid) return false;

  for(int i=0;i<20;i++) {Grid->Cells[0][i] = "";Grid->Cells[1][i]="";}

  Grid->Cells[0][0] = "Number";
  Grid->Cells[0][1] = "Depth";
  Grid->Cells[0][2] = "Area";
  Grid->Cells[0][3] = "Angle";
  Grid->Cells[0][4] = "Length";
  Grid->Cells[1][0] = Number;
  Grid->Cells[1][1] = Depth;
  Grid->Cells[1][2] = Area;
  Grid->Cells[1][3] = Angle;
  Grid->Cells[1][4] = Length;

  return true;
}

void MkBolt::Draw(TObject *Sender)
{
  BoltLine.Draw(Sender);
}

void MkBolt::Out(TObject *Sender)
{

}
#else
#endif
void MkBolt::Out(char *fname)
{
  FILE *fp;
  fp = fopen(fname,"a");
  if(!fp) {
    MkDebug(fname); MkDebug(" is not found, so fp is null and return false\n");
    return;
  }
            //12345678901234567890123456789012345678901234567890123456789012345678901234567890
//fprintf(fp,"  Bolt Depth    Length   Area  Spacing\n");
//fprintf(fp,"   No.   (m)     (m)     (m2)    (m)\n");
  fprintf(fp,"  %3d   %5.2f   %5.2f  %5.2f   %5.2f\n",Number,Depth,Length,Area,Spacing);
  fprintf(fp,"                      (%5.2f)\n",Area/(Spacing>EPS?Spacing:1));
  fprintf(fp,"\n");
  fclose(fp);
}

#if defined(_MSC_VER) && defined(_WINDOWS_)
void MkBolt::Draw(MkPaint *pb)
{

}
#endif

bool MkBolt::operator==(MkBolt &bolt)
{
  bool flag = true;
  flag == flag && MkEntity::operator==((MkEntity&)bolt);
  flag == flag && Number==bolt.Number;
  flag == flag && Depth==bolt.Depth;
  flag == flag && Area==bolt.Area;
  flag == flag && Angle==bolt.Angle;
  flag == flag && Spacing==bolt.Spacing;  
  flag == flag && Length==bolt.Length;

  return flag;
}
bool MkBolt::operator!=(MkBolt &bolt)
{
  return !operator==(bolt);
}

MkBolt & MkBolt::operator=(MkBolt &bolt)
{
  MkEntity::operator=((MkEntity&)bolt);
  BoltLine=bolt.BoltLine;
  Number=bolt.Number;
  Depth=bolt.Depth;
  Area=bolt.Area;
  Angle=bolt.Angle;
  Spacing=bolt.Spacing;  
  Length=bolt.Length;
  YoungMod=bolt.YoungMod;
  ShearTor=bolt.ShearTor;
  SecMomentY=bolt.SecMomentY, 
  SecMomentZ=bolt.SecMomentZ;  
  InstallSide=bolt.InstallSide;

  return *this;
}

MkBolts::MkBolts(int size,MkBolt *bolts)
{

    if (size < 0) {
      MkDebug("::MkBolts - MkBolts(int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSize == 0) {
       FBolt = NULL;
       return;
    }

    FBolt = new MkBolt[FSize];
    for (int i=0;i<FSize;i++) (*this)[i] = bolts[i];
}

MkBolts::MkBolts(int size)
{
    if (size < 0) {
      MkDebug("::MkBolts - MkBolts(int size)");;
      return;
    }

    FSizeOfArray = size;
    FSize = 0;
    if (FSizeOfArray == 0) {
       FBolt = NULL;
       return;
    }

    FBolt = new MkBolt[FSizeOfArray];
}

MkBolts::~MkBolts()
{
   FSizeOfArray = FSize = 0;
   if (FBolt) {
      delete[] FBolt;
      FBolt = NULL;
   }
}

void MkBolts::Initialize(int size)
{
    int i;
    if (size < 0) {
      MkDebug("::MkBolts - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;

    FSizeOfArray = FSize = size;

    if (FSizeOfArray == 0) {
       if (FBolt!=NULL) delete[] (MkBolt*)FBolt;
       FBolt = NULL;
       return;
    }

    if (FBolt!=NULL) delete[] (MkBolt*)FBolt;
    FBolt = new MkBolt[FSizeOfArray];
    for (i=0;i<FSize;i++) FBolt[i].Number = i;
}

void MkBolts::Initialize(int size,MkBolt *bolts)
{
    int i;
    if (size < 0 || bolts == NULL) {
      MkDebug("::MkBolts - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSize = FSizeOfArray = size;
    if (FSizeOfArray == 0) {
       if (FBolt!=NULL) delete[] (MkBolt*)FBolt;
       FBolt = NULL;
       return;
    }

    if (FBolt!=NULL) delete[] (MkBolt*)FBolt;
    FBolt = new MkBolt[FSizeOfArray];
    for (i=0;i<FSizeOfArray;i++) FBolt[i] = bolts[i];
    for (i=0;i<FSize;i++) FBolt[i].Number = i;
}

int MkBolts::Grow(int delta)
{
    int i;
    MkBolt *bolt=NULL;

    if (!(bolt = new MkBolt[FSizeOfArray+delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        bolt[i] = FBolt[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        bolt[i] = NullBolt;
    if (FBolt) {
       delete[] (MkBolt*)FBolt;
       FBolt = NULL;
    }
    FBolt = bolt;
    FSizeOfArray = FSizeOfArray+delta;
    return FSizeOfArray;
}

int MkBolts::Shrink(int delta)
{
    int i;
    MkBolt *bolt=NULL;

    if (!(bolt = new MkBolt[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        bolt[i] = FBolt[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        bolt[i] = NullBolt;
    if (FBolt) {
       delete[] (MkBolt*)FBolt;
       FBolt = NULL;
    }
    FBolt = bolt;
    FSizeOfArray = FSizeOfArray-delta;
    return FSizeOfArray;
}

bool MkBolts::Add(MkBolt &bolt)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    FSize++;
    FBolt[FSize-1] = bolt;
    return true;
}

bool MkBolts::Add(int index, MkBolt &bolt)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    for (int i=FSize-1;i>=index;i--)
      FBolt[i+1] = FBolt[i];
    FSize++;
    FBolt[index] = bolt;
    return true;
}

bool MkBolts::Delete(MkBolt &bolt)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FBolt[i] == bolt) break;
    }
    if(i==FSize) return false;
    if(FBolt[i] == bolt) {
      for (int j=i;j<FSize-1;j++)
        FBolt[j] = FBolt[j+1];
    }
    FSize--;
    FBolt[FSize] = NullBolt;
    return true;
}

bool MkBolts::Delete(int index)
{
    for (int j=index;j<FSize-1;j++)
        FBolt[j] = FBolt[j+1];

    FSize--;
    FBolt[FSize] = NullBolt;
    return true;
}

bool MkBolts::Clear()
{
   FSizeOfArray = FSize = 0;
   if (FBolt) {
      delete[] FBolt;
      FBolt = NULL;
   }
   return true;
}

MkBolt & MkBolts::operator[](int i)
{
    if (0<=i && i<FSize) return FBolt[i];
    else if(FSize<=i && i<FSizeOfArray) {
      FSize=i+1;
      return FBolt[i];
    }
    else if (FSizeOfArray <= i) {
      Grow(i-FSizeOfArray+5);
      return NullBolt;
    }
    else return NullBolt;
}

MkBolts & MkBolts::operator=(MkBolts &bolts)
{
    int i;

    Clear();
    FSize = bolts.FSize;
    FSizeOfArray = bolts.FSizeOfArray;
    if (FSizeOfArray == 0) {
       FBolt = NULL;
       return *this;
    }
    this->FBolt = new MkBolt[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FBolt[i] = bolts.FBolt[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FBolt[i] = NullBolt;

    return *this;
}

bool MkBolts::operator==(MkBolts &bolts)
{
    int i;

    if (FSize != bolts.FSize) return false;
    for (i=0;i<FSize;i++)
      if (this->FBolt[i] != bolts.FBolt[i]) return false;

    return true;
}

#ifdef __BCPLUSPLUS__
void MkBolts::Out(TObject *Sender)
{

}
#endif

void MkBolts::Out(char *fname)
{
  FILE *fp;
  fp = fopen(fname,"a");
  if(!fp) {
    return;
  }

  if(FSize==0) return;
    
            //12345678901234567890123456789012345678901234567890123456789012345678901234567890
  fprintf(fp,"\n");
  fprintf(fp,"                           <Information of Rockolts>\n");
  fprintf(fp,"\n");
  fprintf(fp,"  Bolt  Depth   Length  Area  Spacing\n");
  fprintf(fp,"   No.   (m)      (m)   (m2)    (m)\n");
  fclose(fp);

  for(int i=0;i<FSize;i++) 
    FBolt[i].Out(fname);
}

#ifdef __BCPLUSPLUS__
void MkBolts::Draw(TObject *Sender)
{
    TColor C;
    float Offset;
    if (FSize == 0) return;
    if (String(Sender->ClassName()) == String("MkPaintBox")) {
       MkPaintBox *pb=(MkPaintBox*)Sender;
       C = pb->Canvas->Pen->Color;
       pb->Canvas->Pen->Color = Color;
       for (int i = 0; i < FSize;i++) {
           Offset = pb->Offset(3);
           FBolt[i].Draw(pb);
       }
       pb->Canvas->Pen->Color = C;
    }
}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void MkBolts::Draw(MkPaint *pb)
{

}
#endif

//---------------------------------------------------------------------------

MkSlab::MkSlab()
{
  Number=0;
  Depth=0;
  Area=0;
  Angle=0;
  Length=0;
}
MkSlab::MkSlab(int n)
{
  Number=0;
  Depth=0;
  Area=0;
  Angle=0;
  Length=0;
}

#ifdef __BCPLUSPLUS__
bool MkSlab::UpdateFrom()
{
  if(!Grid) return false;

  Number=Grid->Cells[1][0].ToInt();
  Depth =Grid->Cells[1][1].ToDouble();
  Area  =Grid->Cells[1][2].ToDouble();
  Angle =Grid->Cells[1][3].ToDouble();
  Length=Grid->Cells[1][4].ToDouble();

  return true;
}

bool MkSlab::UpdateTo()
{

  if(!Grid) return false;

  for(int i=0;i<20;i++) {Grid->Cells[0][i] = "";Grid->Cells[1][i]="";}

  Grid->Cells[0][0] = "Number";
  Grid->Cells[0][1] = "Depth";
  Grid->Cells[0][2] = "Area";
  Grid->Cells[0][3] = "Angle";
  Grid->Cells[0][4] = "Length";
  Grid->Cells[1][0] = Number;
  Grid->Cells[1][1] = Depth;
  Grid->Cells[1][2] = Area;
  Grid->Cells[1][3] = Angle;
  Grid->Cells[1][4] = Length;

  return true;
}

void MkSlab::Out(TObject *Sender)
{

}

#else
#endif
void MkSlab::Out(char *fname)
{

}

bool MkSlab::operator==(MkSlab &slab)
{
  bool flag = true;
  flag = flag && MkEntity::operator==((MkEntity&)slab);
  flag = flag && Number==slab.Number;
  flag = flag && Depth==slab.Depth;
  flag = flag && Area==slab.Area;
  flag = flag && Angle==slab.Angle;
  flag = flag && Length==slab.Length;

  return flag;
}

bool MkSlab::operator!=(MkSlab &slab)
{
  return !operator==(slab);
}

MkSlab & MkSlab::operator=(MkSlab &slab)
{
  MkEntity::operator=((MkEntity&)slab);
  Number=slab.Number;
  Depth=slab.Depth;
  Area=slab.Area;
  Angle=slab.Angle;
  Length=slab.Length;
  return *this;
}

#ifdef __BCPLUSPLUS__
void  MkSlab::Draw(TObject *Sender)
{
  SlabLine.Draw(Sender);
}
#endif
  
#if defined(_MSC_VER) && defined(_WINDOWS_)
void MkSlab::Draw(MkPaint *pb)
{
  SlabLine.Draw(pb);
}
#endif


MkSlabs::MkSlabs(int size,MkSlab *slabs)
{

    if (size < 0) {
      MkDebug("::MkSlabs - MkSlabs(int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSize == 0) {
       FSlab = NULL;
       return;
    }

    FSlab = new MkSlab[FSize];
    for (int i=0;i<FSize;i++) (*this)[i] = slabs[i];
}

MkSlabs::MkSlabs(int size)
{
    if (size < 0) {
      MkDebug("::MkSlabs - MkSlabs(int size)");;
      return;
    }

    FSizeOfArray = size;
    FSize = 0;
    if (FSizeOfArray == 0) {
       FSlab = NULL;
       return;
    }

    FSlab = new MkSlab[FSizeOfArray];
}

MkSlabs::~MkSlabs()
{
   FSizeOfArray = FSize = 0;
   if (FSlab) {
      delete[] FSlab;
      FSlab = NULL;
   }
}


void MkSlabs::Initialize(int size)
{
    int i;
    if (size < 0) {
      MkDebug("::MkSlabs - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;

    FSizeOfArray = FSize = size;

    if (FSizeOfArray == 0) {
       if (FSlab!=NULL) delete[] (MkSlab*)FSlab;
       FSlab = NULL;
       return;
    }

    if (FSlab!=NULL) delete[] (MkSlab*)FSlab;
    FSlab = new MkSlab[FSizeOfArray];
    for (i=0;i<FSize;i++) FSlab[i].Number = i;    
}

void MkSlabs::Initialize(int size,MkSlab *slabs)
{
    int i;
    if (size < 0 || slabs == NULL) {
      MkDebug("::MkSlabs - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSize = FSizeOfArray = size;
    if (FSizeOfArray == 0) {
       if (FSlab!=NULL) delete[] (MkSlab*)FSlab;
       FSlab = NULL;
       return;
    }

    if (FSlab!=NULL) delete[] (MkSlab*)FSlab;
    FSlab = new MkSlab[FSizeOfArray];
    for (i=0;i<FSizeOfArray;i++) FSlab[i] = slabs[i];
    for (i=0;i<FSize;i++) FSlab[i].Number = i;
}

int MkSlabs::Grow(int delta)
{
    int i;
    MkSlab *slab=NULL;

    if (!(slab = new MkSlab[FSizeOfArray+delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        slab[i] = FSlab[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        slab[i] = NullSlab;
    if (FSlab) {
       delete[] (MkSlab*)FSlab;
       FSlab = NULL;
    }
    FSlab = slab;
    FSizeOfArray = FSizeOfArray+delta;
    return FSizeOfArray;
}

int MkSlabs::Shrink(int delta)
{
    int i;
    MkSlab *slab=NULL;

    if (!(slab = new MkSlab[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        slab[i] = FSlab[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        slab[i] = NullSlab;
    if (FSlab) {
       delete[] (MkSlab*)FSlab;
       FSlab = NULL;
    }
    FSlab = slab;
    FSizeOfArray = FSizeOfArray-delta;
    return FSizeOfArray;
}

bool MkSlabs::Add(MkSlab &slab)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    FSize++;
    FSlab[FSize-1] = slab;
    return true;
}

bool MkSlabs::Add(int index, MkSlab &slab)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    for (int i=FSize-1;i>=index;i--)
      FSlab[i+1] = FSlab[i];
    FSize++;
    FSlab[index] = slab;
    return true;
}

bool MkSlabs::Delete(MkSlab &slab)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FSlab[i] == slab) break;
    }
    if(i==FSize) return false;
    if(FSlab[i] == slab) {
      for (int j=i;j<FSize-1;j++)
        FSlab[j] = FSlab[j+1];
    }
    FSize--;
    FSlab[FSize] = NullSlab;
    return true;
}

bool MkSlabs::Delete(int index)
{
    for (int j=index;j<FSize-1;j++)
        FSlab[j] = FSlab[j+1];

    FSize--;
    FSlab[FSize] = NullSlab;
    return true;
}

bool MkSlabs::Clear()
{
   FSizeOfArray = FSize = 0;
   if (FSlab) {
      delete[] FSlab;
      FSlab = NULL;
   }
   return true;
}

MkSlab & MkSlabs::operator[](int i)
{
    if (0<=i && i<FSize) return FSlab[i];
    else if(FSize<=i && i<FSizeOfArray) {
      FSize=i+1;
      return FSlab[i];
    }
    else if (FSizeOfArray <= i) {
      Grow(i-FSizeOfArray+5);
      return NullSlab;
    }
    else return NullSlab;
}

MkSlabs & MkSlabs::operator=(MkSlabs &slabs)
{
    int i;

    Clear();
    FSize = slabs.FSize;
    FSizeOfArray = slabs.FSizeOfArray;
    if (FSizeOfArray == 0) {
       FSlab = NULL;
       return *this;
    }
    this->FSlab = new MkSlab[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FSlab[i] = slabs.FSlab[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FSlab[i] = NullSlab;

    return *this;
}

bool MkSlabs::operator==(MkSlabs &slabs)
{
    int i;

    if (FSize != slabs.FSize) return false;
    for (i=0;i<FSize;i++)
      if (this->FSlab[i] != slabs.FSlab[i]) return false;

    return true;
}
#ifdef __BCPLUSPLUS__
void MkSlabs::Draw(TObject *Sender)
{
    TColor C;
    float Offset;
    if (FSize == 0) return;
    if (String(Sender->ClassName()) == String("MkPaintBox")) {
       MkPaintBox *pb=(MkPaintBox*)Sender;
       C = pb->Canvas->Pen->Color;
       pb->Canvas->Pen->Color = Color;
       for (int i = 0; i < FSize;i++) {
           Offset = pb->Offset(3);
           FSlab[i].Draw(pb);
       }
       pb->Canvas->Pen->Color = C;
    }
}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void MkSlabs::Draw(MkPaint *pb)
{

}
#endif

//---------------------------------------------------------------------------
MkRetainPanel::MkRetainPanel()
{
  Number=0;
  Thick=0;
  Press=0;
  Width=0;
  BendCompStressAllow=0;
  Moment=0;
}
MkRetainPanel::MkRetainPanel(int n)
{
  Number=0;
  Thick=0;
  Press=0;
  Width=0;
  BendCompStressAllow=0;
  Moment=0;
}
#ifdef __BCPLUSPLUS__
bool MkRetainPanel::UpdateFrom()
{
  if(!Grid) return false;

  Number=Grid->Cells[1][0].ToInt();
  Thick=Grid->Cells[1][1].ToDouble();
  Press=Grid->Cells[1][2].ToDouble();
  Width =Grid->Cells[1][3].ToDouble();
  BendCompStressAllow=Grid->Cells[1][4].ToDouble();
  Moment=Grid->Cells[1][4].ToDouble();
  return true;
}

bool MkRetainPanel::UpdateTo()
{

  if(!Grid) return false;

  for(int i=0;i<20;i++) {Grid->Cells[0][i] = "";Grid->Cells[1][i]="";}

  Grid->Cells[0][0] = "Number";
  Grid->Cells[0][1] = "Thick";
  Grid->Cells[0][2] = "Press";
  Grid->Cells[0][3] = "Width";
  Grid->Cells[0][4] = "BendCompStressAllow";
  Grid->Cells[0][5] = "Moment";

  Grid->Cells[1][0] = Number;
  Grid->Cells[1][1] = Thick;
  Grid->Cells[1][2] = Press;
  Grid->Cells[1][3] = Width;
  Grid->Cells[1][4] = BendCompStressAllow;
  Grid->Cells[1][5] = Moment;

  return true;
}

void MkRetainPanel::Draw(TObject *Sender)
{
  
}
#endif

bool MkRetainPanel::operator==(MkRetainPanel &pan)
{
  bool flag = true;
  flag == flag && MkEntity::operator==((MkEntity&)pan);
  flag == flag && Number==pan.Number;
  flag == flag && Thick==pan.Thick;
  flag == flag && Press==pan.Press;
  flag == flag && Width==pan.Width;
  flag == flag && BendCompStressAllow==pan.BendCompStressAllow;
  flag == flag && Moment==pan.Moment;

  return flag;
}
bool MkRetainPanel::operator!=(MkRetainPanel &pan)
{
  return !operator==(pan);
}

MkRetainPanel & MkRetainPanel::operator=(MkRetainPanel &pan)
{
  MkEntity::operator=((MkEntity&)pan);
  Number=pan.Number;
  Thick=pan.Thick;
  Press=pan.Press;
  Width=pan.Width;
  BendCompStressAllow=pan.BendCompStressAllow;
  Moment=pan.Moment;
  return *this;
}

#if defined(_MSC_VER) && defined(_WINDOWS_)
void MkRetainPanel::Draw(MkPaint *Sender)
{
}
#endif

MkRetainPanels::MkRetainPanels(int size,MkRetainPanel *pans)
{

    if (size < 0) {
      MkDebug("::MkRetainPanels - MkRetainPanels(int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSize == 0) {
       FRetainPanel = NULL;
       return;
    }

    FRetainPanel = new MkRetainPanel[FSize];
    for (int i=0;i<FSize;i++) (*this)[i] = pans[i];
}

MkRetainPanels::MkRetainPanels(int size)
{
    if (size < 0) {
      MkDebug("::MkRetainPanels - MkRetainPanels(int size)");;
      return;
    }

    FSizeOfArray = size;
    FSize = 0;
    if (FSizeOfArray == 0) {
       FRetainPanel = NULL;
       return;
    }

    FRetainPanel = new MkRetainPanel[FSizeOfArray];
}

MkRetainPanels::~MkRetainPanels()
{
   FSizeOfArray = FSize = 0;
   if (FRetainPanel) {
      delete[] FRetainPanel;
      FRetainPanel = NULL;
   }
}

void MkRetainPanels::Initialize(int size)
{
    int i;
    if (size < 0) {
      MkDebug("::MkRetainPanels - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;

    FSizeOfArray = FSize = size;

    if (FSizeOfArray == 0) {
       if (FRetainPanel!=NULL) delete[] (MkRetainPanel*)FRetainPanel;
       FRetainPanel = NULL;
       return;
    }

    if (FRetainPanel!=NULL) delete[] (MkRetainPanel*)FRetainPanel;
    FRetainPanel = new MkRetainPanel[FSizeOfArray];
    for (i=0;i<FSize;i++) FRetainPanel[i].Number = i;    
}

void MkRetainPanels::Initialize(int size,MkRetainPanel *pans)
{
    int i;
    if (size < 0 || pans == NULL) {
      MkDebug("::MkRetainPanels - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSize = FSizeOfArray = size;
    if (FSizeOfArray == 0) {
       if (FRetainPanel!=NULL) delete[] (MkRetainPanel*)FRetainPanel;
       FRetainPanel = NULL;
       return;
    }

    if (FRetainPanel!=NULL) delete[] (MkRetainPanel*)FRetainPanel;
    FRetainPanel = new MkRetainPanel[FSizeOfArray];
    for (i=0;i<FSizeOfArray;i++) FRetainPanel[i] = pans[i];
    for (i=0;i<FSize;i++) FRetainPanel[i].Number = i;
}

int MkRetainPanels::Grow(int delta)
{
    int i;
    MkRetainPanel *pan=NULL;

    if (!(pan = new MkRetainPanel[FSizeOfArray+delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        pan[i] = FRetainPanel[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        pan[i] = NullRetainPanel;
    if (FRetainPanel) {
       delete[] (MkRetainPanel*)FRetainPanel;
       FRetainPanel = NULL;
    }
    FRetainPanel = pan;
    FSizeOfArray = FSizeOfArray+delta;
    return FSizeOfArray;
}

int MkRetainPanels::Shrink(int delta)
{
    int i;
    MkRetainPanel *pan=NULL;

    if (!(pan = new MkRetainPanel[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        pan[i] = FRetainPanel[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        pan[i] = NullRetainPanel;
    if (FRetainPanel) {
       delete[] (MkRetainPanel*)FRetainPanel;
       FRetainPanel = NULL;
    }
    FRetainPanel = pan;
    FSizeOfArray = FSizeOfArray-delta;
    return FSizeOfArray;
}

bool MkRetainPanels::Add(MkRetainPanel &pan)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    FSize++;
    FRetainPanel[FSize-1] = pan;
    return true;
}

bool MkRetainPanels::Add(int index, MkRetainPanel &pan)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    for (int i=FSize-1;i>=index;i--)
      FRetainPanel[i+1] = FRetainPanel[i];
    FSize++;
    FRetainPanel[index] = pan;
    return true;
}

bool MkRetainPanels::Delete(MkRetainPanel &pan)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FRetainPanel[i] == pan) break;
    }
    if(i==FSize) return false;
    if(FRetainPanel[i] == pan) {
      for (int j=i;j<FSize-1;j++)
        FRetainPanel[j] = FRetainPanel[j+1];
    }
    FSize--;
    FRetainPanel[FSize] = NullRetainPanel;
    return true;
}

bool MkRetainPanels::Delete(int index)
{
    for (int j=index;j<FSize-1;j++)
        FRetainPanel[j] = FRetainPanel[j+1];

    FSize--;
    FRetainPanel[FSize] = NullRetainPanel;
    return true;
}

bool MkRetainPanels::Clear()
{
   FSizeOfArray = FSize = 0;
   if (FRetainPanel) {
      delete[] FRetainPanel;
      FRetainPanel = NULL;
   }
   return true;
}

MkRetainPanel & MkRetainPanels::operator[](int i)
{
    if (0<=i && i<FSize) return FRetainPanel[i];
    else if(FSize<=i && i<FSizeOfArray) {
      FSize=i+1;
      return FRetainPanel[i];
    }
    else if (FSizeOfArray <= i) {
      Grow(i-FSizeOfArray+5);
      return NullRetainPanel;
    }
    else return NullRetainPanel;
}

MkRetainPanels & MkRetainPanels::operator=(MkRetainPanels &pans)
{
    int i;

    Clear();
    FSize = pans.FSize;
    FSizeOfArray = pans.FSizeOfArray;
    if (FSizeOfArray == 0) {
       FRetainPanel = NULL;
       return *this;
    }
    this->FRetainPanel = new MkRetainPanel[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FRetainPanel[i] = pans.FRetainPanel[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FRetainPanel[i] = NullRetainPanel;

    return *this;
}

bool MkRetainPanels::operator==(MkRetainPanels &pans)
{
    int i;

    if (FSize != pans.FSize) return false;
    for (i=0;i<FSize;i++)
      if (this->FRetainPanel[i] != pans.FRetainPanel[i]) return false;

    return true;
}

#ifdef __BCPLUSPLUS__
void MkRetainPanels::Draw(TObject *Sender)
{
    TColor C;
    float Offset;
    if (FSize == 0) return;
    if (String(Sender->ClassName()) == String("MkPaintBox")) {
       MkPaintBox *pb=(MkPaintBox*)Sender;
       C = pb->Canvas->Pen->Color;
       pb->Canvas->Pen->Color = Color;
       for (int i = 0; i < FSize;i++) {
           Offset = pb->Offset(3);
           FRetainPanel[i].Draw(pb);
       }
       pb->Canvas->Pen->Color = C;
    }
}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void MkRetainPanels::Draw(MkPaint *Sender)
{
}
#endif

//---------------------------------------------------------------------------

