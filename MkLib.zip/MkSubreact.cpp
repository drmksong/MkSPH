//---------------------------------------------------------------------------
#include "MkSubreact.h"

#ifdef __BCPLUSPLUS__
#pragma package(smart_init)
#endif

#pragma hdrstop
//#include "stdafx.h"

MkSubreact NullSubreact(0);
bool MkSubreact::Build(MkLayers &lay, MkCuts &cuts, MkFills &fills, MkWall &wall)
{
  int i,j,k;
  bool flag=true;
  float offset;
  float depth_c=0,depth_f=-1000;
  float cut_s=-1000, cut_e=1000;
  MkPoint isp[2];
  MkPoints p,pnts;
  MkLine l,line;

  flag = BuildRange(wall) && flag;

  offset = Direction[0]<0?2*EPS:-2*EPS;
  offset += wall.GetLine()[0].X;

  if(cuts.GetSize()) {
    MkWall &lw = *cuts[0].GetWall(0);
    MkWall &rw = cuts[0].GetWall(1)?*cuts[0].GetWall(1):*cuts[0].GetWall(0);
    cut_s = lw.GetLine()[0].X;
    cut_e = rw.GetLine()[0].X;
    if(fabs(cut_s-cut_e)<EPS) cut_e = 1.0e3;
  }

  for(i=0;i<cuts.GetSize();i++) {
    depth_c = depth_c < cuts[i].GetDepth() ? depth_c : cuts[i].GetDepth();
  }
  for(i=0;i<fills.GetSize();i++) {
    depth_f = depth_f > fills[i].GetDepth() ? depth_f : fills[i].GetDepth();
  }

  if((depth_f+1000)<EPS) depth_f = depth_c;

  if((offset-cut_s)<EPS || (offset-cut_e)>EPS) {
    float g = -10000;
    for(i=0;i<lay.GetSize();i++) 
      g = g>lay[i].GetRect().GetTop()?g:lay[i].GetRect().GetTop();
    depth_c = depth_f = g;
  }

  if (cut_s < offset && offset < cut_e) { // inside
    l = wall.GetLine();
    l.SetFiniteness(true);
    offset = Direction[0]<0?2*EPS:-2*EPS;
    l[0].X += offset;
    l[1].X += offset;
    l[0].Y = l[0].Y<l[1].Y ? l[0].Y-2*EPS:l[0].Y+2*EPS;
    l[1].Y = l[0].Y>l[1].Y ? l[1].Y-2*EPS:l[1].Y+2*EPS;    

    for (i=0;i<lay.GetSize();i++) {
      MkRect &rect = lay[i].GetRect();
      pnts = rect.GetIntPoints(l);

      if(pnts.GetSize()==2) {
	if (pnts[0].Y > pnts[1].Y) Swap(pnts[0],pnts[1]);
	pnts[0].Y += 2*(float)EPS;
	pnts[1].Y -= 2*(float)EPS;
      }
      if(pnts.GetSize()==1) {
	if(fabs(pnts[0].Y-lay[i].GetRect().GetBot()) < EPS) pnts[0].Y += 2*(float)EPS;
	else if(fabs(pnts[0].Y-lay[i].GetRect().GetTop()) < EPS) pnts[0].Y -= 2*(float)EPS;
      }
      flag=true;
      for (j=0;j<pnts.GetSize();j++) {
	flag = true;
	for (k=0;k<p.GetSize();k++) {
	  if(CalDist(p[k],pnts[j])<EPS)
	    flag = false;
	}
	if ((pnts[j].Y < depth_c) && flag) 
	  p.Add(pnts[j]);
      }
    }
    flag = true;
    for(k=0;k<p.GetSize();k++) {
      if(CalDist(p[k],l[0])<EPS)
	flag = false;
    }
    if(/*l[0].Y < depth_c+EPS && */flag)
      p.Add(l[0]);

    flag = true;
    for(k=0;k<p.GetSize();k++) {
      if(CalDist(p[k],l[1])<EPS)
	flag = false;
    }
    if(/*l[1].Y < depth_c+EPS && */flag) 
      p.Add(l[1]);

    p.Add(MkPoint(l[0].X,depth_c-2*EPS));
    p.Add(MkPoint(l[0].X,depth_c+2*EPS));    

    for (i=0;i<p.GetSize()-1;i++) {
	  for (j=i+1;j<p.GetSize();j++) {
		if (p[i].Y < p[j].Y) 
		  Swap(p[i],p[j]);
	  }
    }
	Subreact.Clear();
    Subreact.Initialize(p.GetSize(),p.GetPoints());
    p.Clear();

    for (i=0;i<Subreact.GetSize();i++) {
      float x=0;
      if(Subreact[i].Y < depth_c) {
	    x = lay.GetHorSubReact(Subreact[i]);
	    Subreact[i].X = x;
      }
      else if(depth_c < Subreact[i].Y && Subreact[i].Y < depth_f) {
	    x = fills[0].GetHorSubReact();
	    Subreact[i].X = x;
      }
      else Subreact[i].X = 0;
    }
  }
  else {  //outside
    l = wall.GetLine();
    l.SetFiniteness(true);
    offset = Direction[0]<0?2*EPS:-2*EPS;
    l[0].X += offset;
    l[1].X += offset;
    l[0].Y = l[0].Y<l[1].Y ? l[0].Y-2*EPS:l[0].Y+2*EPS;
    l[1].Y = l[0].Y>l[1].Y ? l[1].Y-2*EPS:l[1].Y+2*EPS;    

    for (i=0;i<lay.GetSize();i++) {
      MkRect &rect = lay[i].GetRect();
      pnts.Clear();
      pnts = rect.GetIntPoints(l);
      if(pnts.GetSize()==2) {
	if (pnts[0].Y > pnts[1].Y) Swap(pnts[0],pnts[1]);
	pnts[0].Y += 2*(float)EPS;
	pnts[1].Y -= 2*(float)EPS;
      }
      if(pnts.GetSize()==1) {
	if(fabs(pnts[0].Y-lay[i].GetRect().GetBot()) < (float)EPS) pnts[0].Y += 2*(float)EPS;
	else if(fabs(pnts[0].Y-lay[i].GetRect().GetTop()) < (float)EPS) pnts[0].Y -= 2*(float)EPS;
      }
      for (j=0;j<pnts.GetSize();j++) {
	flag = true;
	for(k=0;k<p.GetSize();k++) {
	  if(CalDist(p[k],pnts[j])<EPS)
	    flag = false;
	}
	if(flag) p.Add(pnts[j]);
      }
    }

    isp[0] = pnts[0];
    for(i=1;i<pnts.GetSize();i++) 
      if(isp[0].Y<pnts[i].Y) isp[0] = pnts[i];
    isp[0].Y += 4*(float)EPS;

    flag = true;
    for(k=0;k<p.GetSize();k++) {
      if(CalDist(p[k],isp[0])<EPS)
	flag = false;
    }
    if(flag) 
      p.Add(isp[0]);

    flag = true;
    for(k=0;k<p.GetSize();k++) {
      if(CalDist(p[k],l[0])<EPS)
	flag = false;
    }
    if(flag) 
      p.Add(l[0]);

    flag = true;
    for(k=0;k<p.GetSize();k++) {
      if(CalDist(p[k],l[1])<EPS)
	flag = false;
    }
    if(flag)  
      p.Add(l[1]);

    for (i=0;i<p.GetSize()-1;i++)  // sort
      for (j=i+1;j<p.GetSize();j++)
	if (p[i].Y < p[j].Y) Swap(p[i],p[j]);

    Subreact.Clear();
    Subreact.Initialize(p.GetSize(),p.GetPoints());
    p.Clear();

    for (i=0;i<Subreact.GetSize();i++) {
      float x=0;
      x = lay.GetHorSubReact(Subreact[i]);
      Subreact[i].X = x;
    }
  }
  return true;
}

bool MkSubreact::BuildRange(MkWall &wall)
{
  MkPoint sp,ep,p;
  MkRect r;
  MkRangeShape rs;

  sp = wall.GetLine()[0];
  ep = wall.GetLine()[1];

  if(sp==ep) return false;

  p = sp.Y<ep.Y?sp:ep;
  p.X = p.X-EPS*2;
  p.Y = p.Y-EPS*2;

  r.SetOrigin(p);
  r.SetWidth((float)EPS*4);
  r.SetHeight(wall.GetLine().GetLength()+EPS*4);

  rs.SetShape(&r);

  Range.Clear();
  Range.SetRoot(&rs);
  return true;
}

bool MkSubreact::Out(char *fname)
{
  FILE *fp;
  fp = fopen(fname,"a");
  if(!fp) {
    MkDebug(fname); MkDebug(" is not found, so fp is null and return false\n");
    return false;
  }

  fprintf(fp,"-------------------------begin of subreact info--------------\n");
  fprintf(fp,"LoadType      : MkLoad\n");
  fprintf(fp,"Dir vector    : (%10.3f,%10.3f,%10.3f) \n",Direction[0], Direction[1], Direction[2]);
  fprintf(fp,"Origin        : (%10.3f,%10.3f,%10.3f) \n",Origin.X, Origin.Y, Origin.Z);
  fclose(fp);

  Subreact.Out(fname);
  fp = fopen(fname,"a");
  if(!fp) {
    MkDebug(fname); MkDebug(" is not found, so fp is null and return false\n");
    return false;
  }
  fprintf(fp,"-------------------------end of subreact info----------------\n");
  fclose(fp);
}

bool MkSubreact::operator==(MkSubreact &subreact)
{
  bool flag;
  flag = Direction == subreact.Direction &&
         Origin == subreact.Origin &&
         Range == subreact.Range;
  return flag;
}

bool MkSubreact::operator!=(MkSubreact &subreact)
{
  return !operator==(subreact);
}

MkSubreact & MkSubreact::operator=(MkSubreact &subreact)
{
  Direction=subreact.Direction;
  Origin=subreact.Origin;
  Range=subreact.Range;
#ifdef __BCPLUSPLUS__
  Color=subreact.Color;
#endif
  return *this;
}
//--------------------------------------------------------------------
MkSubreacts::MkSubreacts(int size,MkSubreact *subreacts)
{

    if (size < 0) {
      MkDebug("::MkSubreacts - MkSubreacts(int size)");;
      return;
    }

    FSize = size;
    if (FSize == 0) {
       FSubreact = NULL;
       return;
    }

    FSubreact = new MkSubreact[FSize];
    assert(FSubreact);
    for (int i=0;i<FSize;i++) FSubreact[i]=subreacts[i];
}

MkSubreacts::~MkSubreacts()
{
  FSize = 0;
   if (FSubreact) {
    delete[] FSubreact;
    FSubreact = NULL;
  }
}

void MkSubreacts::Initialize(int size)
{
    if (size < 0) {
      MkDebug("::MkSubreacts - Initialize(int size)");;
      return;
    }
    if (FSize== size) return;

    FSize= size;

    if (FSize== 0) {
       if (FSubreact!=NULL) delete[] (MkSubreact*)FSubreact;
       FSubreact = NULL;
       return;
    }

    if (FSubreact!=NULL) delete[] (MkSubreact*)FSubreact;
    FSubreact = new MkSubreact[FSize];
}

void MkSubreacts::Initialize(int size,MkSubreact *subreacts)
{
    if (size < 0) {
      MkDebug("::MkSubreacts - Initialize(int size)");;
      return;
    }
    if (FSize== size) return;

    FSize= size;

    if (FSize== 0) {
       if (FSubreact!=NULL) delete[] (MkSubreact*)FSubreact;
       FSubreact = NULL;
       return;
    }

    if (FSubreact!=NULL) delete[] (MkSubreact*)FSubreact;
    FSubreact = new MkSubreact[FSize];
    for(int i=0;i<FSize;i++) FSubreact[i] = subreacts[i];
}



bool MkSubreacts::Add(MkSubreact &subreact)
{
    int i,tmp=FSize;
    MkSubreact *sub;

    sub = new MkSubreact[FSize+1];
    if(!sub) return false;
    for (i=0;i<FSize;i++) {
      sub[i] = FSubreact[i];
    }

    delete[] FSubreact;
    FSubreact = sub;

    FSize++;
    FSubreact[FSize-1] = subreact;
    return true;
}

bool MkSubreacts::Delete(MkSubreact &subreact)
{
    int i,j;
    MkSubreact *sub;

    for (i=0;i<FSize;i++) {
      if(FSubreact[i] == subreact) break;
    }
    if(i==FSize) return false;
    if(FSubreact[i] != subreact) return false;

    sub = new MkSubreact[FSize+1];
    if(!sub) return false;

    for(j=0;j<i;j++) 
      sub[j] = FSubreact[j];
    for(j=i;j<FSize;j++) 
      sub[j-1] = FSubreact[j];

    delete[] FSubreact;
    FSubreact = sub;
    FSize--;
    return true;
}

bool MkSubreacts::Clear()
{
 if (FSubreact) {
   delete[] FSubreact;
   FSubreact = NULL;
   FSize = 0;
   return true;
 }
 else return false;
}

bool MkSubreacts::Out(char *fname)
{
  for (int i=0;i<FSize;i++) FSubreact[i].Out(fname);
  return true;
}

MkSubreact & MkSubreacts::operator[](int i)
{
    if (FSize == 0) return NullSubreact;
    else if (i >=0 && i < FSize) return FSubreact[i];
    else return NullSubreact;
}

MkSubreacts & MkSubreacts::operator=(MkSubreacts &subreacts)
{
    int i;

    Clear();
    FSize = subreacts.FSize;
    if (FSize == 0) {
       FSubreact = NULL;
       return *this;
    }
    FSubreact = new MkSubreact[FSize];
    assert(FSubreact);

    for (i=0;i<FSize;i++)
      FSubreact[i]=subreacts[i];

    return *this;
}

bool MkSubreacts::operator==(MkSubreacts &subreacts)
{
    int i;

    if (FSize != subreacts.FSize) return false;
    for (i=0;i<FSize;i++)
      if (this->FSubreact[i] != subreacts.FSubreact[i]) return false;

    return true;
}

bool MkSubreacts::operator!=(MkSubreacts &subreacts)
{
  return !(*this==subreacts);
}

#ifdef __BCPLUSPLUS__
void MkSubreacts::Draw(TObject *Sender)
{
  for (int i=0;i<FSize;i++)
    FSubreact[i].Draw(Sender);
}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void MkSubreacts::Draw(MkPaint *pb)
{
  for (int i=0;i<FSize;i++)
    FSubreact[i].Draw(pb);
}
#endif
//---------------------------------------------------------------------------
