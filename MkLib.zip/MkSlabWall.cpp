//---------------------------------------------------------------------------
#include "MkSlabWall.h"
#ifdef __BCPLUSPLUS__
#include <vcl.h>
#endif
#pragma hdrstop
//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#pragma package(smart_init)
#endif
//---------------------------------------------------------------------------
MkSlabWall NullSlabWall(0);
MkSlabWall::MkSlabWall()
{
  Number=0;
  DepthTop=0;
  DepthBot = 0;
  Thick=0;
  Length=0;
}
MkSlabWall::MkSlabWall(int n)
{
  Number=0;
  DepthTop=0;
  DepthBot = 0;
  Thick=0;
  Length=0;
}

#ifdef __BCPLUSPLUS__
bool MkSlabWall::UpdateFrom()
{
  if(!Grid) return false;

  Number=Grid->Cells[1][0].ToInt();
  Depth =Grid->Cells[1][1].ToDouble();
//  Area  =Grid->Cells[1][2].ToDouble();
//  Angle =Grid->Cells[1][3].ToDouble();
  Length=Grid->Cells[1][4].ToDouble();

  return true;
}

bool MkSlabWall::UpdateTo()
{
  if(!Grid) return false;

  for(int i=0;i<20;i++) {Grid->Cells[0][i] = "";Grid->Cells[1][i]="";}

  Grid->Cells[0][0] = "Number";
  Grid->Cells[0][1] = "Depth";
  Grid->Cells[0][2] = "Area";
  Grid->Cells[0][3] = "Angle";
  Grid->Cells[0][4] = "Length";
  Grid->Cells[1][0] = Number;
  Grid->Cells[1][1] = Depth;
//  Grid->Cells[1][2] = Area;
//  Grid->Cells[1][3] = Angle;
  Grid->Cells[1][4] = Length;

  return true;
}

void MkSlabWall::Out(TObject *Sender)
{

}
#else
#endif
void MkSlabWall::Out(char *fname)
{

}

bool MkSlabWall::operator==(MkSlabWall &slab)
{
  bool flag = true;
  flag = flag && MkEntity::operator==((MkEntity&)slab);
  flag = flag && Number==slab.Number;
  flag = flag && Depth==slab.Depth;
//  flag = flag && Area==slab.Area;
//  flag = flag && Angle==slab.Angle;
  flag = flag && Length==slab.Length;

  return flag;
}

bool MkSlabWall::operator!=(MkSlabWall &slab)
{
  return !operator==(slab);
}

MkSlabWall & MkSlabWall::operator=(MkSlabWall &slab)
{
  MkEntity::operator=((MkEntity&)slab);
  Number=slab.Number;
  Depth=slab.Depth;
//  Area=slab.Area;
//  Angle=slab.Angle;
  Length=slab.Length;
  return *this;
}

#ifdef __BCPLUSPLUS__
void  MkSlabWall::Draw(TObject *Sender)
{
  SlabWallLine.Draw(Sender);
}
#endif
  
#if defined(_MSC_VER) && defined(_WINDOWS_)
void MkSlabWall::Draw(MkPaint *pb)
{
  SlabWallLine.Draw(pb);
}
#endif


MkSlabWalls::MkSlabWalls(int size,MkSlabWall *slabs)
{

    if (size < 0) {
      MkDebug("::MkSlabWalls - MkSlabWalls(int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSize == 0) {
       FSlabWall = NULL;
       return;
    }

    FSlabWall = new MkSlabWall[FSize];
    for (int i=0;i<FSize;i++) (*this)[i] = slabs[i];
}

MkSlabWalls::MkSlabWalls(int size)
{
    if (size < 0) {
      MkDebug("::MkSlabWalls - MkSlabWalls(int size)");;
      return;
    }

    FSizeOfArray = size;
    FSize = 0;
    if (FSizeOfArray == 0) {
       FSlabWall = NULL;
       return;
    }

    FSlabWall = new MkSlabWall[FSizeOfArray];
}

MkSlabWalls::~MkSlabWalls()
{
   FSizeOfArray = FSize = 0;
   if (FSlabWall) {
      delete[] FSlabWall;
      FSlabWall = NULL;
   }
}


void MkSlabWalls::Initialize(int size)
{
    int i;
    if (size < 0) {
      MkDebug("::MkSlabWalls - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;

    FSizeOfArray = FSize = size;

    if (FSizeOfArray == 0) {
       if (FSlabWall!=NULL) delete[] (MkSlabWall*)FSlabWall;
       FSlabWall = NULL;
       return;
    }

    if (FSlabWall!=NULL) delete[] (MkSlabWall*)FSlabWall;
    FSlabWall = new MkSlabWall[FSizeOfArray];
    for (i=0;i<FSize;i++) FSlabWall[i].Number = i;    
}

void MkSlabWalls::Initialize(int size,MkSlabWall *slabs)
{
    int i;
    if (size < 0 || slabs == NULL) {
      MkDebug("::MkSlabWalls - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSize = FSizeOfArray = size;
    if (FSizeOfArray == 0) {
       if (FSlabWall!=NULL) delete[] (MkSlabWall*)FSlabWall;
       FSlabWall = NULL;
       return;
    }

    if (FSlabWall!=NULL) delete[] (MkSlabWall*)FSlabWall;
    FSlabWall = new MkSlabWall[FSizeOfArray];
    for (i=0;i<FSizeOfArray;i++) FSlabWall[i] = slabs[i];
    for (i=0;i<FSize;i++) FSlabWall[i].Number = i;
}

int MkSlabWalls::Grow(int delta)
{
    int i;
    MkSlabWall *slab=NULL;

    if (!(slab = new MkSlabWall[FSizeOfArray+delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        slab[i] = FSlabWall[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        slab[i] = NullSlabWall;
    if (FSlabWall) {
       delete[] (MkSlabWall*)FSlabWall;
       FSlabWall = NULL;
    }
    FSlabWall = slab;
    FSizeOfArray = FSizeOfArray+delta;
    return FSizeOfArray;
}

int MkSlabWalls::Shrink(int delta)
{
    int i;
    MkSlabWall *slab=NULL;

    if (!(slab = new MkSlabWall[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        slab[i] = FSlabWall[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        slab[i] = NullSlabWall;
    if (FSlabWall) {
       delete[] (MkSlabWall*)FSlabWall;
       FSlabWall = NULL;
    }
    FSlabWall = slab;
    FSizeOfArray = FSizeOfArray-delta;
    return FSizeOfArray;
}

bool MkSlabWalls::Add(MkSlabWall &slab)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    FSize++;
    FSlabWall[FSize-1] = slab;
    return true;
}

bool MkSlabWalls::Add(int index, MkSlabWall &slab)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    for (int i=FSize-1;i>=index;i--)
      FSlabWall[i+1] = FSlabWall[i];
    FSize++;
    FSlabWall[index] = slab;
    return true;
}

bool MkSlabWalls::Delete(MkSlabWall &slab)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FSlabWall[i] == slab) break;
    }
    if(i==FSize) return false;
    if(FSlabWall[i] == slab) {
      for (int j=i;j<FSize-1;j++)
        FSlabWall[j] = FSlabWall[j+1];
    }
    FSize--;
    FSlabWall[FSize] = NullSlabWall;
    return true;
}

bool MkSlabWalls::Delete(int index)
{
    for (int j=index;j<FSize-1;j++)
        FSlabWall[j] = FSlabWall[j+1];

    FSize--;
    FSlabWall[FSize] = NullSlabWall;
    return true;
}

bool MkSlabWalls::Clear()
{
   FSizeOfArray = FSize = 0;
   if (FSlabWall) {
      delete[] FSlabWall;
      FSlabWall = NULL;
   }
   return true;
}

MkSlabWall & MkSlabWalls::operator[](int i)
{
    if (0<=i && i<FSize) return FSlabWall[i];
    else if(FSize<=i && i<FSizeOfArray) {
      FSize=i+1;
      return FSlabWall[i];
    }
    else if (FSizeOfArray <= i) {
      Grow(i-FSizeOfArray+5);
      return NullSlabWall;
    }
    else return NullSlabWall;
}

MkSlabWalls & MkSlabWalls::operator=(MkSlabWalls &slabs)
{
    int i;

    Clear();
    FSize = slabs.FSize;
    FSizeOfArray = slabs.FSizeOfArray;
    if (FSizeOfArray == 0) {
       FSlabWall = NULL;
       return *this;
    }
    this->FSlabWall = new MkSlabWall[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FSlabWall[i] = slabs.FSlabWall[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FSlabWall[i] = NullSlabWall;

    return *this;
}

bool MkSlabWalls::operator==(MkSlabWalls &slabs)
{
    int i;

    if (FSize != slabs.FSize) return false;
    for (i=0;i<FSize;i++)
      if (this->FSlabWall[i] != slabs.FSlabWall[i]) return false;

    return true;
}
#ifdef __BCPLUSPLUS__
void MkSlabWalls::Draw(TObject *Sender)
{
    TColor C;
    float Offset;
    if (FSize == 0) return;
    if (String(Sender->ClassName()) == String("MkPaintBox")) {
       MkPaintBox *pb=(MkPaintBox*)Sender;
       C = pb->Canvas->Pen->Color;
       pb->Canvas->Pen->Color = Color;
       for (int i = 0; i < FSize;i++) {
           Offset = pb->Offset(3);
           FSlabWall[i].Draw(pb);
       }
       pb->Canvas->Pen->Color = C;
    }
}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void MkSlabWalls::Draw(MkPaint *pb)
{

}
#endif
