//---------------------------------------------------------------------------
#ifndef MkBeamSpringH
#define MkBeamSpringH
#include "MkExcavStep.h"
#include "MkLoad.h"
#include "MkSubReact.h"
#include "MkAnalysis.h"

//---------------------------------------------------------------------------
// Ghaboussi & Pecknold
//enum MkDistribType {stNodal, stDistributal,}; obsolete

class MkBeamSpring : public MkAnalysis {
protected:
  float TOL;
  int Iter, MaxIter;
  int PrintStep; // do not change Step, it is fixed within current excav. step solve
  char FileName[256];
  //  MkDistribType LoadType,SpringType; // nodal or distributal, obsolete
  bool Initialized;

  MkLayers *LayRef;
  MkLoads *LoadRef;
  MkSubreacts *SubRef;

  MkStiff Stiff;
  MkMatrix KM;
  MkVector Var; // primary variable for solving, it is used only for showing, so useless.
  MkVector RHS; // initially it is right-hand side vector, but after the solve it contains the variable

  MkFloat U,Upl,Upr,Uyal,Uypl,Uyar,Uypr,Kl,Kr,Pol,Por,Pal,Par,Ppl,Ppr,Pl,Pr,Al,Ar;
  //-----------------------------------
  // U : displacement(Number of step(k), Number of node(n), Axis(x=0 or r=1))
  // Upl : left plastic displacement(k,n,x)
  // Upr : right plastic displacement(k,n,x)
  // Uyal : left active pressure displacement limit
  // Uypl : left passive pressure displacement limit
  // Uyar : right active pressure displacement limit
  // Uypr : right passive pressure displacement limit
  // Kl : left ground spring(k,n,x)
  // Kr : right groudn spring(k,n,x)
  // Pol : left static pressure(k,n,x)
  // Por : right static pressure(k,n,x)
  // Pal : left activ pressure(k,n,x)
  // Par : right activ pressure(k,n,x)
  // Ppl : left passive pressure(k,n,x)
  // Ppr : right passive pressure(k,n,x)
  // Pl : left limit pressure(active or passive)(k,n,x)
  // Pr : right limit pressure(active or passive)(k,n,x)
  // Al : left plastic indicator(k,n,x)
  // Ar : right plastic indicator(k,n,x)
  //-----------------------------------
  MkFloat dU,dUpl,dUpr,dKl,dKr,dPol,dPor,dPl,dPr;
  //-----------------------------------
  // [0] : x-displacement, [1] : z-rotation
  // dU : displacement increment
  // dUpl : left plastic displacement increment
  // dUpr : right plastic displacement increment
  // dKl : left ground spring increment
  // dKr : right ground spring imcrement
  // dPol : left static pressure increment
  // dPor : right static pressure increment
  // dPl : left limit pressure increment
  // dPr : right limit pressure increment
  //-----------------------------------
  MkFloat TotLeftEarthLoad;  // horizontal total load (including water pressure)
  MkFloat TotRightEarthLoad; // horizontal total load (including water pressure)
  MkFloat LeftEarthLoad;  // left horizontal static load
  MkFloat RightEarthLoad; // right horizontal static load
  MkFloat LeftEarthLu;    // left horizontal passive load
  MkFloat RightEarthLu;   // right horizontal passive load
  MkFloat LeftEarthLd;    // left horizontal active load
  MkFloat RightEarthLd;   // right horizontal active load

  MkFloat LeftHydLoad;
  MkFloat RightHydLoad;
  MkNodalForce JackingForce;
  MkNodalForce IniForceCorrect;

  MkFloat LeftNodalKh; // Ground stiffness of left side of nodes
  MkFloat RightNodalKh;  // Ground stiffness of right side of nodes

  MkFloat NodalResultant;  // used at CalcNodalResultant
  MkFloat NodalPress; // used at CalcNodalPress and CalcNodalPress2

#ifdef __BCPLUSPLUS__
  TMemo *Memo;
#endif

public:
  MkBeamSpring(){Initialized = false;TOL=(float)0.00001;AnalysisType=atBeamSpring;PrintStep=10;memset(FileName,'\0',255);NodeRef=NULL;LayRef=NULL;SubRef=NULL;}
  MkBeamSpring(float tol){Initialized = false;TOL=tol;PrintStep=10;memset(FileName,'\0',255);NodeRef=NULL;LayRef=NULL;SubRef=NULL;}
  ~MkBeamSpring(){}
  void SetTOL(float tol){TOL=tol;}
#ifdef __BCPLUSPLUS__
  void SetMemo(TMemo *memo){Memo=memo;}
#endif
  void SetFileName(char *name){strcpy(FileName,name);}
  void SetMaxIter(int m){MaxIter = m;}
  void SetPrint(int s){PrintStep=s;}
  void IncCurStep(){CurStep++;}
  void DecCurStep(){CurStep--;}

  bool Initialize();
  bool Clear();
  bool Setup();
  void CurStepInit();
  void IniCurStepVariable(); // dU,dUpl,dUpr,dKl,dKr,dPol,dPor,dPl,dPr
  void IterUpdate();
  void BuildActiveLoad(); //Pal, Par
  void BuildPassiveLoad(); // Ppl, Ppr
  void BuildStaticLoad(); // Pol, Por
  void BuildSpring(); // Kl, Kr
  void BuildPlasticLimit(); // Uya, Uyp
  void BuildPressureLimit();  // Pl, Pr
  void BuildPlasticIndicator(); // Al, Ar

  void UpdateDisplacement(); // Stiffness matrix
  void UpdateStiff(); // Stiffness matrix
  void UpdatePlasticLimit(); // Pl,Pr
  void UpdatePlasticIndacator(); // Al, Ar

  bool Apply(MkLayers &lay){LayRef = &lay;}
  bool Apply(MkLoads &load){LoadRef = &load;}
  bool Apply(MkSubreacts &sub){SubRef = &sub;}

  void ApplySpring(MkMatrix &mat); // apply ground spring to system matrix 
  bool ApplyNodal(MkSubreact &sub);
  bool ApplyDistributal(MkSubreact &sub);

  bool CalcDistLoad(MkRangeTree &range, MkPolygon &press, MkFloat &load);
  bool CalcEarthLoad(MkLoad *load);
  bool CalcEarthLu(MkLoad *load);
  bool CalcEarthLd(MkLoad *load);
  bool CalcHydLoad(MkLoad *load);

  bool CheckTol(MkVector &f, MkVector &b);
  bool Solve();
  bool Post();
  bool Out();
  MkVector & GetVar(){return Var;}
  MkVector & GetRHS(){return RHS;}
  MkMatrix & GetStiffMatrix(){return Stiff.GetStiffMatrix();}
  MkStiff  & GetStiff(){return Stiff;}
};
#endif
