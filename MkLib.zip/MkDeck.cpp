//---------------------------------------------------------------------------
#include "MkDeck.h"
#ifdef __BCPLUSPLUS__
#include <vcl.h>
#endif
#pragma hdrstop
//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#pragma package(smart_init)
#endif

MkDeck::MkDeck()
{
  isInstalled = false;
  DeckType = dtNone;
  DeckDir = dtPerpend;
  Height = Width = Thick =0;// Y,X,Z for each
  MainBeam = NULL;
}

