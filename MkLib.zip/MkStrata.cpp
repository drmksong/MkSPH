//---------------------------------------------------------------------------
#include "MkStrata.h"
#ifdef __BCPLUSPLUS__
#include <vcl.h>
#endif
#pragma hdrstop
//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#pragma package(smart_init)
#endif
//---------------------------------------------------------------------------
MkStrata NullStrata(0);
MkStratum NullStratum(0);

MkStrata::MkStrata()
{
  Number=0;
#ifdef __BCPLUSPLUS__
  Name=" ";
#else
  memset(Name,'\0',255);
#endif

  WetUnitWeight[0]=0;
  SubUnitWeight[0]=0;
  Cohesion[0]=0;
  Friction[0]=0;
  HorSubReact[0]=0;
  VerSubReact[0]=0;
  WetUnitWeight[1]=0;
  SubUnitWeight[1]=0;
  Cohesion[1]=0;
  Friction[1]=0;
  HorSubReact[1]=0;
  VerSubReact[1]=0;
  Burden=0;
  K0 = 1;
  Ka = 0;
  Kp = 0;
}

MkStrata::MkStrata(int n)
{
  Number=0;
#ifdef __BCPLUSPLUS__
  Name=" ";
#else
  memset(Name,'\0',255);
#endif


  WetUnitWeight[0]=0;
  SubUnitWeight[0]=0;
  Cohesion[0]     =0;
  Friction[0]     =0;
  HorSubReact[0]  =0;
  VerSubReact[0]  =0;
  WetUnitWeight[1]=0;
  SubUnitWeight[1]=0;
  Cohesion[1]     =0;
  Friction[1]     =0;
  HorSubReact[1]  =0;
  VerSubReact[1]  =0;
  Burden          =0;
  K0=1;
  Ka = 0;
  Kp = 0;
}

#ifdef __BCPLUSPLUS__
bool MkStrata::UpdateFrom()
{
  if(!Grid) return false;

  Number          =Grid->Cells[1][0].ToInt();
  Name            =Grid->Cells[1][1];
  WetUnitWeight[0]=Grid->Cells[1][2].ToDouble();
  SubUnitWeight[0]=Grid->Cells[1][3].ToDouble();
  Cohesion[0]     =Grid->Cells[1][4].ToDouble();
  Friction[0]     =Grid->Cells[1][5].ToDouble();
  HorSubReact[0]  =Grid->Cells[1][6].ToDouble();
  VerSubReact[0]  =Grid->Cells[1][7].ToDouble();
  WetUnitWeight[1]=Grid->Cells[1][8].ToDouble();
  SubUnitWeight[1]=Grid->Cells[1][9].ToDouble();
  Cohesion[1]     =Grid->Cells[1][10].ToDouble();
  Friction[1]     =Grid->Cells[1][11].ToDouble();
  HorSubReact[1]  =Grid->Cells[1][12].ToDouble();
  VerSubReact[1]  =Grid->Cells[1][13].ToDouble();

  return true;
}

bool MkStrata::UpdateTo()
{
  if(!Grid) return false;

  for(int i=0;i<20;i++) {Grid->Cells[0][i] = "";Grid->Cells[1][i]="";}

  Grid->Cells[0][0] =  "Number";
  Grid->Cells[0][1] =  "Name";
  Grid->Cells[0][2] =  "WetUnitWeight[0]";
  Grid->Cells[0][3] =  "SubUnitWeight[0]";
  Grid->Cells[0][4] =  "Cohesion[0]";
  Grid->Cells[0][5] =  "Friction[0]";
  Grid->Cells[0][6] =  "HorSubReact[0]";
  Grid->Cells[0][7] =  "VerSubReact[0]";
  Grid->Cells[0][8] =  "WetUnitWeight[1]";
  Grid->Cells[0][9] =  "SubUnitWeight[1]";
  Grid->Cells[0][10] = "Cohesion[1]";
  Grid->Cells[0][11] = "Friction[1]";
  Grid->Cells[0][12] = "HorSubReact[1]";
  Grid->Cells[0][13] = "VerSubReact[1]";

  Grid->Cells[1][0] =  Number;
  Grid->Cells[1][1] =  Name;
  Grid->Cells[1][2] =  WetUnitWeight[0];
  Grid->Cells[1][3] =  SubUnitWeight[0];
  Grid->Cells[1][4] =  Cohesion[0];
  Grid->Cells[1][5] =  Friction[0];
  Grid->Cells[1][6] =  HorSubReact[0];
  Grid->Cells[1][7] =  VerSubReact[0];
  Grid->Cells[1][8] =  WetUnitWeight[1];
  Grid->Cells[1][9] =  SubUnitWeight[1];
  Grid->Cells[1][10] = Cohesion[1];
  Grid->Cells[1][11] = Friction[1];
  Grid->Cells[1][12] = HorSubReact[1];
  Grid->Cells[1][13] = VerSubReact[1];

  return true;
}
#endif


float MkStrata::GetWetUnitWeight(MkPoint &pnt)
{
  return 0;
}

float MkStrata::GetCohesion(MkPoint &pnt)
{
  return 0;
}

float MkStrata::GetFriction(MkPoint &pnt)
{
  return 0;
}

float MkStrata::GetHorSubReact(MkPoint &pnt)
{
  return 0;
}

float MkStrata::GetVerSubReact(MkPoint &pnt)
{
  return 0;
}


float MkStrata::GetWetUnitWeight(MkLine &line)
{
  return 0;
}

float MkStrata::GetCohesion(MkLine &line)
{
  return 0;
}

float MkStrata::GetFriction(MkLine &line)
{
  return 0;
}

float MkStrata::GetHorSubReact(MkLine &line)
{
  return 0;
}

float MkStrata::GetVerSubReact(MkLine &line)
{
  return 0;
}

float MkStrata::InLen(MkLine &line)
{
  return 0;
}

MkLine MkStrata::InLine(MkLine &line)
{
  return NullLine;
}

bool MkStrata::operator==(MkStrata&)
{
  return false;
}

bool MkStrata::operator!=(MkStrata&)
{
  return false;
}

#ifdef __BCPLUSPLUS__
void  MkStrata::Draw(TObject *Sender)
{

}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void MkStrata::Draw(MkPaint *pb)
{

}
#endif
//---------------------------------------------------------------------------
MkStratum::MkStratum(int size,MkStrata *stratum)
{
    if (size < 0) {
      MkDebug("::MkStratum - MkStratum(int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSize == 0) {
       FStrata = NULL;
       return;
    }

    FStrata = new MkStrata[FSizeOfArray];
    for (int i=0;i<FSizeOfArray;i++) (*this)[i] = stratum[i];
}

MkStratum::MkStratum(int size)
{
    if (size < 0) {
      MkDebug("::MkStratum - MkStratum(int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSize == 0) {
       FStrata = NULL;
       return;
    }

    FStrata = new MkStrata[FSizeOfArray];
}

MkStratum::~MkStratum()
{
   FSizeOfArray = FSize = 0;
   if (FStrata) {
      delete[] FStrata;
      FStrata = NULL;
   }
}

void MkStratum::Initialize(int size)
{
    int i;
    if (size < 0) {
      MkDebug("::MkStratum - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray== size) return;

    FSizeOfArray=FSize=size;

    if (FSizeOfArray== 0) {
       if (FStrata!=NULL) delete[] (MkStrata*)FStrata;
       FStrata = NULL;
       return;
    }

    if (FStrata!=NULL) delete[] (MkStrata*)FStrata;
    FStrata = new MkStrata[FSizeOfArray];
    for(i=0;i<FSize;i++) FStrata[i].Number = i;
}

void MkStratum::Initialize(int size,MkStrata *stratum)
{
    int i;
    if (size < 0 || stratum == NULL) {
      MkDebug("::MkStratum - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSize= size;

    if (FSizeOfArray== 0) {
       if (FStrata!=NULL) delete[] (MkStrata*)FStrata;
       FStrata = NULL;
       return;
    }

    if (FStrata!=NULL) delete[] (MkStrata*)FStrata;
    FStrata = new MkStrata[FSizeOfArray];
    for(i=0;i<FSizeOfArray;i++) FStrata[i] = stratum[i];
    for(i=0;i<FSize;i++) FStrata[i].Number = i;
}

int MkStratum::Grow(int delta)
{
    int i;
    MkStrata *strata=NULL;

    if (!(strata = new MkStrata[FSizeOfArray+delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        strata[i] = FStrata[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        strata[i] = NullStrata;
    if (FStrata) {
       delete[] (MkStrata*)FStrata;
       FStrata = NULL;
    }
    FStrata = strata;
    FSizeOfArray = FSizeOfArray+delta;
    return FSizeOfArray;
}

int MkStratum::Shrink(int delta)
{
    int i;
    MkStrata *strata=NULL;

    if (!(strata = new MkStrata[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        strata[i] = FStrata[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        strata[i] = NullStrata;
    if (FStrata) {
       delete[] (MkStrata*)FStrata;
       FStrata = NULL;
    }
    FStrata = strata;
    FSizeOfArray = FSizeOfArray-delta;
    return FSizeOfArray;
}

bool MkStratum::Add(MkStrata &strata)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    FSize++;
    FStrata[FSize-1] = strata;
    return true;
}

bool MkStratum::Add(int index, MkStrata &strata)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    for (int i=FSize-1;i>=index;i--)
      FStrata[i+1] = FStrata[i];
    FSize++;
    FStrata[index] = strata;
    return true;
}

bool MkStratum::Delete(MkStrata &strata)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FStrata[i] == strata) break;
    }
    if(i==FSize) return false;
    if(FStrata[i] == strata) {
      for (int j=i;j<FSize-1;j++)
        FStrata[j] = FStrata[j+1];
    }
    FSize--;
    FStrata[FSize] = NullStrata;
    return true;
}

bool MkStratum::Delete(int index)
{
    for (int j=index;j<FSize-1;j++)
        FStrata[j] = FStrata[j+1];

    FSize--;
    FStrata[FSize] = NullStrata;
    return true;
}

bool MkStratum::Clear()
{
   FSize = 0;
   if (FStrata) {
      delete[] FStrata;
      FStrata = NULL;
   }
   return true;
}

MkStrata & MkStratum::operator[](int i)
{
    if (0<=i && i<FSize) return FStrata[i];
    else if(FSize<=i && i<FSizeOfArray) {
      FSize=i+1;
      return FStrata[i];
    }
    else if (FSizeOfArray <= i) {
      Grow(i-FSizeOfArray+5);
      return NullStrata;
    }
    else return NullStrata;
}

MkStratum & MkStratum::operator=(MkStratum &stratum)
{
    int i;

    Clear();
    FSize = stratum.FSize;
    FSizeOfArray = stratum.FSizeOfArray;

    if (FSizeOfArray == 0) {
       FStrata = NULL;
       return *this;
    }
    this->FStrata = new MkStrata[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FStrata[i] = stratum.FStrata[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FStrata[i] = NullStrata;

    return *this;
}

bool MkStratum::operator==(MkStratum &stratum)
{
    int i;

    if (FSize != stratum.FSize) return false;
    for (i=0;i<FSize;i++)
      if (this->FStrata[i] != stratum.FStrata[i]) return false;

    return true;
}

#ifdef __BCPLUSPLUS__
void MkStratum::Draw(TObject *Sender)
{
    TColor C;
    float Offset;
    if (FSize == 0) return;
    if (String(Sender->ClassName()) == String("MkPaintBox")) {
       MkPaintBox *pb=(MkPaintBox*)Sender;
       C = pb->Canvas->Pen->Color;
       pb->Canvas->Pen->Color = Color;
       for (int i = 0; i < FSize;i++) {
           Offset = pb->Offset(3);
           FStrata[i].Draw(pb);
       }
       pb->Canvas->Pen->Color = C;
    }
}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void MkStratum::Draw(MkPaint *pb)
{

}
#endif
//---------------------------------------------------------------------------

