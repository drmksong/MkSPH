//---------------------------------------------------------------------------
#include "MkReader.h"

MkGeomReader::MkGeomReader()
{
    memo = (TObject*)NULL;
    memset(FileName,'\0',sizeof(FileName));
}

MkGeomReader::MkGeomReader(TObject *Sender)
{
    memo = dynamic_cast<TMemo *>(Sender);
    memset(FileName,'\0',sizeof(FileName));
}

MkGeomReader::~MkGeomReader()
{

}

void MkGeomReader::SetMemo(TObject *Sender)
{
    memo = dynamic_cast<TMemo *>(Sender);
    memo->Lines->Add("Memo is assigned to GeomReader!");
}

MkShapeList & MkGeomReader::ReadFile()
{
      char str[256],key[100],dmmy[100];
      MkPoint start_point, end_point;
      MkPoint center_point;
      float radius, start_ang, end_ang;
      float x1,y1,z1,x2,y2,z2;

      MkShapeList tmp_shape_list;
      TStringList  *tmp_string_list = new TStringList;

      int shape_count = 0;
      Key key_index;

      FP = fopen(FileName,"r");
      if (!FP) {
         delete tmp_string_list;
         return ShapeList;
      }

      fgets(str,255,FP);
      if (!strncmp(str,"#start",6)) {
         while (!feof(FP) && strncmp(str,"#end",4) ) {
             fgets(str,255,FP);
             sscanf(str,"%s",key);

             if (!strncmp(key,"#dummy_line",11)) {
                 key_index = dummy_line;
                 shape_count++;
             }
             else if (!strncmp(key,"#line",5)) {
                 key_index = line;
                 shape_count++;
             }
             else if (!strncmp(key,"#arc_by_line",12)) {
                 key_index = arc_by_line;
                 shape_count++;
             }
             else if (!strncmp(key,"#arc",4)) {
                 key_index = arc;
                 shape_count++;
             }
             else key_index = none;

             switch (key_index) {
                case dummy_line :
                     sscanf(str,"%s %f %f %f %f %f %f",&dmmy,&x1,&y1,&z1,&x2,&y2,&z2);
                     start_point.SetPoint(x1,y1,z1);
                     end_point.SetPoint(x2,y2,z2);
                     break;
                case line :
                     sscanf(str,"%s %f %f %f %f %f %f",&dmmy,&x1,&y1,&z1,&x2,&y2,&z2);
                     start_point.SetPoint(x1,y1,z1);
                     end_point.SetPoint(x2,y2,z2);
                     break;
                case arc_by_line :
                     sscanf(str,"%s %f %f %f %f %f %f",&dmmy,&x1,&y1,&z1,&x2,&y2,&z2);
                     start_point.SetPoint(x1,y1,z1);
                     end_point.SetPoint(x2,y2,z2);
                     break;
                case arc :
                     sscanf(str,"%s %f %f %f %f %f %f",&dmmy,&x1,&y1,&z1,&radius,&start_ang,&end_ang);
                     break;
                default : break;
             }

             if (key_index == line) {
                 tmp_shape_list.Add(new MkLine(start_point,end_point,clWhite));
                 tmp_string_list->Add(key);
             }

             if (key_index == dummy_line) {
                 tmp_shape_list.Add(new MkLine(start_point,end_point,clGray));
                 tmp_string_list->Add(key);
             }

             else if (key_index == arc) {
                 tmp_shape_list.Add(new MkCircle());
                 tmp_string_list->Add(key);
             }

             else if (key_index == arc_by_line) {
                 tmp_shape_list.Add(new MkCircle());
                 tmp_string_list->Add(key);
             }
         }
      }

      if (tmp_string_list->Strings[0].AnsiCompare("#line")
       && tmp_string_list->Strings[0].AnsiCompare("#dummy_line") ) {
          fclose(FP);
          delete tmp_string_list;
          return ShapeList;
      }

      if (memo) {
         AnsiString AStr = " Number of shape is "+AnsiString(shape_count);
         memo->Lines->Add(AStr);
         for (int i = 0; i < shape_count;i++) {
             memo->Lines->Add(tmp_string_list->Strings[i]);
         }
         ShapeList = tmp_shape_list;
         memo->Lines->Add(" List of shape is assigned.");
      }

      fclose(FP);
      FRealPolygon.Initialize(ShapeList.GetNumberOfShape());
      for (int i=0;i<ShapeList.GetNumberOfShape();i++) {
          if (!tmp_string_list->Strings[i].AnsiCompare("#line")){
             MkLine *rlp = dynamic_cast<MkLine *>(&ShapeList[i]);
             FRealPolygon[i] = (*rlp)[0];
          }
      }

      delete tmp_string_list;
      return ShapeList;
}

MkShapeList & MkGeomReader::ReadFile(char *file_name)
{
     SetFileName(file_name);
     return ReadFile();
}

MkPoint & MkGeomReader::operator[](int i)
{
     return FRealPolygon[i];
}

//---------------------------------------------------------------------------

MkRailWayReader::MkRailWayReader()
{
    memo = (TObject*)NULL;
    memset(FileName,'\0',sizeof(FileName));
}

MkRailWayReader::MkRailWayReader(TObject *Sender)
{
    memo = dynamic_cast<TMemo *>(Sender);
    memset(FileName,'\0',sizeof(FileName));
}

MkRailWayReader::~MkRailWayReader()
{

}

void MkRailWayReader::SetMemo(TObject *Sender)
{
    memo = dynamic_cast<TMemo *>(Sender);
    memo->Lines->Add("Memo is assigned to GeomReader!");
}

bool MkRailWayReader::ReadFile()
{
      char str[256];
      int i;
      int count;
      float dmy[7];
      MkPoint *rp,*rp2;

      Float station;

      FP = fopen(FileName,"r");
      if (!FP) {
         return false;
      }

      memset(str,'\0',255);
      
      fgets(str,255,FP);

      if (strncmp(str,"RailWay",7)) {
         fclose(FP);
         return false;
      }

      count = 0;
      while(!feof(FP)) {
         if (!fgets(str,255,FP)) break;
         sscanf(str,"%f %f %f %f %f %f %f",&dmy[0],&dmy[1],&dmy[2],&dmy[3],&dmy[4],&dmy[5],&dmy[6],&dmy[7]);
         if (dmy[0]||dmy[1]||dmy[2]||dmy[3]||dmy[4]||dmy[5]||dmy[6]||dmy[7]) count++;
      }

      station.Initialize(count);
      rp = new MkPoint[count];
      if (NumOfLine == 2) rp2 = new MkPoint[count];

      rewind(FP);
      fgets(str,255,FP);

      if (strncmp(str,"RailWay",7)) {
         fclose(FP);
         return false;
      }

      count = 0;
      XMin = YMin = 100000000;
      XMax = YMax = -100000000;
      // delete it from here
/*      char fname[256];
      memset(fname,'\0',255);
      strncpy(fname,FileName,strlen(FileName)-4);
      strcat(fname,".mod");
      FILE *fp1 = fopen(fname,"w");
*/      // delete it to

      while(!feof(FP)) {
         if (!fgets(str,255,FP)) break;
         if (NumOfLine == 1) sscanf(str,"%f %f %f %f",&station(count),&rp[count].X,&rp[count].Y,&rp[count].Z);
         else if (NumOfLine == 2) sscanf(str,"%f %f %f %f %f %f %f",&station(count),
                                    &rp[count].X,&rp[count].Y,&rp[count].Z,
                                    &rp2[count].X,&rp2[count].Y,&rp2[count].Z);
//       delete it from here
/*         MkPoint a(204437.5249,230310.8786,0);
         MkPoint b(203185.0353,233522.7656,0);
         float dmy;
         dmy = rp[count].X;
         rp[count].X = rp[count].Y;
         rp[count].Y = dmy;
         rp[count] = rp[count] - b;
         rp[count].Rotate(27,0,0);
         rp[count] = rp[count] + a;
         if (NumOfLine == 2) {
            dmy = rp2[count].X;
            rp2[count].X = rp2[count].Y;
            rp2[count].Y = dmy;
            rp2[count] = rp2[count] - b;
            rp2[count].Rotate(27,0,0);
            rp2[count] = rp2[count] + a;
         }
         fprintf(fp1,"%f %f %f %f %f %f %f\n",station(count),
           rp[count].X,rp[count].Y,rp[count].Z,
           rp2[count].X,rp2[count].Y,rp2[count].Z);
*/ //       delete it to
         if (XMin > rp[count].X) XMin = rp[count].X;
         if (XMax < rp[count].X) XMax = rp[count].X;
         if (YMin > rp[count].Y) YMin = rp[count].Y;
         if (YMax < rp[count].Y) YMax = rp[count].Y;

         if (NumOfLine == 2) {
           if (XMin > rp2[count].X) XMin = rp2[count].X;
           if (XMax < rp2[count].X) XMax = rp2[count].X;
           if (YMin > rp2[count].Y) YMin = rp2[count].Y;
           if (YMax < rp2[count].Y) YMax = rp2[count].Y;
         }
         str[strlen(str)] = '\0';
         memo->Lines->Add(str);
         count++;
      }
      // delete it from here
      // if (fp1) fclose(fp1);
      // delete it to

      FRailWay.Initialize(count,rp,station);
      if(NumOfLine == 2) FRailWay2.Initialize(count,rp2,station);

      delete[] rp;
      if(NumOfLine == 2) delete[] rp2;

      fclose(FP);
      return true;
}

bool MkRailWayReader::ReadFile(char *file_name)
{
     SetFileName(file_name);
     return ReadFile();
}

MkPoint MkRailWayReader::operator()(int k,int i,float j)
{
     if (k==1) return FRailWay(i,j);
     else if (k==2) return FRailWay2(i,j);
     else return NullPoint;
}

MkPoint MkRailWayReader::operator()(int i,float j)
{
     return FRailWay(i,j);
}

bool MkRailWayReader::SaveLayerData()
{
     char filename[256];
     char ext[256];
     FILE *fp;

     for (int i = 0 ; i < 256;i++) filename[i] = '\0';

     strcpy(ext,ExtractFileExt(AnsiString(FileName)).c_str());
     strncpy(filename,FileName,strlen(FileName)-strlen(ext));
     strcat(filename,".lay");

     fp = fopen(filename,"w");

     if (fp == NULL) {
        return false;
     }
     for (int i = 0 ; i < FRailWay.Station.getSzX();i++){
         int I;float J;
         I = int(FRailWay.Station(i)/1000);
         J = FRailWay.Station(i) - I*1000;
         fprintf(fp," %f %f %f %f %f\n",(*this)(I,J).X,(*this)(I,J).Y,
                                      FRailWay.FirstLayerDepth(i),
                                      FRailWay.SecondLayerDepth(i),
                                      FRailWay.ThirdLayerDepth(i));
     }

     fclose(fp);
     return true;
}

bool MkRailWayReader::SaveLayerData(char *fname)
{
     char filename[256];
     char ext[256];
     char str[256];
     FILE *fp,*fpin;
     float station;

     for (int i = 0 ; i < 256;i++) filename[i] = '\0';

     strcpy(ext,ExtractFileExt(AnsiString(FileName)).c_str());
     strncpy(filename,FileName,strlen(FileName)-strlen(ext));
     strcat(filename,".lay");

     fp = fopen(filename,"w");
     if (fp == NULL) {
        return false;
     }

     fpin = fopen(fname,"r");
     if (fpin == NULL) {
        fclose(fp);
        return false;
     }

     while(!feof(fpin)) {
        int dmmy = 0;
        fgets(str,255,fpin);
        sscanf(str,"%d",&dmmy); if (dmmy == 0) continue;
        sscanf(str,"%f",&station);
        sscanf(str,"%s",ext);
        strcpy(filename,str+strlen(ext));
        int I;float J;
        I = int(station/1000);
        J = station - I*1000;
        fprintf(fp,"%f %f %s",(*this)(I,J).X,(*this)(I,J).Y,filename);
     }

     fclose(fp);fclose(fpin);
     return true;
}

//---------------------------------------------------------------------------
MkGridReader::MkGridReader()
{
    memo = (TObject*)NULL;
    memset(GridFileName,'\0',sizeof(GridFileName));
}

MkGridReader::MkGridReader(TObject *Sender)
{
    memo = dynamic_cast<TMemo *>(Sender);
    memset(GridFileName,'\0',sizeof(GridFileName));
}

MkGridReader::~MkGridReader()
{

}

void MkGridReader::SetMemo(TObject *Sender)
{
    memo = dynamic_cast<TMemo *>(Sender);
    memo->Lines->Add("Memo is assigned to GeomReader!");
}

bool MkGridReader::ReadFile(char *file_name)
{
     SetGridFileName(file_name);
     return ReadFile();
}

bool MkGridReader::ReadTomoFile(char *file_name)
{
     SetTomoFileName(file_name);
     return ReadTomoFile();
}

bool MkGridReader::SaveFile(char *file_name)
{
     SetFldFileName(file_name);
     return SaveFile();
}

bool MkGridReader::SaveGrid(char *file_name)
{
     SetGridFileName(file_name);
     return SaveGrid();
}

bool MkGridReader::SaveLayerFile(char *file_name)
{
     SetLayerFileName(file_name);
     return SaveLayerFile();
}

void MkGridReader::SetLayerFileName(char *file_name)
{
//     char str[256];
     char FileName[256];
     char Path[256];
     char Ext[256];

     if (!strlen(file_name)) return;

     strcpy(FileName,ExtractFileName(AnsiString(file_name)).c_str());
     strcpy(Path,ExtractFilePath(AnsiString(file_name)).c_str());
     strcpy(Ext,ExtractFileExt(AnsiString(file_name)).c_str());
     strcpy(LayerFldFileName1,Path);
     strcpy(LayerFldFileName2,Path);
     strcpy(LayerFldFileName3,Path);
     strcpy(LayerFldFileName4,Path);
     strcpy(LayerFldFileName5,Path);
     strncat(LayerFldFileName1,FileName,strlen(FileName)-strlen(Ext));
     strncat(LayerFldFileName2,FileName,strlen(FileName)-strlen(Ext));
     strncat(LayerFldFileName3,FileName,strlen(FileName)-strlen(Ext));
     strncat(LayerFldFileName4,FileName,strlen(FileName)-strlen(Ext));
     strncat(LayerFldFileName5,FileName,strlen(FileName)-strlen(Ext));

     strcat(LayerFldFileName1,"1");
     strcat(LayerFldFileName2,"2");
     strcat(LayerFldFileName3,"3");
     strcat(LayerFldFileName4,"4");
     strcat(LayerFldFileName5,"5");

     strcat(LayerFldFileName1,Ext);
     strcat(LayerFldFileName2,Ext);
     strcat(LayerFldFileName3,Ext);
     strcat(LayerFldFileName4,Ext);
     strcat(LayerFldFileName5,Ext);
};

bool MkGridReader::SaveCutFile(char *file_name)
{
     SetCutFileName(file_name);
     return SaveCutFile();
}

bool MkGridReader::ReadFile()
{
      char str[256];
      long i,j;

      FP = fopen(GridFileName,"r");
      if (!FP) {
         return false;
      }

      fgets(str,255,FP);

      if (strncmp(str,"DSAA",4)) {
         fclose(FP);
         return false;
      }

      fgets(str,255,FP);
      sscanf(str, "%d %d",&NX,&NY);
      Side.Initialize(NX,NY);

      fgets(str,255,FP);
      sscanf(str,"%f %f",&XMin,&XMax);

      fgets(str,255,FP);
      sscanf(str,"%f %f",&YMin,&YMax);

      fgets(str,255,FP);
      sscanf(str,"%f %f",&DataMin,&DataMax);

      X.Initialize(NX);
      Y.Initialize(NY);
      Z.Initialize(NY);
      Data.Initialize(NX,NY);

      float xstep,ystep;
      xstep = (XMax - XMin)/(NX+1);
      ystep = (YMax - YMin)/(NY+1);
      for (i=0;i< NX;i++) {
          X[i] = XMin + i*xstep;
      }

      for (i=0;i< NY;i++) {
          Y[i] = YMin + i*ystep;
      }

      for (i=0;i< NY;i++) {
          Z[i] = YMin + i*ystep;
      }

      for (j=0;j<NY;j++)
        for (i=0;i<NX;i++) {
          fscanf(FP,"%f",&Data[(int)i][j]);
        }

      fclose(FP);
      return true;
}

bool MkGridReader::ReadFirstLayerFile()
{
      char str[256];
      long i,j;

      FP = fopen(FirstLayerName,"r");
      if (!FP) {
         return false;
      }

      fgets(str,255,FP);

      if (strncmp(str,"DSAA",4)) {
         fclose(FP);
         return false;
      }

      fgets(str,255,FP);
      sscanf(str, "%d %d",&NX,&NY);

      fgets(str,255,FP);
      sscanf(str,"%f %f",&XMin,&XMax);

      fgets(str,255,FP);
      sscanf(str,"%f %f",&YMin,&YMax);

      fgets(str,255,FP);
      sscanf(str,"%f %f",&DataMin,&DataMax);

      FirstLayerData.Initialize(NX,NY);

      float xstep,ystep;
      xstep = (XMax - XMin)/(NX+1);
      ystep = (YMax - YMin)/(NY+1);
      for (i=0;i< NX;i++) {
          X[i] = XMin + i*xstep;
      }

      for (i=0;i< NY;i++) {
          Y[i] = YMin + i*ystep;
      }

      for (i=0;i< NY;i++) {
          Z[i] = YMin + i*ystep;
      }

      for (j=0;j<NY;j++)
        for (i=0;i<NX;i++) {
          fscanf(FP,"%f",&FirstLayerData[(int)i][j]);
        }

      fclose(FP);
      return true;
}

bool MkGridReader::SaveFirstLayerGridFile()
{
      char str[256];
      long i,j;
      float datamin=10000000,datamax=-10000000;

      FP = fopen(FirstLayerGridName,"w");
      if (!FP) {
         return false;
      }

      fputs("DSAA\n",FP);

      sprintf(str, "%d %d\n",NX,NY);
      fputs(str,FP);

      sprintf(str,"%f %f\n",XMin,XMax);
      fputs(str,FP);

      sprintf(str,"%f %f\n",YMin,YMax);
      fputs(str,FP);

      for (j=0;j<NY;j++){
        for (i=0;i<NX;i++) {
          datamin = datamin > Data[int(i)][j]-FirstLayerData[(int)i][j] ? Data[int(i)][j]-FirstLayerData[(int)i][j] : datamin;
          datamax = datamax < Data[int(i)][j]-FirstLayerData[(int)i][j] ? Data[int(i)][j]-FirstLayerData[(int)i][j] : datamax;
        }
      }

      sprintf(str,"%f %f\n",datamin,datamax);
      fputs(str,FP);

      int cnt;


      for (j=0;j<NY;j++){
        cnt=0;
        for (i=0;i<NX;i++) {
          cnt++;
          fprintf(FP,"%10.4f ",Data[int(i)][j]-FirstLayerData[(int)i][j]);
          if (cnt>9) {fputs("\n",FP);cnt=0;}
        }
        fputs("\n\n",FP);
      }

      fclose(FP);
      return true;
}


bool MkGridReader::ReadSecondLayerFile()
{
      char str[256];
      long i,j;

      FP = fopen(SecondLayerName,"r");
      if (!FP) {
         return false;
      }

      fgets(str,255,FP);

      if (strncmp(str,"DSAA",4)) {
         fclose(FP);
         return false;
      }

      fgets(str,255,FP);
      sscanf(str, "%d %d",&NX,&NY);

      fgets(str,255,FP);
      sscanf(str,"%f %f",&XMin,&XMax);

      fgets(str,255,FP);
      sscanf(str,"%f %f",&YMin,&YMax);

      fgets(str,255,FP);
      sscanf(str,"%f %f",&DataMin,&DataMax);

      SecondLayerData.Initialize(NX,NY);

      float xstep,ystep;
      xstep = (XMax - XMin)/(NX+1);
      ystep = (YMax - YMin)/(NY+1);
      for (i=0;i< NX;i++) {
          X[i] = XMin + i*xstep;
      }

      for (i=0;i< NY;i++) {
          Y[i] = YMin + i*ystep;
      }

      for (i=0;i< NY;i++) {
          Z[i] = YMin + i*ystep;
      }

      for (j=0;j<NY;j++)
        for (i=0;i<NX;i++) {
          fscanf(FP,"%f",&SecondLayerData[(int)i][j]);
        }

      fclose(FP);
      return true;
}

bool MkGridReader::SaveSecondLayerGridFile()
{
      char str[256];
      long i,j;
      float datamin=10000000,datamax=-10000000;

      FP = fopen(SecondLayerGridName,"w");
      if (!FP) {
         return false;
      }

      fputs("DSAA\n",FP);

      sprintf(str, "%d %d\n",NX,NY);
      fputs(str,FP);

      sprintf(str,"%f %f\n",XMin,XMax);
      fputs(str,FP);

      sprintf(str,"%f %f\n",YMin,YMax);
      fputs(str,FP);

      for (j=0;j<NY;j++){
        for (i=0;i<NX;i++) {
          datamin = datamin > Data[int(i)][j]-FirstLayerData[(int)i][j]-SecondLayerData[(int)i][j] ? Data[int(i)][j]-FirstLayerData[(int)i][j]-SecondLayerData[(int)i][j] : datamin;
          datamax = datamax < Data[int(i)][j]-FirstLayerData[(int)i][j]-SecondLayerData[(int)i][j] ? Data[int(i)][j]-FirstLayerData[(int)i][j]-SecondLayerData[(int)i][j] : datamax;
        }
      }

      sprintf(str,"%f %f\n",datamin,datamax);
      fputs(str,FP);

      int cnt;

      for (j=0;j<NY;j++) {
        cnt = 0;
        for (i=0;i<NX;i++) {
          cnt++;
          fprintf(FP,"%10.4f ",Data[int(i)][j]-FirstLayerData[(int)i][j]-SecondLayerData[(int)i][j]);
          if (cnt>9) {fputs("\n",FP);cnt=0;}
        }
        fputs("\n\n",FP);
      }

      fclose(FP);
      return true;
}

bool MkGridReader::ReadThirdLayerFile()
{
      char str[256];
      long i,j;

      FP = fopen(ThirdLayerName,"r");
      if (!FP) {
         return false;
      }

      fgets(str,255,FP);

      if (strncmp(str,"DSAA",4)) {
         fclose(FP);
         return false;
      }

      fgets(str,255,FP);
      sscanf(str, "%d %d",&NX,&NY);

      fgets(str,255,FP);
      sscanf(str,"%f %f",&XMin,&XMax);

      fgets(str,255,FP);
      sscanf(str,"%f %f",&YMin,&YMax);

      fgets(str,255,FP);
      sscanf(str,"%f %f",&DataMin,&DataMax);

      ThirdLayerData.Initialize(NX,NY);

      float xstep,ystep;
      xstep = (XMax - XMin)/(NX+1);
      ystep = (YMax - YMin)/(NY+1);
      for (i=0;i< NX;i++) {
          X[i] = XMin + i*xstep;
      }

      for (i=0;i< NY;i++) {
          Y[i] = YMin + i*ystep;
      }

      for (i=0;i< NY;i++) {
          Z[i] = YMin + i*ystep;
      }


      for (j=0;j<NY;j++) {
        for (i=0;i<NX;i++) {
          fscanf(FP,"%f",&ThirdLayerData[(int)i][j]);
        }
      }

      fclose(FP);
      return true;
}

bool MkGridReader::ReadFourthLayerFile()
{
      char str[256];
      long i,j;

      FP = fopen(FourthLayerName,"r");
      if (!FP) {
         return false;
      }

      fgets(str,255,FP);

      if (strncmp(str,"DSAA",4)) {
         fclose(FP);
         return false;
      }

      fgets(str,255,FP);
      sscanf(str, "%d %d",&NX,&NY);

      fgets(str,255,FP);
      sscanf(str,"%f %f",&XMin,&XMax);

      fgets(str,255,FP);
      sscanf(str,"%f %f",&YMin,&YMax);

      fgets(str,255,FP);
      sscanf(str,"%f %f",&DataMin,&DataMax);

      FourthLayerData.Initialize(NX,NY);

      float xstep,ystep;
      xstep = (XMax - XMin)/(NX+1);
      ystep = (YMax - YMin)/(NY+1);
      for (i=0;i< NX;i++) {
          X[i] = XMin + i*xstep;
      }

      for (i=0;i< NY;i++) {
          Y[i] = YMin + i*ystep;
      }

      for (i=0;i< NY;i++) {
          Z[i] = YMin + i*ystep;
      }


      for (j=0;j<NY;j++) {
        for (i=0;i<NX;i++) {
          fscanf(FP,"%f",&FourthLayerData[(int)i][j]);
        }
      }

      fclose(FP);
      return true;
}

bool MkGridReader::ReadFifthLayerFile()
{
      char str[256];
      long i,j;

      FP = fopen(FifthLayerName,"r");
      if (!FP) {
         return false;
      }

      fgets(str,255,FP);

      if (strncmp(str,"DSAA",4)) {
         fclose(FP);
         return false;
      }

      fgets(str,255,FP);
      sscanf(str, "%d %d",&NX,&NY);

      fgets(str,255,FP);
      sscanf(str,"%f %f",&XMin,&XMax);

      fgets(str,255,FP);
      sscanf(str,"%f %f",&YMin,&YMax);

      fgets(str,255,FP);
      sscanf(str,"%f %f",&DataMin,&DataMax);

      FifthLayerData.Initialize(NX,NY);

      float xstep,ystep;
      xstep = (XMax - XMin)/(NX+1);
      ystep = (YMax - YMin)/(NY+1);
      for (i=0;i< NX;i++) {
          X[i] = XMin + i*xstep;
      }

      for (i=0;i< NY;i++) {
          Y[i] = YMin + i*ystep;
      }

      for (i=0;i< NY;i++) {
          Z[i] = YMin + i*ystep;
      }


      for (j=0;j<NY;j++) {
        for (i=0;i<NX;i++) {
          fscanf(FP,"%f",&FifthLayerData[(int)i][j]);
        }
      }

      fclose(FP);
      return true;
}

bool MkGridReader::ReadTomoFile()
{
      char str[256],str2[256];
      float station, nx,ny;

      FP = fopen(TomoFileName,"r");
      if (!FP) {
         return false;
      }

      fgets(str,255,FP);

      if (strncmp(str,"#Tomography",11)) {
         fclose(FP);
         return false;
      }

      fgets(str,255,FP);
      sscanf(str,"%s %f %f %f",str2,&station,&nx,&ny);
      NX = nx;
      NY = ny;

      X.Initialize(NX);
      Y.Initialize(NX);
      Z.Initialize(NY);
      Data.Initialize(NX,NY);

      for (long j = 0; j < NY ; j++ )
        for (long i = 0 ; i < NX ; i++) {
          fgets(str,255,FP);
          float x,y,z,data;
          sscanf(str,"%f %f %f %f\n",&x,&y,&z,&data);
          X(i)=x;Y(i)=y;Z(j)=z;Data(i,j)=data;
        }

      fclose(FP);
      return true;
}

void MkGridReader::SetSide()
{
    Side.Initialize(NX,NY);
}

void MkGridReader::ClearSide()
{
    Side.Clear();
}

void MkGridReader::SetupSide()
{
    MkPoint rp,sp,ep;
    MkLine rl;
//    float x,y;
    float cross=1;
    float side=1;
    float min_dist;
    int   Nearest;
    float dist[3],d;

    for (int i=0;i<NX;i++) {
        for (int j=0;j<NY;j++) {
//            float x,y;//,elev[3];
//            x = X(i);
//            y = Y(j);
            rp.X = X(i);
            rp.Y = Y(j);
            rp.Z = 0;
            min_dist = 10000000000;
            for (int l=0;l<FRailWay.GetSize()-1;l++) {
                sp.X = FRailWay[l].X;
                sp.Y = FRailWay[l].Y;
                sp.Z = 0;
                dist[0] = CalDist(sp,rp);
                ep.X = FRailWay[l+1].X;
                ep.Y = FRailWay[l+1].Y;
                ep.Z = 0;
                dist[1] = CalDist(ep,rp);
                dist[2] = (dist[0] + dist[1])/2;
                if (min_dist > dist[2]) {
                   Nearest = l;
                   min_dist = dist[2];
                }
            }
            sp.X = FRailWay[Nearest].X;
            sp.Y = FRailWay[Nearest].Y;
            sp.Z = 0;
            ep.X = FRailWay[Nearest+1].X;
            ep.Y = FRailWay[Nearest+1].Y;
            ep.Z = 0;

            rl.SetLine(sp,ep);
            cross = rl * rp;

            d = rl.CalDist(rp);
            if (cross < 0) {
               side = -d;
            }
            else if (cross > 0) {
               side = d;
            }
            else if (fabs(cross) <0.1) {
               side = 0;
            }
            Side(i,j) = side;
        }
    }
}

bool MkGridReader::SaveFile()
{
    FILE *fp;
    char str[256];

    fp = fopen(FldFileName,"w");
    if (!fp) {
       return false;
    }

    fprintf(fp,"# AVS field file %s\n",FldFileName);
    fprintf(fp,"ndim = %d\n",2);
    fprintf(fp,"dim1 = %d\n",NX);
    fprintf(fp,"dim2 = %d\n",NY);
    fprintf(fp,"nspace = %d\n",3);
    if ( Side.getSzX() * Side.getSzY() != 0)   // Side �� ������ �Ǿ��ִ���
      fprintf(fp,"veclen = %d\n",2);           // �ƴ����� ���� �޶�����.
    else if (Side.getSzX() * Side.getSzY() == 0)
      fprintf(fp,"veclen = %d\n",1);
    fprintf(fp,"data = float\n");
    fprintf(fp,"field = irregular\n");
    if ( Side.getSzX() * Side.getSzY() != 0)
      fprintf(fp,"label = Elevation Side\n");
    else if (Side.getSzX() * Side.getSzY() == 0)
      fprintf(fp,"label = Elevation \n");

    if ( Side.getSzX() * Side.getSzY() == 0) {
      fprintf(fp,"variable 1 filetype=ascii skip= 0 offset=2 stride=3\n");
      fprintf(fp,"coord    1 filetype=ascii skip= 0 offset=0 stride=3\n");
      fprintf(fp,"coord    2 filetype=ascii skip= 0 offset=1 stride=3\n");
      fprintf(fp,"coord    3 filetype=ascii skip= 0 offset=2 stride=3\n");
    }

    if ( Side.getSzX() * Side.getSzY() != 0) {
      fprintf(fp,"variable 1 filetype=ascii skip= 0 offset=2 stride=4\n");
      fprintf(fp,"variable 2 filetype=ascii skip= 0 offset=3 stride=4\n");
      fprintf(fp,"coord    1 filetype=ascii skip= 0 offset=0 stride=4\n");
      fprintf(fp,"coord    2 filetype=ascii skip= 0 offset=1 stride=4\n");
      fprintf(fp,"coord    3 filetype=ascii skip= 0 offset=2 stride=4\n");
    }

    strcpy(str,"\f\f\n");
    fprintf(fp,"%s",str);

    for (long j = 0; j < NY ; j++ )
      for (long i = 0 ; i < NX ; i++)
        if ( Side.getSzX() * Side.getSzY() != 0)
           fprintf(FP,"%10.3f %10.3f %10.3f %10.3f\n",X[i]-FXMin,Y[j]-FYMin,Data[(int)i][j],Side(i,j));
        else if ( Side.getSzX() * Side.getSzY() == 0)
           fprintf(FP,"%10.3f %10.3f %10.3f\n",X[i]-FXMin,Y[j]-FYMin,Data[(int)i][j]);

    fclose(fp);
    return true;
}

bool MkGridReader::SaveGrid()
{
      char str[256];
      long i,j;

      FP = fopen(GridFileName,"w");
      if (!FP) {
         return false;
      }

      strcpy(str,"DSAA\n");
      fputs(str,FP);

      sprintf(str, "%d %d\n",NX,NY);
      fputs(str,FP);

      sprintf(str,"%f %f\n",XMin,XMax);
      fputs(str,FP);

      sprintf(str,"%f %f\n",YMin,YMax);
      fputs(str,FP);


      sprintf(str,"%f %f\n",DataMin,DataMax);
      fputs(str,FP);

      int cnt;
      for (j=0;j<NY;j++) {
        cnt = 0;
        for (i=0;i<NX;i++) {
          fprintf(FP,"%20.8f ",Data[(int)i][j]); cnt++;
          if (cnt %10 == 0) fprintf(FP,"\n");
        }
        fprintf(FP,"\n");
      }

      fclose(FP);
      return true;
}

bool MkGridReader::SaveGrid(char *grid_file,Float &data)
{
      char str[256];
      long i,j;

      FP = fopen(grid_file,"w");
      if (!FP) {
         return false;
      }

      strcpy(str,"DSAA\n");
      fputs(str,FP);

      sprintf(str, "%d %d\n",NX,NY);
      fputs(str,FP);

      sprintf(str,"%f %f\n",XMin,XMax);
      fputs(str,FP);

      sprintf(str,"%f %f\n",YMin,YMax);
      fputs(str,FP);

      float data_min,data_max;
      data_min = data_max = data[0][0];

      for (j=0;j<NY;j++) {
        for (i=0;i<NX;i++) {
          data_min = data_min < data[(int)i][j] ? data_min : data[(int)i][j];
          data_max = data_max > data[(int)i][j] ? data_max : data[(int)i][j];
        }
      }

      sprintf(str,"%f %f\n",data_min,data_max);
      fputs(str,FP);

      int cnt;
      for (j=0;j<NY;j++) {
        cnt = 0;
        for (i=0;i<NX;i++) {
          fprintf(FP,"%7.3f ",data[(int)i][j]); cnt++;
          if (cnt %10 == 0) fprintf(FP,"\n");
        }
        fprintf(FP,"\n");
      }

      fclose(FP);
      return true;
}


bool MkGridReader::SaveTomoFile(char *file_name)
{
     SetTomoFileName(file_name);
     return SaveTomoFile();
}

bool MkGridReader::SaveTomoFile()
{
      MkPoint rp,dir,sta_pt;
      float theta;

      FP = fopen(TomoFileName,"w");
      if (!FP) {
         return false;
      }
      int i;float j;

      i = Station/1000;
      j = Station - int(Station/1000)*1000;

      dir = FRailWay.FowardDir(i,j);
      sta_pt = FRailWay(i,j);
      theta = acos(dir.X)*180/M_PI;
      if ( fabs(dir.X - cos(theta*M_PI/180)) > 0.01) theta += 180;

      fprintf(FP,"#Tomography Data\nStation %10.3f %d %d\n",Station,NX,NY);
      for (long j = 0; j < NY ; j++ )
        for (long i = 0 ; i < NX ; i++) {
          rp.Set(X[i],0,Z[j]);
          rp.Translate(-55,0,0);
          rp.Rotate(theta-90,0,0);
//          rp.Translate(sta_pt.X-FXMin,sta_pt.Y-FYMin,0);
          rp.Translate(sta_pt.X,sta_pt.Y,0);
          fprintf(FP,"%10.3f %10.3f %10.3f %10.3f\n",rp.X,rp.Y,rp.Z,Data[(int)i][j]);
        }

      fclose(FP);
      return true;
}

bool  MkGridReader::SaveLayerFile()
{

    FILE *fp;
    char str[256];

    //----------------------- first layer
    fp = fopen(LayerFldFileName1,"w");
    if (!fp) {
       return false;
    }

    fprintf(fp,"# AVS field file %s\n",LayerFldFileName1);
    fprintf(fp,"ndim = %d\n",2);
    fprintf(fp,"dim1 = %d\n",NX);
    fprintf(fp,"dim2 = %d\n",NY);
    fprintf(fp,"nspace = %d\n",3);
    if ( Side.getSzX() * Side.getSzY() != 0)   // Side �� ������ �Ǿ��ִ���
      fprintf(fp,"veclen = %d\n",2);           // �ƴ����� ���� �޶�����.
    else if (Side.getSzX() * Side.getSzY() == 0)
      fprintf(fp,"veclen = %d\n",1);
    fprintf(fp,"data = float\n");
    fprintf(fp,"field = irregular\n");
    if ( Side.getSzX() * Side.getSzY() != 0)
      fprintf(fp,"label = Elevation Side\n");
    else if (Side.getSzX() * Side.getSzY() == 0)
      fprintf(fp,"label = Elevation \n");

    if ( Side.getSzX() * Side.getSzY() == 0) {
      fprintf(fp,"variable 1 filetype=ascii skip= 0 offset=2 stride=3\n");
      fprintf(fp,"coord    1 filetype=ascii skip= 0 offset=0 stride=3\n");
      fprintf(fp,"coord    2 filetype=ascii skip= 0 offset=1 stride=3\n");
      fprintf(fp,"coord    3 filetype=ascii skip= 0 offset=2 stride=3\n");
    }
    if ( Side.getSzX() * Side.getSzY() != 0) {
      fprintf(fp,"variable 1 filetype=ascii skip= 0 offset=2 stride=4\n");
      fprintf(fp,"variable 2 filetype=ascii skip= 0 offset=3 stride=4\n");
      fprintf(fp,"coord    1 filetype=ascii skip= 0 offset=0 stride=4\n");
      fprintf(fp,"coord    2 filetype=ascii skip= 0 offset=1 stride=4\n");
      fprintf(fp,"coord    3 filetype=ascii skip= 0 offset=2 stride=4\n");
    }

    strcpy(str,"\f\f\n");
    fprintf(fp,"%s",str);

    for (long j = 0; j < NY ; j++ )
      for (long i = 0 ; i < NX ; i++)
          if ( Side.getSzX() * Side.getSzY() != 0)
             fprintf(fp,"%10.3f %10.3f %10.3f %10.3f \n",X[i]-FXMin,Y[j]-FYMin,
             Data[(int)i][j]-FirstLayerData[(int)i][j],Side(i,j));
          else if( Side.getSzX() * Side.getSzY() == 0)
             fprintf(fp,"%10.3f %10.3f %10.3f \n",X[i]-FXMin,Y[j]-FYMin,
             Data[(int)i][j]-FirstLayerData[(int)i][j]);
     fclose(fp);

    //----------------------- second layer
    fp = fopen(LayerFldFileName2,"w");
    if (!fp) {
       return false;
    }

    fprintf(fp,"# AVS field file %s\n",LayerFldFileName2);
    fprintf(fp,"ndim = %d\n",2);
    fprintf(fp,"dim1 = %d\n",NX);
    fprintf(fp,"dim2 = %d\n",NY);
    fprintf(fp,"nspace = %d\n",3);
    if ( Side.getSzX() * Side.getSzY() != 0)   // Side �� ������ �Ǿ��ִ���
      fprintf(fp,"veclen = %d\n",2);           // �ƴ����� ���� �޶�����.
    else if (Side.getSzX() * Side.getSzY() == 0)
      fprintf(fp,"veclen = %d\n",1);
    fprintf(fp,"data = float\n");
    fprintf(fp,"field = irregular\n");
    if ( Side.getSzX() * Side.getSzY() != 0)
      fprintf(fp,"label = Elevation Side\n");
    else if (Side.getSzX() * Side.getSzY() == 0)
      fprintf(fp,"label = Elevation \n");

    if ( Side.getSzX() * Side.getSzY() == 0) {
      fprintf(fp,"variable 1 filetype=ascii skip= 0 offset=2 stride=3\n");
      fprintf(fp,"coord    1 filetype=ascii skip= 0 offset=0 stride=3\n");
      fprintf(fp,"coord    2 filetype=ascii skip= 0 offset=1 stride=3\n");
      fprintf(fp,"coord    3 filetype=ascii skip= 0 offset=2 stride=3\n");
    }
    if ( Side.getSzX() * Side.getSzY() != 0) {
      fprintf(fp,"variable 1 filetype=ascii skip= 0 offset=2 stride=4\n");
      fprintf(fp,"variable 2 filetype=ascii skip= 0 offset=3 stride=4\n");
      fprintf(fp,"coord    1 filetype=ascii skip= 0 offset=0 stride=4\n");
      fprintf(fp,"coord    2 filetype=ascii skip= 0 offset=1 stride=4\n");
      fprintf(fp,"coord    3 filetype=ascii skip= 0 offset=2 stride=4\n");
    }

    strcpy(str,"\f\f\n");
    fprintf(fp,"%s",str);

    for (long j = 0; j < NY ; j++ )
      for (long i = 0 ; i < NX ; i++)
          if ( Side.getSzX() * Side.getSzY() != 0)
             fprintf(fp,"%10.3f %10.3f %10.3f %10.3f\n",X[i]-FXMin,Y[j]-FYMin,
             Data[(int)i][j]-FirstLayerData[(int)i][j]-SecondLayerData[(int)i][j],Side(i,j));
          else if( Side.getSzX() * Side.getSzY() == 0)
             fprintf(fp,"%10.3f %10.3f %10.3f \n",X[i]-FXMin,Y[j]-FYMin,
             Data[(int)i][j]-FirstLayerData[(int)i][j]-SecondLayerData[(int)i][j]);
    fclose(fp);

    //----------------------- third layer
    fp = fopen(LayerFldFileName3,"w");
    if (!fp) {
       return false;
    }

    fprintf(fp,"# AVS field file %s\n",LayerFldFileName3);
    fprintf(fp,"ndim = %d\n",2);
    fprintf(fp,"dim1 = %d\n",NX);
    fprintf(fp,"dim2 = %d\n",NY);
    fprintf(fp,"nspace = %d\n",3);
    if ( Side.getSzX() * Side.getSzY() != 0)   // Side �� ������ �Ǿ��ִ���
      fprintf(fp,"veclen = %d\n",2);           // �ƴ����� ���� �޶�����.
    else if (Side.getSzX() * Side.getSzY() == 0)
      fprintf(fp,"veclen = %d\n",1);
    fprintf(fp,"data = float\n");
    fprintf(fp,"field = irregular\n");
    if ( Side.getSzX() * Side.getSzY() != 0)
      fprintf(fp,"label = Elevation Side\n");
    else if (Side.getSzX() * Side.getSzY() == 0)
      fprintf(fp,"label = Elevation \n");

    if ( Side.getSzX() * Side.getSzY() == 0) {
      fprintf(fp,"variable 1 filetype=ascii skip= 0 offset=2 stride=3\n");
      fprintf(fp,"coord    1 filetype=ascii skip= 0 offset=0 stride=3\n");
      fprintf(fp,"coord    2 filetype=ascii skip= 0 offset=1 stride=3\n");
      fprintf(fp,"coord    3 filetype=ascii skip= 0 offset=2 stride=3\n");
    }
    if ( Side.getSzX() * Side.getSzY() != 0) {
      fprintf(fp,"variable 1 filetype=ascii skip= 0 offset=2 stride=4\n");
      fprintf(fp,"variable 2 filetype=ascii skip= 0 offset=3 stride=4\n");
      fprintf(fp,"coord    1 filetype=ascii skip= 0 offset=0 stride=4\n");
      fprintf(fp,"coord    2 filetype=ascii skip= 0 offset=1 stride=4\n");
      fprintf(fp,"coord    3 filetype=ascii skip= 0 offset=2 stride=4\n");
    }

    strcpy(str,"\f\f\n");
    fprintf(fp,"%s",str);

    for (long j = 0; j < NY ; j++ )
      for (long i = 0 ; i < NX ; i++)
          if ( Side.getSzX() * Side.getSzY() != 0)
             fprintf(fp,"%10.3f %10.3f %10.3f %10.3f\n",X[i]-FXMin,Y[j]-FYMin,
             Data[(int)i][j]-FirstLayerData[(int)i][j]-SecondLayerData[(int)i][j]-ThirdLayerData[(int)i][j]
             ,Side(i,j));
          else if( Side.getSzX() * Side.getSzY() == 0)
             fprintf(fp,"%10.3f %10.3f %10.3f\n",X[i]-FXMin,Y[j]-FYMin,
             Data[(int)i][j]-FirstLayerData[(int)i][j]-SecondLayerData[(int)i][j]-ThirdLayerData[(int)i][j],Side(i,j));
    fclose(fp);

    //----------------------- fourth layer
    fp = fopen(LayerFldFileName4,"w");
    if (!fp) {
       return false;
    }

    fprintf(fp,"# AVS field file %s\n",LayerFldFileName4);
    fprintf(fp,"ndim = %d\n",2);
    fprintf(fp,"dim1 = %d\n",NX);
    fprintf(fp,"dim2 = %d\n",NY);
    fprintf(fp,"nspace = %d\n",3);
    if ( Side.getSzX() * Side.getSzY() != 0)   // Side �� ������ �Ǿ��ִ���
      fprintf(fp,"veclen = %d\n",2);           // �ƴ����� ���� �޶�����.
    else if (Side.getSzX() * Side.getSzY() == 0)
      fprintf(fp,"veclen = %d\n",1);
    fprintf(fp,"data = float\n");
    fprintf(fp,"field = irregular\n");
    if ( Side.getSzX() * Side.getSzY() != 0)
      fprintf(fp,"label = Elevation Side\n");
    else if (Side.getSzX() * Side.getSzY() == 0)
      fprintf(fp,"label = Elevation \n");

    if ( Side.getSzX() * Side.getSzY() == 0) {
      fprintf(fp,"variable 1 filetype=ascii skip= 0 offset=2 stride=3\n");
      fprintf(fp,"coord    1 filetype=ascii skip= 0 offset=0 stride=3\n");
      fprintf(fp,"coord    2 filetype=ascii skip= 0 offset=1 stride=3\n");
      fprintf(fp,"coord    3 filetype=ascii skip= 0 offset=2 stride=3\n");
    }
    if ( Side.getSzX() * Side.getSzY() != 0) {
      fprintf(fp,"variable 1 filetype=ascii skip= 0 offset=2 stride=4\n");
      fprintf(fp,"variable 2 filetype=ascii skip= 0 offset=3 stride=4\n");
      fprintf(fp,"coord    1 filetype=ascii skip= 0 offset=0 stride=4\n");
      fprintf(fp,"coord    2 filetype=ascii skip= 0 offset=1 stride=4\n");
      fprintf(fp,"coord    3 filetype=ascii skip= 0 offset=2 stride=4\n");
    }

    strcpy(str,"\f\f\n");
    fprintf(fp,"%s",str);

    for (long j = 0; j < NY ; j++ )
      for (long i = 0 ; i < NX ; i++)
          if ( Side.getSzX() * Side.getSzY() != 0)
             fprintf(fp,"%10.3f %10.3f %10.3f %10.3f\n",X[i]-FXMin,Y[j]-FYMin,
             Data[(int)i][j]-FirstLayerData[(int)i][j]-SecondLayerData[(int)i][j]-ThirdLayerData[(int)i][j]-FourthLayerData[(int)i][j]
             ,Side(i,j));
          else if( Side.getSzX() * Side.getSzY() == 0)
             fprintf(fp,"%10.3f %10.3f %10.3f\n",X[i]-FXMin,Y[j]-FYMin,
             Data[(int)i][j]-FirstLayerData[(int)i][j]-SecondLayerData[(int)i][j]-ThirdLayerData[(int)i][j]-FourthLayerData[(int)i][j],Side(i,j));
    fclose(fp);

    //----------------------- fifth layer
    fp = fopen(LayerFldFileName5,"w");
    if (!fp) {
       return false;
    }

    fprintf(fp,"# AVS field file %s\n",LayerFldFileName5);
    fprintf(fp,"ndim = %d\n",2);
    fprintf(fp,"dim1 = %d\n",NX);
    fprintf(fp,"dim2 = %d\n",NY);
    fprintf(fp,"nspace = %d\n",3);
    if ( Side.getSzX() * Side.getSzY() != 0)   // Side �� ������ �Ǿ��ִ���
      fprintf(fp,"veclen = %d\n",2);           // �ƴ����� ���� �޶�����.
    else if (Side.getSzX() * Side.getSzY() == 0)
      fprintf(fp,"veclen = %d\n",1);
    fprintf(fp,"data = float\n");
    fprintf(fp,"field = irregular\n");
    if ( Side.getSzX() * Side.getSzY() != 0)
      fprintf(fp,"label = Elevation Side\n");
    else if (Side.getSzX() * Side.getSzY() == 0)
      fprintf(fp,"label = Elevation \n");

    if ( Side.getSzX() * Side.getSzY() == 0) {
      fprintf(fp,"variable 1 filetype=ascii skip= 0 offset=2 stride=3\n");
      fprintf(fp,"coord    1 filetype=ascii skip= 0 offset=0 stride=3\n");
      fprintf(fp,"coord    2 filetype=ascii skip= 0 offset=1 stride=3\n");
      fprintf(fp,"coord    3 filetype=ascii skip= 0 offset=2 stride=3\n");
    }
    if ( Side.getSzX() * Side.getSzY() != 0) {
      fprintf(fp,"variable 1 filetype=ascii skip= 0 offset=2 stride=4\n");
      fprintf(fp,"variable 2 filetype=ascii skip= 0 offset=3 stride=4\n");
      fprintf(fp,"coord    1 filetype=ascii skip= 0 offset=0 stride=4\n");
      fprintf(fp,"coord    2 filetype=ascii skip= 0 offset=1 stride=4\n");
      fprintf(fp,"coord    3 filetype=ascii skip= 0 offset=2 stride=4\n");
    }

    strcpy(str,"\f\f\n");
    fprintf(fp,"%s",str);

    for (long j = 0; j < NY ; j++ )
      for (long i = 0 ; i < NX ; i++)
          if ( Side.getSzX() * Side.getSzY() != 0)
             fprintf(fp,"%10.3f %10.3f %10.3f %10.3f\n",X[i]-FXMin,Y[j]-FYMin,
             Data[(int)i][j]-FirstLayerData[(int)i][j]-SecondLayerData[(int)i][j]-ThirdLayerData[(int)i][j]-FourthLayerData[(int)i][j]-FifthLayerData[(int)i][j]
             ,Side(i,j));
          else if( Side.getSzX() * Side.getSzY() == 0)
             fprintf(fp,"%10.3f %10.3f %10.3f\n",X[i]-FXMin,Y[j]-FYMin,
             Data[(int)i][j]-FirstLayerData[(int)i][j]-SecondLayerData[(int)i][j]-ThirdLayerData[(int)i][j]-FourthLayerData[(int)i][j]-FifthLayerData[(int)i][j],Side(i,j));
    fclose(fp);
    return true;

}

bool MkGridReader::SaveCutFile()
{
      char str[256];

      FP = fopen(CutFileName,"w");
      if (!FP) {
         return false;
      }

      MkLine rl[4];
      MkPoint rp[4];
      float data[4];
      MkPoint pnt[5];
      float pnt_data[5];

      int cnt[4] = {0,0,0,0},count;
      int con_line[2];

      for (long j = 0; j < NY-1 ; j++ ) {
        for (long i = 0 ; i < NX-1 ; i++) {

          rp[0] = MkPoint( X[i]-FXMin,Y[j]-FYMin);
          rp[1] = MkPoint( X[i+1]-FXMin,Y[j]-FYMin);
          rp[2] = MkPoint( X[i+1]-FXMin,Y[j+1]-FYMin);
          rp[3] = MkPoint( X[i]-FXMin,Y[j+1]-FYMin);

          data[0] = Data[(int)i][j];
          data[1] = Data[(int)(i+1)][j];
          data[2] = Data[(int)(i+1)][j+1];
          data[3] = Data[(int)i][j+1];

          rl[0] = MkLine( X[i]-FXMin,Y[j]-FYMin,X[i+1]-FXMin,Y[j]-FYMin);
          rl[1] = MkLine( X[i+1]-FXMin,Y[j]-FYMin,X[i+1]-FXMin,Y[j+1]-FYMin);
          rl[2] = MkLine( X[i+1]-FXMin,Y[j+1]-FYMin,X[i]-FXMin,Y[j+1]-FYMin);
          rl[3] = MkLine( X[i]-FXMin,Y[j+1]-FYMin,X[i]-FXMin,Y[j]-FYMin);

          for (int k=0;k<4;k++) cnt[k] = 0;
          count = 0;
          for (int k=0;k<4;k++) {
              if (CutLine*rp[k]>0) {
                 count++;
                 cnt[k]++;
              }
          }

          if (count==4)
             fprintf(FP," %14.3f %14.3f %14.3f"
                        " %14.3f %14.3f %14.3f"
                        " %14.3f %14.3f %14.3f"
                        " %14.3f %14.3f %14.3f\n",
                        X[i]-FXMin,Y[j]-FYMin,Data[(int)i][j],
                        X[i+1]-FXMin,Y[j]-FYMin,Data[(int)i+1][j],
                        X[i+1]-FXMin,Y[j+1]-FYMin,Data[(int)i+1][j+1],
                        X[i]-FXMin,Y[j+1]-FYMin,Data[(int)i][j+1]);

          else if (count == 3) { // ������ �𼭸�
             for (int k=0;k<4;k++) {
                if (!cnt[k]) {
                   con_line[0] = (k-1+4) % 4;
                   con_line[1] = (k+4) % 4;
                   pnt[0] = rp[(k+1) % 4];
                   pnt[1] = rp[(k+2) % 4];
                   pnt[2] = rp[(k+3) % 4];
                   pnt_data[0] = data[(k+1) % 4];
                   pnt_data[1] = data[(k+2) % 4];
                   pnt_data[2] = data[(k+3) % 4];
                }
             }

             for (int k=0;k<2;k++) {
                float ratio=0;
                MkLine line;
                pnt[k+3] = CutLine & rl[con_line[k]];
                if (k%2) line.SetLine(pnt[k+3],rl[con_line[k]][0]);
                else line.SetLine(rl[con_line[k]][0],pnt[k+3]);
                ratio = line.GetLength()/rl[con_line[k]].GetLength();
                if (ratio>1) {
                   memo->Lines->Add("In saving CutSaveFile routine, there may be error in grid file or something.");
                   memo->Lines->Add("It can not be done.");
                   fclose(FP);
                   return false;
                }
//                if (k%2) pnt_data[k+3] = data[con_line[k]] + ratio*(data[(con_line[k]+1)%4]-data[con_line[k]]);
//                else pnt_data[k+3] = data[(con_line[k]+1)%4] + ratio*(data[k]-data[(con_line[k]+1)%4]);
                  pnt_data[k+3] = (*this)(pnt[k+3].X,pnt[k+3].Y);
             }

             fprintf(FP," %14.3f %14.3f %14.3f"
                        " %14.3f %14.3f %14.3f"
                        " %14.3f %14.3f %14.3f"
                        " %14.3f %14.3f %14.3f\n",
                        pnt[0].X,pnt[0].Y,pnt_data[0],
                        pnt[1].X,pnt[1].Y,pnt_data[1],
                        pnt[2].X,pnt[2].Y,pnt_data[2],
                        pnt[3].X,pnt[3].Y,pnt_data[3]);

               fprintf(FP," %14.3 %14.3 %14.3"
                        " %14.3 %14.3 %14.3"
                        " %14.3 %14.3 %14.3"
                        " %14.3 %14.3 %14.3\n",
                        pnt[0].X,pnt[0].Y,pnt_data[0],
                        pnt[3].X,pnt[3].Y,pnt_data[3],
                        pnt[4].X,pnt[4].Y,pnt_data[4],
                        pnt[4].X,pnt[4].Y,pnt_data[4]);
          }

          else if (count == 2) { // �ΰ��� �𼭸�
             if (cnt[3]&&cnt[0]) {
                pnt[0] = rp[0];
                pnt[3] = rp[3];
                pnt[1] = CutLine & rl[0];
                pnt[2] = CutLine & rl[2];

                pnt_data[0] = data[0];
                pnt_data[3] = data[3];

                MkLine line(rl[0][0],pnt[1]);
                float ratio = line.GetLength()/rl[0].GetLength();
                if (ratio>1) {
                   memo->Lines->Add("In saving CutSaveFile routine, there may be error in grid file or something.");
                   memo->Lines->Add("It can not be done.");
                   fclose(FP);
                   return false;
                }
                pnt_data[1] = data[0] + ratio*(data[1]-data[0]);

                line.SetLine(pnt[2],rl[2][0]);
                ratio = line.GetLength()/rl[2].GetLength();
                if (ratio>1) {
                   memo->Lines->Add("In saving CutSaveFile routine, there may be error in grid file or something.");
                   memo->Lines->Add("It can not be done.");
                   fclose(FP);
                   return false;
                }
                pnt_data[2] = data[3] + ratio*(data[2]-data[3]);
             }
             if (cnt[2]&&cnt[3]) {
                pnt[2] = rp[2];
                pnt[3] = rp[3];
                pnt[0] = CutLine & rl[3];
                pnt[1] = CutLine & rl[1];

                pnt_data[2] = data[2];
                pnt_data[3] = data[3];

                MkLine line(rl[3][0],pnt[0]);
                float ratio = line.GetLength()/rl[3].GetLength();
                if (ratio>1) {
                   memo->Lines->Add("In saving CutSaveFile routine, there may be error in grid file or something.");
                   memo->Lines->Add("It can not be done.");
                   fclose(FP);
                   return false;
                }
                pnt_data[0] = data[3] + ratio*(data[0]-data[3]);

                line.SetLine(pnt[1],rl[1][1]);
                ratio = line.GetLength()/rl[1].GetLength();
                if (ratio>1) {
                   memo->Lines->Add("In saving CutSaveFile routine, there may be error in grid file or something.");
                   memo->Lines->Add("It can not be done.");
                   fclose(FP);
                   return false;
                }
                pnt_data[1] = data[2] + ratio*(data[1]-data[2]);

             }
             if (cnt[0]&&cnt[1]) {
                pnt[0] = rp[0];
                pnt[1] = rp[1];
                pnt[2] = CutLine & rl[1];
                pnt[3] = CutLine & rl[3];

                pnt_data[0] = data[0];
                pnt_data[1] = data[1];

                MkLine line(rl[1][0],pnt[2]);
                float ratio = line.GetLength()/rl[1].GetLength();
                if (ratio>1) {
                   memo->Lines->Add("In saving CutSaveFile routine, there may be error in grid file or something.");
                   memo->Lines->Add("It can not be done.");
                   fclose(FP);
                   return false;
                }
                pnt_data[2] = data[1] + ratio*(data[2]-data[1]);

                line.SetLine(pnt[3],rl[3][1]);
                ratio = line.GetLength()/rl[3].GetLength();
                if (ratio>1) {
                   memo->Lines->Add("In saving CutSaveFile routine, there may be error in grid file or something.");
                   memo->Lines->Add("It can not be done.");
                   fclose(FP);
                   return false;
                }
                pnt_data[3] = data[0] + ratio*(data[3]-data[0]);

             }
             if (cnt[1]&&cnt[2]) {
                pnt[1] = rp[1];
                pnt[2] = rp[2];
                pnt[0] = CutLine & rl[0];
                pnt[3] = CutLine & rl[2];

                pnt_data[1] = data[1];
                pnt_data[2] = data[2];
                MkLine line(pnt[0],rl[0][1]);
                float ratio = line.GetLength()/rl[0].GetLength();
                if (ratio>1) {
                   memo->Lines->Add("In saving CutSaveFile routine, there may be error in grid file or something.");
                   memo->Lines->Add("It can not be done.");
                   fclose(FP);
                   return false;
                }
                pnt_data[0] = data[1] + ratio*(data[0]-data[1]);

                line.SetLine(rl[2][0],pnt[3]);
                ratio = line.GetLength()/rl[2].GetLength();
                if (ratio>1) {
                   memo->Lines->Add("In saving CutSaveFile routine, there may be error in grid file or something.");
                   memo->Lines->Add("It can not be done.");
                   fclose(FP);
                   return false;
                }
                pnt_data[3] = data[2] + ratio*(data[3]-data[2]);
             }

             fprintf(FP," %14.3 %14.3 %14.3"
                        " %14.3 %14.3 %14.3"
                        " %14.3 %14.3 %14.3"
                        " %14.3 %14.3 %14.3\n",
                        pnt[0].X,pnt[0].Y,pnt_data[0],
                        pnt[1].X,pnt[1].Y,pnt_data[1],
                        pnt[2].X,pnt[2].Y,pnt_data[2],
                        pnt[3].X,pnt[3].Y,pnt_data[3]);
          }

          else if (count == 1) { // �Ѱ��� �𼭸�
             for (int k=0;k<4;k++) {
                if (cnt[k]) {
                   con_line[0] = (k + 4) % 4;
                   con_line[1] = (k-1+4) % 4;
                   pnt[0] = rp[k];
                   pnt_data[0] = data[k];
                }
             }

             for (int k=0;k<2;k++) {
                float ratio=0;
                MkLine line;
                pnt[k+1] = CutLine & rl[con_line[k]];
                if (k%2) line.SetLine(pnt[k+1],rl[con_line[k]][0]);
                else line.SetLine(rl[con_line[k]][0],pnt[k+1]);

                ratio = line.GetLength()/rl[con_line[k]].GetLength();
                if (ratio>1) {
                   memo->Lines->Add("In saving CutSaveFile routine, there may be error in grid file or something.");
                   memo->Lines->Add("It can not be done.");
                   fclose(FP);
                   return false;
                }
//                if (k==1) pnt_data[k+1] = data[(con_line[k]+1)%4] + ratio*(data[con_line[k]]-data[(con_line[k]+1)%4]);
//                if (k==0) pnt_data[k+1] = data[con_line[k]] + ratio*(data[(con_line[k]+1)%4]-data[con_line[k]]);
                  pnt_data[k+1] = (*this)(pnt[k+1].X,pnt[k+1].Y);
             }

             fprintf(FP," %14.3 %14.3 %14.3"
                        " %14.3 %14.3 %14.3"
                        " %14.3 %14.3 %14.3"
                        " %14.3 %14.3 %14.3\n",
                        pnt[0].X,pnt[0].Y,pnt_data[0],
                        pnt[1].X,pnt[1].Y,pnt_data[1],
                        pnt[2].X,pnt[2].Y,pnt_data[2],
                        pnt[2].X,pnt[2].Y,pnt_data[2]);
          }
        }
      }

      fclose(FP);
      return true;
}

bool MkGridReader::SaveModFlowFile(char *file_name)
{
     SetModFlowFileName(file_name);
     return SaveModFlowFile();
}

ModFlowData::ModFlowData()
{
     NumOfLayer = 0;
     for (int i = 0 ; i < 5 ; i++ ) NumOfGrid[i] = 0;
     LevelOfDatum = 0;
}

ModFlowData & ModFlowData::operator=(ModFlowData &data)
{
     NumOfLayer = data.NumOfLayer;
     for (int i = 0 ; i < 5 ; i++ ) NumOfGrid[i] = data.NumOfGrid[i];
     LevelOfDatum = data.LevelOfDatum;
     return *this;
}

bool MkGridReader::SaveModFlowFile()
{
     int TotGrid=0;
     for (int i=0;i<FModFlowData.NumOfLayer;i++) {
         TotGrid += FModFlowData.NumOfGrid[i];
     }

     Float data;
     data.CopyFrom(FirstLayerData);
     
     char (*str)[256] = new char[TotGrid+1][256];
     char ext[80];

     AnsiString mod_name,mod_ext;
     mod_name = ExtractFileName(ModFlowFileName);
     mod_ext = ExtractFileExt(ModFlowFileName);

     for (int i = 0 ; i < TotGrid+1 ; i++ ) {
         memset(str[i],'\0',255);
         strncpy(str[i],mod_name.c_str(),mod_name.Length()-mod_ext.Length());
         sprintf(ext,"_%d.grd",i);
         strcat(str[i],ext);
     }

     int cnt=0;
     for (int k=0 ; k < FModFlowData.NumOfLayer-1 ; k++ ) {
         for (int l=0 ; l < FModFlowData.NumOfGrid[k];l++) {
             for (int i=0;i<NX;i++)  {
                 for (int j=0;j<NY;j++) {
                     if (k==0) data(i,j) = FirstLayerData(i,j)-l*(SecondLayerData(i,j))/FModFlowData.NumOfGrid[k];
                     else if (k==1) data(i,j) = FirstLayerData(i,j)-SecondLayerData(i,j)-l*(ThirdLayerData(i,j))/FModFlowData.NumOfGrid[k];
                     else if (k==2) data(i,j) = FirstLayerData(i,j)-SecondLayerData(i,j)-ThirdLayerData(i,j)-l*(FourthLayerData(i,j))/FModFlowData.NumOfGrid[k];
                     else if (k==3) data(i,j) = FirstLayerData(i,j)-SecondLayerData(i,j)-ThirdLayerData(i,j)-FourthLayerData(i,j)-l*(FifthLayerData(i,j))/FModFlowData.NumOfGrid[k];
                 }
             }
             SaveGrid(str[cnt],data);cnt++;
         }
     }

     int k=FModFlowData.NumOfLayer-1;
     for (int l=0 ; l < FModFlowData.NumOfGrid[k];l++) {
         for (int i=0;i<NX;i++) {
             for (int j=0;j<NY;j++) {
                 if (k==1) data(i,j) = FirstLayerData(i,j)-SecondLayerData(i,j)-l*(FirstLayerData(i,j)-SecondLayerData(i,j)-FModFlowData.LevelOfDatum)/FModFlowData.NumOfGrid[k];
                 else if (k==2) data(i,j) = FirstLayerData(i,j)-SecondLayerData(i,j)-ThirdLayerData(i,j)-l*(FirstLayerData(i,j)-SecondLayerData(i,j)-ThirdLayerData(i,j)-FModFlowData.LevelOfDatum)/FModFlowData.NumOfGrid[k];
                 else if (k==3) data(i,j) = FirstLayerData(i,j)-SecondLayerData(i,j)-ThirdLayerData(i,j)-FourthLayerData(i,j)-l*(FirstLayerData(i,j)-SecondLayerData(i,j)-ThirdLayerData(i,j)-FourthLayerData(i,j)-FModFlowData.LevelOfDatum)/FModFlowData.NumOfGrid[k];
                 else if (k==4) data(i,j) = FirstLayerData(i,j)-SecondLayerData(i,j)-ThirdLayerData(i,j)-FourthLayerData(i,j)-FifthLayerData(i,j)-l*(FirstLayerData(i,j)-SecondLayerData(i,j)-ThirdLayerData(i,j)-FourthLayerData(i,j)-FifthLayerData(i,j)-FModFlowData.LevelOfDatum)/FModFlowData.NumOfGrid[k];
             }
         }
         SaveGrid(str[cnt],data);cnt++;
     }

     delete[] str;
     return true;
}

float MkGridReader::GetHeight(float x,float y)
{
      MkPoint rp[4];
      MkTriangle rt[2];
      MkLine rl[2];
      float data[4];
      long I,J;
      long i,j;

      if (x < XMin || x > XMax || y < YMin || y > YMax) return 0;

      for (i = 0 ; i < NX-1 ; i++) {
        if (x > X[i] && x < X[i+1]) {
           I = i;
           break;
        }
      }
      for (j = 0; j < NY-1 ; j++ ) {
        if (y > Y[j] && y < Y[j+1]) {
           J = j;
           break;
        }
      }
      if (i == NX-1 || j == NY-1) return 0;

      rp[0] = MkPoint(X[I  ],Y[J  ],Data[(int)I][J]);
      rp[1] = MkPoint(X[I+1],Y[J  ],Data[(int)(I+1)][J]);
      rp[2] = MkPoint(X[I+1],Y[J+1],Data[(int)(I+1)][J+1]);
      rp[3] = MkPoint(X[I  ],Y[J+1],Data[(int)I][J+1]);

      data[0] = Data[(int)I][J];
      data[1] = Data[(int)(I+1)][J];
      data[2] = Data[(int)(I+1)][J+1];
      data[3] = Data[(int)I][J+1];

      rt[0].Reset(rp[0],rp[1],rp[3]);
      rt[1].Reset(rp[1],rp[2],rp[3]);

      if (rt[0].isIn(x,y)) {
         return rt[0](x,y);
      }

      else if (rt[1].isIn(x,y)) {
         return rt[1](x,y);
      }
      else return 0;
}

float MkGridReader::operator()(float x,float y)
{
      return GetHeight(x,y);
}

float MkGridReader::operator()(int i,int j)
{
      if (i >= 0 && i < NX && j >= 0 && j < NY)
         return Data(i,j);
      else return 0;
}

//---------------------------------------------------------------------------
MkBoreReader::MkBoreReader()
{
    memo = (TObject*)NULL;
    memset(FileName,'\0',sizeof(FileName));
}

MkBoreReader::MkBoreReader(TObject *Sender)
{
    memo = dynamic_cast<TMemo *>(Sender);
    memset(FileName,'\0',sizeof(FileName));
}

MkBoreReader::~MkBoreReader()
{

}

void MkBoreReader::SetMemo(TObject *Sender)
{
    memo = dynamic_cast<TMemo *>(Sender);
    memo->Lines->Add("Memo is assigned to MkBoreReader!");

}

MkBoreReader::ReadFile()
{
      char str[256];
      int i;
      int count;

      float station,offset;

      FP = fopen(FileName,"r");
      if (!FP) {
         return false;
      }

      fgets(str,255,FP);

      if (strncmp(str,"Borehole",8)) {
         fclose(FP);
         return false;
      }

      fgets(str,255,FP);
      sscanf(str,"%f %f",&station,&offset);
      Station = station;
      Offset = offset;

      int I;float J;
      I = int(station/1000);
      J = station - I*1000;

      Location = FRailWay(I,J);

      count = 0;
      while(!feof(FP)) {
         if (!fgets(str,255,FP)) break;
         sscanf(str,"%d",&i);
         if (i!=0) count++;
      }

      MkJointPlane *jp = new MkJointPlane[count];

      rewind(FP);
      fgets(str,255,FP);

      if (strncmp(str,"Borehole",8)) {
         fclose(FP);
         return false;
      }

      fgets(str,255,FP);
      sscanf(str,"%f %f",&station,&offset);

      count = 0;
      while(!feof(FP)) {
         float depth,dipdir,dip,aperture;
         int sort=0,form=0,condition=0;
         int dmmy;
         if (!fgets(str,255,FP)) break;

         sscanf(str,"%f %f %f %d %f %d %d",&depth,&dipdir,&dip,&sort,&aperture,&form,&condition);

//         if (dip < 0) dipdir += 270;
//         else dipdir += 90;
//         dip = dip > 0 ? dip : -dip;

         jp[count].SetDipNDir(dip,dipdir);
         jp[count].SetAperture(aperture);
         jp[count].SetSort(sort);
         jp[count].SetForm(form);
         jp[count].SetCondition(condition);
         jp[count].SetScale(100,100);
         float offx,offy;
         offx = Offset*cos(-dipdir*M_PI/180);
         offy = Offset*sin(-dipdir*M_PI/180);
         jp[count].SetTranslate(offx,offy,0);
         jp[count].SetTranslate(Location.X,Location.Y,Location.Z-depth);

         str[strlen(str)-1] = '\0';
         memo->Lines->Add(str);
         count++;
      }

      FJoint.Initialize(count,jp);

      delete[] jp;
      fclose(FP);
      return true;
}

MkBoreReader::ReadFile(char *file_name)
{
     SetFileName(file_name);
     return ReadFile();
}

MkBoreReader::SaveUCDFile(char *file_name)
{
     SetUCDFileName(file_name);
     return SaveUCDFile();
}

MkBoreReader::SaveUCDFile()
{
    FILE *fp;
    int i,j;
    int count=0,k=0;
    float ApTh=100;
    bool flag=false;
    fp = fopen(UCDFileName,"w");
    for (i=0;i<FJoint.GetSize();i++) {
      if (FJoint[i].GetAperture() > ApTh) {
         count++;
      }
    }
    if (count <= 0) {
       for (i=0;i<FJoint.GetSize();i++) {
           if (FJoint[i].GetAperture() > ApTh/10.0) {
              flag = true;
              count++;
           }
       }
    }

    fprintf(fp,"%d %d %d %d %d\n",count*4,count, 1,0,0);
    for (i=0,k=0;i<FJoint.GetSize();i++) {
      if (!flag && FJoint[i].GetAperture() > ApTh) {
        for (j=0;j<4;j++)
            fprintf(fp,"%5d %10.5f %10.5f %10.5f\n",k*4+j+1,
                       FJoint[i][j].X-FXMin,FJoint[i][j].Y-FYMin,FJoint[i][j].Z);
        k++;
      }
    }

    for (i=0,k=0;i<FJoint.GetSize();i++) {
      if (flag && FJoint[i].GetAperture() > ApTh/10.0) {
        for (j=0;j<4;j++)
            fprintf(fp,"%5d %10.5f %10.5f %10.5f\n",k*4+j+1,
                       FJoint[i][j].X-FXMin,FJoint[i][j].Y-FYMin,FJoint[i][j].Z);
        k++;
      }
    }

    for (i=0;i<count;i++)
        fprintf(fp,"%5d 1 quad %5d %5d %5d %5d\n",i+1,i*4+1,i*4+2,i*4+3,i*4+4);
    fprintf(fp,"1 1\n");
    fprintf(fp,"None, degree \n");
    for (i=0;i<count;i++)
        for (j=0;j<4;j++)
                fprintf(fp,"%5d %10.5f\n",i*4+j+1,1);

    fclose(fp);
}

MkBoreReader::SavePatFile(char *file_name)
{
     SetPatFileName(file_name);
     return SavePatFile();
}

MkBoreReader::SavePatFile()
{
    FILE *fp;
    int i,j;
    char str[256];

    fp = fopen(PatFileName,"w");
    sprintf(str,"BOREHORE %s",ExtractFileName(AnsiString(FileName)));
    fprintf(fp,"%s\n",str);
    sprintf(str,"%d",FJoint.GetSize());
    fprintf(fp,"%s\n",str);

    for (i = 0 ; i < FJoint.GetSize() ; i++ ) {
        sprintf(str,"%10.3f \t %10.3f",FJoint[i].GetDipDir(),FJoint[i].GetDip());
        fprintf(fp,"%s\n",str);
    }

    fclose(fp);
}

MkJointPlane & MkBoreReader::operator[](int i)
{
    return FJoint[i];
}

//---------------------------------------------------------------------------

MkTeleReader::MkTeleReader()
{
    memo = (TObject*)NULL;
    memset(FileName,'\0',sizeof(FileName));
}

MkTeleReader::MkTeleReader(TObject *Sender)
{
    memo = dynamic_cast<TMemo *>(Sender);
    memset(FileName,'\0',sizeof(FileName));
}

MkTeleReader::~MkTeleReader()
{

}

void MkTeleReader::SetMemo(TObject *Sender)
{
    memo = dynamic_cast<TMemo *>(Sender);
    memo->Lines->Add("Memo is assigned to MkTeleReader!");

}

MkTeleReader::ReadFile()
{
      char str[256];
      int i;
      int count;


      float station,offset;

      FP = fopen(FileName,"r");
      if (!FP) {
         return false;
      }

      fgets(str,255,FP);
      AnsiString Astr(str);
      if (strncmp(Astr.UpperCase().c_str(),"BOREHOLE",8)) {
         fclose(FP);
         return false;
      }

      fgets(str,255,FP);
      sscanf(str,"%f %f",&station,&offset);

      Station = station;
      Offset = offset;

      fgets(str,255,FP);
      fgets(str,255,FP);
      fgets(str,255,FP);
      fgets(str,255,FP);

      int I;float J;
      I = int(station/1000);
      J = station - I*1000;

      Location = FRailWay(I,J);

      count = 0;
      while(!feof(FP)) {
         if (!fgets(str,255,FP)) break;
         sscanf(str,"%d",&i);
         if (i!=0) count++;
      }

      MkJointPlane *jp = new MkJointPlane[count];

      rewind(FP);
      fgets(str,255,FP);

      if (strncmp(Astr.UpperCase().c_str(),"BOREHOLE",8)) {
         fclose(FP);
         return false;
      }

      fgets(str,255,FP);
      sscanf(str,"%f %f",&station,&offset);

      fgets(str,255,FP);
      fgets(str,255,FP);
      fgets(str,255,FP);
      fgets(str,255,FP);

      MaxDepth = -100000;
      count = 0;
      while(!feof(FP)) {
         float depth,dipdir,dip,aperture;
         int sort,form,condition;
         int dmmy;
         if (!fgets(str,255,FP)) break;

         sscanf(str,"%d %f %f %f %d",&dmmy,&depth,&dipdir,&dip,&sort);
         // sort 1 : clear fracture
         // sort 2 : normal fracture
         // sort 3 : acceptable fracture
         // sort 8 : layer boundary
         // sort 9 : fault

         if (MaxDepth < depth) MaxDepth = depth;

         jp[count].SetDipNDir(dip,dipdir);
         jp[count].SetSort(sort);
         jp[count].SetScale(100,100);

         float offx,offy;
         offx = Offset*cos(-dipdir*M_PI/180);
         offy = Offset*sin(-dipdir*M_PI/180);
         jp[count].SetTranslate(offx,offy,0);
         jp[count].SetTranslate(Location.X,Location.Y,Location.Z-depth);

         str[strlen(str)-1] = '\0';
         memo->Lines->Add(str);
         count++;
      }

      FJoint.Initialize(count,jp);

      delete[] jp;
      fclose(FP);
      return true;
}

MkTeleReader::ReadFile(char *file_name)
{
     SetFileName(file_name);
     return ReadFile();
}

MkTeleReader::SaveUCDFile(char *file_name)
{
     SetUCDFileName(file_name);
     return SaveUCDFile();
}

MkTeleReader::SaveUCDFile()
{

    FILE *fp;
    int i,j;
    int count=0,k=0;
    float ApTh=100;
    fp = fopen(UCDFileName,"w");
    for (i=0;i<FJoint.GetSize();i++) {
//      if (FJoint[i].GetSort() == 9 || FJoint[i].GetSort() == 1) {
      if (FJoint[i].GetSort() == 9) {
         count++;
      }
    }

    fprintf(fp,"%d %d %d %d %d\n",count*4+12,count+6, 1,0,0);
    for (i=0,k=0;i<FJoint.GetSize();i++) {
//      if (FJoint[i].GetSort() == 9 || FJoint[i].GetSort() == 1) {
      if (FJoint[i].GetSort() == 9) {
        for (j=0;j<4;j++)
            fprintf(fp,"%5d %10.5f %10.5f %10.5f\n",k*4+j+1,
                       FJoint[i][j].X-FXMin,FJoint[i][j].Y-FYMin,FJoint[i][j].Z);
        k++;
      }
    }

//  borehole location and geometry

    k = count*4+1;
    for (i=0;i<6;i++) {
        float ang,x,y,z;
        ang = (30+i*60)*M_PI/180;
        x = Location.X - FXMin + cos(ang);
        y = Location.Y - FYMin + sin(ang);
        z = Location.Z;
        fprintf(fp,"%5d %10.5f %10.5f %10.5f\n",k,x,y,z);
        k++;
    }

    for (i=0;i<6;i++) {
        float ang,x,y,z;
        ang = (30+i*60)*M_PI/180;
        x = Location.X - FXMin + cos(ang);
        y = Location.Y - FYMin + sin(ang);
        z = Location.Z-MaxDepth;
        fprintf(fp,"%5d %10.5f %10.5f %10.5f\n",k,x,y,z);
        k++;
    }

    for (i=0;i<count;i++)
        fprintf(fp,"%5d 1 quad %5d %5d %5d %5d\n",i+1,i*4+1,i*4+2,i*4+3,i*4+4);

//  borehole location and geometry
    for (i=0;i<6;i++)
        fprintf(fp,"%5d 1 quad %5d %5d %5d %5d\n",i+count+1,
        i+1+count*4,(i+1)%6+1+count*4,(i+1)%6+7+count*4,i+7+count*4);

    fprintf(fp,"1 1\n");
    fprintf(fp,"None, degree \n");

    for (i=0,k=0;i<FJoint.GetSize();i++) {
//      if (FJoint[i].GetSort() == 9 || FJoint[i].GetSort() == 1) {
      if (FJoint[i].GetSort() == 9) {
        for (j=0;j<4;j++)
                fprintf(fp,"%5d %5d\n",k*4+j+1,FJoint[i].GetSort());
        k++;
      }
    }

//  borehole location and geometry
    k = count*4+1;
    for (i=0;i<12;i++) fprintf(fp,"%5d %10.5f\n",k+i,0);

    fclose(fp);
}

MkJointPlane & MkTeleReader::operator[](int i)
{
    return FJoint[i];
}
//---------------------------------------------------------------------------
MkFaceMapReader::MkFaceMapReader()
{
    memo = (TObject*)NULL;
    memset(FileName,'\0',sizeof(FileName));
}

MkFaceMapReader::MkFaceMapReader(TObject *Sender)
{
    memo = dynamic_cast<TMemo *>(Sender);
    memset(FileName,'\0',sizeof(FileName));
}

MkFaceMapReader::~MkFaceMapReader()
{
}

void MkFaceMapReader::SetMemo(TObject *Sender)
{
    memo = dynamic_cast<TMemo *>(Sender);
    memo->Lines->Add("Memo is assigned to MkFaceMapReader!");
}

MkFaceMapReader::ReadFile()
{
      char str[256];
      int i;
      int count;

      FP = fopen(FileName,"r");
      if (!FP) {
         return false;
      }

      fgets(str,255,FP);

      if (strncmp(str,"Facemap",7)) {
         fclose(FP);
         return false;
      }

      count = 0;
      while(!feof(FP)) {
         if (!fgets(str,255,FP)) break;
         sscanf(str,"%d",&i);
         if (i!=0) count++;
      }

      MkJointPlane *jp = new MkJointPlane[count];
      Station.Initialize(count);

      rewind(FP);
      fgets(str,255,FP);

      if (strncmp(str,"Facemap",7)) {
         fclose(FP);
         return false;
      }

      count = 0;
      while(!feof(FP)) {
         float station,depth,dipdir,dip,aperture;
         int sort=0,form=0,condition=0;
         int dmmy;
         if (!fgets(str,255,FP)) break;

         sscanf(str,"%f %f %f",&station,&dip,&dipdir);

         int I;float J;
         I = int(station/1000);
         J = station - I*1000;

//         if (dip < 0) dipdir += 270;
//         else dipdir += 90;
//         dip = dip > 0 ? dip : -dip;

         Station(count) = station;
         Location = FRailWay(I,J);
         jp[count].SetDipNDir(dip,dipdir);
         jp[count].SetScale(35,35);
         jp[count].SetTranslate(Location.X,Location.Y,Location.Z);

         str[strlen(str)-1] = '\0';
         memo->Lines->Add(str);
         count++;
      }

      FJoint.Initialize(count,jp);

      delete[] jp;
      fclose(FP);
      return true;
}

MkFaceMapReader::ReadFile(char *file_name)
{
     SetFileName(file_name);
     return ReadFile();
}

MkJointPlane & MkFaceMapReader::operator[](int i)
{
    return FJoint[i];
}

//---------------------------------------------------------------------------

MkJSetReader::MkJSetReader()
{
    memo = (TObject*)NULL;
    memset(FileName,'\0',sizeof(FileName));
}

MkJSetReader::MkJSetReader(TObject *Sender)
{
    memo = dynamic_cast<TMemo *>(Sender);
    memset(FileName,'\0',sizeof(FileName));
}

MkJSetReader::~MkJSetReader()
{

}

void MkJSetReader::SetMemo(TObject *Sender)
{
    memo = dynamic_cast<TMemo *>(Sender);
    if (!memo) memo->Lines->Add("Memo is assigned to MkTeleReader!");
}

MkJSetReader::ReadFile()
{
      char str[256],title[10];
      int i;
      int count;

      float station,offset;

      FP = fopen(FileName,"r");
      if (!FP) {
         return false;
      }

      fgets(str,255,FP);
      AnsiString Astr(str);
      if (strncmp(Astr.UpperCase().c_str(),"JOINT",5)) {
         fclose(FP);
         return false;
      }

      fgets(str,255,FP);
      sscanf(str,"%f %f",&station,&offset);

      Station = station;
      Offset = offset;

      int I;float J;
      I = int(station/1000);
      J = station - I*1000;

      Location = FRailWay(I,J);

      fgets(str,255,FP);

      count = 0;
      while(!feof(FP)) {
         if (!fgets(str,255,FP)) break;
         sscanf(str,"%d",&i);
         if (i!=0) count++;
      }

      JSet *js = new JSet[count];

      rewind(FP);
      fgets(str,255,FP);

      if (strncmp(Astr.UpperCase().c_str(),"JOINT",5)) {
         fclose(FP);
         return false;
      }

      fgets(str,255,FP);
      sscanf(str,"%f %f",&station,&offset);

      sprintf(str,"Station : %dK%.0f",I,J);
      if (memo) memo->Lines->Add(str);
      if (memo) memo->Lines->Add("-----------------------");

      fgets(str,255,FP);

      count = 0;
      while(!feof(FP)) {
         float mean_dip_dir,mean_dip,std_dev,percent;
         int dmmy;
         if (!fgets(str,255,FP)) break;

         sscanf(str,"%d %f %f %f %f",&dmmy,&mean_dip_dir,&mean_dip,&std_dev,&percent);

         js[count].SetDipDir(mean_dip_dir);
         js[count].SetDip(mean_dip);
         js[count].SetStdDev(std_dev);
         js[count].SetPercent(percent);

         str[strlen(str)-1] = '\0';
         if (memo) memo->Lines->Add(str);
         count++;
      }
      if (memo) memo->Lines->Add("-----------------------");
      if (memo) memo->Lines->Add(" ");

      FJSets.Initialize(count,js);

      delete[] js;
      fclose(FP);
      return true;

}

MkJSetReader::ReadFile(char *file_name)
{
      SetFileName(file_name);
      ReadFile();
}
//---------------------------------------------------------------------------
MkBoreholesReader::MkBoreholesReader()
{
    memo = (TObject*)NULL;
    memset(FileName,'\0',sizeof(FileName));
}

MkBoreholesReader::MkBoreholesReader(TObject *Sender)
{
    memo = dynamic_cast<TMemo *>(Sender);
    memset(FileName,'\0',sizeof(FileName));
}

MkBoreholesReader::~MkBoreholesReader()
{

}

void MkBoreholesReader::SetMemo(TObject *Sender)
{
    memo = dynamic_cast<TMemo *>(Sender);
    if (!memo) memo->Lines->Add("Memo is assigned to MkTeleReader!");
}

MkBoreholesReader::ReadFile()
{
      char str[256],title[10];
      int i;
      int count;

      float station,offset;

      FP = fopen(FileName,"r");
      if (!FP) {
         return false;
      }

      fgets(str,255,FP);
      AnsiString Astr(str);
      if (strncmp(Astr.UpperCase().c_str(),"BOREHOLE",8)) {
         fclose(FP);
         return false;
      }

      fgets(str,255,FP);
      sscanf(str,"%f %f",&station,&offset);

      Station = station;
      Offset = offset;

      int I;float J;
      I = int(station/1000);
      J = station - I*1000;

      Location = FRailWay(I,J);

      fgets(str,255,FP);

      count = 0;
      while(!feof(FP)) {
         if (!fgets(str,255,FP)) break;
         sscanf(str,"%d",&i);
         if (i!=0) count++;
      }


      rewind(FP);
      fgets(str,255,FP);

      if (strncmp(Astr.UpperCase().c_str(),"BOREHOLE",8)) {
         fclose(FP);
         return false;
      }

      fgets(str,255,FP);
      sscanf(str,"%f %f",&station,&offset);

      sprintf(str,"Station : %dK%.0f",I,J);
      if (memo) memo->Lines->Add(str);
      if (memo) memo->Lines->Add("-----------------------");

      fgets(str,255,FP);

      count = 0;
      while(!feof(FP)) {

      }
      if (memo) memo->Lines->Add("-----------------------");
      if (memo) memo->Lines->Add(" ");

      fclose(FP);
      return true;

}

MkBoreholesReader::ReadFile(char *file_name)
{
      SetFileName(file_name);
      ReadFile();
}

//---------------------------------------------------------------------------

MkFaultReader::MkFaultReader()
{
    for (int i=0;i<255;i++) FileName[i] = '\0';
    memo = (TMemo*)NULL;
}

MkFaultReader::MkFaultReader(TObject *Sender)
{
    memo = dynamic_cast<TMemo *>(Sender);
    memset(FileName,'\0',sizeof(FileName));
}

MkFaultReader::~MkFaultReader()
{

}

void MkFaultReader::SetMemo(TObject *Sender)
{
    memo = dynamic_cast<TMemo *>(Sender);
    if (!memo) memo->Lines->Add("Memo is assigned to MkTeleReader!");
}

bool MkFaultReader::ReadFile()
{
      char str[256];
      int i;
      int count;
      int Case;

      float station,offset;

      FP = fopen(FileName,"r");
      if (!FP) {
         return false;
      }

      fgets(str,255,FP);
      AnsiString Astr(str);
      if (strncmp(Astr.UpperCase().c_str(),"FAULT",5) &&
          strncmp(Astr.UpperCase().c_str(),"FLTLO",5) &&
          strncmp(Astr.UpperCase().c_str(),"FLTLZ",5)) {
         fclose(FP);
         return false;
      }
      if (!strncmp(Astr.UpperCase().c_str(),"FAULT",5)) Case = 1;
      else if (!strncmp(Astr.UpperCase().c_str(),"FLTLO",5)) Case = 2;
      else if (!strncmp(Astr.UpperCase().c_str(),"FLTLZ",5)) Case = 3;

      fgets(str,255,FP); // column title

      count = 0;
      while(!feof(FP)) {
         if (!fgets(str,255,FP)) break;
         sscanf(str,"%d",&i);
         if (i!=0) count++;
      }

      MkFault *fault = new MkFault[count];

      rewind(FP);

      fgets(str,255,FP);

      fgets(str,255,FP); // column title

      count = 0;
      while(!feof(FP)) {
         float station,x,y,z,dip,dir,thickness,length;

         int dmmy;
         if (!fgets(str,255,FP)) break;

         if (Case == 1) {
            sscanf(str,"%f %f %f %f %f",&station,&dip,&dir,&thickness,&length);
            fault[count].SetStation(station);
            int I = int(station/1000);
            int J = station - I*1000;
            MkPoint cen = FRailWay(I,J);
            fault[count].SetCenter(cen);
         }
         else if (Case == 2) {
            sscanf(str,"%f %f %f %f %f %f",&x,&y,&dip,&dir,&thickness,&length);
            fault[count].SetCenter(MkPoint(x,y,0));
         }
         else if (Case == 3) {
            sscanf(str,"%f %f %f %f %f %f %f",&x,&y,&z,&dip,&dir,&thickness,&length);
            fault[count].SetCenter(MkPoint(x,y,z));
         }

         fault[count].SetDip(dip);
         fault[count].SetDipDir(dir);
         fault[count].SetThickness(thickness);
         fault[count].SetLength(length);

         str[strlen(str)-1] = '\0';
         if (memo) memo->Lines->Add(str);
         count++;
      }
      if (memo) memo->Lines->Add("-----------------------");
      if (memo) memo->Lines->Add(" ");

      FFaults.Initialize(count,fault);

      delete[] fault;

      fclose(FP);
      return true;

}

bool MkFaultReader::ReadFile(char *file_name)
{
      SetFileName(file_name);
      ReadFile();
}
//---------------------------------------------------------------------------

MkResistReader::MkResistReader()
{
    memset(FileName,'\0',255);
    memo = (TMemo*)NULL;
}

MkResistReader::MkResistReader(TObject *Sender)
{
    memo = dynamic_cast<TMemo *>(Sender);
    memset(FileName,'\0',sizeof(FileName));
}

MkResistReader::~MkResistReader()
{

}

void MkResistReader::SetMemo(TObject *Sender)
{
    memo = dynamic_cast<TMemo *>(Sender);
    if (!memo) memo->Lines->Add("Memo is assigned to MkTeleReader!");
}

void remove(char *str)
{
    int i,count;
    count = strlen(str);
    for (i = 0 ; i < count ; i++) {
        if(str[i] == '\t' || str[i] == '\n') str[i] = ' ';
    }
}
char* move_p(char *str)
{
   while( *str == ' ' && *str != '\0') str++;
   return str;
}

bool MkResistReader::ReadFile()
{
      char str[256],dmmy[256];
      int i,j;
      int NumVert, NumDepth; // ����Ž�� ���� �� ��Ž���ڷ��� ������尹��
      int Case;
      int count;
      float fmmy;
      Float Depth,Res;
      Float X,Y,Z;

      float station,offset;

      FP = fopen(FileName,"r");
      if (!FP) {
         return false;
      }

      fgets(str,255,FP);
      AnsiString Astr(str);
      if (strncmp(Astr.UpperCase().c_str(),"#DIPOLEDIPOLE",13) &&
          strncmp(Astr.UpperCase().c_str(),"#SCHLUMBERGER",13)) {
         fclose(FP);
         return false;
      }
      if (!strncmp(Astr.UpperCase().c_str(),"#DIPOLEDIPOLE",13)) Case = 1;
      else if (!strncmp(Astr.UpperCase().c_str(),"#SCHLUMBERGER",13)) Case = 2;

//      fgets(str,255,FP); // column title
      if (Case == 1) {

      }
      else if (Case == 2) {
        while(!feof(FP)) {
          fgets(str,255,FP);remove(str);memo->Lines->Add(str);

          if(!strncmp(str,"#DATA",5)) {
            sscanf(str,"%s %d %d", dmmy, &NumVert, &NumDepth);
            if (!(NumVert * NumDepth)) {
              fclose(FP);
              return false;
            }
            if (!FResist.GetSize()) FResist.Initialize(NumVert*NumDepth);
            count = 0;
            Depth.Initialize(NumDepth);
            Res.Initialize(NumVert);
            fgets(str,255,FP);remove(str);memo->Lines->Add(str); // read comment
            char *pt;
            for (i=0;i<NumDepth;i++){
              fgets(str,255,FP);remove(str);memo->Lines->Add(str);
              pt = str;
              memset(dmmy,'\0',255);
              sscanf(pt,"%s",dmmy);
              sscanf(dmmy,"%f",&Depth(i));
              pt = pt + strlen(dmmy);
              pt = move_p(pt);

              for(j=0;j<NumVert;j++) {
                memset(dmmy,'\0',255);
                sscanf(pt,"%s",dmmy);
//                sscanf(dmmy,"%f",&Res[(long)j]);
                sscanf(dmmy,"%f",&fmmy);
                Res(j) = fmmy;
                pt = move_p(pt);
                pt = pt + strlen(dmmy);

                FResist[count] = Res(j);
                count++;
              }
            }
          }
          if(!strncmp(str,"#COORD",6)) {
            sscanf(str,"%s %d %d", dmmy, &NumVert, &NumDepth);
            if (!(NumVert * NumDepth)) {
              fclose(FP);
              return false;
            }
            X.Initialize(NumVert);
            Y.Initialize(NumVert);
            Z.Initialize(NumVert);
            if (!FResist.GetSize()) FResist.Initialize(NumVert*NumDepth);
            count = 0;
            for (i = 0;i < NumVert;i++) {
              fgets(str,255,FP);remove(str);memo->Lines->Add(str);
              sscanf(str,"%d %f %f",&j,&X(i),&Y(i));
            }

            for (i = 0 ; i < NumDepth;i++) {
              for (j = 0 ; j < NumVert;j++) {
                float Z;
                Z = FTopoGrid(X(j),Y(j)) - Depth(i);
                MkPoint rp(X(j),Y(j),Z);
                FResist[count].X = rp.X;
                FResist[count].Y = rp.Y;
                FResist[count].Z = rp.Z;
                count++;
              }
            }
          }
        }
      }
      fclose(FP);
}

bool MkResistReader::ReadFile(char *file_name)
{
      SetFileName(file_name);
      ReadFile();
}

//---------------------------------------------------------------------------
MkCNPReader::MkCNPReader()
{
    memset(FileName,'\0',sizeof(FileName));
    memo = (TMemo*)NULL;
}

MkCNPReader::MkCNPReader(TObject *Sender)
{
    memo = dynamic_cast<TMemo *>(Sender);
    memset(FileName,'\0',sizeof(FileName));
}

MkCNPReader::~MkCNPReader()
{

}

void MkCNPReader::SetMemo(TObject *Sender)
{
    memo = dynamic_cast<TMemo *>(Sender);
    if (!memo) memo->Lines->Add("Memo is assigned to MkTeleReader!");
}

bool MkCNPReader::ReadFile(char *file_name)
{
    SetFileName(file_name);
    ReadFile();
}

bool MkCNPReader::ReadFile()
{
      char str[256];
      FP = fopen(FileName,"r");
      if (!FP) {
         return false;
      }

      fgets(str,255,FP);
      AnsiString Astr(str);
      if (strncmp(Astr.UpperCase().c_str(),"#CUT&PASTE",10)) {
         fclose(FP);
         return false;
      }
      fgets(str,255,FP);
      sscanf(str,"%d",&NumOfPlanes);
      if (NumOfPlanes <= 0) {
         fclose(FP);
         return false;
      }

      NumOfEachPlanes.Initialize(NumOfPlanes);
      FPointsPlanes.Initialize(NumOfPlanes);

      for (int i = 0 ; i < NumOfPlanes;i++) {
          int n;
          char mode[10],tit1[10],tit2[10];
          float v1,v2;
          THeightMode hm;
          MkOrient fo;
          fgets(str,255,FP);
          sscanf(str,"%d %s %s %f %s %f",&n,mode,tit1,&v1,tit2,&v2);
          if (n < 3) {
             fclose(FP);
             NumOfEachPlanes.Clear();
             FPointsPlanes.Clear();
             return false;
          }
          NumOfEachPlanes[i] = n;
          FPointsPlanes[i].Initialize(n);

          if (!strncmp(mode,"Paste",5)) FPointsPlanes[i].SetHeightMode(hmPaste);
          else if (!strncmp(mode,"Cut",3)) FPointsPlanes[i].SetHeightMode(hmCut);
          else FPointsPlanes[i].SetHeightMode(hmAbs);

          if (!strncmp(tit1,"DipDir",6)&& !strncmp(tit2,"Dip",3)) {
             fo.DipDir = v1;
             fo.Dip = v2;
          }
          else if (!strncmp(tit1,"Dip",3)&& !strncmp(tit2,"DipDir",6)) {
             fo.DipDir = v2;
             fo.Dip = v1;
          }
          else {
             fo.DipDir = 0;
             fo.Dip = 0;
          }

          FPointsPlanes[i].SetOrient(fo);
          for (int j = 0 ; j < n;j++) {
              float x,y,z;
              fgets(str,255,FP);
              sscanf(str,"%f %f %f",&x,&y,&z);
              FPointsPlanes[i][j].SetPoint(x,y,z);
          }
      }
      fclose(FP);
      return true;
}

//---------------------------------------------------------------------------