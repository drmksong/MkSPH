//---------------------------------------------------------------------------
#include "MkBeam.h"
#ifdef __BCPLUSPLUS__
#include <vcl.h>
#endif
#pragma hdrstop
//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#pragma package(smart_init)
#endif
//---------------------------------------------------------------------------
MkBeam NullMkBeam(0);
MkBeam::MkBeam()
{
  Clear();
}

MkBeam::MkBeam(int)
{
  Clear();
}

void MkBeam::Clear()
{
  BB=0;
  HH=0;
  tt1=0;
  tt2=0;
  AA=0;
  W=0;
  Aw=0;
  Zx=0;
  Ix=0;
  rx=0;
  ry=0;
}

#ifdef __BCPLUSPLUS__
void MkBeam::Import(MkGlobalVar &globalvar, int sec)
{
  switch(BeamType) {
    case btSidePile: {
      BB=globalvar.sidepile_BB[sec+1];
      HH=globalvar.sidepile_HH[sec+1];
      tt1=globalvar.sidepile_tt1[sec+1];
      tt2=globalvar.sidepile_tt2[sec+1];
      AA=globalvar.sidepile_AA[sec+1];
      W=globalvar.sidepile_W[sec+1];
      Aw=globalvar.sidepile_Aw[sec+1];
      Zx=globalvar.sidepile_Zx[sec+1];
      Ix=globalvar.sidepile_Ix[sec+1];
      rx=globalvar.sidepile_rx[sec+1];
      ry=globalvar.sidepile_ry[sec+1];
     }
    break;
    case btMidPile: {
      BB=globalvar.midpile_BB[sec+1];
      HH=globalvar.midpile_HH[sec+1];
      tt1=globalvar.midpile_tt1[sec+1];
      tt2=globalvar.midpile_tt2[sec+1];
      AA=globalvar.midpile_AA[sec+1];
      W=globalvar.midpile_W[sec+1];
      Aw=globalvar.midpile_Aw[sec+1];
      Zx=globalvar.midpile_Zx[sec+1];
      Ix=globalvar.midpile_Ix[sec+1];
      rx=globalvar.midpile_rx[sec+1];
      ry=globalvar.midpile_ry[sec+1];
    }
    break;
    case btMainBeam: {
      BB=globalvar.mainbeam_BB[sec+1];
      HH=globalvar.mainbeam_HH[sec+1];
      tt1=globalvar.mainbeam_tt1[sec+1];
      tt2=globalvar.mainbeam_tt2[sec+1];
      AA=globalvar.mainbeam_AA[sec+1];
      W=globalvar.mainbeam_W[sec+1];
      Aw=globalvar.mainbeam_Aw[sec+1];
      Zx=globalvar.mainbeam_Zx[sec+1];
      Ix=globalvar.mainbeam_Ix[sec+1];
      rx=globalvar.mainbeam_rx[sec+1];
      ry=globalvar.mainbeam_ry[sec+1];
    }
    break;
    case btSupportBeam: {
      BB=globalvar.supportbeam_BB[sec+1];
      HH=globalvar.supportbeam_HH[sec+1];
      tt1=globalvar.supportbeam_tt1[sec+1];
      tt2=globalvar.supportbeam_tt2[sec+1];
      AA=globalvar.supportbeam_AA[sec+1];
      W=globalvar.supportbeam_W[sec+1];
      Aw=globalvar.supportbeam_Aw[sec+1];
      Zx=globalvar.supportbeam_Zx[sec+1];
      Ix=globalvar.supportbeam_Ix[sec+1];
      rx=globalvar.supportbeam_rx[sec+1];
      ry=globalvar.supportbeam_ry[sec+1];
    }
    break;
    case btSupportBeam_M: {
      BB=globalvar.supportbeam_m_BB[sec+1];
      HH=globalvar.supportbeam_m_HH[sec+1];
      tt1=globalvar.supportbeam_m_tt1[sec+1];
      tt2=globalvar.supportbeam_m_tt2[sec+1];
      AA=globalvar.supportbeam_m_AA[sec+1];
      W=globalvar.supportbeam_m_W[sec+1];
      Aw=globalvar.supportbeam_m_Aw[sec+1];
      Zx=globalvar.supportbeam_m_Zx[sec+1];
    }
    break;
    case btStrut: {
      BB=globalvar.strut_BB[sec+1];
      HH=globalvar.strut_HH[sec+1];
      tt1=globalvar.strut_tt1[sec+1];
      tt2=globalvar.strut_tt2[sec+1];
      AA=globalvar.strut_AA[sec+1];
      W=globalvar.strut_W[sec+1];
      Aw=globalvar.strut_Aw[sec+1];
      Zx=globalvar.strut_Zx[sec+1];
      Ix=globalvar.strut_Ix[sec+1];
      rx=globalvar.strut_rx[sec+1];
      ry=globalvar.strut_ry[sec+1];
    }
    break;
    case btSheetPile: {
      BB=globalvar.sheetpile_BB[sec+1];
      HH=globalvar.sheetpile_HH[sec+1];
      tt1=globalvar.sheetpile_tt1[sec+1];
      AA=globalvar.sheetpile_AA[sec+1];
      W=globalvar.sheetpile_W[sec+1];
      Aw=globalvar.sheetpile_Aw[sec+1];
      Zx=globalvar.sheetpile_Zx[sec+1];
    }
    break;
  }
}

void MkBeam::Export(MkGlobalVar &globalvar, int sec)
{
  switch(BeamType) {
    case btSidePile: {
      globalvar.sidepile_BB[sec+1] =BB;
      globalvar.sidepile_HH[sec+1] =HH;
      globalvar.sidepile_tt1[sec+1]=tt1;
      globalvar.sidepile_tt2[sec+1]=tt2;
      globalvar.sidepile_AA[sec+1] =AA;
      globalvar.sidepile_W[sec+1]  =W ;
      globalvar.sidepile_Aw[sec+1] =Aw;
      globalvar.sidepile_Zx[sec+1] =Zx;
      globalvar.sidepile_Ix[sec+1] =Ix;
      globalvar.sidepile_rx[sec+1] =rx;
      globalvar.sidepile_ry[sec+1] =ry;
     }
    break;
    case btMidPile: {
      globalvar.midpile_BB[sec+1]=BB;
      globalvar.midpile_HH[sec+1]=HH;
      globalvar.midpile_tt1[sec+1]=tt1;
      globalvar.midpile_tt2[sec+1]=tt2;
      globalvar.midpile_AA[sec+1]=AA;
      globalvar.midpile_W[sec+1]=W;
      globalvar.midpile_Aw[sec+1]=Aw;
      globalvar.midpile_Zx[sec+1]=Zx;
      globalvar.midpile_Ix[sec+1]=Ix;
      globalvar.midpile_rx[sec+1]=rx;
      globalvar.midpile_ry[sec+1]=ry;
    }
    break;
    case btMainBeam: {
      globalvar.mainbeam_BB[sec+1]=BB;
      globalvar.mainbeam_HH[sec+1]=HH;
      globalvar.mainbeam_tt1[sec+1]=tt1;
      globalvar.mainbeam_tt2[sec+1]=tt2;
      globalvar.mainbeam_AA[sec+1]=AA;
      globalvar.mainbeam_W[sec+1]=W;
      globalvar.mainbeam_Aw[sec+1]=Aw;
      globalvar.mainbeam_Zx[sec+1]=Zx;
      globalvar.mainbeam_Ix[sec+1]=Ix;
      globalvar.mainbeam_rx[sec+1]=rx;
      globalvar.mainbeam_ry[sec+1]=ry;
    }
    break;
    case btSupportBeam: {
      globalvar.supportbeam_BB[sec+1]=BB;
      globalvar.supportbeam_HH[sec+1]=HH;
      globalvar.supportbeam_tt1[sec+1]=tt1;
      globalvar.supportbeam_tt2[sec+1]=tt2;
      globalvar.supportbeam_AA[sec+1]=AA;
      globalvar.supportbeam_W[sec+1]=W;
      globalvar.supportbeam_Aw[sec+1]=Aw;
      globalvar.supportbeam_Zx[sec+1]=Zx;
      globalvar.supportbeam_Ix[sec+1]=Ix;
      globalvar.supportbeam_rx[sec+1]=rx;
      globalvar.supportbeam_ry[sec+1]=ry;
    }
    break;
    case btSupportBeam_M: {
      globalvar.supportbeam_m_BB[sec+1]=BB;
      globalvar.supportbeam_m_HH[sec+1]=HH;
      globalvar.supportbeam_m_tt1[sec+1]=tt1;
      globalvar.supportbeam_m_tt2[sec+1]=tt2;
      globalvar.supportbeam_m_AA[sec+1]=AA;
      globalvar.supportbeam_m_W[sec+1]=W;
      globalvar.supportbeam_m_Aw[sec+1]=Aw;
      globalvar.supportbeam_m_Zx[sec+1]=Zx;
    }
    break;
    case btStrut: {
      globalvar.strut_BB[sec+1]=BB;
      globalvar.strut_HH[sec+1]=HH;
      globalvar.strut_tt1[sec+1]=tt1;
      globalvar.strut_tt2[sec+1]=tt2;
      globalvar.strut_AA[sec+1]=AA;
      globalvar.strut_W[sec+1]=W;
      globalvar.strut_Aw[sec+1]=Aw;
      globalvar.strut_Zx[sec+1]=Zx;
      globalvar.strut_Ix[sec+1]=Ix;
      globalvar.strut_rx[sec+1]=rx;
      globalvar.strut_ry[sec+1]=ry;
    }
    break;
    case btSheetPile: {
      globalvar.sheetpile_BB[sec+1]=BB;
      globalvar.sheetpile_HH[sec+1]=HH;
      globalvar.sheetpile_tt1[sec+1]=tt1;
      globalvar.sheetpile_AA[sec+1]=AA;
      globalvar.sheetpile_W[sec+1]=W;
      globalvar.sheetpile_Aw[sec+1]=Aw;
      globalvar.sheetpile_Zx[sec+1]=Zx;
    }
    break;
  }
}
#endif

bool MkBeam::operator==(MkBeam &beam)
{
  bool flag=true;
  flag = flag && SteelType==beam.SteelType;
  flag = flag && BeamType==beam.BeamType;

  flag = flag && BB==beam.BB;
  flag = flag && HH==beam.HH;
  flag = flag && tt1==beam.tt1;
  flag = flag && tt2==beam.tt2;
  flag = flag && AA==beam.AA;
  flag = flag && W==beam.W;
  flag = flag && Aw==beam.Aw;
  flag = flag && Zx==beam.Zx;
  flag = flag && Ix==beam.Ix;
  flag = flag && rx==beam.rx;
  flag = flag && ry==beam.ry;
  return flag;
}

bool MkBeam::operator!=(MkBeam &beam)
{
  return !operator==(beam);
}

MkBeam &MkBeam::operator=(MkBeam &beam)
{
  SteelType=beam.SteelType;
  BeamType=beam.BeamType;

  BB=beam.BB;
  HH=beam.HH;
  tt1=beam.tt1;
  tt2=beam.tt2;
  AA=beam.AA;
  W=beam.W;
  Aw=beam.Aw;
  Zx=beam.Zx;
  Ix=beam.Ix;
  rx=beam.rx;
  ry=beam.ry;
  return *this;
}
//---------------------------------------------------------------------------
MkBeams::MkBeams(int size,MkBeam *beams)
{
    if (size < 0) {
      MkDebug("::MkBeams - MkBeams(int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSize == 0) {
       FBeam = NULL;
       return;
    }

    FBeam = new MkBeam[FSize];
    for (int i=0;i<FSize;i++) (*this)[i] = beams[i];
}

MkBeams::MkBeams(int size)
{
    if (size < 0) {
      MkDebug("::MkBeams - MkBeams(int size)");;
      return;
    }

    FSize = FSizeOfArray = size;

    if (FSizeOfArray == 0) {
       FBeam = NULL;
       return;
    }

    FBeam = new MkBeam[FSizeOfArray];
}

MkBeams::~MkBeams()
{
   FSizeOfArray = FSize = 0;
   if (FBeam) {
      delete[] FBeam;
      FBeam = NULL;
   }
}

void MkBeams::Initialize(int size)
{
    if (size < 0) {
      MkDebug("::MkBeams - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;

    FSize = FSizeOfArray = size;

    if (FSizeOfArray == 0) {
       if (FBeam!=NULL) delete[] (MkBeam*)FBeam;
       FBeam = NULL;
       return;
    }

    if (FBeam!=NULL) delete[] (MkBeam*)FBeam;
    FBeam = new MkBeam[FSizeOfArray];
}

void MkBeams::Initialize(int size,MkBeam *beams)
{

    if (size < 0 || beams == NULL) {
      MkDebug("::MkBeams - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSize = FSizeOfArray = size;
    if (FSizeOfArray == 0) {
       if (FBeam!=NULL) delete[] (MkBeam*)FBeam;
       FBeam = NULL;
       return;
    }

    if (FBeam!=NULL) delete[] (MkBeam*)FBeam;
    FBeam = new MkBeam[FSizeOfArray];
    for (int i=0;i<FSizeOfArray;i++) FBeam[i] = beams[i];
}

int MkBeams::Grow(int delta)
{
    int i;
    MkBeam *beam=NULL;

    if (!(beam = new MkBeam[FSizeOfArray+delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        beam[i] = FBeam[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        beam[i] = NullMkBeam;
    if (FBeam) {
       delete[] (MkBeam*)FBeam;
       FBeam = NULL;
    }
    FBeam = beam;
    FSizeOfArray = FSizeOfArray+delta;

    return FSizeOfArray;
}

int MkBeams::Shrink(int delta)
{
    int i;
    MkBeam *beam=NULL;

    if (!(beam = new MkBeam[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        beam[i] = FBeam[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        beam[i] = NullMkBeam;
    if (FBeam) {
       delete[] (MkBeam*)FBeam;
       FBeam = NULL;
    }
    FBeam = beam;
    FSizeOfArray = FSizeOfArray-delta;

    return FSizeOfArray;
}

bool MkBeams::Add(MkBeam &beam)
{
    int tmp=FSizeOfArray;
    bool flag=false;
    for (int i=0;i<FSize;i++) if (FBeam[i]==beam) flag=true;

    if(flag) return false;
    if (FSize>=FSizeOfArray) {
       Grow(FSize-FSizeOfArray+10);
       if (tmp==FSizeOfArray) return false;
    }
    FSize++;
    FBeam[FSize-1] = beam;

    return true;
}

bool MkBeams::Add(int index, MkBeam &beam)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) Grow(FSize-FSizeOfArray+1);
    if(tmp==FSizeOfArray) return false;

    for (int i=FSize-1;i>=index;i--)
      FBeam[i+1] = FBeam[i];
    FSize++;
    FBeam[index] = beam;
    return true;
}

bool MkBeams::Delete(MkBeam &beam)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FBeam[i] == beam) break;
    }
    if(i==FSize) return false;
    if(FBeam[i] == beam) {
      for (int j=i;j<FSize-1;j++)
        FBeam[j] = FBeam[j+1];
    }
    FSize--;
    FBeam[FSize] = NullMkBeam;
    return true;
}

bool MkBeams::Delete(int index)
{
    for (int j=index;j<FSize-1;j++)
        FBeam[j] = FBeam[j+1];

    FSize--;
    FBeam[FSize] = NullMkBeam;
    return true;
}

bool MkBeams::Clear()
{
   FSizeOfArray = FSize = 0;
   if (FBeam) {
      delete[] FBeam;
      FBeam = NULL;
   }
   return true;
}

MkBeam & MkBeams::operator[](int i)
{
    if (FSizeOfArray == 0) return NullMkBeam;
    if (i >= FSize && i < FSizeOfArray) FSize = i+1;

    if (i >=0 && i < FSize) return FBeam[i];
    else return NullMkBeam;
}

MkBeams & MkBeams::operator=(MkBeams &beams)
{
    int i;

    Clear();
    FSize = beams.FSize;
    FSizeOfArray = beams.FSizeOfArray;
    if (FSize == 0) {
       FBeam = NULL;
       return *this;
    }
    this->FBeam = new MkBeam[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FBeam[i] = beams.FBeam[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FBeam[i] = NullMkBeam;

    return *this;
}

bool MkBeams::operator==(MkBeams &beams)
{
  int i;

  if (FSize != beams.FSize) return false;
  for (i=0;i<FSize;i++)
    if (this->FBeam[i] != beams.FBeam[i]) return false;

  return true;
}
//---------------------------------------------------------------------------
