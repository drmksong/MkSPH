//---------------------------------------------------------------------------
#ifndef MkReaderH				   
#define MkReaderH
#include <stdio.h>
#include <string.h>
#include "MkPoint.h"
#include "MkPointData.h"
#include "MkLine.h"
#include "MkCircle.h"
#include "MkShape.h"
#include "MkPolygon.h"
#include "MkFloat.h"
#include "MkRailWay.h"
#include "MkPlane.h"
#include "JsetUnit.h"
#include "BoreholesUnit.h"
#include "FaultUnit.h"
#include "MkGrid.h"

enum Key {dummy_line,line,arc_by_line,arc,none} ;
enum MkResistType { Inv_Resist, Ver_Resist };

class MkGeomReader {
private:
      FILE *FP;
      char FileName[256];
      MkShapeList ShapeList;
      MkPolygon FRealPolygon;
      TMemo *memo;
public:
      MkGeomReader();
      MkGeomReader(TObject *);
      ~MkGeomReader();
      void SetMemo(TObject *);
      void SetFileName(char *file_name){if (file_name) strcpy(FileName,file_name);};
      MkShapeList & ReadFile();
      MkShapeList & ReadFile(char *file_name);
      MkShapeList & GetShapeList() {return ShapeList;}
      void SetPolygon(MkPolygon &rp){FRealPolygon = rp;}
      MkPolygon &GetPolygon(){return FRealPolygon;}
      char * GetFileName(){return FileName;}
      MkPoint & operator[](int i);
      int GetNumOfPoints(void){return FRealPolygon.GetSize();}
};

class MkRailWayReader {
private:
      FILE *FP;
      char FileName[256];
      MkRailWay FRailWay;
      MkRailWay FRailWay2;
      TMemo *memo;
      int NumOfLine;
public:
      MkRailWayReader();
      MkRailWayReader(TObject *);
      ~MkRailWayReader();
      void SetMemo(TObject *);
      void SetFileName(char *file_name){if (file_name) strcpy(FileName,file_name);};
      bool ReadFile();
      bool ReadFile(char *file_name);
      MkRailWay & GetRailWay() {return FRailWay;}
      MkRailWay & GetRailWay(int i) {if (i==1)return FRailWay; else if (i==2)return FRailWay2;}
      char *GetFileName() {return FileName;}
      MkPoint operator()(int k,int i,float j);
      MkPoint operator()(int i,float j);
      bool SaveLayerData();
      bool SaveLayerData(char *);
      void SetNumOfLine(int n){NumOfLine = n;}
      int  GetNumOfLine(void){return NumOfLine;}
public:
      float XMin,XMax,YMin,YMax;
};

enum MkDataType {dtField,dtTomography} ;

struct ModFlowData {
      int NumOfLayer; // maximum layer is 5
      int NumOfGrid[5];
      float LevelOfDatum;

      ModFlowData();
      ModFlowData & operator=(ModFlowData&);
};

class MkGridReader {
private:
      FILE *FP;
      MkDataType FDataType;
      MkRailWay FRailWay;
      MkLine CutLine;

      char GridFileName[256];
      char FldFileName[256];
      char TomoFileName[256];
      char LayerFileName[256];
      char LayerFldFileName1[256];
      char LayerFldFileName2[256];
      char LayerFldFileName3[256];
      char LayerFldFileName4[256];
      char LayerFldFileName5[256];
      char FirstLayerName[256];
      char SecondLayerName[256];
      char ThirdLayerName[256];
      char FourthLayerName[256];
      char FifthLayerName[256];
      char FirstLayerGridName[256];
      char SecondLayerGridName[256];
      char CutFileName[256];
      char ModFlowFileName[256];

      TMemo *memo;
      int NX,NY;
      Float Side;
//      Float FirstLayerData,SecondLayerData,ThirdLayerData;  //delete it
      Float X,Y,Z,Data,FirstLayerData,SecondLayerData,ThirdLayerData,FourthLayerData,FifthLayerData;
      ModFlowData FModFlowData;

      float XMin,XMax,YMin,YMax,ZMin,ZMax,DataMin,DataMax;//Z mean value.
      float Station;  // 40km500 = 40500
public:
      MkGridReader();
      MkGridReader(TObject *);
      ~MkGridReader();
      void SetMemo(TObject *);
      void SetRailWay(MkRailWay &RailWay){FRailWay = RailWay;};
      void SetStation(float station){Station = station;};
      float GetStation(){return Station;}
      void SetGridFileName(char *file_name){if (file_name) strcpy(GridFileName,file_name);};
      char *GetGridFileName(){return GridFileName;}
      void SetFldFileName(char *file_name){if (file_name) strcpy(FldFileName,file_name);};
      void SetTomoFileName(char *file_name){if (file_name) strcpy(TomoFileName,file_name);};
      void SetFirstLayerFileName(char *file_name){if (file_name) strcpy(FirstLayerName,file_name);};
      void SetSecondLayerFileName(char *file_name){if (file_name) strcpy(SecondLayerName,file_name);};
      void SetThirdLayerFileName(char *file_name){if (file_name) strcpy(ThirdLayerName,file_name);};
      void SetFourthLayerFileName(char *file_name){if (file_name) strcpy(FourthLayerName,file_name);};
      void SetFifthLayerFileName(char *file_name){if (file_name) strcpy(FifthLayerName,file_name);};
      void SetLayerFileName(char *file_name);
      void SetCutFileName(char *file_name){if (file_name) strcpy(CutFileName,file_name);};
      void SetModFlowFileName(char *file_name){if (file_name) strcpy(ModFlowFileName,file_name);};
      void SetCutLine(MkLine rl){CutLine = rl;};
      void SetCutLine(MkPoint sp,MkPoint ep){CutLine = MkLine(sp,ep);};
      void SetFirstLayerGridName(char *fname){strcpy(FirstLayerGridName,fname);};
      void SetSecondLayerGridName(char *fname){strcpy(SecondLayerGridName,fname);};
      void SetModFlowData(ModFlowData &data){FModFlowData = data;}
      bool ReadFile();
      bool ReadTomoFile();
      bool ReadFirstLayerFile();
      bool ReadSecondLayerFile();
      bool ReadThirdLayerFile();
      bool ReadFourthLayerFile();
      bool ReadFifthLayerFile();
      bool SaveFile();
      bool SaveGrid();
      bool SaveGrid(char *grid_file,Float &data);
      bool SaveFirstLayerGridFile();
      bool SaveSecondLayerGridFile();
      bool SaveTomoFile();
      bool SaveLayerFile();
      bool SaveCutFile();
      bool SaveModFlowFile();
      bool SaveLayerFile(char *file_name);
      bool ReadFile(char *file_name);
      bool ReadTomoFile(char *fine_name);
      bool SaveFile(char *file_name);
      bool SaveGrid(char *file_name);
      bool SaveTomoFile(char *file_name);
      bool SaveCutFile(char *file_name);
      bool SaveModFlowFile(char *file_name);      
      void SetSide(); //  initialize Side
      void ClearSide(); // destroy Side object
      void SetupSide();  // determine the side of the node

      float GetHeight(float x,float y);
      void  SetNX(int nx){NX = nx;}
      void  SetNY(int ny){NY = ny;}

      int  GetNX(){return NX;}
      int  GetNY(){return NY;}
      Float & GetX(){return X;}
      Float & GetY(){return Y;}
      Float & GetZ(){return Z;}
      Float & GetData(){return Data;}
      Float & GetFirstLayerData(){return FirstLayerData;}
      Float & GetSecondLayerData(){return SecondLayerData;}
      Float & GetThirdLayerData(){return ThirdLayerData;}
      Float & GetFourthLayerData(){return FourthLayerData;}
      Float & GetFifthLayerData(){return FifthLayerData;}
      void SetData(Float &data){Data.CopyFrom(data);}

      float operator()(float x,float y);
      float operator()(int i,int j);
public:
      float FXMin,FYMin;
};

class MkBoreReader {
private:
      FILE *FP;
      MkRailWay FRailWay;
      char FileName[256];
      char UCDFileName[256];
      char PatFileName[256];
      MkJointPlanes FJoint;
      float Station;
      float Offset;// �������ؼ����� �¿�� ��� ����, +�� ������, -�� ����
      MkPoint Location;
      Float FDepth;
      TMemo *memo;
public:
      MkBoreReader();
      MkBoreReader(TObject *);
      ~MkBoreReader();
      void SetMemo(TObject *);
      void SetRailWay(MkRailWay &RailWay){FRailWay = RailWay;}
      void SetFileName(char *file_name){if (file_name) strcpy(FileName,file_name);}
      void SetUCDFileName(char *file_name){if (file_name) strcpy(UCDFileName,file_name);}
      void SetPatFileName(char *file_name){if (file_name) strcpy(PatFileName,file_name);}

      char * GetFileName(){return FileName;}
      ReadFile();
      ReadFile(char *file_name);
      SaveUCDFile(char *file_name);
      SaveUCDFile();
      SavePatFile(char *file_name);
      SavePatFile();
      MkJointPlanes & GetJointPlanes() {return FJoint;}
      MkJointPlane & operator[](int i);
public:
      float FXMin,FYMin;
};

class MkTeleReader {
private:
      FILE *FP;
      MkRailWay FRailWay;
      char FileName[256];
      char UCDFileName[256];
      MkJointPlanes FJoint;
      float Station;
      float Offset;// �������ؼ����� �¿�� ��� ����, +�� ������, -�� ����
      MkPoint Location;
      Float FDepth;
      float MaxDepth;
      TMemo *memo;
public:
      MkTeleReader();
      MkTeleReader(TObject *);
      ~MkTeleReader();
      void SetMemo(TObject *);
      void SetRailWay(MkRailWay &RailWay){FRailWay = RailWay;};
      void SetFileName(char *file_name){if (file_name) strcpy(FileName,file_name);};
      void SetUCDFileName(char *file_name){if (file_name) strcpy(UCDFileName,file_name);};
      ReadFile();
      ReadFile(char *file_name);
      SaveUCDFile(char *file_name);
      SaveUCDFile();
      MkJointPlanes & GetJointPlanes() {return FJoint;}
      MkJointPlane & operator[](int i);
public:
      float FXMin,FYMin;
};

class MkFaceMapReader {
private:
      FILE *FP;
      MkRailWay FRailWay;
      char FileName[256];
      MkJointPlanes FJoint;
      Float Station;
      MkPoint Location;
      TMemo *memo;
public:
      MkFaceMapReader();
      MkFaceMapReader(TObject *);
      ~MkFaceMapReader();
      void SetMemo(TObject *);
      void SetRailWay(MkRailWay &RailWay){FRailWay = RailWay;}
      void SetFileName(char *file_name){if (file_name) strcpy(FileName,file_name);}

      char * GetFileName(){return FileName;}
      ReadFile();
      ReadFile(char *file_name);
      MkJointPlanes & GetJointPlanes() {return FJoint;}
      MkJointPlane & operator[](int i);
public:
      float FXMin,FYMin;
};

class MkJSetReader {
private:
      FILE *FP;
      JSets FJSets;
      char FileName[256];
      TMemo *memo;
      float Station,Offset;
      MkPoint Location;
      MkRailWay FRailWay;
public:
      MkJSetReader();
      MkJSetReader(TObject *);
      ~MkJSetReader();
      void SetMemo(TObject *);
      void SetFileName(char *file_name){if (file_name) strcpy(FileName,file_name);};
      ReadFile();
      ReadFile(char *file_name);
      JSets & GetJSets(){return FJSets;}
      float GetStation(){return Station;}
      JSet & operator[](int i){return FJSets[i];}
};

class MkBoreholesReader {
private:
      FILE *FP;
      MkBoreholes FBoreholes;
      char FileName[256];
      TMemo *memo;
      float Station,Offset;
      MkPoint Location;
      MkRailWay FRailWay;
public:
      MkBoreholesReader();
      MkBoreholesReader(TObject *);
      ~MkBoreholesReader();
      void SetMemo(TObject *);
      void SetFileName(char *file_name){if (file_name) strcpy(FileName,file_name);};
      ReadFile();
      ReadFile(char *file_name);
      MkBoreholes & GetBoreholes(){return FBoreholes;}
      float GetStation(){return Station;}
      float GetOffset(){return Offset;}
      MkBorehole & operator[](int i){return FBoreholes[i];}
};

class MkFaultReader {
private:
      FILE *FP;
      MkFaults FFaults;
      char FileName[256];
      TMemo *memo;
      MkRailWay FRailWay;
public:
      MkFaultReader();
      MkFaultReader(TObject *);
      ~MkFaultReader();
      void SetMemo(TObject *);
      void SetRailWay(MkRailWay &RailWay){FRailWay = RailWay;};
      void SetFileName(char *file_name){if (file_name) strcpy(FileName,file_name);};
      bool ReadFile();
      bool ReadFile(char *file_name);
      MkFaults & GetFaults(){return FFaults;}
      MkFault & GetFault(int i){return FFaults[i];}
      MkFault & operator[](int i){return FFaults[i];}
};

class MkResistReader {
private:
      FILE *FP;
      MkDataPoints FResist;
      char FileName[256];
      TMemo *memo;
      MkRailWay FRailWay;
      MkResistType FResistType;
      MkTopoGrid FTopoGrid;
public:
      MkResistReader();
      MkResistReader(TObject *);
      ~MkResistReader();
      void SetMemo(TObject *);
      void SetRailWay(MkRailWay &RailWay){FRailWay = RailWay;};
      void SetTopo(MkTopoGrid &TopoGrid){FTopoGrid = TopoGrid;}
      void SetFileName(char *file_name){if (file_name) strcpy(FileName,file_name);};
      MkDataPoints &GetResist(){return FResist;}
      bool ReadFile();
      bool ReadFile(char *file_name);
//      TResist & operator[](int i){return FResist[i];}
};

class MkCNPReader {
private:
      FILE *FP;
      MkPointsPlanes FPointsPlanes;
      char FileName[20];
      TMemo *memo;
      int NumOfPlanes;
      Int NumOfEachPlanes;
public:
      MkCNPReader();
      MkCNPReader(TObject *);
      ~MkCNPReader();
      void SetMemo(TObject *);
      void SetFileName(char *file_name){if (file_name) strcpy(FileName,file_name);};
      MkPointsPlanes &GetPointsPlanes(){return FPointsPlanes;}
      bool ReadFile();
      bool ReadFile(char *file_name);
};

//---------------------------------------------------------------------------
#endif
