//---------------------------------------------------------------------------
#ifndef MkFaultH
#define MkFaultH

#include "MkPoint.h"

class MkFault {
private:
   float Dip,DipDir,Thickness,Length,Station;
   MkPoint Center;
   MkPoint Location; // �ܺο��� �׻� �������־�� �Ѵ�.
public:
   MkFault();
   MkFault(float station,float dip,float dip_dir,float thickness,float length);
   void SetDip(float dip){Dip = dip;}
   void SetDipDir(float dip_dir){DipDir = dip_dir;}
   void SetThickness(float thickness){Thickness = thickness;}
   void SetLength(float length){Length = length;}
   void SetStation(float station){Station = station;}
   void SetStation(int i,float j){Station = i*1000+j;}
   void SetCenter(MkPoint cen){Center = cen;}
   float GetDip(){return Dip;}
   float GetDipDir(){return DipDir;}
   float GetThickness(){return Thickness;}
   float GetLength(){return Length;}
   float GetStation(){return Station;}
   MkPoint GetCenter(){return Center;}
   MkFault & operator=(MkFault &fault){ Dip = fault.Dip;
                                      DipDir = fault.DipDir;
                                      Thickness = fault.Thickness;
                                      Length = fault.Length;
                                      Station = fault.Station;
                                      Center = fault.Center;
                                      return *this;};
};

class MkFaults {
private:
      int FSize;
      MkFault  *FFault;
public:
       MkFaults();
       MkFaults(int);
       ~MkFaults();
       bool Initialize(int size);
       bool Initialize(int size,MkFault *fault);
       void Clear();

       MkFault & operator()(int);
       MkFault & operator[](int);
       MkFaults & operator=(MkFaults & a);

       int GetSize() { return FSize; };
};
extern MkFault NullFault;
//---------------------------------------------------------------------------
#endif
