//---------------------------------------------------------------------------
//#include "stdafx.h"
#include "MkContBeam.h"

#ifdef __BCPLUSPLUS__
#include <vcl.h>
#pragma hdrstop
#endif
//--------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#pragma package(smart_init)
#endif
MkContBeam::MkContBeam() : MkAnalysis()
{
  AnalysisType = atContBeam;
}

MkContBeam::MkContBeam(int n) : MkAnalysis(n)
{
  AnalysisType = atContBeam;
}

bool MkContBeam::Setup()
{                                                   
  //  boundary conditions and loads should be applied,
  //  before calling this, e.g.,
  //  Apply(loads);
  //  Apply(bc);
  //  in main routine
  int i,j,k;
  Elements.SetupStiff();
  Stiff.SetupMatrix(*NodeRef);
  Stiff.Assemble(Elements);
  Stiff.Out(FileName);

  int size=Stiff.GetStiffMatrix().GetFI();
  if(Var.GetSize()!=size) Var.Initialize(size);
  if(RHS.GetSize()!=size) RHS.Initialize(size);

  for (i=0;i<JackingForce.GetSize();i++) {
    NodalLoad(JackingForce.GetNode(i),0) += JackingForce.GetForce(i);
  }
  for (i=0;i<IniForceCorrect.GetSize();i++) {
    NodalLoad(IniForceCorrect.GetNode(i),0) += IniForceCorrect.GetForce(i);
  }

  for (i=0;i<RHS.GetSize();i++) {
    j=Stiff.GetSteer().Node(i);
    k=Stiff.GetSteer().NDof(i);
    if((*NodeRef)[j].GetDOFs()[k].GetDOFType()==doftXDis) {
      float load;  // delete it
      load = NodalLoad(j,0);  // delete it
      RHS(i) = NodalLoad(j,0); // x-directional load
    }
    else if((*NodeRef)[j].GetDOFs()[k].GetDOFType()==doftZAng) {
      RHS(i) = NodalLoad(j,1);  // z-rotational load
    }
  }

  for (i=0;i<JackingForce.GetSize();i++) {
    NodalLoad(JackingForce.GetNode(i),0) -= JackingForce.GetForce(i);
  }
  for (i=0;i<IniForceCorrect.GetSize();i++) {
    NodalLoad(IniForceCorrect.GetNode(i),0) -= IniForceCorrect.GetForce(i);
  }

//  for (i=0;i<RHS.GetSize();i++) { // delete it test for cantilever beam
//    RHS(i) = 0;                   // delete it
//  }                               // delete it
//  RHS(22) = 1;                    // delete it

  return true;
}

bool MkContBeam::Post()  // calculate force and stress resultant of structures
{
  int i,j,k,ndata=0,cnt=0;
  float t[]={0.0,0.25,0.5,0.75,1.0};
  float loc[2]={1e4,-1e4};
  for (i=0;i<Elements.GetSize();i++) {
    Elements[i].Post();
    if(Elements[i].isBeamElement()) {
      MkBeamElement *beam = dynamic_cast<MkBeamElement*>(&Elements[i]);
      if(!beam) continue;
      MkLine &l = beam->GetLine();
      if(l[0].X<loc[0]) loc[0] = l[0].X;
      if(l[0].X>loc[1]) loc[1] = l[0].X;
      ndata+=2;
    }
  }

  WallResult.Initialize(6,ndata);

  cnt=0;
  for (i=0;i<Elements.GetSize();i++) {
    if(Elements[i].isBeamElement()) {
      MkBeamElement *beam = dynamic_cast<MkBeamElement*>(&Elements[i]);
      if(!beam) continue;
      MkLine &l = beam->GetLine();
      for(j=0;j<2;j++,cnt++) {
        WallResult(0,cnt) = fabs(loc[0]-l[0].X)<EPS?0:1; // wall
        WallResult(1,cnt) = l.GetDivision(j).Y+((j==0)?+EPS:-EPS); // y-coord
        WallResult(2,cnt) = beam->GetDisp(j); // dis
        WallResult(3,cnt) = 0; // press
        WallResult(4,cnt) = ((j==0)?1:-1)*beam->GetShearForce(j); // shear
        WallResult(5,cnt) = ((j==0)?1:-1)*beam->GetMoment(j); // mom
      }
    }
  }

  for (i=0;i<ndata-1;i++) {
    for (j=i+1;j<ndata;j++) {
      if(fabs(WallResult(0,i)-WallResult(0,j))<EPS && WallResult(1,i)<WallResult(1,j)) {
        for (k=0;k<WallResult.getSzX();k++) {
//          swap(WallResult(k,i),WallResult(k,j));
        }
      }
    }
  }

  for (i=0;i<Elements.GetSize();i++) {
    if(Elements[i].isTrussElement()) {
      MkTrussElement *truss = dynamic_cast<MkTrussElement*>(&Elements[i]);
      if(!truss) continue;
      MkLine &l = truss->GetLine();
      ndata++;
    }
  }

  AxialResult.Initialize(3,ndata);
  cnt=0;
  for (i=0;i<Elements.GetSize();i++) {
    if(Elements[i].isTrussElement()) {
      MkTrussElement *truss = dynamic_cast<MkTrussElement*>(&Elements[i]);
      float t;
      if(!truss) continue;
      MkLine &l = truss->GetLine();
      AxialResult(0,cnt) = t = l.GetDivision(0.5).X; // x-coord
      AxialResult(1,cnt) = t = l.GetDivision(0.5).Y; // y-coord
      t = truss->GetAxialForce(0.5) ; //   axial force
      AxialResult(2,cnt) = truss->GetAxialForce(0.5) ; //   axial force
      cnt++;
    }
  }

  return true;
}

bool MkContBeam::Out()
{
  FILE *fp;
  char str[256];
  static bool flag=true;
  int i,nnode,nelem;
  memset(str,'\0',255);
  nnode = NodeRef->GetSize();
  nelem = Elements.GetSize();

  MkDebug("MkContBeam::Start function Out()\n");

  MkDebug("FileName is ");MkDebug(FileName);MkDebug("\n");

  if(strlen(FileName)) {
    if(!flag) fp = fopen(FileName,"w");
    else fp = fopen(FileName,"a");

    if(!fp) {
      MkDebug(FileName);
      MkDebug(" is not found...fp is null so return false\n");
      return false;
    }

    if(!flag) {
      sprintf(str,"--------------BASIC OUTPUT-------------------\n");
      fputs(str,fp);
      sprintf(str,"- This is tempory outfile format to verify  -\n");
      fputs(str,fp);
      sprintf(str,"- the ContBeam logic and the results.       -\n");
      fputs(str,fp);
      sprintf(str,"- ESCOT(c)Copyright 2004, ESCO Eng. & Cons. -\n");
      fputs(str,fp);
      sprintf(str,"---------------------------------------------\n\n");
      fputs(str,fp);
    }

    sprintf(str,"STEP : %d\n\n",1);
    fputs(str,fp);

    sprintf(str,"Node coordinate : number of node is %d\n", nnode);
    fputs(str,fp);
//               12345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890
    sprintf(str,"     node         x         y         z      disp  rotation     shear    moment\n");
    fputs(str,fp);

    for(i=0;i<nnode;i++) {
      sprintf(str,"%9d %9.3f %9.3f %9.3f %9.6f %9.6f\n",
        i,(*NodeRef)[i].GetPoint().X,(*NodeRef)[i].GetPoint().Y,(*NodeRef)[i].GetPoint().Z,NodalDis(i,0),NodalDis(i,1));
      fputs(str,fp);
    }

    sprintf(str,"Result \n");
    fputs(str,fp);
    sprintf(str,"no. Disp or Rot \n");
    fputs(str,fp);
    for(i=0;i<Var.GetSize();i++) {
      sprintf(str,"%10d %20.10f \n",i,Var[i]);
      fputs(str,fp);
    }

    sprintf(str,"\nElement : number of element is %d\n", nelem);
    fputs(str,fp);

//               1234567890123456789012345678901234567890123456789012345678901234567890
    sprintf(str,"   element    node0     node1     shear     shear    moment    moment\n");
    fputs(str,fp);

    for(i=0;i<nelem;i++) {
      if(Elements[i].isBeamElement()) {
        MkBeamElement *beam=dynamic_cast<MkBeamElement*>(&Elements[i]);
        if(!beam) continue;
        sprintf(str,"%9d %9d %9d %9.3f %9.3f %9.3f %9.3f\n", i, beam->GetNodeNumber(0),beam->GetNodeNumber(1), beam->GetShearForce(0), beam->GetShearForce(1),beam->GetMoment(0), beam->GetMoment(1));
      }
      else {
        sprintf(str,"%9d %9d %9d\n", i, Elements[i].GetNodeNumber(0),Elements[i].GetNodeNumber(1));
      }
      fputs(str,fp);
    }
//               1234567890123456789012345678901234567890123456789012345678901234567890
    sprintf(str," data num    l or r     depth      disp     press     shear    moment\n");
    fputs(str,fp);
    for(i=0;i<WallResult.getSzY();i++) {
      sprintf(str,"%10d %10d %10.5f %10.5f %10.5f %10.5f %10.5f\n",i,(int)(WallResult(0,i)+0.5),WallResult(1,i),WallResult(2,i),WallResult(3,i),WallResult(4,i),WallResult(5,i));
      fputs(str,fp);
    }

    fclose(fp);
  }

#ifdef __BCPLUSPLUS__
  if(Memo) {
//    sprintf(str,"STEP : %d\n\n",Step);
//    Memo->Lines->Add(str);

//               123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890
    sprintf(str,"     node         x         y         z      disp    lpress    rpress     lload    rload\n");
    Memo->Lines->Add(str);

    //    for(int i=0;i<nnode;i++) {
    //      sprintf(str,"%9d %9.3f %9.3f %9.3f %9.6f %9.6f %9.6f %9.6f %9.6f\n",
    //        i, (*NodeRef)[i].GetPoint().X, (*NodeRef)[i].GetPoint().Y,(*NodeRef)[i].GetPoint().Z,
    //        (*NodeRef)[i].PrimaryVar(0),(*NodeRef)[i].SecondVar(0),(*NodeRef)[i].SecondVar(1),
    //        NodalLoad(i,0),NodalLoad(i,1));
    //      Memo->Lines->Add(str);
    //    }

    sprintf(str,"\nElement : number of element is %d\n", nelem);
//    Memo->Lines->Add(str);

//               12345678901234567890123456789012345678901234567890
    sprintf(str,"   element    node0     node1 \n");
//    Memo->Lines->Add(str);

    for(int i=0;i<nelem;i++) {
      sprintf(str,"%10d %10d %10d\n", i, Elements[i].GetNodeNumber(0),Elements[i].GetNodeNumber(1));
//      Memo->Lines->Add(str);
    }
  }
#endif

  flag = true;
  return flag;
}

bool MkContBeam::Solve()
{
  int size,i,j,k;
  Setup();
  Var = RHS;
  size = Var.GetSize();
  Stiff.GetStiffMatrix().Solve(Var,stHybrid);

  for (i=0;i<size;i++) {
    j=Stiff.GetSteer().Node(i);
    k=Stiff.GetSteer().NDof(i);
    if((*NodeRef)[j].GetDOFs()[k].GetDOFType()==doftXDis) {
      float dis;
      dis = Var(i);
      NodalDis(j,0) = Var(i);
      (*NodeRef)[j].SetXDis(Var(i));
    }
    else if((*NodeRef)[j].GetDOFs()[k].GetDOFType()==doftZAng) {
      float ang;
      ang = Var(i);
      NodalDis(j,1) = Var(i);
      (*NodeRef)[j].SetZAng(Var(i));
    }
  }

  Post();
  Out();
  return true;
}

bool MkContBeam::Apply(MkLoads &load, MkLayers &lay)
{
  int i,j;
  char str[256];
  for(i=0;i<NodeRef->GetSize();i++) {
    NodalLoad(i,0) = 0;
    NodalLoad(i,1) = 0;
  }
  for(i=0;i<Elements.GetSize();i++) {
    if(!Elements[i].isBeamElement()) continue;
    MkBeamElement *beam = dynamic_cast<MkBeamElement*>(&Elements[i]);
    if(!beam) continue;
    for (j=0;j<12;j++) beam->GetFixedEnd()[j] = 0;
  }
  for (i=0;i<load.GetSize();i++) {
    if(load[i].GetLoadApplyType()==latNodal) ApplyNodal(load[i],lay);
    else if(load[i].GetLoadApplyType()==latDistributal) ApplyDistributal(load[i],lay);
  }
  for (i=0;i<NodalLoad.getSzX();i++) {
    sprintf(str,"  >>  %d-th Nodal Load is %f, %f\n",i,NodalLoad(i,0),NodalLoad(i,1));
    MkDebug(str);
  }
  return true;
}

bool MkContBeam::ApplyNodal(MkLoad &load,MkLayers &)
{
  int i;
  float ymin,ymax,len;
  MkNode node[2];
  int nodenum[2];
  MkPolygon poly;
  MkPolygon &press = load.GetStaticPress();

  for(i=0;i<Elements.GetSize();i++) {
    if(!Elements[i].isBeamElement()) continue;
    node[0] = Elements[i].GetElemNode(0);
    node[1] = Elements[i].GetElemNode(1);
    if(fabs(node[0].GetPoint().Y-node[1].GetPoint().Y)<EPS) continue;
    if(!load.isIn(node[0].GetPoint()) || !load.isIn(node[1].GetPoint())) continue;

    nodenum[0] = Elements[i].GetNodeNumber(0);
    nodenum[1] = Elements[i].GetNodeNumber(1);
    ymin = node[0].GetPoint().Y;
    ymax = (node[0].GetPoint().Y+node[1].GetPoint().Y)/2;
    len = fabs(ymax-ymin);
    if(ymin>ymax) swap(ymin,ymax);
    GetSubPolygon(ymin,ymax,press,poly);
    NodalLoad(nodenum[0],0) += poly.GetArea();

    ymin = (node[0].GetPoint().Y+node[1].GetPoint().Y)/2;
    ymax = node[1].GetPoint().Y;
    len = fabs(ymax-ymin);
    if(ymin>ymax) swap(ymin,ymax);
    GetSubPolygon(ymin,ymax,press,poly);
    NodalLoad(nodenum[1],0) += poly.GetArea();
  }
  return true;
}

bool MkContBeam::ApplyDistributal(MkLoad &load,MkLayers &)
{
  int i,j;
  float ymin,ymax;
  MkNode node[2];
  int nodenum[2];
  float aj,bj,lj,lj1,len;
  float f1,f2,f3,f4;
  MkPolygon poly;
  MkPolygon &press = load.GetStaticPress();

  for(i=0;i<Elements.GetSize();i++) {
    if(!Elements[i].isBeamElement()) continue;
    MkBeamElement *beam = dynamic_cast<MkBeamElement*>(&Elements[i]);
    node[0] = Elements[i].GetElemNode(0);
    node[1] = Elements[i].GetElemNode(1);
    if(fabs(node[0].GetPoint().Y-node[1].GetPoint().Y)<EPS) continue;
    if(!load.isIn(node[0].GetPoint()) || !load.isIn(node[1].GetPoint())) continue;

    nodenum[0] = Elements[i].GetNodeNumber(0);
    nodenum[1] = Elements[i].GetNodeNumber(1);

    if(node[0].GetPoint().Y<node[1].GetPoint().Y) {
      Swap(node[0],node[1]);
      swap(nodenum[0],nodenum[1]);
    }

    ymin = node[0].GetPoint().Y;
    ymax = node[1].GetPoint().Y;
    len = fabs(ymax-ymin);
    if(ymin>ymax) swap(ymin,ymax);

    GetSubPolygon(ymin,ymax,press,poly);

    f1=f2=f3=f4=0; // element-wise integration of shape function...
    for(j=0;j<poly.GetSize();j++) {
      GetSubParam(j,poly,aj,bj,lj1,lj);
      f1 += ShapeFunInteg1(aj,bj,len,lj1,lj);
      f2 += ShapeFunInteg2(aj,bj,len,lj1,lj);
      f3 += ShapeFunInteg3(aj,bj,len,lj1,lj);
      f4 += ShapeFunInteg4(aj,bj,len,lj1,lj);
    }
    NodalLoad(nodenum[0],0) -= f1;
    NodalLoad(nodenum[0],1) -= f2;
    NodalLoad(nodenum[1],0) -= f3;
    NodalLoad(nodenum[1],1) -= f4;
    if(!beam) continue;
    beam->GetFixedEnd()[0] = f3;  // still I can not figure it out...!
    beam->GetFixedEnd()[5] = f4;  // I hope I can understand sometime later.
    beam->GetFixedEnd()[6] = f1;
    beam->GetFixedEnd()[11] = f2;      
  }
  return true;
}

bool MkContBeam::operator==(MkContBeam &cb)
{
  return MkAnalysis::operator==((MkAnalysis&)cb);
}

bool MkContBeam::operator!=(MkContBeam &cb)
{
  return MkAnalysis::operator!=((MkAnalysis&)cb);
}

#ifdef __BCPLUSPLUS__
void MkContBeam::Draw(TObject *obj)
{
  NodeRef->Draw(obj);
  Elements.Draw(obj);
}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void MkContBeam::Draw(MkPaint *pb)
{
  NodeRef->Draw(pb);
  Elements.Draw(pb);
}
#endif
