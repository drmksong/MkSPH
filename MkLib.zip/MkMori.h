//---------------------------------------------------------------------------
#ifndef MkMoriH
#define MkMoriH
#include "MkMesh.h"
#include "MkEntity.h"
#include "MkSteer.h"
#include "MkLoad.h"
#include "MkBndCon.h"
#include "MkAnalysis.h"
#include "MkNodalForce.h"

//--------------------------------------------------------------------
// LeftEarthLoad   Store only pure load(shear(0), moment(1)) from the earth
//                 pressure and added to LeftNodalLoad
// RightEarthLoad  Store only pure load(shear(0), moment(1)) from the earth
//                 pressure and added to RighttNodalLoad
// LeftHydLoad     Store only pure load(shear(0), moment(1)) from the hydraulic
//                 pressure and added to LeftNodalLoad
// RightHydLoad    Store only pure load(shear(0), moment(1)) from the hydraulic
//                 pressure and added to RightNodalLoad
// JackingForce    Store the nodal force of the node where the struts or anchors
//                 are installed
// IniForceCor...  Store the nodal force of the node where the struts or anchors
//                 are installed to correct the axial force due to initial disp.
// LeftNodalLoad   Store all the left nodal force of the node before solve it
// RightNodalLoad  Store all the right nodal force of the node before solve it
// LeftNodalKh     Ground stiffness of each side of nodes
// RightNodalKh    Ground stiffness of each side of nodes
// NodalQu         Cumulative plastic displacement at nodes
// LeftLimitQu     Plastic displacement limit at nodes //no use
// RightLimitQu    Plastic displacement limit at nodes //no use
// if active load < Kh*dis < passive load then it is in elastic, otherwize in plastic
// LeftNodalLu     Upper limit of load
// RightNodalLu    Upper limit of load
// LeftNodalLd     Lower limit of load
// RightNodalLd    Lower limit of load
// NodalLen        Nodal length from middle point to middle point of each elements
// NodalDis        Nodal displacement NodalDis(i)
// NodalAng        Nodal ang. disp.   NodalAng(i)
// NodalShear      Nodal shear force  NodalShear(i)
// NodalMom        Nodal moment       NodalMom(i)
// LeftEarthPress  For plot only(stored when the earth pressure applied) LeftEarthPress(i)
// RightEarthPress For plot only(stored when the earth pressure applied) RightEarthPress(i)
// LeftHydPress    For plot only(stored when the earth pressure applied) LeftHydPress(i)
// RightHydPress   For plot only(stored when the earth pressure applied) RightHydPress(i)

class MkMori : public MkAnalysis {
protected:
  bool useQu;// plastic limit of displacement
  MkFloat TotLeftEarthLoad;  // horizontal total load (including water pressure)
  MkFloat TotRightEarthLoad; // horizontal total load (including water pressure)
  //  MkFloat EffLeftEarthLu;    // horizontal effective load
  //  MkFloat EffRightEarthLu;   // horizontal effective load
  //  MkFloat EffLeftEarthLd;    // horizontal effective load
  //  MkFloat EffRightEarthLd;   // horizontal effective load

  MkFloat LeftEarthLoad;  // horizontal mechanical load
  MkFloat RightEarthLoad; // horizontal mechanical load
  MkFloat LeftEarthLu;    // horizontal mechanical load
  MkFloat RightEarthLu;   // horizontal mechanical load
  MkFloat LeftEarthLd;    // horizontal mechanical load
  MkFloat RightEarthLd;   // horizontal mechanical load

  MkFloat LeftHydLoad;
  MkFloat RightHydLoad;
  MkNodalForce JackingForce;
  MkNodalForce IniForceCorrect;

  MkFloat NodalLoad; // residential effective load (left+right effective load)

  MkFloat LeftNodalKh;
  MkFloat RightNodalKh;
  MkFloat NodalQu;
  MkFloat LeftLimitQu;
  MkFloat RightLimitQu;
  MkFloat NodalLen;

  MkFloat NodalDis,CurStepDis;
  MkFloat NodalAng,CurStepAng;
  MkFloat NodalShear;
  MkFloat NodalMom;
  
  MkFloat LeftEarthPress;
  MkFloat RightEarthPress;
  MkFloat LeftHydPress;
  MkFloat RightHydPress;   

  float TOL;
  int Step;
#ifdef __BCPLUSPLUS__
  TMemo *Memo;
#endif
  void InitVar();

public:
  MkMori():MkAnalysis() {Clear();}
  MkMori(float tol) : MkAnalysis() {Clear();TOL = tol;}
  ~MkMori(){}

  void SetNodes(MkNodes &nodes){NodeRef = &nodes;InitVar();}
  void SetElements(MkElements &elem){Elements = elem;Elements.SetNodes(*NodeRef);}
  void SetTOL(float tol){TOL=tol;}
#ifdef __BCPLUSPLUS__
  void SetMemo(TMemo *memo){Memo=memo;}
#endif
  void SetFileName(char *name){strcpy(FileName,name);}
  void SetPrint(int s){PrintStep=s;}
  void SetUseQu(bool use){useQu = use;}

  MkVector & GetVar(){return Var;}
  MkVector & GetRHS(){return RHS;}
  MkMatrix & GetStiffMatrix(){return Stiff.GetStiffMatrix();}
  MkStiff  & GetStiff(){return Stiff;}

  MkFloat & GetTotLeftEarthLoad(){return TotLeftEarthLoad;}
  MkFloat & GetTotRightEarthLoad(){return TotRightEarthLoad;}
  MkFloat & GetLeftEarthLoad(){return LeftEarthLoad;}
  MkFloat & GetRightEarthLoad(){return RightEarthLoad;}
  MkFloat & GetLeftEarthLu(){return LeftEarthLu;}
  MkFloat & GetRightEarthLu(){return RightEarthLu;}
  MkFloat & GetLeftEarthLd(){return LeftEarthLd;}
  MkFloat & GetRightEarthLd(){return RightEarthLd;}
  MkFloat & GetLeftHydLoad(){return LeftHydLoad;}
  MkFloat & GetRightHydLoad(){return RightHydLoad;}

  MkFloat & GetNodalLoad(){return NodalLoad;}

  MkFloat & GetLeftNodalKh(){return LeftNodalKh;}
  MkFloat & GetRightNodalKh(){return RightNodalKh;}
  MkFloat & GetNodalQu(){return NodalQu;}
  MkFloat & GetLeftLimitQu(){return LeftLimitQu;}
  MkFloat & GetRightLimitQu(){return RightLimitQu;}

  MkFloat & GetNodalLen(){return NodalLen;}
  MkFloat & GetNodalDis(){return NodalDis;}
  MkFloat & GetNodalAng(){return NodalAng;}
  MkFloat & GetNodalShear(){return NodalShear;}
  MkFloat & GetNodalMom(){return NodalMom;}

  MkFloat & GetLeftEarthPress(){return LeftEarthPress;}
  MkFloat & GetRightEarthPress(){return RightEarthPress;}
  MkFloat & GetLeftHydPress(){return LeftHydPress;}
  MkFloat & GetRightHydPress(){return RightHydPress;}
  bool GetUseQu(){return useQu;}

public:
  bool Initialize();
  bool Setup();
  bool Pre(MkMatrix &);
  bool Solve();
  bool Post();

  bool Apply(MkLoads &load, MkLayers &lay);
  bool Apply(MkLayers &lay){MkDebug("MkMori::Apply(MkLayers&) is called.\n");return false;}
  bool Apply(MkSubreacts &sub); 
  bool ApplyNodal(MkSubreact &sub); // nodal subreacts(get area of subreacts of layer)
  bool ApplyDistributal(MkSubreact &sub); // distributal subreacts(integrate subreacts of layer)
  void ApplySubreact(MkMatrix &mat);
  bool ApplyJackingForce(MkNodalForce &jack){JackingForce = jack;return true;}
  bool ApplyIniForceCorrect(MkNodalForce &ini){IniForceCorrect = ini;return true;}

  void UpdateNodalDis();
  void CalcNodalLen();
  void CalcNodalPress();
  void CalcLimitQu(); 
  void ExtractResult();

  bool CalcNodalLoad(MkRangeTree &range, MkPolygon &press, MkFloat &load);
  bool CalcDistLoad(MkRangeTree &range, MkPolygon &press, MkFloat &load);
  bool CalcEarthLoad(MkLoad *load);
  bool CalcEarthLu(MkLoad *load);
  bool CalcEarthLd(MkLoad *load);
  bool CalcHydLoad(MkLoad *load);
  bool CalcEarthLoad(MkLayers &lay);
  //  bool CalcEarthLu(MkLayers &lay);
  //  bool CalcEarthLd(MkLayers &lay);

  bool CheckTol(MkVector &,MkVector &);
  bool Out();
  bool Out(char *fname);
  bool OutStiff(char *fname);
  bool OutStiff(MkMatrix &,char *fname);
  bool OutLoad(char *fname);
  bool OutVar(char *fname);
  void Clear();

  /*
  bool ApplyNodal(MkLoads &load, MkLayers &lay);
  bool CalcNodalLoad(MkLoad *load, MkFloat &nodal);
  bool CalcNodalLoad(MkLoad *load);
  bool CalcNodalLu(MkLoad *load);
  bool CalcNodalLd(MkLoad *load);
  bool CalcNodalLu(MkLayers &lay);
  bool CalcNodalLd(MkLayers &lay);
  bool CalcNodalHydLoad(MkLoad *load);
  */
};
//--------------------------------------------------------------------
#endif
