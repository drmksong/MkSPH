//---------------------------------------------------------------------------
#ifndef MkJunkH
#define MkJunkH
#include "MkObject.h"
#include "MkFloat.h"
//---------------------------------------------------------------------------
class MkJunk : public MkObject {
public:
  double exca_depth_L, exca_depth_R;
  double ToptoGL, SidepileCTC, MidpileCTC, SideInsert, MidInsert;
  double GL_R_minus_GL_L;

  float DepthUnderDan;
  int EarthPressType, HydPressType, WaterTabType;
  int SubsidType, GrdType, NumMeas;
  float ExcaWidth, IntFricAng;
  MkFloat MeasValue;

  float ImpearmUnitWeight, PearmUnitWeight, ImpearmThick, PearmThick, BotHead;
  float ShearStrength, UnitWeightAboveDatum, HeightFromExcavLevel/*D*/, LongLen/*L*/;
  int GeoType;
  float TotalUnitWeight, SubUnitWeight, HeadGradient;

public:
  MkJunk();
  ~MkJunk(){}

  void Clear();

  double Getexca_depth_L(){return exca_depth_L;}
  double Getexca_depth_R(){return exca_depth_R;}
  double GetToptoGL(){return ToptoGL;}
  double GetSidepileCTC(){return SidepileCTC;}
  double GetMidpileCTC(){return MidpileCTC;}
  double GetSideInsert(){return SideInsert;}
  double GetMidInsert(){return MidInsert;}
  double GetGL_R_minus_GL_L(){return GL_R_minus_GL_L;}

  float GetDepthUnderDan(){return DepthUnderDan;}
  int GetEarthPressType(){return EarthPressType;}
  int GetHydPressType(){return HydPressType;}
  int GetWaterTabType(){return WaterTabType;}
  int GetSubsidType(){return SubsidType;}
  int GetGrdType(){return GrdType;}
  int GetNumMeas(){return NumMeas;}
  float GetExcaWidth(){return ExcaWidth;}
  float GetIntFricAng(){return IntFricAng;}
  MkFloat &GetMeasValue(){return MeasValue;}

  float GetImpearmUnitWeight(){return ImpearmUnitWeight;}
  float GetPearmUnitWeight(){return PearmUnitWeight;}
  float GetImpearmThick(){return ImpearmThick;}
  float GetPearmThick(){return PearmThick;}
  float GetBotHead(){return BotHead;}
  float GetShearStrength(){return ShearStrength;}
  float GetUnitWeightAboveDatum(){return UnitWeightAboveDatum;}
  float GetHeightFromExcavLevel(){return HeightFromExcavLevel;}/*D*/
  float GetLongLen(){return LongLen;}/*L*/
  int GetGeoType(){return GeoType;}
  float GetTotalUnitWeight(){return TotalUnitWeight;}
  float GetSubUnitWeight(){return SubUnitWeight;}
  float GetHeadGradient(){return HeadGradient;}

  void Setexca_depth_L(double a){exca_depth_L=a;}
  void Setexca_depth_R(double a){exca_depth_R=a;}
  void SetToptoGL(double a){ToptoGL=a;}
  void SetSidepileCTC(double a){SidepileCTC=a;}
  void SetMidpileCTC(double a){MidpileCTC=a;}
  void SetSideInsert(double a){SideInsert=a;}
  void SetMidInsert(double a){MidInsert=a;}
  void SetGL_R_minus_GL_L(double a){GL_R_minus_GL_L=a;}

  void SetDepthUnderDan(float a){DepthUnderDan=a;}
  void SetEarthPressType(int a){EarthPressType=a;}
  void SetHydPressType(int a){HydPressType=a;}
  void SetWaterTabType(int a){WaterTabType=a;}
  void SetSubsidType(int a){SubsidType=a;}
  void SetGrdType(int a){GrdType=a;}
  void SetNumMeas(int a){NumMeas=a;}
  void SetExcaWidth(float a){ExcaWidth=a;}
  void SetIntFricAng(float a){IntFricAng=a;}
  void SetMeasValue(MkFloat &a){MeasValue=a;}

  void SetImpearmUnitWeight(float a){ImpearmUnitWeight=a;}
  void SetPearmUnitWeight(float a){PearmUnitWeight=a;}
  void SetImpearmThick(float a){ImpearmThick=a;}
  void SetPearmThick(float a){PearmThick=a;}
  void SetBotHead(float a){BotHead=a;}
  void SetShearStrength(float a){ShearStrength=a;}
  void SetUnitWeightAboveDatum(float a){UnitWeightAboveDatum=a;}
  void SetHeightFromExcavLevel(float a){HeightFromExcavLevel=a;}/*D*/
  void SetLongLen(float a){LongLen=a;}/*L*/
  void SetGeoType(int a){GeoType=a;}
  void SetTotalUnitWeight(float a){TotalUnitWeight=a;}
  void SetSubUnitWeight(float a){SubUnitWeight=a;}
  void SetHeadGradient(float a){HeadGradient=a;}

  MkJunk &operator=(MkJunk &junk);
};
#endif

