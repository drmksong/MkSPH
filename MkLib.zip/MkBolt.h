//---------------------------------------------------------------------------
#ifndef MkBoltH
#define MkBoltH
#include "MkEntity.h"
//---------------------------------------------------------------------------
class MkBolt : public MkEntity {
  MkSide Side;
  int Tan, SupportTan;
#ifdef __BCPLUSPLUS__
  AnsiString Spec;  
#else
  char Spec[256];
#endif

protected:
  MkLine BoltLine;
  float Area;
  float Angle;
  float Spacing;
  float YoungMod;
  float Diameter;

public:
  MkBolt();
  MkBolt(int n);
  ~MkBolt(){};
public: //setting function
  void SetSide(MkSide side){Side = side;}
  void SetTan(int tan){Tan = tan;}
  void SetSupportTan(int tan){SupportTan = tan;}
#ifdef __BCPLUSPLUS__
  void SetSpec(AnsiString spec){Spec = spec;}
#else
  void SetSpec(char *spec){strcpy(Spec,spec);}
#endif

  void SetArea(float a){Area=a;}
  void SetAngle(float a){Angle=a;}
  void SetSpacing(float s){Spacing=s;}
  void SetLength(float l){Length=l;}
  void SetYoungMod(float y){YoungMod = y;}
  void SetLine(MkLine &line)
    {
      BoltLine = line;
      BoltLine.SetFiniteness(true);
      Depth = -BoltLine[0].Y;
      Length = BoltLine.GetLength();
    }
  void SetDiameter(float d){Diameter = d;}

public:
  MkSide GetSide(){return Side;}
  int GetTan(){return Tan;}
  int GetSupportTan(){return SupportTan;}
#ifdef __BCPLUSPLUS__
  AnsiString GetSpec(){return Spec;}
#else
  char *GetSpec(){return Spec;}
#endif

  float GetArea(){return Area;}
  float SetAngle(){return Angle;}
  float GetSpacing(){return Spacing;}
  float GetLength(){return Length;}
  float GetYoungMod(){return YoungMod;}
  MkLine &GetLine(){return BoltLine;}
  float GetDiameter(){return Diameter;}

public:
#ifdef __BCPLUSPLUS__
  AnsiString ClassName(){return AnsiString("MkBolt");};
  bool UpdateFrom(TStringGrid *grid){Grid = grid;return UpdateFrom();};
  bool UpdateTo(TStringGrid *grid){Grid = grid;return UpdateTo();};
  bool UpdateFrom();
  bool UpdateTo();
  void Out(TObject *);
  void Import(MkGlobalVar &globalvar, int sec, MkSide side, int tan);
  void Export(MkGlobalVar &globalvar, int sec, MkSide side, int tan);
#else
  char* ClassName(){return "MkBolt";}
#endif
  void Out(char *fname);
  void Clear();

#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif

  bool operator==(MkBolt&);
  bool operator!=(MkBolt&);
  MkBolt& operator=(MkBolt&);
};

class MkBolts {
protected:
  MkBolt *FBolt;
  int FSize;//Actual size of entities
  int FSizeOfArray;
#ifdef __BCPLUSPLUS__
  TColor Color;
#endif
public:
  MkBolts(int size,MkBolt *ent);
  MkBolts(int size);
  MkBolts(){FSizeOfArray = FSize = 0;FBolt = NULL;}
  ~MkBolts();
  virtual void Initialize(int size);
  virtual void Initialize(int size,MkBolt *);
  int GetSize(){return FSize;};
  int GetNumber(){return FSize;};
  bool Add(MkBolt &bolt);  // change of size of bolt
  bool Add(int index,MkBolt &bolt);
  bool Delete(MkBolt &bolt);  // change of size of bolt
  bool Delete(int index);
  int Grow(int Delta);            // change of size of array
  int Shrink(int Delta);          // change of size of array
  bool Clear();
#ifdef __BCPLUSPLUS__
  TColor GetColor(){return Color;};
  void SetColor(TColor c){Color = c;}
  void Out(TObject *);
  void Import(MkGlobalVar &globalvar, int sec);
  void Export(MkGlobalVar &globalvar, int sec);
#else
#endif

  void Out(char *fname);
#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif

  virtual MkBolt & operator[](int);
  MkBolts & operator=(MkBolts &bolts);
  bool operator==(MkBolts &bolts);
};
//---------------------------------------------------------------------------
extern MkBolt NullBolt;
//---------------------------------------------------------------------------
#endif
