//---------------------------------------------------------------------------
#include "MkSection.h"
#ifdef __BCPLUSPLUS__
#include <vcl.h>
#endif

#pragma hdrstop
//#include "stdafx.h"
//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#pragma package(smart_init)
#endif
//---------------------------------------------------------------------------
MkSection NullSection(0);

MkSection::MkSection()
{
  AnaSection.SetNodes(Nodes);
#ifdef __BCPLUSPLUS__
  Grid = NULL;
  PaintBox = NULL;
#endif
  Clear();
}

MkSection::MkSection(int )
{
  AnaSection.SetNodes(Nodes);
#ifdef __BCPLUSPLUS__
  Grid = NULL;
  PaintBox = NULL;
#endif
  Clear();
}

//------------------------------------------------ New functions
// Based on the Nodes contains all the nodes previously
// to improve the speed of analysis, because the installation
// of new structure into support system takes too much time
bool MkSection::SetupAllNodes() // exclude the case of intersection
{                               // Be carefull!!! 2004.11.07
  int i,j,k,nnode=0,n=0,div,cnt;
  MkPoints pnt,pnts;
  MkInt index;
  bool flag;

  if(Spacing<EPS) return false;

  for (i=0;i<Piles.GetSize();i++) {
    nnode += int(Piles[i].GetLength()/Spacing)+1;
    if(Piles[i].GetLine()[0].Y>Piles[i].GetLine()[1].Y) Swap(Piles[i].GetLine()[0],Piles[i].GetLine()[1]);
  }
  for (i=0;i<Struts.GetSize();i++) {
    nnode += int(Struts[i].GetLength()/Spacing)+1;
    if(Struts[i].GetLine()[0].X>Struts[i].GetLine()[1].X) Swap(Struts[i].GetLine()[0],Struts[i].GetLine()[1]);
  }
  for (i=0;i<Anchors.GetSize();i++) {
    nnode += int(Anchors[i].GetLength()/Spacing)+1;
    if(Anchors[i].GetLine()[0].X>Anchors[i].GetLine()[1].X) Swap(Anchors[i].GetLine()[0],Anchors[i].GetLine()[1]);
  }
  for (i=0;i<Bolts.GetSize();i++) {
    nnode += int(Bolts[i].GetLength()/Spacing)+1;
    if(Bolts[i].GetLine()[0].X>Bolts[i].GetLine()[1].X) Swap(Bolts[i].GetLine()[0],Bolts[i].GetLine()[1]);
  }

  nnode += Piles.GetSize()*Struts.GetSize();
  nnode += Piles.GetSize()*Anchors.GetSize();
  nnode += Piles.GetSize()*Bolts.GetSize();

  pnt.Initialize(nnode);

  MkPoint np(-1000,-1000,-1000);
  for(i=0;i<nnode;i++)
    pnt[i] = np;

  for (i=0;i<Piles.GetSize();i++) {
    MkLine &pl=Piles[i].GetLine();
    div = int(Piles[i].GetLength()/Spacing);
    for(j=0;j<div+1;j++) {
      pnt[n] = pl.GetDivision(float(j)/float(div));
      n++;
    }
  }
  for (i=0;i<Struts.GetSize();i++) {
    MkLine &sl=Struts[i].GetLine();
    div = int(Struts[i].GetLength()/Spacing);
    for(j=0;j<div+1;j++) {
      pnt[n] = sl.GetDivision(float(j)/float(div));
      n++;
    }
  }
  for (i=0;i<Anchors.GetSize();i++) {
    MkLine &al=Anchors[i].GetLine();
    div = int(Anchors[i].GetLength()/Spacing);
    for(j=0;j<div+1;j++) {
      pnt[n] = al.GetDivision(float(j)/float(div));
      n++;
    }
  }
  for (i=0;i<Bolts.GetSize();i++) {
    MkLine &bl=Bolts[i].GetLine();
    div = int(Bolts[i].GetLength()/Spacing);
    for(j=0;j<div+1;j++) {
      pnt[n] = bl.GetDivision(float(j)/float(div));
      n++;
    }
  }

  for(i=0;i<Piles.GetSize();i++) {
    MkLine &pl=Piles[i].GetLine();
    for(j=0;j<Struts.GetSize();j++) {
      MkLine &sl=Struts[j].GetLine();
      if(pl&&sl) {
	pnt[n] = pl & sl;
	n++;
      }
    }
    for(j=0;j<Anchors.GetSize();j++) {
      MkLine &al=Anchors[j].GetLine();
      if(pl&&al) {
	pnt[n] = pl & al;
	n++;
      }
    }
    for(j=0;j<Bolts.GetSize();j++) {
      MkLine &bl=Bolts[j].GetLine();
      if(pl&&bl) {
	pnt[n] = pl & bl;
	n++;
      }
    }
  }

  n=0;
  pnts.Clear();
  flag = nnode == pnt.GetSize();

  for(i=0;i<nnode;i++) {
    flag = true;
    for(j=0;j<n;j++) {
      if(pnt[i]==np || pnt[i]==pnts[j]) {
	flag = false;
      }
    }
    if(flag) {pnts.Add(pnt[i]);n++;}
  }

  MkDOFs dof(6);
  dof[0].SetType(doftXDis,bndtFix);
  dof[1].SetType(doftYDis,bndtFix);
  dof[2].SetType(doftZDis,bndtFix);
  dof[3].SetType(doftXAng,bndtFix);
  dof[4].SetType(doftYAng,bndtFix);
  dof[5].SetType(doftZAng,bndtFix);

  Nodes.Clear();
  Nodes.Initialize(n);

  for (i=0;i<n;i++) {
    Nodes[i].SetPoint(pnts[i]);
    Nodes[i].SetDOF(dof);
  }
  AnaSection.SetNodes(Nodes);
}
//------------------------------------------------ New functions
bool MkSection::LoadScrFromFile()
{
  FILE *fp;
  if(strlen(scFileName)==0) return false;
  fp = fopen(scFileName,"r");
  if(!fp) return false;


  fclose(fp);
  return true;
}

bool MkSection::LoadProfile()
{
  int i,n=0;
  FILE *fp;
  char str[512];
  MkProfiles prof;

  fp = fopen(prfFileName,"r");
  if(!fp) return false;

  while(!feof(fp)) {
    memset(str,'\0',511);
    fgets(str,511,fp);
    if(strlen(str)) n++;
  }

  prof.Initialize(n);

  n=0;
  rewind(fp);
  while(!feof(fp)) {
    memset(str,'\0',511);
    fgets(str,511,fp);
    if(strlen(str)) {
      prof[n].ParseScript(str);
      n++;
    }
  }

  for(i=0;i<prof.GetSize();i++) {
    switch(prof[i].GetProfType()) {
      case pfLayer:
             n = prof[i].GetProfNum();
             if(n<Layers.GetSize()) Layers[n].SetProfile(prof[i]);
             break;
      case pfCut:
             n = prof[i].GetProfNum();
             if(n<Cuts.GetSize()) Cuts[n].SetProfile(prof[i]);
             break;
      case pfFill:
             n = prof[i].GetProfNum();
             if(n<Fills.GetSize()) Fills[n].SetProfile(prof[i]);
             break;
    }
  }

  fclose(fp);
  return true;
}

bool MkSection::GenProfile()
{
  int i;
  MkProfile prof;

  for(i=0;i<Cuts.GetSize();i++) {
    if(Cuts[i].GetProfile().GetSize()>0) continue;
    prof.Initialize(1);
    prof[0].X = 0;
    prof[0].Y = -Cuts[i].GetDepth();
    Cuts[i].SetProfile(prof);
  }

  for(i=0;i<Fills.GetSize();i++) {
    if(Fills[i].GetProfile().GetSize()>0) continue;
    prof.Initialize(1);
    prof[0].X = 0;
    prof[0].Y = -Fills[i].GetDepth();
    Fills[i].SetProfile(prof); 
  }

  for(i=0;i<Layers.GetSize();i++) {
    if(Layers[i].GetProfile().GetSize()>0) continue;
    prof.Initialize(1);
    prof[0].X = 0;
    prof[0].Y = -Layers[i].GetDepth();
    Layers[i].SetProfile(prof);
  }
}

bool MkSection::LoadDatFromFile()
{
  FILE *fp;
  if(strlen(iFileName)==0) return false;
  fp = fopen(iFileName,"r");
  if(!fp) return false;


  fclose(fp);
  return true;
}

bool MkSection::SaveScrToFile()
{
  FILE *fp;
  if(strlen(scFileName)==0) return false;
  fp = fopen(scFileName,"w");
  if(!fp) return false;


  fclose(fp);
  return true;
}

bool MkSection::SaveProfile()
{
  int i,nprof,n;
  FILE *fp;
  char str;
  MkProfiles prof;

  fp = fopen(prfFileName,"w");
  if(!fp) return false;

  nprof = Layers.GetSize()+Cuts.GetSize()+Fills.GetSize();
  if(nprof <= 0) return false;
  prof.Initialize(nprof);

  n = 0;
  for(i=0;i<Layers.GetSize();i++,n++) {
    prof[n] = Layers[i].GetProfile();
  }

  for(i=0;i<Cuts.GetSize();i++,n++) {
    prof[n] = Cuts[i].GetProfile();
  }

  for(i=0;i<Fills.GetSize();i++,n++) {
    prof[n] = Fills[i].GetProfile();
  }

  for(i=0;i<prof.GetSize();i++) if(prof[i].GetProfType()!=pfNone) fprintf(fp,"%s",prof[i].GetScript());
  fclose(fp);
  return true;
}

bool MkSection::SaveDatToFile()
{
  FILE *fp;
  if(strlen(iFileName)==0) return false;
  fp = fopen(iFileName,"w");
  if(!fp) return false;
  fclose(fp);
  return true;
}

bool MkSection::Out(char *fname)
{
  FILE *fp;
  if(strlen(fname)==0) return false;
  fp = fopen(fname,"w");
  if(!fp) return false;
            //12345678901234567890123456789012345678901234567890123456789012345678901234567890
  fprintf(fp,"                         E S C O T ver. 1.0 \n");
  fprintf(fp,"\n");
  fprintf(fp,"         Excavation Support Calculation and Optimization Tool\n");
  fprintf(fp,"       Copyright (c) 2004, ESCO Engineers and Consultants Co., Ltd.\n");
  fprintf(fp,"\n");
  fprintf(fp,"Any fatal results due to unfavorable data are user's resposibility. Checking of\n");
  fprintf(fp,"input data as well as the results is recommended\n");
  fprintf(fp,"This program can be changed without any prior notice for improvement.\n");
  fprintf(fp,"Any suggestion or advice on the program or manual would be welcomed.\n");
  fprintf(fp,"Tel:02-6006-4114, Fax:02-6006-4115\n");
  fprintf(fp,"\n");
  fclose(fp);

  Layers.Out(fname);
  Cuts.Out(fname);
  Fills.Out(fname);
  Piles.Out(fname);
  Struts.Out(fname);
  Anchors.Out(fname);
  Bolts.Out(fname);
  ExcavStep.Out(fname);
  //  BndConds.Out(fname);
  //  AnaSection.Out(fname);
  ResultOut(fname);

  fp = fopen(fname,"a");
  if(!fp) return false;
  fclose(fp);
}

bool MkSection::ResultOut(char *fname)
{
  MaxResultOut(fname);
  StepResultOut(fname);
  return true;
}

bool MkSection::MaxResultOut(char *fname)
{
  int i,j,k;
  char str[500],s[256];
  FILE *fp;
  MkFloat maxshear, minshear, maxmom, minmom;
  fp = fopen(fname,"a");

  if (WallResult.getSzX()*WallResult.getSzY()<EPS) {
    fclose(fp);
    return false;
  }

//(wall number:0 ,depth:1, displacement:2, earth pressure:3, shear force:4, moment:5
  maxshear.Initialize(WallResult.getSzX(),3);
  minshear.Initialize(WallResult.getSzX(),3);
  maxmom.Initialize(WallResult.getSzX(),3);
  minmom.Initialize(WallResult.getSzX(),3);

  for (i=0;i<WallResult.getSzX();i++) {
    maxshear(i,2) = -1.0e20;
    minshear(i,2) =  1.0e20;
    maxmom(i,2) = -1.0e20;
    minmom(i,2) =  1.0e20;
  }

  for(i=0;i<WallResult.getSzX();i++) {
    for(k=0;k<WallResult.getSzZ();k++) {
      if(maxshear(i,2)<WallResult(i,4,k)) {
        maxshear(i,0) = WallResult(i,0,k);
        maxshear(i,1) = WallResult(i,1,k);
        maxshear(i,2) = WallResult(i,4,k);
      }
      if(minshear(i,2)>WallResult(i,4,k)) {
        minshear(i,0) = WallResult(i,0,k);
        minshear(i,1) = WallResult(i,1,k);
        minshear(i,2) = WallResult(i,4,k);
      }
      if(maxmom(i,2)<WallResult(i,5,k)) {
        maxmom(i,0) = WallResult(i,0,k);
        maxmom(i,1) = WallResult(i,1,k);
        maxmom(i,2) = WallResult(i,5,k);
      }
      if(minmom(i,2)>WallResult(i,5,k)) {
        minmom(i,0) = WallResult(i,0,k);
        minmom(i,1) = WallResult(i,1,k);
        minmom(i,2) = WallResult(i,5,k);
      }
    }
  }
  fputs("\n\n",fp);

              //12345678901234567890123456789012345678901234567890123456789012345678901234567890
    fprintf(fp,"           < Minimum and Maximum Values of Vertical Wall > \n");
    fprintf(fp,"\n");
    fprintf(fp,"Step             SHEAR(ton/m)                     MOMENT(ton-m/m)\n");
    fprintf(fp," no    side   depth  min   side  depth  max   side  depth  min   side  depth  max \n");
  for (i=0;i<WallResult.getSzX();i++) {
    fprintf(fp,"%3d    %5s %5.2f %5.2f  %5s %5.2f %5.2f  %5s %5.2f %5.2f  %5s %5.2f %5.2f\n",
                i,int(minshear(i,0)+0.5)==0?"left":"right", minshear(i,1)*MPa2Tonf,minshear(i,2)*MPa2Tonf,
                  int(maxshear(i,0)+0.5)==0?"left":"right", maxshear(i,1)*MPa2Tonf,maxshear(i,2)*MPa2Tonf,
                  int(minmom(i,0)+0.5)==0?"left":"right", minmom(i,1)*MPa2Tonf,minmom(i,2)*MPa2Tonf,
                  int(maxmom(i,0)+0.5)==0?"left":"right", maxmom(i,1)*MPa2Tonf,maxmom(i,2)*MPa2Tonf);
  }
  fputs("\n\n",fp);
    
  if(Struts.GetSize()>0) {
    fprintf(fp,"           < Strut Axial Force > \n");
    fprintf(fp,"\n");
    sprintf(str,"Step   ");
    for(i=0;i<Struts.GetSize();i++) {
      sprintf(s," %5d ",i);
      strcat(str,s);
    }
    strcat(str,"\n");
    fputs(str,fp);

    sprintf(str," no    ");
    for(i=0;i<Struts.GetSize();i++) {
      sprintf(s," %5.2f ",Struts[i].GetDepth());
      strcat(str,s);
    }
    strcat(str,"\n");    
    fputs(str,fp);

    for (j=0;j<StrutAxial.getSzX();j++) {
      sprintf(str," %3d   ",j);
      for(i=0;i<Struts.GetSize();i++) {
        sprintf(s," %5.2f ",StrutAxial(j,i,1)*MPa2Tonf);
        strcat(str,s);
      }
	  strcat(str,"\n");
      fputs(str,fp);
    }
    fputs("\n\n",fp);
  }

  if(Anchors.GetSize()>0) {
    fprintf(fp,"           < Anchor Axial Force > \n");
    fprintf(fp,"\n");
    sprintf(str,"Step   ");
    for(i=0;i<Anchors.GetSize();i++) {
      sprintf(s," %5d ",i);
      strcat(str,s);
    }
    strcat(str,"\n");
    fputs(str,fp);

    sprintf(str," no    ");
    for(i=0;i<Anchors.GetSize();i++) {
      sprintf(s," %5.2f ",Anchors[i].GetDepth());
      strcat(str,s);
    }
    strcat(str,"\n");
    fputs(str,fp);

    for (j=0;j<AnchorAxial.getSzX();j++) {
      sprintf(str," %3d   ",j);
      for(i=0;i<Anchors.GetSize();i++) {
        sprintf(s," %5.2f ",AnchorAxial(j,i,1)*MPa2Tonf);
        strcat(str,s);
      }
	  strcat(str,"\n");    
      fputs(str,fp);
    }
    fputs("\n\n",fp);
  }
  if(Bolts.GetSize()>0) {
    fprintf(fp,"           < Bolt Axial Force > \n");
    fprintf(fp,"\n");
    sprintf(str,"Step   ");
    for(i=0;i<Bolts.GetSize();i++) {
      sprintf(s," %5d ",i);
      strcat(str,s);
    }
    strcat(str,"\n");
    fputs(str,fp);

    sprintf(str," no    ");
    for(i=0;i<Bolts.GetSize();i++) {
      sprintf(s," %5.2f ",Bolts[i].GetDepth());
      strcat(str,s);
    }
    strcat(str,"\n");
    fputs(str,fp);

    for (j=0;j<BoltAxial.getSzX();j++) {
      sprintf(str," %3d   ",j); 
      for(i=0;i<Bolts.GetSize();i++) {
        sprintf(s," %5.2f ",BoltAxial(j,i,1)*MPa2Tonf);
        strcat(str,s);
      }
	  strcat(str,"\n");    
      fputs(str,fp);
    }
    fputs("\n\n",fp);
  }
  fclose(fp);
}

bool MkSection::StepResultOut(char *fname)
{
  int i,j,k;
  FILE *fp;               // angle and either side of pressure must be added
  fp = fopen(fname,"a");  //wall:0, depth:1, displacement:2, earth pressure:3, shear force:4, moment:5

  for(i=0;i<WallResult.getSzX();i++) {
                //12345678901234567890123456789012345678901234567890123456789012345678901234567890
      fprintf(fp,"              < Result of Step No %3d > \n",i);
      fprintf(fp,"\n");
      fprintf(fp,"Side     Depth     Disp    Press     Shear     Moment\n");
      fprintf(fp,"          (m)      (mm)   (ton/m)   (ton/m2)  (ton-m/m)\n");
    for (k=0;k<WallResult.getSzZ();k++) {
      if(k==0 || k%2==1) fprintf(fp,"%5s %8.4f %8.4f  %8.4f  %8.4f  %8.4f\n",
                  int(WallResult(i,0,k)+0.5)==0?"left":"right",WallResult(i,1,k)+EPS,WallResult(i,2,k)*1000,
                  WallResult(i,3,k)*MPa2Tonf,WallResult(i,4,k)*MPa2Tonf,WallResult(i,5,k)*MPa2Tonf);
    }
    fputs("\n\n\n",fp);
  }
  fclose(fp);
  return true;
}

bool MkSection::Apply(MkSteps &steps)
{
  int i,n;
  MkExcavType et;
  MkEntityType ett;
  float s;
  int div;

  MkPiles &pile = AnaSection.GetPiles();
  MkStruts &strut = AnaSection.GetStruts();
  MkBolts &bolt = AnaSection.GetBolts();
  MkAnchors &anchor = AnaSection.GetAnchors();
  MkCuts &cut = AnaSection.GetCuts();
  MkFills &fill = AnaSection.GetFills();

  s = Spacing;

  for(i=0;i<steps.Size;i++) {
    et=steps[i].ExcavType;
    ett=steps[i].EntityType;
    n=steps[i].EntityNum;
    MkDebug("Apply::");MkDebug(steps[i].Out());
    switch(ett) {
    case ettPile:
      MkDebug("  Apply::");MkDebug("install pile\n");
      if(s>EPS) Piles[n].SetDivision(int(Piles[n].GetLine().GetLength()/s));
      if(et==etInstall && 0 <= n && n < Piles.GetSize()) {
        pile.Add(Piles[n]);
        AnaSection.Install(Piles[n]);
      }
      else if(et==etUninstall && 0 <= n && n < Piles.GetSize()) {AnaSection.Uninstall(Piles[n]);pile.Delete(Piles[n]);}
      else {MkDebug("Error :: excav step on Pile");return false;}
      break;
    case ettStrut:
      if(s>EPS) Struts[n].SetDivision(1/*int(Struts[n].GetLine().GetLength()/s)*/);
      if(et==etInstall && 0 <= n && n < Struts.GetSize()) {AnaSection.Install(Struts[n]);strut.Add(Struts[n]);}
      else if(et==etUninstall && 0 <= n && n < Struts.GetSize()) {AnaSection.Uninstall(Struts[n]);strut.Delete(Struts[n]);}
      else {MkDebug("Error :: excav step on Strut");return false;}
      break;
    case ettAnchor:
      if(s>EPS) Anchors[n].SetDivision(1/*int(Anchors[n].GetLine().GetLength()/s)*/);
      if(et==etInstall && 0 <= n && n < Anchors.GetSize()) {AnaSection.Install(Anchors[n]);anchor.Add(Anchors[n]);}
      else if(et==etUninstall && 0 <= n && n < Anchors.GetSize()) {AnaSection.Uninstall(Anchors[n]);anchor.Delete(Anchors[n]);}
      else {MkDebug("Error :: excav step on Anchor");return false;}
      break;
    case ettBolt:
      if(s>EPS) Bolts[n].SetDivision(1/*int(Bolts[n].GetLine().GetLength()/s)*/);
      if(et==etInstall && 0 <= n && n < Bolts.GetSize()) {AnaSection.Install(Bolts[n]);bolt.Add(Bolts[n]);}
      else if(et==etUninstall && 0 <= n && n < Bolts.GetSize()) {AnaSection.Uninstall(Bolts[n]);bolt.Delete(Bolts[n]);}
      else {MkDebug("Error :: excav step on Bolt");return false;}
      break;
    case ettCut:
      if(et==etCut && 0 <= n && n < Cuts.GetSize()) cut.Add(Cuts[n]);
      else {MkDebug("Error :: excav step on Cut");return false;}
      break;
    case ettFill:
      if(et==etFill && 0 <= n && n < Fills.GetSize()) fill.Add(Fills[n]);
      else {MkDebug("Error :: excav step on Fill");return false;}
      break;
    case ettNone:
      {MkDebug("Error :: excav step etNone occured");return false;}
    default:
      {MkDebug("Error :: excav step Unknown case occured");return false;}
    }
  }
  return true;
}

bool MkSection::ApplyNew(MkSteps &steps)
{
  int i,n;
  MkExcavType et;
  MkEntityType ett;

  MkPiles &pile = AnaSection.GetPiles();
  MkStruts &strut = AnaSection.GetStruts();
  MkBolts &bolt = AnaSection.GetBolts();
  MkAnchors &anchor = AnaSection.GetAnchors();
  MkCuts &cut = AnaSection.GetCuts();
  MkFills &fill = AnaSection.GetFills();

  for(i=0;i<steps.Size;i++) {
    et=steps[i].ExcavType;
    ett=steps[i].EntityType;
    n=steps[i].EntityNum;
    MkDebug("ApplyNew::"); MkDebug(steps[i].Out());
    switch(ett) {
    case ettPile:
      if(et==etInstall && 0 <= n && n < Piles.GetSize()) {
        pile.Add(Piles[n]);
        AnaSection.InstallNew(Piles[n]);
      }
      else if(et==etUninstall && 0 <= n && n < Piles.GetSize()) {AnaSection.UninstallNew(Piles[n]);pile.Delete(Piles[n]);}
      else {MkDebug("Error :: excav step on Pile");return false;}
      break;
    case ettStrut:
      if(et==etInstall && 0 <= n && n < Struts.GetSize()) {AnaSection.InstallNew(Struts[n]);strut.Add(Struts[n]);}
      else if(et==etUninstall && 0 <= n && n < Struts.GetSize()) {AnaSection.UninstallNew(Struts[n]);strut.Delete(Struts[n]);}
      else {MkDebug("Error :: excav step on Strut");return false;}
      break;
    case ettAnchor:
      if(et==etInstall && 0 <= n && n < Anchors.GetSize()) {AnaSection.InstallNew(Anchors[n]);anchor.Add(Anchors[n]);}
      else if(et==etUninstall && 0 <= n && n < Anchors.GetSize()) {AnaSection.UninstallNew(Anchors[n]);anchor.Delete(Anchors[n]);}
      else {MkDebug("Error :: excav step on Anchor");return false;}
      break;
    case ettBolt:
      if(et==etInstall && 0 <= n && n < Bolts.GetSize()) {AnaSection.InstallNew(Bolts[n]);bolt.Add(Bolts[n]);}
      else if(et==etUninstall && 0 <= n && n < Bolts.GetSize()) {AnaSection.UninstallNew(Bolts[n]);bolt.Delete(Bolts[n]);}
      else {MkDebug("Error :: excav step on Bolt");return false;}
      break;
    case ettCut:
      if(et==etCut && 0 <= n && n < Cuts.GetSize()) cut.Add(Cuts[n]);
      else {MkDebug("Error :: excav step on Cut");return false;}
      break;
    case ettFill:
      if(et==etFill && 0 <= n && n < Fills.GetSize()) fill.Add(Fills[n]);
      else {MkDebug("Error :: excav step on Fill");return false;}
      break;
    case ettNone:
      {MkDebug("Error :: excav step etNone occured");return false;}
    default:
      {MkDebug("Error :: excav step Unknown case occured");return false;}
    }
  }
  return true;
}

/*
bool MkSection::ApplyProfile()
{
//  Lay, Cut, Fill
  int i;
  if(!Profiles.GetSize()) return false;
  for (i=0;i<Profiles.GetSize();i++) {
    int n = Profiles[i].GetProfNum();
    MkProfType &pf = Profiles[i].GetProfType();
    MkPolygon &poly = Profiles[i].GetProfile();

    switch(pf) {
      case pfLayer: Layers[n].SetPolygon(poly);  break;
      case pfCut: Cuts[n].SetCutLine(poly); break;
      case pfFill: Fills[n].SetFillLine(poly); break;
    }
  }
  return true;
}
*/

bool MkSection::Solve(int step,MkAnalysisType at)
{
  int i;
  MkAnalyses &ana = AnaSection.GetAnalysis();
  AnaSection.GetPiles().Clear();
  AnaSection.GetStruts().Clear();
  AnaSection.GetBolts().Clear();
  AnaSection.GetAnchors().Clear();
  AnaSection.GetCuts().Clear();
  AnaSection.GetFills().Clear();

  for (i=0;i<AnaSection.GetAnalysis().GetSize();i++) {
    //MkDebug("Add element for strut\n");
    AnaSection.GetAnalysis()[i]->GetElements().Clear();
  }

  MkSteps &es=ExcavStep(step);
  ApplyNew(es);

  for(i=0;i<ana.GetSize();i++) {
    ana[i]->SetMaxExcavStep(ExcavStep.GetMaxExcavStep());
    ana[i]->SetCurStep(step);
  }

  AnaSection.SetLayer(Layers);
  AnaSection.Apply(BndConds);

  MkDebug("It's about Solve of AnaSection\n");
  AnaSection.Solve(at);
  Post();
  Out(FileName);
  return true;
}

bool MkSection::Post() // must be revised!!!
{
  int i,j,k;
  int curstep;
  int szx,szy,szz,szy1,szz1;
  MkFloat &wres=AnaSection.GetAnalysis()[0]->GetWallResult();
  MkFloat &ares=AnaSection.GetAnalysis()[0]->GetAxialResult();
  MkFloat wallres,axialres;
  MkFloat strutaxial,anchoraxial,boltaxial;

  szx = WallResult.getSzX();
  szy = WallResult.getSzY();
  szz = WallResult.getSzZ();
  szy1 = wres.getSzX();
  szz1 = wres.getSzY();

  if(max(szy,szy1)*max(szz,szz1)<EPS) return false;
  wallres.Initialize(szx+1,max(szy,szy1),max(szz,szz1));

  for(i=0;i<szx;i++) {
    for(j=0;j<szy;j++) {
      for(k=0;k<szz;k++) {
        wallres(i,j,k) = WallResult(i,j,k);
      }
    }
  }

  for(j=0;j<szy1;j++) {
    float t;
    t = 0;
    for(k=0;k<szz1;k++) {
      t = wres(j,k);
      wallres(szx,j,k) = wres(j,k);
    }
  }
  WallResult.CopyFrom(wallres);

  szx = AxialResult.getSzX();
  szy = AxialResult.getSzY();
  szz = AxialResult.getSzZ();
  szy1 = ares.getSzX();
  szz1 = ares.getSzY();

  if(max(szy,szy1)*max(szz,szz1)<EPS) return false;
  axialres.Initialize(szx+1,max(szy,szy1),max(szz,szz1));

  for(i=0;i<szx;i++) {
    for(j=0;j<szy;j++) {
      for(k=0;k<szz;k++) {
        axialres(i,j,k) = AxialResult(i,j,k);
      }
    }
  }

  for(j=0;j<szy1;j++) {
    for(k=0;k<szz1;k++) {
      float t;
      t = ares(j,k);
      axialres(szx,j,k) = ares(j,k);
    }
  }
  AxialResult.CopyFrom(axialres);

  if(Struts.GetSize()>0) {
    szx = StrutAxial.getSzX();
    szy = Struts.GetSize();
    strutaxial.Initialize(szx+1,szy,2);
    for(i=0;i<szx;i++) {
      for(j=0;j<szy;j++) {
        for (k=0;k<2;k++) {
          strutaxial(i,j,k) = StrutAxial(i,j,k);
        }
      }
    }

    curstep = AxialResult.getSzX()-1;
    for(k=0;k<AxialResult.getSzZ();k++) {
      for(j=0;j<Struts.GetSize();j++) {
        MkPoint pnt(AxialResult(curstep,0,k),AxialResult(curstep,1,k));
        MkLine &l = Struts[j].GetLine();
        if(l.IsInLine(pnt) && fabs(strutaxial(curstep,j,1))<fabs(AxialResult(curstep,2,k)))
          strutaxial(curstep,j,1) = AxialResult(curstep,2,k);
      }
    }
    StrutAxial.CopyFrom(strutaxial);
  }

  if(Anchors.GetSize()>0) {
    szx = AnchorAxial.getSzX();
    szy = Anchors.GetSize();
    anchoraxial.Initialize(szx+1,szy,2);
    for(i=0;i<szx;i++) {
      for(j=0;j<szy;j++) {
        for (k=0;k<2;k++) {
          anchoraxial(i,j,k) = AnchorAxial(i,j,k);
        }
      }
    }

    curstep = AxialResult.getSzX()-1;
    for(k=0;k<AxialResult.getSzZ();k++) {
      for(j=0;j<Anchors.GetSize();j++) {
        MkPoint pnt(AxialResult(curstep,0,k),AxialResult(curstep,1,k));
        MkLine &l = Anchors[j].GetLine();
        if(l.IsInLine(pnt) &&fabs(anchoraxial(curstep,j,1))<fabs(AxialResult(curstep,2,k))) {
          anchoraxial(curstep,j,1) = AxialResult(curstep,2,k);
          if(Anchors[j].GetSide()==mkLeft) anchoraxial(curstep,j,0) = 0;
          else anchoraxial(curstep,j,0) = 1;
        }
      }
    }
    AnchorAxial.CopyFrom(anchoraxial);
  }

  if(Bolts.GetSize()>0) {
    szx = BoltAxial.getSzX();
    szy = Bolts.GetSize();
    boltaxial.Initialize(szx+1,szy,2);
    for(i=0;i<szx;i++) {
      for(j=0;j<szy;j++) {
        for (k=0;k<2;k++) {
          boltaxial(i,j,k) = BoltAxial(i,j,k);
        }
      }
    }

    curstep = AxialResult.getSzX()-1;
    for(k=0;k<AxialResult.getSzZ();k++) {
      for(j=0;j<Bolts.GetSize();j++) {
        MkPoint pnt(AxialResult(curstep,0,k),AxialResult(curstep,1,k));
        MkLine &l = Bolts[j].GetLine();
        if(l.IsInLine(pnt) &&fabs(boltaxial(curstep,j,1))<fabs(AxialResult(curstep,2,k))) {
          boltaxial(curstep,j,1) = AxialResult(curstep,2,k);
          if(Bolts[j].GetSide()==mkLeft) boltaxial(curstep,j,0) = 0;
          else boltaxial(curstep,j,0) = 1;
        }
      }
    }
    BoltAxial.CopyFrom(boltaxial);
  }
  return true;
}

bool MkSection::CheckNodes()
{
  int i,j;
  bool flag,ret;
  char str[256];
  ret = true;
  for(i=0;i<Nodes.GetSize();i++) {
    flag = false;
    MkPoint &p = Nodes[i].GetPoint();
    for(j=0;j<Piles.GetSize();j++) {
      MkLine &l = Piles[j].GetLine();
      flag = flag || l.IsInLine(p);
    }
    for(j=0;j<Struts.GetSize();j++) {
      MkLine &l = Struts[j].GetLine();
      flag = flag || l.IsInLine(p);
    }
    for(j=0;j<Anchors.GetSize();j++) {
      MkLine &l = Anchors[j].GetLine();
      flag = flag || l.IsInLine(p);
    }
    for(j=0;j<Bolts.GetSize();j++) {
      MkLine &l = Bolts[j].GetLine();
      flag = flag || l.IsInLine(p);
    }
    if(!flag) {
      sprintf(str,"node (%5d-%10.4f,%10.4f) is not belong to any entity\n",i,Nodes[i].GetPoint().X,Nodes[i].GetPoint().Y);
      MkDebug(str);
      ret = flag;
    }
  }
  return ret;
}

bool MkSection::CheckElements()
{
  int i;
  bool flag=true;
  MkAnalyses &ana=AnaSection.GetAnalysis();
  
  for(i=0;i<ana.GetSize();i++) {
    MkElements &elem=ana[i]->GetElements();
    flag = CheckElements(elem) && flag;
  }
  return flag;
}

bool MkSection::CheckElements(MkElements &elem)
{
  // check if there is element which is located outside of entity
  int i,j,k;
  bool flag,flag2,ret;
  char str[256];
  ret = true;

  for(i=0;i<elem.GetSize();i++) {
    flag = false;
    for(k=0;k<Piles.GetSize();k++) {
      MkLine &l = Piles[k].GetLine();
      flag2=true;
      for(j=0;j<elem[j].GetElemNode().getSzX();j++) {
	MkPoint &p = elem[j].GetElemNode(j).GetPoint();
	flag2 = flag2 && l.IsInLine(p);
      }
      flag=flag||flag2;
    }
    for(k=0;k<Struts.GetSize();k++) {
      MkLine &l = Struts[k].GetLine();
      flag2=true;
      for(j=0;j<elem[j].GetElemNode().getSzX();j++) {
	MkPoint &p = elem[j].GetElemNode(j).GetPoint();
	flag2 = flag2 && l.IsInLine(p);
      }
      flag=flag||flag2;
    }
    for(k=0;k<Anchors.GetSize();k++) {
      MkLine &l = Anchors[k].GetLine();
      flag2=true;
      for(j=0;j<elem[j].GetElemNode().getSzX();j++) {
	MkPoint &p = elem[j].GetElemNode(j).GetPoint();
	flag2 = flag2 && l.IsInLine(p);
      }
      flag=flag||flag2;
    }
    for(k=0;k<Bolts.GetSize();k++) {
      MkLine &l = Bolts[k].GetLine();
      flag2=true;
      for(j=0;j<elem[j].GetElemNode().getSzX();j++) {
	MkPoint &p = elem[j].GetElemNode(j).GetPoint();
	flag2 = flag2 && l.IsInLine(p);
      }
      flag=flag||flag2;
    }
    if(!flag) {
      sprintf(str,"elements %d's is not belong to any entity\n",i);
      MkDebug(str);
      ret = flag;
    }
    
  }
  // check if there is element which is overlapped with other element
  for(i=0;i<elem.GetSize();i++) {
    MkPoint sp,ep;
    sp = elem[i].GetElemNode(0).GetPoint();
    ep = elem[i].GetElemNode(1).GetPoint();
    MkLine li(sp,ep);
    li.SetFiniteness(true);
    for(j=1;j<elem.GetSize();j++) {
      if(i==j) continue;
      sp = elem[j].GetElemNode(0).GetPoint();
      ep = elem[j].GetElemNode(1).GetPoint();

      if(li.IsInLine(sp) && sp!=li[0] && sp!=li[1]) {
	sprintf(str,"element %d and element %d is overlapped\n",i,j);
	MkDebug(str);
	ret = false;
      }
      if(li.IsInLine(ep) && ep!=li[0] && ep!=li[1]) {
	sprintf(str,"element %d and element %d is overlapped\n",i,j);
	MkDebug(str);
	ret = false;
      }
    }
  }
  // check if the elements cover all area of entity
  return ret;
}

MkPile &MkSection::GetSidePile()
{
  int i;
  for(i=0;i<Piles.GetSize();i++) {
    if(Piles[i].GetPileLoc()==plSide) break;
  }
  if(i>=0 && i<Piles.GetSize()) return Piles[i];
  else NullPile;
}

MkPile &MkSection::GetMidPile()
{
  int i;
  for(i=0;i<Piles.GetSize();i++) {
    if(Piles[i].GetPileLoc()==plMid) break;
  }
  if(0<=i && i<Piles.GetSize()) return Piles[i];
  else NullPile;
}

bool MkSection::hasSidePile()
{
  int i;
  for(i=0;i<Piles.GetSize();i++) {
    if(Piles[i].GetPileLoc()==plSide) return true;
  }
  return false;
}

bool MkSection::hasMidPile()
{
  int i;
  for(i=0;i<Piles.GetSize();i++) {
    if(Piles[i].GetPileLoc()==plMid) return true;
  }
  return false;
}

bool MkSection::operator==(MkSection& sec)
{
  bool flag=true;

  flag = flag && Spacing == sec.Spacing;
  flag = flag && SolMode == sec.SolMode;
  flag = flag && Echo == sec.Echo;
  flag = flag && SectionLength == sec.SectionLength;
  flag = flag && SectionType == sec.SectionType;

  flag = flag && Layers == sec.Layers;
  flag = flag && Piles  == sec.Piles;
  flag = flag && Struts == sec.Struts;
//  flag = flag && Wales  == sec.Wales;
  flag = flag && Slabs  == sec.Slabs;
  flag = flag && SlabWalls  == sec.SlabWalls;
  flag = flag && Anchors == sec.Anchors;
  flag = flag && Bolts   == sec.Bolts;
  flag = flag && RetainPanels == sec.RetainPanels;
  flag = flag && ExcavStep == sec.ExcavStep;
  flag = flag && Cuts == Cuts;
  flag = flag && Fills == Fills;
  flag = flag && BndConds == sec.BndConds;
  flag = flag && PileSections == sec.PileSections; // new class
  flag = flag && AnaSection == sec.AnaSection;
//  flag = flag && Profiles == sec.Profiles;
  flag = flag && SunexProfiles == sec.SunexProfiles;
  flag = flag && GroundImprov == sec.GroundImprov;
  flag = flag && Water== sec.Water;
  flag = flag && Steel == sec.Steel;              // interconnected with Spec
  flag = flag && Spec == sec.Spec;                // new class
  flag = flag && Deck == sec.Deck;
  flag = flag && CIP == sec.CIP;
  flag = flag && SoilBearing == sec.SoilBearing;
  flag = flag && RockBearing == sec.RockBearing;
  flag = flag && Junk == sec.Junk;

  return flag;
}

bool MkSection::operator!=(MkSection& sec)
{
  return !(*this==sec);
}

MkSection &MkSection::operator=(MkSection &sec)
{
  Spacing = sec.Spacing;
  SolMode = sec.SolMode;
  Echo = sec.Echo;
  SectionLength = sec.SectionLength;
  SectionType = sec.SectionType;

  Layers = sec.Layers;
  Piles  = sec.Piles;
  Struts = sec.Struts;
//  Wales  = sec.Wales;
  Slabs  = sec.Slabs;
  SlabWalls  = sec.SlabWalls;
  Anchors = sec.Anchors;
  Bolts   = sec.Bolts;
  RetainPanels = sec.RetainPanels;
  ExcavStep = sec.ExcavStep;
  Cuts = Cuts;
  Fills = Fills;
  BndConds = sec.BndConds;
  PileSections = sec.PileSections; // new class
  AnaSection = sec.AnaSection;
//  Profiles = sec.Profiles;
  SunexProfiles = sec.SunexProfiles;
  GroundImprov = sec.GroundImprov;
  Water= sec.Water;
  Steel = sec.Steel;              // interconnected with Spec
  Spec = sec.Spec;                // new class
  Deck = sec.Deck;
  CIP = sec.CIP;
  SoilBearing = sec.SoilBearing;
  RockBearing = sec.RockBearing;
  Junk = sec.Junk;

  Supports = sec.Supports;
  support_L = sec.support_L;
  support_R = sec.support_R;
}

void MkSection::Clear()
{
  memset(FileName,255,'\0'); // output file
  memset(scFileName,255,'\0');
  memset(iFileName,255,'\0'); // internal use
  Selected=false;

  Spacing = 0;
  SolMode = smElastic;
  Echo = false;
  SectionLength = 0;
  SectionType=stSingleWall;

  Nodes.Clear();
  Layers.Clear();
  Piles.Clear();
  Struts.Clear();
//  Wales.Clear();
  Slabs.Clear();
  SlabWalls.Clear();
  Anchors.Clear();
  Bolts.Clear();
  RetainPanels.Clear();
  ExcavStep.Clear();
  Cuts.Clear();
  Fills.Clear();
  BndConds.Clear();
  AnaSection.Clear();
//  Profiles.Clear();
  SunexProfiles.Clear();

  GroundImprov.Clear();
  Water.Clear();
  PileSections.Clear();
  Steel.Initialize(14);
  Spec.Clear();
  Deck.Clear();
  CIP.Clear();
  SoilBearing.Clear();
  RockBearing.Clear();
  SoilBearing.SetType(btSoil);
  RockBearing.SetType(btRock);
  Junk.Clear();

  Supports.Clear();
  support_L.Clear();
  support_R.Clear();
}

bool MkSection::BuildStepEntity(int stepnum) // for displaying excav step 
{
  int i,j,n;
  MkExcavType et;
  MkEntityType ett;

  MkSteps &steps = ExcavStep(stepnum);
  MkPiles &pile = StepPiles;
  MkStruts &strut = StepStruts;
  MkAnchors &anchor = StepAnchors;
  MkBolts &bolt = StepBolts;
  MkCut &cut = StepCut;
  MkFill &fill = StepFill;

  pile.Clear();
  strut.Clear();
  anchor.Clear();
  bolt.Clear();
  cut.Clear();
  fill.Clear();

  for(i=0;i<steps.Size;i++) {
    et=steps[i].ExcavType;
    ett=steps[i].EntityType;
    n=steps[i].EntityNum;
    MkDebug("ApplyNew::"); MkDebug(steps[i].Out());
    switch(ett) {
    case ettPile:
      if(et==etInstall && 0 <= n && n < Piles.GetSize()) {
        for(j=0;j<Piles.GetSize();j++)
          pile.Add(Piles[j]);
      }
      else if(et==etUninstall && 0 <= n && n < Piles.GetSize()) {pile.Delete(Piles[n]);}
      else {MkDebug("Error :: excav step on Pile");return false;}
      break;
    case ettStrut:
      if(et==etInstall && 0 <= n && n < Struts.GetSize()) {strut.Add(Struts[n]);}
      else if(et==etUninstall && 0 <= n && n < Struts.GetSize()) {strut.Delete(Struts[n]);}
      else {MkDebug("Error :: excav step on Strut");return false;}
      break;
    case ettAnchor:
      if(et==etInstall && 0 <= n && n < Anchors.GetSize()) {anchor.Add(Anchors[n]);}
      else if(et==etUninstall && 0 <= n && n < Anchors.GetSize()) {anchor.Delete(Anchors[n]);}
      else {MkDebug("Error :: excav step on Anchor");return false;}
      break;
    case ettBolt:
      if(et==etInstall && 0 <= n && n < Bolts.GetSize()) {bolt.Add(Bolts[n]);}
      else if(et==etUninstall && 0 <= n && n < Bolts.GetSize()) {bolt.Delete(Bolts[n]);}
      else {MkDebug("Error :: excav step on Bolt");return false;}
      break;
    case ettCut:
      if(et==etCut && 0 <= n && n < Cuts.GetSize()) cut = Cuts[n];
      else {MkDebug("Error :: excav step on Cut");return false;}
      break;
    case ettFill:
      if(et==etFill && 0 <= n && n < Fills.GetSize()) fill = Fills[n];
      else {MkDebug("Error :: excav step on Fill");return false;}
      break;
    case ettNone:
      {MkDebug("Error :: excav step etNone occured");return false;}
    default:
      {MkDebug("Error :: excav step Unknown case occured");return false;}
    }
  }
  return true;
}

void MkSection::AnalSupport()
{
  int i, nl=0, nr=0, nstrut=0, nanc=0, nbolt=0;
  nl = support_L.GetSize();
  nr = support_R.GetSize();

  for(i=0;i<nl;i++) if(support_L[i].type == "������") nstrut++;
  for(i=0;i<nl;i++) if(support_L[i].type == "��Ŀ") nanc++;
  for(i=0;i<nr;i++) if(support_R[i].type == "��Ŀ") nanc++;
  for(i=0;i<nl;i++) if(support_L[i].type == "�Ϻ�Ʈ") nbolt++;
  for(i=0;i<nr;i++) if(support_R[i].type == "�Ϻ�Ʈ") nbolt++;
  Struts.Initialize(nstrut);
  Anchors.Initialize(nanc);
  Bolts.Initialize(nbolt);
}

void MkSection::BuildSupport()
{
#ifdef __BCPLUSPLUS__
  int nl, nr, nlstrut, nrstrut, n;
  MkFloat depth;
  MkFloat spacing;
  MkFloat length;
  MkFloat freelen;
  MkFloat sticklen;
  MkFloat inidis;
  MkFloat strloss;
  MkFloat jackforce;
  MkFloat angle;
  MkFloat area;
  MkFloat numofwire;
  MkFloat dia;
  MkInt   side;
  float   dist;
  float   loc;

  int     i,j,k,l,cnt;
  int     nStrut=0, nAnchor=0, nBolt=0, nCut=0, nFill=0, nWales;
  double  anc_area=98.71*1.0e-6;  // is it right? -> should be replaced with equation based on the spec of anchor

  MkPiles &pile = GetPiles();
  MkStruts &struts = GetStruts();
  MkAnchors &anchor = GetAnchors();
  MkBolts &bolt = GetBolts();
//  MkCuts &cut = sec.GetCuts(); //is already built in ExcavStepUnit
//  MkFills &fill = sec.GetFills(); //is already built in ExcavStepUnit
//  MkBeam strut;
  MkWales wales;

  nl = support_L.GetSize();
  nr = support_R.GetSize();

  nlstrut = 0;
  for(i=0;i<nl;i++) if(support_L[i].type == "������") nlstrut++;
  nrstrut = 0;
  for(i=0;i<nr;i++) if(support_R[i].type == "������") nrstrut++;

  if(Supports.GetSize()<=0) {
    if(PileSections.GetSize()==0) {
      Supports = support_L;
    }
    else {
      n = nl+nr-nlstrut;
      Supports.Initialize(n);
      for(i=0;i<nl;i++) {
        Supports[i] = support_L[i];
      }
      n = nl;
      for(i=0;i<nr;i++) {
        if(support_R[i].type != "������") {
          Supports[n] = support_R[i];
          n++;
        }
      }
    }
  }

  dist = 0;
  for (j=0;j<support_L.GetSize();j++) {
    if(support_L[j].type == "������") {
      nStrut++;
    }
    else if(support_L[j].type == "��Ŀ") {
      nAnchor++;
    }
    else if(support_L[j].type == "�Ϻ�Ʈ") {
      nBolt++;
    }
    else {
      // do anything needed.
    }
  }

  for (j=0;j<support_R.GetSize();j++) {
    if(support_R[j].type == "��Ŀ") {
      nAnchor++;
    }
    else if(support_R[j].type == "�Ϻ�Ʈ") {
      nBolt++;
    }
    else {
      // do anything needed.
    }
  }

  nWales = nStrut + nAnchor;


  if(nStrut) {
    struts.Initialize(nStrut);
    depth.Initialize(nStrut);
    spacing.Initialize(nStrut);
    jackforce.Initialize(nStrut);
    inidis.Initialize(nStrut);
    strloss.Initialize(nStrut);
    angle.Initialize(nStrut);
    wales.Initialize(nStrut);    
    cnt = 0;
    for (j=0;j<support_L.GetSize();j++) {
      if(support_L[j].type=="������") {
        depth(cnt) = -support_L[j].depth;
        spacing(cnt) = support_L[j].var;
        jackforce(cnt) = support_L[j].jackingforce;
        inidis(cnt) = support_L[j].inidis;
        strloss(cnt) = support_L[j].strloss;
        wales[cnt]= support_L[j].Wale;
        cnt++;
      }
    }

//    for (j=0;j<support_R.GetSize();j++) {         // if support is strut then
//      if(support_R[j].type=="������") {           // support_L and support_R
//        depth(cnt) = -support_R[j].depth;         // is the same
//        spacing(cnt) = support_R[j].var;
//        jackforce(cnt) = support_R[j].jackingforce;
//        inidis(cnt) = support_R[j].inidis;
//        strloss(cnt) = support_R[j].strloss;
//        wales[cnt] = support_R[j].Wale;
//        cnt++;
//      }
//    }

    for (j=0;j<nStrut;j++) {
      MkLine line;

      line.SetLine(MkPoint(0,depth(j)),MkPoint(loc,depth(j)));
      struts[j].SetLine(line);
      struts[j].SetYoungMod(E*DimUnit.press());
      struts[j].SetDepth(depth(j));
      struts[j].SetLength(line.GetLength());
      struts[j].SetSpacing(spacing(j));
      struts[j].SetJackingForce(jackforce(j));  // You have to apply JackingForce
      struts[j].SetIniDisp(inidis(j));       // You have to apply JackingForce
      struts[j].SetStressLoss(strloss(j));    // You have to apply JackingForce
      struts[j].SetRakerAng(0);      // You have to apply JackingForce

      struts[j].ExtractSpec(ShortSteelName(Spec.Strut.steelname()));
      struts[j].SetWale(wales[j]);
//      struts[j].SetArea(strut.AA*1.0e-4); // cm2 -> m2
//      struts[j].SetT1(strut.tt1*1.0e-3); // mm -> m
//      struts[j].SetT2(strut.tt2*1.0e-3); // mm -> m
//      struts[j].SetWidth(strut.BB*1.0e-3); // mm -> m
//      struts[j].SetHeight(strut.HH*1.0e-3); // mm -> m
//      struts[j].SetWeight(strut.W*1.0e-3); // kg/m -> tonf/m
//      struts[j].SetSecMomentY(strut.Ix*1.0e-8); // cm4 -> m4
//      struts[j].SetSecMomentZ(strut.Ix*1.0e-8); // cm4 -> m4
//      struts[j].SetRadX(strut.rx*1.0e-2); // cm -> m
//      struts[j].SetRadY(strut.ry*1.0e-2); // cm -> m
    }
  }

  if(nAnchor>0) {
    anchor.Initialize(nAnchor);
    depth.Initialize(nAnchor);
    area.Initialize(nAnchor);
    angle.Initialize(nAnchor);
    numofwire.Initialize(nAnchor);
    freelen.Initialize(nAnchor);
    sticklen.Initialize(nAnchor);
    length.Initialize(nAnchor);
    jackforce.Initialize(nAnchor);
    inidis.Initialize(nAnchor);
    strloss.Initialize(nAnchor);
    side.Initialize(nAnchor);
    wales.Initialize(nAnchor);

    cnt = 0;
    for (j=0;j<support_L.GetSize();j++) {
      if(support_L[j].type=="��Ŀ") {
        depth(cnt) = -support_L[j].depth;
        numofwire(cnt) = support_L[j].tendonEA;
        area(cnt) = numofwire(cnt)*anc_area;
        inidis(cnt) = support_L[j].inidis;
        strloss(cnt) = support_L[j].strloss;
        angle(cnt) = support_L[j].var;
        freelen(cnt) = support_L[j].freelen;
        sticklen(cnt) = support_L[j].sticklen;
        length(cnt) = freelen(cnt)+sticklen(cnt);
        jackforce(cnt) = support_L[j].jackingforce;
        wales[cnt]= support_L[j].Wale;
        side(cnt) = 0;
        cnt++;
      }
    }

    for (j=0;j<support_R.GetSize();j++) {
      if(support_R[j].type=="��Ŀ") {
			  depth(cnt) = -support_R[j].depth;
			  numofwire(cnt) = support_R[j].tendonEA;
			  area(cnt) = numofwire(cnt)*anc_area;
        inidis(cnt) = support_R[j].inidis;
        strloss(cnt) = support_R[j].strloss;
			  angle(cnt) = support_R[j].var;
			  freelen(cnt) = support_R[j].freelen;
			  sticklen(cnt) = support_R[j].sticklen;
			  length(cnt) = freelen(cnt)+sticklen(cnt);
			  jackforce(cnt) = support_R[j].jackingforce;
        wales[cnt]= support_R[j].Wale;
			  side(cnt) = 1;
			  cnt++;
			}
    }

    for (j=0;j<nAnchor;j++) {
			MkLine line;

			if(side(j)==0) {
			  line.SetLine(MkPoint(0,depth(j)),
			    MkPoint(-length(j)*cos(angle(j)*3.14159/180.0),depth(j)-length(j)*sin(angle(j)*3.14159/180.0)));
			}
			else {
			  line.SetLine(MkPoint(dist,depth(j)),
                MkPoint(dist+length(j)*cos(angle(j)*3.14159/180.0),depth(j)-length(j)*sin(angle(j)*3.14159/180.0)));
      }
			anchor[j].SetLine(line);
			anchor[j].SetYoungMod(E*DimUnit.press());
			anchor[j].SetDepth(depth(j));
			anchor[j].SetArea(area(j));
			anchor[j].SetAngle(angle(j));
			anchor[j].SetSpacing(Junk.SidepileCTC);
			anchor[j].SetLength(length(j));
      anchor[j].SetJackingForce(jackforce(j));  // you have to apply jacking force
			anchor[j].SetTenLoss(strloss(j));               // you have to apply jacking force
			anchor[j].SetIniDis(inidis(j));                // you have to apply jacking force
			anchor[j].SetWireNum(numofwire(j));
			anchor[j].SetFreeLength(freelen(j));
			anchor[j].SetStickLength(sticklen(j));
			anchor[j].SetJackingForce(jackforce(j));
			anchor[j].SetSide(side(j)==0?mkLeft:mkRight);
      anchor[j].SetWale(wales[j]);
    }
  }

  if(nBolt>0) {
    bolt.Initialize(nBolt);
    depth.Initialize(nBolt);
    length.Initialize(nBolt);
    side.Initialize(nBolt);
    area.Initialize(nBolt);
    dia.Initialize(nBolt);

//    float dia;
//    AnsiString sub;
//    sub = Spec.Bolt.dia.SubString(2,2);
//    dia = sub.Length()?sub.ToDouble():0;

    cnt = 0;
    for (j=0;j<support_L.GetSize();j++) {
      if(support_L[j].type=="�Ϻ�Ʈ") {
        depth(cnt) = -support_L[j].depth;
        length(cnt) = support_L[j].var;
        dia(cnt) = support_L[j].freelen;
        area(cnt) = M_PI*dia(cnt)*dia(cnt)/4*1.0e-6;
        side(cnt) = 0;
        cnt++;
      }
    }
    for (j=0;j<support_R.GetSize();j++) {
      if(support_R[j].type=="�Ϻ�Ʈ") {
        depth(cnt) = -support_R[j].depth;
        length(cnt) = support_R[j].var;
        dia(cnt) = support_R[j].freelen;
        area(cnt) = M_PI*dia(cnt)*dia(cnt)/4*1.0e-6;
        side(cnt) = 1;
        cnt++;
      }
    }

    for (j=0;j<nBolt;j++) {
      MkLine line;
      if(side(j)==0) {
        line.SetLine(MkPoint(0,depth(j)),MkPoint(-length(j),depth(j)));
      }
      else {
        line.SetLine(MkPoint(dist,depth(j)),MkPoint(dist+length(j),depth(j)));
      }
      bolt[j].SetLine(line);
      bolt[j].SetSpacing(Junk.SidepileCTC);
      bolt[j].SetDepth(depth(j));
      bolt[j].SetYoungMod(E*DimUnit.press());
      bolt[j].SetDiameter(dia(j));
      bolt[j].SetArea(area(j));  // you have to refer it from the msSpec
      bolt[j].SetAngle(0.0);
      bolt[j].SetLength(length(j));
      bolt[j].SetSide(side(j)==0?mkLeft:mkRight);
    }
  }
#endif
}

void MkSection::BuildTan()  //should be called after BuildSupport
{
  int i,n,nl,nr;

  nl = support_L.GetSize();
  nr = support_R.GetSize();
  n = nl + nr;
  //assign tan to support_L
  for(i=0;i<nl;i++) support_L[i].Tan = i;

  //assign tan to support_R
  for(i=0;i<nl;i++) support_R[i].Tan = i+nl;

  //assign tan to Supports
  for(i=0;i<n;i++) Supports[i].Tan = i;

  //assign tan to MkStrut

  //assign tan to MkAnchor


  //assign tan to MkBolt
}

void MkSection::BuildCutnFill()
{
  int i, ncut=0,nfill=0;
  MkSteps &steps = ExcavStep.GetSteps();
  for(i=0;i<steps.GetSize();i++) {
    if(steps[i].ExcavType==etCut) ncut++;
    if(steps[i].ExcavType==etFill) nfill++;
  }

  if(ncut>=0) Cuts.Initialize(ncut);
  if(nfill>=0) Fills.Initialize(nfill);

  for(i=0;i<Cuts.GetSize() && Piles.GetSize()>0 ;i++) {
    Cuts[i].SetWall(&Piles[0],0);
    if (Piles.GetSize()>1)Cuts[i].SetWall(&Piles[Piles.GetSize()-1],1);
  }

  for(i=0;i<Fills.GetSize() && Piles.GetSize()>0 ;i++) {
    Fills[i].SetWall(&Piles[0],0);
    if (Piles.GetSize()>1)Fills[i].SetWall(&Piles[Piles.GetSize()-1],1);
  }

  ncut = nfill = 0;
  for(i=0;i<steps.GetSize();i++) {
    if(steps[i].ExcavType==etCut) {
      Cuts[ncut].Depth = steps[i].Depth;
      ncut++;
    }
    if(steps[i].ExcavType==etFill) {
      Fills[nfill].Depth = steps[i].Depth;    
      nfill++;
    }
  }
}

#ifdef __BCPLUSPLUS__
void MkSection::Import(MkGlobalVar &globalvar, int sec)
{
  SectionType=globalvar.sectiontype==0?stSingleWall:stDoubleWall;

  Layers.Import(globalvar,sec);
  Piles.Import(globalvar,sec);
//  Struts.Import(globalvar,sec);
//  Anchors.Import(globalvar,sec);
//  Bolts.Import(globalvar,sec);
//  Wales.Import(globalvar,sec);

  PileSections.Import(globalvar,sec);
  Steel.Import(globalvar,sec);
  Spec.ImportFromSteel(Steel);
  GroundImprov.Import(globalvar);
  Water.Import(globalvar,sec);

  SoilBearing.SetType(btSoil);
  RockBearing.SetType(btRock);
  if(::soil_bearing_method==0) SoilBearing.SetMethod(bmBridgeRoad);
  else if(::soil_bearing_method==1) SoilBearing.SetMethod(bmStatic);
  else SoilBearing.SetMethod(bmEtc);
  if(::rock_bearing_method==0) RockBearing.SetMethod(bmGoodman);
  else if(::rock_bearing_method==1) RockBearing.SetMethod(bmTeng);
  else if(::rock_bearing_method==2) RockBearing.SetMethod(bmQuJoint);
  else RockBearing.SetMethod(bmEtc);

  Deck.SetInstall(globalvar.deck[sec+1]==1?true:false);
  if(globalvar.decktype==0) Deck.SetDeckType(dtHighGround);
  else if(globalvar.decktype==1) Deck.SetDeckType(dtLowGround);
  else if(globalvar.decktype==2) Deck.SetDeckType(dtNone);

  CIP.SetCFck(globalvar.C_Fck[sec+1]);
  CIP.SetCFy(globalvar.C_Fy[sec+1]);
  CIP.SetCBarDia(globalvar.C_BarDia[sec+1]);
  CIP.SetCCIPSteel(globalvar.C_CIPSteel[sec+1]);
  CIP.SetCThickDia(globalvar.C_Thick_or_Dia[sec+1]);
  CIP.SetCNumOfBar(globalvar.C_Bar_EA[sec+1]);

  Junk.exca_depth_L=globalvar.exca_depth_L[sec+1];
  Junk.exca_depth_R=globalvar.exca_depth_R[sec+1];
  Junk.ToptoGL=globalvar.ToptoGL[sec+1];
  Junk.SidepileCTC=globalvar.SidepileCTC[sec+1];
  Junk.MidpileCTC=globalvar.MidpileCTC[sec+1];
  Junk.SideInsert=globalvar.SideInsert[sec+1];
  Junk.MidInsert=globalvar.MidInsert[sec+1];
  Junk.GL_R_minus_GL_L=globalvar.GL_R_minus_GL_L[sec+1];

  support_L.SetMajorWale(Spec.Wale.name);
  support_R.SetMajorWale(Spec.Wale.name);
  support_L.Import(globalvar,sec,mkLeft);
  support_R.Import(globalvar,sec,mkRight);

  AnalSupport();
  BuildSupport();

  Struts.Import(globalvar,sec);
//  Anchors.Import(globalvar,sec);
//  Bolts.Import(globalvar,sec);
}

void MkSection::Export(MkGlobalVar &globalvar, int sec)
{
  globalvar.sectiontype=((SectionType==stSingleWall)?100:101);
  ::soil_bearing_method=SoilBearing.GetBearingMethod();
  ::rock_bearing_method=RockBearing.GetBearingMethod();

  globalvar.C_Fck[sec+1]=CIP.GetCFck();
  globalvar.C_Fy[sec+1]=CIP.GetCFy();
  globalvar.C_BarDia[sec+1]=CIP.GetCBarDia();
  globalvar.C_CIPSteel[sec+1]=CIP.GetCCIPSteel();
  globalvar.C_Thick_or_Dia[sec+1]=CIP.GetCThickDia();
  globalvar.C_Bar_EA[sec+1]=CIP.GetCNumOfBar();

  globalvar.exca_depth_L[sec+1]=Junk.exca_depth_L;
  globalvar.exca_depth_R[sec+1]=Junk.exca_depth_R;
  globalvar.ToptoGL[sec+1]=Junk.ToptoGL;
  globalvar.SidepileCTC[sec+1]=Junk.SidepileCTC;
  globalvar.MidpileCTC[sec+1]=Junk.MidpileCTC;
  globalvar.SideInsert[sec+1]=Junk.SideInsert;
  globalvar.MidInsert[sec+1]=Junk.MidInsert;
  globalvar.GL_R_minus_GL_L[sec+1]=Junk.GL_R_minus_GL_L;
  globalvar.deck[sec+1] = Deck.GetInstall()?1:0;
  if(Deck.GetDeckType()==dtHighGround) globalvar.decktype = 0;
  else if(Deck.GetDeckType()==dtLowGround) globalvar.decktype = 1;
  else if(Deck.GetDeckType()==dtNone) globalvar.decktype = 2;


  PileSections.Export(globalvar,sec);
  Spec.ExportToSteel(Steel);
  Steel.Export(globalvar,sec);
  GroundImprov.Export(globalvar);
  globalvar.layer_ea = Layers.GetSize();
  Layers.Export(globalvar,sec);
  support_L.Export(globalvar,sec,mkLeft);
  support_R.Export(globalvar,sec,mkRight);
  Piles.Export(globalvar,sec);
  Water.Export(globalvar,sec);

  Struts.Export(globalvar,sec);
//  Anchors.Export(globalvar,sec);
//  Bolts.Export(globalvar,sec);

}
#endif

void MkSection::SetSidePile(MkBeam &beam)
{
  int i;
  for(i=0;i<Piles.GetSize();i++) {
    if(Piles[i].GetPileLoc()==plSide) Piles[i].SetBeam(beam);
  }
}

void MkSection::SetMidPile(MkBeam &beam)
{
  int i;
  for(i=0;i<Piles.GetSize();i++) {
    if(Piles[i].GetPileLoc()==plMid) Piles[i].SetBeam(beam);
  }
}

void MkSection::SetMainBeam(MkBeam &beam)
{
  MainBeam.SetBeam(beam);
}

void MkSection::SetMidMainBeamProp(MkBeam &beam)
{
  MidMainBeamProp.SetBeam(beam);
}

void MkSection::SetSideMainBeamProp(MkBeam &beam)
{
  SideMainBeamProp.SetBeam(beam);
}

void MkSection::SetStrut(MkBeam &beam)
{
  int i;
  for(i=0;i<Struts.GetSize();i++) {
    Struts[i].SetBeam(beam);
  }
}

#ifdef __BCPLUSPLUS__
void MkSection::Draw(TObject *Sender)
{

}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void MkSection::Draw(MkPaint *pb)
{

}
#endif
//---------------------------------------------------------------------------
MkSections::MkSections(int size,MkSection *sections)
{
    if (size < 0) {
      MkDebug("::MkSections - MkSections(int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSize == 0) {
       FSection = NULL;
       return;
    }

    FSection = new MkSection[FSize];
    for (int i=0;i<FSize;i++) (*this)[i] = sections[i];
}

MkSections::MkSections(int size)
{
    if (size < 0) {
      MkDebug("::MkSections - MkSections(int size)");;
      return;
    }

    FSize = FSizeOfArray = size;

    if (FSizeOfArray == 0) {
       FSection = NULL;
       return;
    }

    FSection = new MkSection[FSizeOfArray];
}

MkSections::~MkSections()
{
   FSizeOfArray = FSize = 0;
   if (FSection) {
      delete[] FSection;
      FSection = NULL;
   }
}

void MkSections::Initialize(int size)
{
    if (size < 0) {
      MkDebug("::MkSections - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;

    FSize = FSizeOfArray = size;
    
    if (FSizeOfArray == 0) {
       if (FSection!=NULL) delete[] (MkSection*)FSection;
       FSection = NULL;
       return;
    }

    if (FSection!=NULL) delete[] (MkSection*)FSection;
    FSection = new MkSection[FSizeOfArray];
}

void MkSections::Initialize(int size,MkSection *sections)
{

    if (size < 0 || sections == NULL) {
      MkDebug("::MkSections - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSize = FSizeOfArray = size;
    if (FSizeOfArray == 0) {
       if (FSection!=NULL) delete[] (MkSection*)FSection;
       FSection = NULL;
       return;
    }

    if (FSection!=NULL) delete[] (MkSection*)FSection;
    FSection = new MkSection[FSizeOfArray];
    for (int i=0;i<FSizeOfArray;i++) FSection[i] = sections[i];
}

int MkSections::Grow(int delta)
{
    int i;
    MkSection *section=NULL;

    if (!(section = new MkSection[FSizeOfArray+delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        section[i] = FSection[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        section[i] = NullSection;
    if (FSection) {
       delete[] (MkSection*)FSection;
       FSection = NULL;
    }
    FSection = section;
    FSizeOfArray = FSizeOfArray+delta;
    return FSizeOfArray;
}

int MkSections::Shrink(int delta)
{
    int i;
    MkSection *section=NULL;

    if (!(section = new MkSection[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        section[i] = FSection[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        section[i] = NullSection;
    if (FSection) {
       delete[] (MkSection*)FSection;
       FSection = NULL;
    }
    FSection = section;
    FSizeOfArray = FSizeOfArray-delta;
    return FSizeOfArray;
}

bool MkSections::Add(MkSection &section)
{
    int tmp=FSizeOfArray;
    bool flag=false;
    for (int i=0;i<FSize;i++) if (FSection[i]==section) flag=true;

    if(flag) return false;
    if (FSize>=FSizeOfArray) {
       Grow(FSize-FSizeOfArray+1);
       if (tmp==FSizeOfArray) return false;
    }

    FSize++;
    FSection[FSize-1] = section;
    return true;
}

bool MkSections::Add(int index, MkSection &section)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) Grow(FSize-FSizeOfArray+1);
    if(tmp==FSizeOfArray) return false;

    for (int i=FSize-1;i>=index;i--)
      FSection[i+1] = FSection[i];
    FSize++;
    FSection[index] = section;
    return true;
}

bool MkSections::Delete(MkSection &section)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FSection[i] == section) break;
    }
    if(i==FSize) return false;
    if(FSection[i] == section) {
      for (int j=i;j<FSize-1;j++)
        FSection[j] = FSection[j+1];
    }
    FSize--;
    FSection[FSize] = NullSection;
    return true;
}

bool MkSections::Delete(int index)
{
    for (int j=index;j<FSize-1;j++)
        FSection[j] = FSection[j+1];

    FSize--;
    FSection[FSize] = NullSection;
    return true;
}

bool MkSections::Clear()
{
   FSizeOfArray = FSize = 0;
   if (FSection) {
      delete[] FSection;
      FSection = NULL;
   }
   return true;
}

#ifdef __BCPLUSPLUS__
void MkSections::Import(MkGlobalVar &globalvar)
{
  int i;
  Initialize(globalvar.section_ea);
  for (i=0;i<FSize && i<15;i++) {
    FSection[i].Import(globalvar,i);
  }
}

void MkSections::Export(MkGlobalVar &globalvar)
{
  int i;
  for (i=0;i<FSize && i<15;i++) {
    FSection[i].Export(globalvar,i);
  }
  globalvar.section_ea = FSize;
}
#endif

MkSection & MkSections::operator[](int i)
{
    if (FSizeOfArray == 0) return NullSection;
    if (i >= FSize && i < FSizeOfArray) FSize = i+1;

    if (i >=0 && i < FSize) return FSection[i];
    else return NullSection;
}

MkSections & MkSections::operator=(MkSections &sections)
{
    int i;

    Clear();
    FSize = sections.FSize;
    FSizeOfArray = sections.FSizeOfArray;
    if (FSize == 0) {
       FSection = NULL;
       return *this;
    }
    this->FSection = new MkSection[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FSection[i] = sections.FSection[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FSection[i] = NullSection;

    return *this;
}

bool MkSections::operator==(MkSections &sections)
{
    int i;

    if (FSize != sections.FSize) return false;
    for (i=0;i<FSize;i++)
      if (this->FSection[i] != sections.FSection[i]) return false;

    return true;
}
#ifdef __BCPLUSPLUS__
void MkSections::Draw(TObject *Sender)
{
  TColor C;
  float Offset;
  if (FSize == 0) return;
  if (String(Sender->ClassName()) == String("MkPaintBox")) {
     MkPaintBox *pb=(MkPaintBox*)Sender;
     C = pb->Canvas->Pen->Color;
     pb->Canvas->Pen->Color = Color;
     for (int i = 0; i < FSize;i++) {
         Offset = pb->Offset(3);
         FSection[i].Draw(pb);
     }
     pb->Canvas->Pen->Color = C;
  }
}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void MkSections::Draw(MkPaint *pb)
{
  for(int i=0;i<FSize;i++)
    FSection[i].Draw(pb);
}
#endif
//---------------------------------------------------------------------------
