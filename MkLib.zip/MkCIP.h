//---------------------------------------------------------------------------
#ifndef MkCIPH
#define MkCIPH
#include "MkWall.h"
//---------------------------------------------------------------------------
class MkCIP : public MkWall {
private:
  int BarDia;
  float Fck,Fy,Fca,Fsa,Vca,Ec,As;
protected:
  int CFck, CFy, CBarDia, CCIPSteel;
  double CThickDia, CNumOfBar;

public:
  MkCIP(){Clear();}
  MkCIP(int ){Clear();}
  ~MkCIP(){}
  void Clear();

public:
  void SetCFck(int i);
  void SetCFy(int );
  void SetCBarDia(int );
  void SetCCIPSteel(int );
  void SetCThickDia(double);
  void SetCNumOfBar(double);
  
public:
  int GetCFck(){return CFck;}
  int GetCFy(){return CFy;}
  int GetCBarDia(){return CBarDia;}
  int GetCCIPSteel(){return CCIPSteel;}
  double GetCThickDia(){return CThickDia;}
  double GetCNumOfBar(){return CNumOfBar;}

public:
  float GetFck(){return Fck;}
  float GetFy(){return Fy;}
  float GetFca(){return Fca;}
  float GetFsa(){return Fsa;}
  float GetVca(){return Vca;}
  float GetEc(){return Ec;}
  float GetAs(){return As;}

#ifdef __BCPLUSPLUS__
  AnsiString ClassName(){return AnsiString("MkCIP");};
#else
  char* ClassName(){return "MkCIP";}
#endif

#ifdef __BCPLUSPLUS__
  void  Draw(TObject *){}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif
};

class MkCIPs {
protected:
    MkCIP *FCIP;
    int FSize;//Actual size of cips
    int FSizeOfArray;
#ifdef __BCPLUSPLUS__
    TColor Color;
#endif
public:
    MkCIPs(int size,MkCIP *cip);
    MkCIPs(int size);
    MkCIPs(){FSizeOfArray = FSize = 0;FCIP = NULL;}
     ~MkCIPs();
    virtual void Initialize(int size);
    virtual void Initialize(int size,MkCIP *);
    int GetSize(){return FSize;};
    int GetNumber(){return FSize;};
    bool Add(MkCIP &cip);  // change of size of cip
    bool Add(int index,MkCIP &cip);
    bool Delete(MkCIP &cip);  // change of size of cip
    bool Delete(int index);
    int Grow(int Delta);            // change of size of array
    int Shrink(int Delta);          // change of size of array
    bool Clear();
#ifdef __BCPLUSPLUS__
    TColor GetColor(){return Color;};
    void SetColor(TColor c){Color = c;}
#endif

#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif

    virtual MkCIP & operator[](int);
    MkCIPs & operator=(MkCIPs &cips);
    bool operator==(MkCIPs &cips);
};
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
#endif


