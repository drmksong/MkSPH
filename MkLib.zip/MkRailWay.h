//---------------------------------------------------------------------------
#ifndef MkRailWayH
#define MkRailWayH
#include "MkInt.h"
#include "MkFloat.h"
#include "MkPoint.h"
#include "MkLine.h"
#include "MkTriangle.h"
#include "MkPolygon.h"
//#include "BirdEyeViewUnit.h"

// How can I distingush between NullPoint and Origin Point.
// if two connected point are the same and is NullPoint then
// isFilled returns false.

class MkRailWay : public MkPolygon {
protected:

    bool Flag;
public:
    MkRailWay(int size, MkPoint *rp,MkFloat &station);
    MkRailWay(int size, MkPoint *);
    MkRailWay(int size);  // empty polygon
    MkRailWay();          // even memory is not allocated
    ~MkRailWay();
    void Initialize(int size,MkPoint *,MkFloat &station);
    void Initialize(int size,MkPoint *);
    void Initialize(int size);
    void Initialize(MkFloat &station);

    void SetDepth();

    MkPoint FowardDir(int i,float j);
    MkPoint BackwardDir(int i,float j);

    float      GetXMin();
    float      GetYMin();

    MkPoint operator()(int i,float j); // Sta. i km j meter.
    MkLine operator()(int i);
    MkPoint & MkRailWay::operator[](int i);
    MkRailWay & operator=(MkRailWay &railway);
public:
    MkFloat Station;
    MkFloat FirstLayerDepth;
    MkFloat SecondLayerDepth;
    MkFloat ThirdLayerDepth;

};
//---------------------------------------------------------------------------
#endif
