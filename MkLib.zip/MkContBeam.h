//---------------------------------------------------------------------------
#ifndef MkContBeamH
#define MkContBeamH
#include "MkAnalysis.h"
#include "MkNodalForce.h"
//---------------------------------------------------------------------------
class MkContBeam : public MkAnalysis {
protected:
  MkFloat NodalLoad;
  MkFloat NodalDis;
  MkNodalForce JackingForce;
  MkNodalForce IniForceCorrect;
public:
  MkContBeam();
  MkContBeam(int);
  ~MkContBeam(){}
public: // key function
  bool Initialize(){
    NodalLoad.Initialize(NodeRef->GetSize(),2); // x-directional and z-rotational load
    NodalDis.Initialize(NodeRef->GetSize(),2);  //
    return true;
  }
  bool Setup();
  bool Post();
  bool Out();
  bool Solve();
  bool Apply(MkLoads &load,MkLayers &);
  bool ApplyNodal(MkLoad &load,MkLayers &);
  bool ApplyDistributal(MkLoad &load,MkLayers &);
  bool ApplyJackingForce(MkNodalForce &jack){JackingForce = jack;return true;}
  bool ApplyIniForceCorrect(MkNodalForce &ini){IniForceCorrect = ini;return true;}
public: 
#ifdef __BCPLUSPLUS__
  AnsiString ClassName(){return AnsiString("MkContBeam");}
#else
  char* ClassName(){return ("MkContBeam");}
#endif
public: // operator function
  bool operator==(MkContBeam &);
  bool operator!=(MkContBeam &);
public:
#ifdef __BCPLUSPLUS__
  void Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif
};
//---------------------------------------------------------------------------
#endif
