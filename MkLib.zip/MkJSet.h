//---------------------------------------------------------------------------
#ifndef MkJSetH
#define MkJSetH

#include <math.h>
#include <math.hpp>
#include <stdlib.h>
#include "MkMisc.h"

class MkJSet {
private:
   float MeanDipDir,MeanDip,StdDev,K,Percent;
   int NumberOfJoint;
public:
   MkJSet(){MeanDipDir = 0;MeanDip = 0;StdDev=0;K = 0;Percent=0;};
   MkJSet(float mean_dip_dir,float mean_dip, float stddev, float k,float percent){
                                 MeanDipDir =mean_dip_dir;
                                 MeanDip =mean_dip;
                                 StdDev =stddev;
                                 K = k;
                                 Percent = percent;};
   void SetDipDir(float dipdir) {MeanDipDir = dipdir;}
   void SetDip(float dip) {MeanDip = dip;}
   void SetStdDev(float stddev){StdDev = stddev;}
   void SetPercent(float percent){Percent = percent;}
   void SetK(float k){K = k;}
   float GetDipDir() {return MeanDipDir;}
   float GetDip() {return MeanDip;}
   float GetStdDev(){return StdDev;}
   float GetPercent(){return Percent;}
   float SetK(){return K;}
   void SetNumberOfJoint(int n) {NumberOfJoint = n;}
   int  GetNumberOfJoint(){return NumberOfJoint;}
   MkJSet & operator=(MkJSet &jset){ MeanDipDir =jset.MeanDipDir;
                                 MeanDip =jset.MeanDip;
                                 StdDev =jset.StdDev;
                                 K = jset.K;
                                 Percent = jset.Percent;
                                 return *this;};
   bool transcod(float alp, float bet, float &psi, float &theta);
   TOrient & Gen();
};

class MkJSets {
private:
   MkJSet *FMkJSet;
   int FSize;
   float Station;
public:
   MkJSets(){FSize = 0;FMkJSet = (MkJSet*)NULL;};
   MkJSets(int size,MkJSet *pjset);
   MkJSets(int size);
   ~MkJSets();
   bool Clear();
   bool SetMkJSets(int size,MkJSet *pjset);
   bool SetMkJSets(int size);
   bool Initialize(int size,MkJSet *pjset){return SetMkJSets(size,pjset);}
   bool Initialize(int size){return SetMkJSets(size);}
   bool Grow(int delta);
   bool AddMkJSet(MkJSet ajset);
   int  GetSize(){return FSize;}
   MkJSets & operator=(MkJSets &jsets);
   MkJSet & operator[](int i);
};

extern MkJSet NullMkJSet;
//---------------------------------------------------------------------------
#endif
