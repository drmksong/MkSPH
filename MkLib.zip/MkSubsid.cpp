//#include "stdafx.h"
#include "MkSubsid.h"

MkSubsid::MkSubsid()
{

}

void MkSubsid::SetPeck()
{
  MkFloat x,y;
}

void MkSubsid::SetORourke()
{
  MkFloat x,y;
}

float MkSubsid::GetSubsid(MkSubsidType sub,float x)
{
  switch(sub) {
  case subCaspe: return GetSubsidCaspe(x);
  case subPeck: return GetSubsidPeck(x);
  case subORourke: return GetSubsidORourke(x);
  }
  return 0;
}

float MkSubsid::GetSubsidCaspe(float x)
{
  if(fabs(Friction)>EPS) Hp = 0.5*Width*tan((45-Friction/2)*3.141592);
  else Hp = Width;
  Ht = Hp + ExcavDepth;
  D = Ht*tan((45-Friction/2)*3.141592);
  Sw = 4*Vs/D;
  Si = Sw*((D-x)/D)*((D-x)/D);
  return Si;
}

float MkSubsid::GetSubsidPeck(float x)
{
  return Peck[x];
}

float MkSubsid::GetSubsidORourke(float x)
{
  return ORourke[x];
}
