//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "ImageProcess.h"
#pragma package(smart_init)
//---------------------------------------------------------------------------
// ValidCtrCheck is used to assure that the components created do not have
// any pure virtual functions.
//

static inline void ValidCtrCheck(TImageProcess *)
{
        new TImageProcess(NULL);
}
//---------------------------------------------------------------------------
__fastcall TImageProcess::TImageProcess(TComponent* Owner)
        : TImage(Owner)
{
}

__fastcall TImageProcess::Smooth()
{
   TColor r[4],g[4],b[4],rm,gm,bm,c;
   for (int i = 0 ; i < Picture->Width-1 ; i++) {
       for (int j = 0 ; j < Picture->Height-1; j++) {
           r[0] = Canvas->Pixels[i][j] & 0xFF0000FF;
           r[1] = Canvas->Pixels[i+1][j] & 0xFF0000FF;
           r[2] = Canvas->Pixels[i][j+1] & 0xFF0000FF;
           r[3] = Canvas->Pixels[i+1][j+1] & 0xFF0000FF;
           g[0] = Canvas->Pixels[i][j] & 0xFF00FF00;
           g[1] = Canvas->Pixels[i+1][j] & 0xFF00FF00;
           g[2] = Canvas->Pixels[i][j+1] & 0xFF00FF00;
           g[3] = Canvas->Pixels[i+1][j+1] & 0xFF00FF00;
           b[0] = Canvas->Pixels[i][j] & 0xFFFF0000;
           b[1] = Canvas->Pixels[i+1][j] & 0xFFFF0000;
           b[2] = Canvas->Pixels[i][j+1] & 0xFFFF0000;
           b[3] = Canvas->Pixels[i+1][j+1] & 0xFFFF0000;
           rm = ((r[0]+r[1]+r[2]+r[3])/8) & 0xFF0000FF;
           gm = ((g[0]+g[1]+g[2]+g[3])/8) & 0xFF00FF00;
           bm = ((b[0]+b[1]+b[2]+b[3])/8) & 0xFFFF0000;
           c = rm | gm | bm;
           Canvas->Pixels[i][j] = c;
       }
   }
}

__fastcall TImageProcess::EdgeDetect()
{
   int LUT[] = {0xFF,0xFF,0xFF,0xFF
                      ,0xFF,0xFF,0xFF,0xFF
                      ,0xFF,0xFF,0xFF,0xFF
                      ,0xFF,0xFF,0xFF,0xFF
                      ,0xFF,0xFF,0xFF,0xFF
                      ,0xFF,0xFF,0   ,0
                      ,0   ,0   ,0xFF,0xFF
                      ,0xFF,0xFF,0xFF,0xFF} ;
   TColor r[2],g[2],b[2],c;
   int rd=0,gd=0,bd=0;
   for (int i = 0 ; i < Picture->Width-1 ; i++) {
       for (int j = 0 ; j < Picture->Height-1; j++) {
           r[0] = Canvas->Pixels[i][j] & 0xFF0000FF;
           r[1] = Canvas->Pixels[i+1][j+1] & 0xFF0000FF;
           g[0] = Canvas->Pixels[i][j] & 0xFF00FF00;
           g[1] = Canvas->Pixels[i+1][j+1] & 0xFF00FF00;
           b[0] = Canvas->Pixels[i][j] & 0xFFFF0000;
           b[1] = Canvas->Pixels[i+1][j+1] & 0xFFFF0000;

           rd = LUT[abs(r[0]-r[1])/4];
           gd = LUT[(abs(g[0]-g[1])/0xFF)/4];
           bd = LUT[(abs(b[0]-b[1])/0xFFFF)/4];
           c = rd | (gd*0xFF) | (bd*0xFFFF);
           Canvas->Pixels[i][j] = c;
       }
   }
}

__fastcall TImageProcess::EdgeDetectL()
{
   int LUT[] = {0xFF,0xFF,0xFF,0xFF
                      ,0xFF,0xFF,0xFF,0xFF
                      ,0xFF,0xFF,0xFF,0xFF
                      ,0xFF,0xFF,0xFF,0xFF
                      ,0xFF,0xFF,0xFF,0xFF
                      ,0xFF,0xFF,0   ,0
                      ,0   ,0   ,0xFF,0xFF
                      ,0xFF,0xFF,0xFF,0xFF} ;
   TColor r[2],g[2],b[2],c;
   int rd=0,gd=0,bd=0;
   for (int i = 0 ; i < Picture->Width-1 ; i++) {
       for (int j = 0 ; j < Picture->Height-1; j++) {
           r[0] = Canvas->Pixels[i][j] & 0x000000FF;
           r[1] = Canvas->Pixels[i+1][j+1] & 0x000000FF;
           g[0] = Canvas->Pixels[i][j] & 0x0000FF00;
           g[1] = Canvas->Pixels[i+1][j+1] & 0x0000FF00;
           b[0] = Canvas->Pixels[i][j] & 0x00FF0000;
           b[1] = Canvas->Pixels[i+1][j+1] & 0x00FF0000;

           rd = LUT[abs(r[0]-r[1])/4];
           gd = LUT[(abs(g[0]-g[1])/0xFF)/4];
           bd = LUT[(abs(b[0]-b[1])/0xFFFF)/4];
           c = rd | (gd*0xFF) | (bd*0xFFFF);
           Canvas->Pixels[i][j] = c;
       }
   }
}

__fastcall TImageProcess::EdgeDetectR()
{
   static int LUT[] = {0xFF,0xFF,0xFF,0xFF
                      ,0xFF,0xFF,0xFF,0xFF
                      ,0xFF,0xFF,0xFF,0xFF
                      ,0xFF,0xFF,0xFF,0xFF
                      ,0xFF,0xFF,0xFF,0xFF
                      ,0xFF,0xFF,0   ,0
                      ,0   ,0   ,0xFF,0xFF
                      ,0xFF,0xFF,0xFF,0xFF} ;
   TColor r[2],g[2],b[2],c;
   int rd=0,gd=0,bd=0;
   for (int i = Picture->Width-1 ; i > 0 ; i--) {
       for (int j = 0 ; j < Picture->Height-1; j++) {
           r[0] = Canvas->Pixels[i][j] & 0xFF0000FF;
           r[1] = Canvas->Pixels[i-1][j+1] & 0xFF0000FF;
           g[0] = Canvas->Pixels[i][j] & 0xFF00FF00;
           g[1] = Canvas->Pixels[i-1][j+1] & 0xFF00FF00;
           b[0] = Canvas->Pixels[i][j] & 0xFFFF0000;
           b[1] = Canvas->Pixels[i-1][j+1] & 0xFFFF0000;

           rd = LUT[abs(r[0]-r[1])/4];
           gd = LUT[(abs(g[0]-g[1])/0xFF)/4];
           bd = LUT[(abs(b[0]-b[1])/0xFFFF)/4];
           c = rd | (gd*0xFF) | (bd*0xFFFF);
           Canvas->Pixels[i][j] = c;
       }
   }
}

__fastcall TImageProcess::EdgeEnhance()
{
   TColor r[2],g[2],b[2],c;
   int rd=0,gd=0,bd=0;
   for (int i = 0 ; i < Picture->Width-1 ; i++) {
       for (int j = 0 ; j < Picture->Height-1; j++) {
           r[0] = Canvas->Pixels[i][j] & 0xFF0000FF;
           r[1] = Canvas->Pixels[i+1][j+1] & 0xFF0000FF;
           g[0] = Canvas->Pixels[i][j] & 0xFF00FF00;
           g[1] = Canvas->Pixels[i+1][j+1] & 0xFF00FF00;
           b[0] = Canvas->Pixels[i][j] & 0xFFFF0000;
           b[1] = Canvas->Pixels[i+1][j+1] & 0xFFFF0000;

           rd = ((2*r[0]-r[1])) & 0xFF0000FF;
           gd = ((2*g[0]-g[1])/0xFF) & 0xFF0000FF;
           bd = ((2*b[0]-b[1])/0xFFFF) & 0xFF0000FF;
           c = rd | (gd*0xFF) | (bd*0xFFFF);
           Canvas->Pixels[i][j] = c;
       }
   }
}

//---------------------------------------------------------------------------
namespace Imageprocess
{
        void __fastcall PACKAGE Register()
        {
                 TComponentClass classes[1] = {__classid(TImageProcess)};
                 RegisterComponents("Samples", classes, 0);
        }
}
//---------------------------------------------------------------------------
 