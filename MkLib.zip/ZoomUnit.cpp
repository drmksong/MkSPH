//---------------------------------------------------------------------------
#include "ZoomUnit.h"
#include <vcl.h>
#pragma hdrstop
#include "ShadowButton.hpp"
//---------------------------------------------------------------------------
#pragma package(smart_init)

int NumOfSec;
//---------------------------------------------------------------------------
void delay(int d)
{
   long FirstTickCount;
   FirstTickCount = GetTickCount();
   do Application->ProcessMessages();
   while((GetTickCount()-FirstTickCount)<Longint(d));
}
//---------------------------------------------------------------------------
void Gambak(TObject *sender)
{
   TShadowButton *sbtn = (TShadowButton*)sender;
   if (sbtn) {
      sbtn->Color = clWhite;
      sbtn->Font->Color = clBlack;
      delay(50);
      sbtn->Color = clBlack;
      sbtn->Font->Color = clWhite;
      delay(50);
      sbtn->Color = clWhite;
      sbtn->Font->Color = clBlack;
      delay(50);
      sbtn->Color = clBlack;
      sbtn->Font->Color = clWhite;
//      delay(15);
   }
}
//---------------------------------------------------------------------------
void zoom(int sx_f,int sy_f,int ex_f,int ey_f,int sx_t,int sy_t,int ex_t,int ey_t)
{
  TCanvas *Canvas = new TCanvas;
  Canvas->Handle = GetDC(0);
  Canvas->Pen->Color = clGray;
  Canvas->Pen->Mode = pmXor;
  int N;  N = NumOfSec;
  int i,j;
  int x1,y1,x2,y2;

  for (i=0;i < N;i++) {
      j = i - 1 < 0 ? 0 : i - 1;
      x1 = (sx_t-sx_f)*i*i/float(N*N) + sx_f;
      y1 = (sy_t-sy_f)*i*i/float(N*N) + sy_f;

      x2 = (ex_t-ex_f)*(i*i/float(N*N)) + ex_f;
      y2 = (ey_t-ey_f)*(i*i/float(N*N)) + ey_f;

      box(Canvas,x1,y1,x2,y2);

      x1 = (sx_t-sx_f)*j*j/float(N*N) + sx_f;
      y1 = (sy_t-sy_f)*j*j/float(N*N) + sy_f;

      x2 = (ex_t-ex_f)*(j*j/float(N*N)) + ex_f;
      y2 = (ey_t-ey_f)*(j*j/float(N*N)) + ey_f;

      box(Canvas,x1,y1,x2,y2);

      delay(10);

      x1 = (sx_t-sx_f)*i*i/float(N*N) + sx_f;
      y1 = (sy_t-sy_f)*i*i/float(N*N) + sy_f;

      x2 = (ex_t-ex_f)*(i*i/float(N*N)) + ex_f;
      y2 = (ey_t-ey_f)*(i*i/float(N*N)) + ey_f;

      box(Canvas,x1,y1,x2,y2);

      x1 = (sx_t-sx_f)*j*j/float(N*N) + sx_f;
      y1 = (sy_t-sy_f)*j*j/float(N*N) + sy_f;

      x2 = (ex_t-ex_f)*(j*j/float(N*N)) + ex_f;
      y2 = (ey_t-ey_f)*(j*j/float(N*N)) + ey_f;

      box(Canvas,x1,y1,x2,y2);
  }

  ReleaseDC(0,Canvas->Handle);
  delete Canvas;
}
//---------------------------------------------------------------------------
void box(TCanvas *canvas,int sx,int sy,int ex,int ey)
{
  canvas->MoveTo(sx,sy);
  canvas->LineTo(sx,ey);

  canvas->MoveTo(sx,ey);
  canvas->LineTo(ex,ey);

  canvas->MoveTo(ex,ey);
  canvas->LineTo(ex,sy);

  canvas->MoveTo(ex,sy);
  canvas->LineTo(sx,sy);
}
//---------------------------------------------------------------------------

 