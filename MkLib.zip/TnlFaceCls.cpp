//---------------------------------------------------------------------------
// This module is general purposed simple graphic class to store, draw,
// manipulate object. It is well suited to VCL component, but not restricted.
// It forms the base for the higher level class, such as tunnel component.
//
// Copyright (c) 1999 Myung Kyu Song, ESCO Consultant Co., Ltd.
#include "TnlFaceCls.h"
#include <vcl.h>
#pragma hdrstop

#include "\vcl\dstring.h"
extern TRealPoint NullPoint;
//---------------------------------------------------------------------------
//  ����
//---------------------------------------------------------------------------
void TRoad::GetInformation(TObject *Sender)
{
    if (String(Sender->ClassName()) == String("TMemo")) {
       TMemo *memo=(TMemo*)Sender;
       char str[256];
       sprintf(str,"�� : %4.2f m",Width);
       memo->Lines->Add("����");
       memo->Lines->Add("-----------------------------------");
       memo->Lines->Add("���� : " + AnsiString(Slope)+'%');
       memo->Lines->Add("������ : " + AnsiString(Number)+" ��");
       memo->Lines->Add(str);
       memo->Lines->Add(" ");
    }
}

TRealPoint & TRoad::operator[](int i)
{
     if (i == 0) return StartPoint;
     else if (i == 1) return EndPoint;
     else if (i == 2) return LineCenter;
     else if (i == 3) return RoadCenter;
     else if (i == 4) return TunnelCenter;
     else {
        ShowMessage("TRoad : Bad Index");
        return NullPoint;
     }
}

TRealPoint & TRoad::operator[](TRoadPoint rp)
{
     if (rp == pStartPoint) return StartPoint;
     else if (rp == pEndPoint) return EndPoint;
     else if (rp == pLineCenter) return LineCenter;
     else if (rp == pRoadCenter) return RoadCenter;
     else if (rp == pTunnelCenter) return TunnelCenter;
     else {
        ShowMessage("TRoad : Bad Parameter");
        return NullPoint;
     }
}

TRoad & TRoad::operator=(TRoad &rd)
{
     (*this).isExist = rd.isExist;
//     (*this).Origin = rd.Origin;
     (*this).Number = rd.Number;
     (*this).Width = rd.Width;
     (*this).Slope = rd.Slope;
     (*this).SlopeAng = rd.SlopeAng;
     (*this).StartPoint = rd.StartPoint;
     (*this).EndPoint = rd.EndPoint;
     (*this).LineCenter = rd.LineCenter;
     (*this).RoadCenter = rd.RoadCenter;
     (*this).TunnelCenter = rd.TunnelCenter;
     return (*this);
}

void TRoad::Locate()
{
     (*this)[pLineCenter].X = 0;
     (*this)[pLineCenter].Y = 0;
     (*this)[pStartPoint].X = 0;
     (*this)[pStartPoint].Y = 0;
     SlopeAng = atan2(-Slope,100);

     (*this)[pRoadCenter].X = (*this)[pStartPoint].X + Number*GetWidth()/2.0;
     (*this)[pRoadCenter].Y = (*this)[pRoadCenter].X * tan(SlopeAng);
     (*this)[pEndPoint].X = (*this)[pStartPoint].X + Number*GetWidth();
     (*this)[pEndPoint].Y = (*this)[pEndPoint].X * tan(SlopeAng);
}

void TRoad::MakePolygon()
{
     Locate();
     Polygon.Initialize(3);
     Polygon.SetColor(clBlue);
     Polygon.SetCloseness(false);
     Polygon[0] = (*this)[pStartPoint];
     Polygon[1] = (*this)[pRoadCenter];
     Polygon[2] = (*this)[pEndPoint];
}

TRealPolygon & TRoad::GetPolygon()
{
    return Polygon;
}

void TRoad::Draw(TObject *Sender){
    Polygon.Draw(Sender);
}
//---------------------------------------------------------------------------
//  ����
//---------------------------------------------------------------------------
void TCheukDae::GetInformation(TObject *Sender)
{
    if (isExist && String(Sender->ClassName()) == String("TMemo")) {
       TMemo *memo=(TMemo*)Sender;
       char str[256];
       sprintf(str,"���� : %4.2f m",Width);
       if (Side == sLeft)
          memo->Lines->Add("��������");
       else if (Side == sRight)
          memo->Lines->Add("��������");
       memo->Lines->Add("-----------------------------------");
       memo->Lines->Add("���� : " + AnsiString(Slope)+'%');
       memo->Lines->Add(str);
       memo->Lines->Add(" ");
    }
}

TCheukDae & TCheukDae::operator=(TCheukDae &cd)
{
     (*this).isExist = cd.isExist;
     (*this).Origin = cd.Origin;
     (*this).Width = cd.Width;
     (*this).Slope = cd.Slope;
     (*this).SlopeAng = cd.SlopeAng;
     (*this).StartPoint = cd.StartPoint;
     (*this).EndPoint = cd.EndPoint;
     return (*this);
}

TRealPoint & TCheukDae::operator[](int i)
{
     if (i == 0) return StartPoint;
     else if (i == 1) return EndPoint;
     else return NullPoint;
}

TRealPolygon & TCheukDae::GetPolygon()
{
    return Polygon;
}

void TCheukDae::Locate()
{
     SlopeAng = atan2(-Slope,100);
     if (Side == sLeft) {
        (*this)[1].X = 0;
        (*this)[1].Y = 0;
        (*this)[0].X = -GetWidth();
        (*this)[0].Y = (*this)[0].X*tan(SlopeAng);
     }
     else if (Side == sRight) {
        (*this)[0].X = 0;
        (*this)[0].Y = 0;
        (*this)[1].X = GetWidth();
        (*this)[1].Y = (*this)[1].X*tan(SlopeAng);
     }
}

void TCheukDae::MoveAbs(TRealPoint origin)
{
    Origin = origin;
}
void TCheukDae::MoveRel(TRealPoint origin)
{
    Origin += origin;
}

void TCheukDae::MakePolygon()
{
     Locate();
     Polygon.Initialize(2);
     Polygon.SetCloseness(false);
     if (Side == sLeft) {
        Polygon[0] = (*this)[0]+Origin;
        Polygon[1] = (*this)[1]+Origin;
        Polygon.SetColor(clRed);
     }
     else if (Side == sRight) {
        Polygon[0] = (*this)[0]+Origin;
        Polygon[1] = (*this)[1]+Origin;
        Polygon.SetColor(clGreen);
     }
}

void TCheukDae::Draw(TObject *Sender)
{
    Polygon.Draw(Sender);
}

//---------------------------------------------------------------------------
//  ����
//---------------------------------------------------------------------------
void TGuideStone::GetInformation(TObject *Sender)
{
    if (isExist && String(Sender->ClassName()) == String("TMemo")) {
       TMemo *memo=(TMemo*)Sender;
       char str[256];
       if (Side == sLeft)
          memo->Lines->Add("��������");
       else if (Side == sRight)
          memo->Lines->Add("��������");
       memo->Lines->Add("-----------------------------------");
       sprintf(str,"���� : %4.2f m",Height);
       memo->Lines->Add(str);
       sprintf(str,"���� : %4.2f m",Width);
       memo->Lines->Add(str);
       memo->Lines->Add(" ");
    }
}

TRealPoint & TGuideStone::operator[](int i)
{
     if (i == 0) return StartPoint;
     else if (i == 1) return MiddlePoint;
     else if (i == 2) return EndPoint;
     else throw;
}

TGuideStone & TGuideStone::operator=(TGuideStone & rd)
{
     (*this).isExist = rd.isExist;
     (*this).Origin = rd.Origin;
     (*this).Width = rd.Width;
     (*this).Height = rd.Height;
     (*this).StartPoint = rd.StartPoint;
     (*this).MiddlePoint = rd.MiddlePoint;
     (*this).EndPoint = rd.EndPoint;
     return (*this);
}

void TGuideStone::Locate()
{
     if (Side == sLeft) {
        (*this)[2].X = 0;
        (*this)[2].Y = 0;
        (*this)[1].X = 0;
        (*this)[1].Y = GetHeight();
        (*this)[0].X = -GetWidth();
        (*this)[0].Y = GetHeight();
     }
     else if (Side == sRight) {
        (*this)[0].X = 0;
        (*this)[0].Y = 0;
        (*this)[1].X = 0;
        (*this)[1].Y = GetHeight();
        (*this)[2].X = GetWidth();
        (*this)[2].Y = GetHeight();
     }
}

void TGuideStone::MoveAbs(TRealPoint origin)
{
    Origin = origin;
}
void TGuideStone::MoveRel(TRealPoint origin)
{
    Origin += origin;
}

void TGuideStone::MakePolygon()
{
     Locate();
     Polygon.Initialize(3);
     Polygon.SetCloseness(false);
     if (Side == sLeft) {
        Polygon[0] = (*this)[0]+Origin;
        Polygon[1] = (*this)[1]+Origin;
        Polygon[2] = (*this)[2]+Origin;
        Polygon.SetColor(clRed);
     }
     else if (Side == sRight) {
        Polygon[0] = (*this)[0]+Origin;
        Polygon[1] = (*this)[1]+Origin;
        Polygon[2] = (*this)[2]+Origin;
        Polygon.SetColor(clGreen);
     }
}

TRealPolygon & TGuideStone::GetPolygon()
{
    return Polygon;
}

void TGuideStone::Draw(TObject *Sender)
{
    Polygon.Draw(Sender);
}

//---------------------------------------------------------------------------
//  �����
//---------------------------------------------------------------------------
void TDrainage::GetInformation(TObject *Sender)
{
    if (isExist && String(Sender->ClassName()) == String("TMemo")) {
       TMemo *memo=(TMemo*)Sender;
       char str[256];
       if (Side == sLeft)
          memo->Lines->Add("���������");
       else if (Side == sRight)
          memo->Lines->Add("���������");
       memo->Lines->Add("-----------------------------------");
       sprintf(str,"���� : %4.2f m",Slope);
       memo->Lines->Add(str);
       sprintf(str,"���� : %4.2f m",Width);
       memo->Lines->Add(str);
       memo->Lines->Add(" ");
     }
}

TDrainage & TDrainage::operator=(TDrainage &d)
{
     (*this).isExist = d.isExist;
     (*this).Origin = d.Origin;
     (*this).Width = d.Width;
     (*this).Slope = d.Slope;
     (*this).SlopeAng = d.SlopeAng;
     (*this).StartPoint = d.StartPoint;
     (*this).EndPoint = d.EndPoint;
     return (*this);
}

TRealPoint & TDrainage::operator[](int i)
{
     if (i == 0) return StartPoint;
     else if (i == 1) return EndPoint;
     else return NullPoint;
}

void TDrainage::Locate()
{
     SlopeAng = atan2(-Slope,100);
     if (Side == sLeft) {
        (*this)[1].X = 0;
        (*this)[1].Y = 0;
        (*this)[0].X = -GetWidth();
        (*this)[0].Y = (*this)[0].X*tan(SlopeAng);
     }
     else if (Side == sRight) {
        (*this)[0].X = 0;
        (*this)[0].Y = 0;
        (*this)[1].X = GetWidth();
        (*this)[1].Y = (*this)[1].X*tan(SlopeAng);
     }
}

void TDrainage::MoveAbs(TRealPoint origin)
{
    Origin = origin;
}
void TDrainage::MoveRel(TRealPoint origin)
{
    Origin += origin;
}

void TDrainage::MakePolygon()
{
     Locate();
     Polygon.Initialize(2);
     Polygon.SetCloseness(false);
     if (Side == sLeft) {
        Polygon[0] = (*this)[0]+Origin;
        Polygon[1] = (*this)[1]+Origin;
        Polygon.SetColor(clRed);
     }
     else if (Side == sRight) {
        Polygon[0] = (*this)[0]+Origin;
        Polygon[1] = (*this)[1]+Origin;
        Polygon.SetColor(clGreen);
     }
}

void TDrainage::Draw(TObject *Sender)
{
    Polygon.Draw(Sender);
}

//---------------------------------------------------------------------------
//  ������
//---------------------------------------------------------------------------
void TGongDongGu::GetInformation(TObject *Sender)
{
    if (isExist && String(Sender->ClassName()) == String("TMemo")) {
       TMemo *memo=(TMemo*)Sender;
       char str[256];
       if (Side == sLeft)
          memo->Lines->Add("����������");
       else if (Side == sRight)
          memo->Lines->Add("����������");
       memo->Lines->Add("-----------------------------------");
       sprintf(str,"���� : %4.2f m",Height);
       memo->Lines->Add(str);
       sprintf(str,"���� : %4.2f m",Width);
       memo->Lines->Add(str);
       sprintf(str,"�������� : %4.2f m",CoverHeight);
       memo->Lines->Add(str);
       sprintf(str,"�������� : %4.2f m",CoverWidth);
       memo->Lines->Add(str);
       sprintf(str,"���γ��� : %4.2f m",InHeight);
       memo->Lines->Add(str);
       sprintf(str,"�����β� : %4.2f m",(Width- InWidth)/2);
       memo->Lines->Add(str);
       memo->Lines->Add(" ");
    }
}

TRealPoint & TGongDongGu::operator[](int i)
{
     if (i == 0) return StartPoint;
     else if (i == 1) return MiddlePoint;
     else if (i == 2) return EndPoint;
     else return NullPoint;
}

TGongDongGu & TGongDongGu::operator=(TGongDongGu &gdg)
{
     (*this).isExist = gdg.isExist;
     (*this).Origin = gdg.Origin;
     (*this).Width = gdg.Width;
     (*this).Height = gdg.Height;
     (*this).InWidth = gdg.InWidth;
     (*this).InHeight = gdg.InHeight;
     (*this).CoverWidth = gdg.CoverWidth;
     (*this).CoverHeight = gdg.CoverHeight;
     (*this).CoverGap = gdg.CoverGap;
     (*this).StartPoint = gdg.StartPoint;
     (*this).EndPoint = gdg.EndPoint;
     return (*this);
}

void TGongDongGu::Locate(void)
{
     if (Side == sLeft) {
        (*this)[2].X = 0;
        (*this)[2].Y = 0;
        (*this)[1].X = 0;
        (*this)[1].Y = GetHeight();
        (*this)[0].X = -GetWidth();
        (*this)[0].Y = GetHeight();
     }
     else if (Side == sRight) {
        (*this)[0].X = 0;
        (*this)[0].Y = 0;
        (*this)[1].X = 0;
        (*this)[1].Y = GetHeight();
        (*this)[2].X = GetWidth();
        (*this)[2].Y = GetHeight();
     }
}

TRealPolygon & TGongDongGu::GetPolygon()
{
     return Polygon;
}

void TGongDongGu::MoveAbs(TRealPoint origin)
{
    Origin = origin;
}

void TGongDongGu::MoveRel(TRealPoint origin)
{
    Origin += origin;
}

void TGongDongGu::MakePolygon()
{
     Locate();
     Polygon.Initialize(3);
     Polygon.SetCloseness(false);
     if (Side == sLeft) {
        Polygon[0] = (*this)[0]+Origin;
        Polygon[1] = (*this)[1]+Origin;
        Polygon[2] = (*this)[2]+Origin;
        Polygon.SetColor(clRed);
     }
     else if (Side == sRight) {
        Polygon[0] = (*this)[0]+Origin;
        Polygon[1] = (*this)[1]+Origin;
        Polygon[2] = (*this)[2]+Origin;
        Polygon.SetColor(clGreen);
     }
}

void TGongDongGu::Draw(TObject *Sender)
{
    Polygon.Draw(Sender);
}

//---------------------------------------------------------------------------
//  �˻�����
//---------------------------------------------------------------------------
void TInspectWay::GetInformation(TObject *Sender)
{
    if (isExist && String(Sender->ClassName()) == String("TMemo")) {
       TMemo *memo=(TMemo*)Sender;
       char str[256];
       memo->Lines->Add("�˻�����");
       memo->Lines->Add("-----------------------------------");
       sprintf(str,"���� : %4.2f m",Height);
       memo->Lines->Add(str);
       sprintf(str,"���� : %4.2f m",Width);
       memo->Lines->Add(str);
       memo->Lines->Add(" ");
    }
}

TInspectWay & TInspectWay::operator=(TInspectWay &iw)
{
     (*this).isExist = iw.isExist;
     (*this).Origin = iw.Origin;
     (*this).Width = iw.Width;
     (*this).Height= iw.Height;
     (*this).Elev= iw.Elev;
     (*this).InteriorMargin = iw.InteriorMargin;;
     return (*this);
}
/*
TRealPolygon & TInspectWay::GetPolygon()
{

}
void TInspectWay::MakePolygon()
{

}
void TInspectWay::Draw(TObject *Sender)
{
//    Polygon.Draw(Sender);
}

*/

//---------------------------------------------------------------------------
//  THP
//---------------------------------------------------------------------------
void TTHP::GetInformation(TObject *Sender)
{
    if (isExist && String(Sender->ClassName()) == String("TMemo")) {
       TMemo *memo=(TMemo*)Sender;
       char str[256];
       if (Side == sLeft)
          memo->Lines->Add("���� THP");
       else if (Side == sRight)
          memo->Lines->Add("���� THP");
       memo->Lines->Add("-----------------------------------");
       sprintf(str,"���� : %4.2f m",Circle.GetRadius());
       memo->Lines->Add(str);
       memo->Lines->Add(" ");
    }
}

TTHP & TTHP::operator=(TTHP &thp)
{
     (*this).isExist = thp.isExist;
     (*this).Side = thp.Side;
     (*this).Origin = thp.Origin;
     (*this).Circle = thp.Circle;
     return (*this);
}

//---------------------------------------------------------------------------
//  �ƿ�������
//---------------------------------------------------------------------------
void TSteelPipe::GetInformation(TObject *Sender)
{
    if (isExist && String(Sender->ClassName()) == String("TMemo")) {
       TMemo *memo=(TMemo*)Sender;
       char str[256];
       if (Side == sLeft)
          memo->Lines->Add("���� �ƿ�������");
       else if (Side == sRight)
          memo->Lines->Add("���� �ƿ�������");
       memo->Lines->Add("-----------------------------------");
       sprintf(str,"���� : %4.2f m",Circle.GetRadius());
       memo->Lines->Add(str);
       memo->Lines->Add(" ");
    }
}

TSteelPipe & TSteelPipe::operator=(TSteelPipe &sp)
{
     (*this).isExist = sp.isExist;
     (*this).Side = sp.Side;
     (*this).Origin = sp.Origin;
     (*this).Circle = sp.Circle;
     return (*this);
}

//---------------------------------------------------------------------------
//  ������ũ��Ʈ
//---------------------------------------------------------------------------
void TPaveConc::GetInformation(TObject *Sender)
{
    if (isExist && String(Sender->ClassName()) == String("TMemo")) {
       TMemo *memo=(TMemo*)Sender;
       char str[256];
       memo->Lines->Add("������ũ��Ʈ");
       memo->Lines->Add("-----------------------------------");
       sprintf(str,"�β� : %4.2f m",Height);
       memo->Lines->Add(str);
       memo->Lines->Add(" ");
    }
}

TPaveConc& TPaveConc::operator=(TPaveConc &pc)
{
     (*this).isExist = pc.isExist;
     (*this).Origin = pc.Origin;
     (*this).Height = pc.Height;
     return (*this);
}

//---------------------------------------------------------------------------
//  �������ũ��Ʈ
//---------------------------------------------------------------------------
void TMixConc::GetInformation(TObject *Sender)
{
    if (isExist && String(Sender->ClassName()) == String("TMemo")) {
       TMemo *memo=(TMemo*)Sender;
       char str[256];
       memo->Lines->Add("�������ũ��Ʈ");
       memo->Lines->Add("-----------------------------------");
       sprintf(str,"�β� : %4.2f m",Height);
       memo->Lines->Add(str);
       memo->Lines->Add(" ");
    }
}

TMixConc& TMixConc::operator=(TMixConc &mc)
{
     (*this).isExist = mc.isExist;
     (*this).Origin = mc.Origin;
     (*this).Height = mc.Height;
     return (*this);
}

//---------------------------------------------------------------------------
//  ������
//---------------------------------------------------------------------------
void TSelectLayer::GetInformation(TObject *Sender)
{
    if (isExist && String(Sender->ClassName()) == String("TMemo")) {
       TMemo *memo=(TMemo*)Sender;
       char str[256];
       memo->Lines->Add("������");
       memo->Lines->Add("-----------------------------------");
       sprintf(str,"�β� : %4.2f m",Height);
       memo->Lines->Add(str);
       memo->Lines->Add(" ");
    }
}

TSelectLayer & TSelectLayer::operator=(TSelectLayer &sl)
{
     (*this).isExist = sl.isExist;
     (*this).Origin = sl.Origin;
     (*this).Height = sl.Height;
     return (*this);
}

//---------------------------------------------------------------------------
//  �����Ѱ� �𼭸�
//---------------------------------------------------------------------------
void TCorner::GetInformation(TObject *Sender)
{
    if (isExist && String(Sender->ClassName()) == String("TMemo")) {
       TMemo *memo=(TMemo*)Sender;
       char str[256];
       memo->Lines->Add("�����Ѱ�𼭸�");
       memo->Lines->Add("-----------------------------------");
       sprintf(str,"���� : %4.2f m",Height);
       memo->Lines->Add(str);
       sprintf(str,"���� : %4.2f m",Width);
       memo->Lines->Add(str);
       memo->Lines->Add(" ");
    }
}

TCorner & TCorner::operator=(TCorner &con)
{
     (*this).isExist = con.isExist;
     (*this).Height = con.Height;
     (*this).Width = con.Width;
     return (*this);
}

//---------------------------------------------------------------------------
//  �ð�����
//---------------------------------------------------------------------------
void TConstMargin::GetInformation(TObject *Sender)
{
    if (isExist && String(Sender->ClassName()) == String("TMemo")) {
       TMemo *memo=(TMemo*)Sender;
       char str[256];
       memo->Lines->Add("�ð�����");
       memo->Lines->Add("-----------------------------------");
       sprintf(str,"�����Ѱ� : %4.2f m",ConstLimit);
       memo->Lines->Add(str);
       sprintf(str,"�˻����� : %4.2f m",InspectWay);
       memo->Lines->Add(str);
       memo->Lines->Add(" ");
    }
}

TConstMargin& TConstMargin::operator=(TConstMargin &cm)
{
     (*this).isExist = cm.isExist;
     (*this).ConstLimit = cm.ConstLimit;
     (*this).InspectWay = cm.InspectWay;
     (*this).LeftCLCircle = cm.LeftCLCircle;
     (*this).RightCLCircle = cm.RightCLCircle;
     (*this).LeftIWCircle = cm.LeftIWCircle;
     (*this).RightIWCircle = cm.RightIWCircle;
     return (*this);
}

void TConstMargin::Draw(TObject *Sender)
{
     for (int i = 0; i< Circles.GetSize();i++)
         Circles[i].Draw(Sender);
}

//---------------------------------------------------------------------------
//  ��������
//---------------------------------------------------------------------------
void TSideMarginWidth::GetInformation(TObject *Sender)
{
    if (isExist && String(Sender->ClassName()) == String("TMemo")) {
       TMemo *memo=(TMemo*)Sender;
       char str[256];
       if (Side == sLeft)
          memo->Lines->Add("���� ���濩����");
       else if (Side == sRight)
          memo->Lines->Add("���� ���濩����");

       memo->Lines->Add("-----------------------------------");
       sprintf(str,"�β� : %4.2f m",Width);
       memo->Lines->Add(str);
       memo->Lines->Add(" ");
    }
}

TSideMarginWidth & TSideMarginWidth::operator=(TSideMarginWidth &smw)
{
     (*this).isExist = smw.isExist;
     (*this).Width = smw.Width;
     return (*this);
}
//---------------------------------------------------------
//  �ι�Ʈ
//---------------------------------------------------------
void TInvert::GetInformation(TObject *Sender)
{
    if (isExist && String(Sender->ClassName()) == String("TMemo")) {
       TMemo *memo=(TMemo*)Sender;
       memo->Lines->Add("�ι�Ʈ");
       memo->Lines->Add("-----------------------------------");
       if(isInstall) memo->Lines->Add("��ġ��");
       else memo->Lines->Add("��ġ����");
    }
}

//---------------------------------------------------------------------------
//  �����Ѱ�
//---------------------------------------------------------------------------
__fastcall TConstLimit::TConstLimit()
{
     isMade = false;
     LeftGuideStone.SetSide(sLeft),RightGuideStone.SetSide(sRight);
     LeftSideMarginWidth.SetSide(sLeft),RightSideMarginWidth.SetSide(sRight);
     LeftDrainage.SetSide(sLeft),RightDrainage.SetSide(sRight);
     LeftCheukDae.SetSide(sLeft),RightCheukDae.SetSide(sRight);
     LeftGongDongGu.SetSide(sLeft),RightGongDongGu.SetSide(sRight);
     LeftTHP.SetSide(sLeft), RightTHP.SetSide(sRight);
     LeftSteelPipe.SetSide(sLeft),RightSteelPipe.SetSide(sRight);
}

void TConstLimit::Init(TRoad &r)
{
     Road = r;
     Road.isExist = true;
}

void TConstLimit::Init(TSide side, TGuideStone &gs)
{
  if (side == sLeft) {
     LeftGuideStone=gs;
     LeftGuideStone.isExist = true;
  }
  else if (side == sRight) {
     RightGuideStone = gs;
     RightGuideStone.isExist = true;
  }
}

void TConstLimit::Init(TInspectWay &iw)
{
     InspectWay = iw;
     InspectWay.isExist = true;
}

void TConstLimit::Init(TConstMargin &cm)
{
     ConstMargin = cm;
     ConstMargin.isExist = true;
}

void TConstLimit::Init(TSide side, TSideMarginWidth &smw)
{
  if (side == sLeft) {
     LeftSideMarginWidth = smw;
     LeftSideMarginWidth.isExist = true;
  }
  else if (side == sRight) {
     RightSideMarginWidth = smw;
     RightSideMarginWidth.isExist = true;
  }
}

void TConstLimit::Init(TSide side, TDrainage &d)
{
  if (side == sLeft) {
     LeftDrainage = d;
     LeftDrainage.isExist = true;
  }
  else if (side == sRight) {
     RightDrainage = d;
     RightDrainage.isExist = true;
  }
}

void TConstLimit::Init(TSide side, TCheukDae &cd)
{
  if (side == sLeft) {
     LeftCheukDae = cd;
     LeftCheukDae.isExist = true;
  }
  else if (side == sRight) {
     RightCheukDae = cd;
     RightCheukDae.isExist = true;
  }
}

void TConstLimit::Init(TSide side, TGongDongGu &gdg)
{
  if (side == sLeft) {
     LeftGongDongGu = gdg;
     LeftGongDongGu.isExist = true;
  }
  else if (side == sRight) {
     RightGongDongGu = gdg;
     RightGongDongGu.isExist = true;
  }
}

void TConstLimit::Init(TSide side, TTHP &thp)
{
  if (side == sLeft) {
     LeftTHP = thp;
     LeftTHP.isExist = true;
  }
  else if (side == sRight) {
     RightTHP = thp;
     RightTHP.isExist = true;
  }
}

void TConstLimit::Init(TSide side, TSteelPipe &sp)
{
  if (side == sLeft) {
     LeftSteelPipe = sp;
     LeftSteelPipe.isExist = true;
  }
  else if (side == sRight) {
     RightSteelPipe = sp;
     RightSteelPipe.isExist = true;
  }
}

void TConstLimit::Init(TPaveConc &pc)
{
   PaveConc = pc;
}

void TConstLimit::Init(TMixConc &mc)
{
   MixConc = mc;
}

void TConstLimit::Init(TSelectLayer &sl)
{
   SelectLayer = sl;
}

void TConstLimit::Init(TInvert &iv)
{
   Invert = iv;
}

void TConstLimit::InitShotcreteThickness(float st)
{
     ShotcreteThickness = st;
}

void TConstLimit::Disable(TRoad &r)
{
     Road.isExist = false;
}

void TConstLimit::Disable(TSide side, TGuideStone &gs)
{
  if (side == sLeft) {
     LeftGuideStone.isExist = false;
  }
  else if (side == sRight) {
     RightGuideStone.isExist = false;
  }
}
void TConstLimit::Disable(TInspectWay &iw)
{
    InspectWay.isExist = false;
}
void TConstLimit::Disable(TConstMargin &cm)
{
    ConstMargin.isExist = false;
}
void TConstLimit::Disable(TSide side, TSideMarginWidth &smw)
{
  if (side == sLeft) {
     LeftSideMarginWidth.isExist = false;
  }
  else if (side == sRight) {
     RightSideMarginWidth.isExist = false;
  }
}
void TConstLimit::Disable(TSide side, TDrainage &d)
{
  if (side == sLeft) LeftDrainage.isExist = false;
  else if (side == sRight) RightDrainage.isExist = false;
}
void TConstLimit::Disable(TSide side, TCheukDae &cd)
{
  if (side == sLeft) LeftCheukDae.isExist = false;
  else if (side == sRight) RightCheukDae.isExist = false;
}
void TConstLimit::Disable(TSide side, TGongDongGu &gdg)
{
  if (side == sLeft) LeftGongDongGu.isExist = false;
  else if (side == sRight) RightGongDongGu.isExist = false;
}

void TConstLimit::Enable(TRoad &r)
{
    Road.isExist = true;
}

void TConstLimit::Enable(TSide side, TGuideStone &gs)
{
  if (side == sLeft) {
     LeftGuideStone.isExist = true;
  }
  else if (side == sRight) {
     RightGuideStone.isExist = true;
  }
}
void TConstLimit::Enable(TInspectWay &iw)
{
    InspectWay.isExist = true;
}
void TConstLimit::Enable(TConstMargin &cm)
{
    ConstMargin.isExist = true;
}
void TConstLimit::Enable(TSide side, TSideMarginWidth &smw)
{
  if (side == sLeft) {
     LeftSideMarginWidth.isExist = true;
  }
  else if (side == sRight) {
     RightSideMarginWidth.isExist = true;
  }
}
void TConstLimit::Enable(TSide side, TDrainage &d)
{
  if (side == sLeft) {
     LeftDrainage.isExist = true;
  }
  else if (side == sRight) {
     RightDrainage.isExist = true;
  }
}
void TConstLimit::Enable(TSide side, TCheukDae &cd)
{
  if (side == sLeft) {
     LeftCheukDae.isExist = true;
  }
  else if (side == sRight) {
     RightCheukDae.isExist = true;
  }
}
void TConstLimit::Enable(TSide side, TGongDongGu &gdg)
{
  if (side == sLeft) {
     LeftGongDongGu.isExist = true;
  }
  else if (side == sRight) {
     RightGongDongGu.isExist = true;
  }
}
bool TConstLimit::CanMakeConstLimit()
{
     if ((!Road.isExist ||
          !LeftCheukDae.isExist ||
          !RightCheukDae.isExist ||
          !LeftSideMarginWidth.isExist ||
          !RightSideMarginWidth.isExist ||
          !LeftDrainage.isExist ||
          !RightDrainage.isExist ||
          !ConstMargin.isExist ||
          !Corner.isExist||
          !Height ) ||
         (!LeftGongDongGu.isExist && !LeftGuideStone.isExist) ||
         (!RightGongDongGu.isExist && !RightGuideStone.isExist)
     ) return false; // �Է°��� ������ ����
     else return true;
}

bool TConstLimit::MakeConstLimit()
{
     int N=0; // �ʿ��� ���� ��

//   ����� ���������� �귯���� �ϴ� ���� +��, �������� �귯����
//   ���� ���� -�� �����Ѵ�.

     if (!CanMakeConstLimit()) return false;

     SetCloseness(true);
     SetColor(clBlue);

     Road.MakePolygon();
     LeftCheukDae.MakePolygon();
     RightCheukDae.MakePolygon();
     LeftDrainage.MakePolygon();
     RightDrainage.MakePolygon();
     LeftGuideStone.MakePolygon();
     RightGuideStone.MakePolygon();
     LeftGongDongGu.MakePolygon();
     RightGongDongGu.MakePolygon();

     // ���� �����Ѱ谡 ������ ��ġ�� ���
     if (LeftCheukDae.GetWidth() > LeftSideMarginWidth.GetWidth()) {
          N+=2;
     }
     // ���� �����Ѱ谡 ����� ������� ������ ���
     else if (fabs(LeftCheukDae.GetWidth() - LeftSideMarginWidth.GetWidth()) < 1.0e-5) {
          N+=2;
     }
     // ���� �����Ѱ谡 ����� ���� ��ġ�� ���
     else if (LeftCheukDae.GetWidth() + LeftDrainage.GetWidth()
          > LeftSideMarginWidth.GetWidth()) {
          N+=3;
     }
     // ���� �����Ѱ谡 ������ �𼭸��� ���
     else if (fabs(LeftCheukDae.GetWidth() + LeftDrainage.GetWidth()
                  - LeftSideMarginWidth.GetWidth())
               < 1.0e-5) {
          N+=4;
     }
     // ���� �����Ѱ谡 �������� ��ġ�� ���
     else if (LeftCheukDae.GetWidth() + LeftDrainage.GetWidth()
             +LeftGuideStone.GetWidth() > LeftSideMarginWidth.GetWidth()) {
          N+=5;
     }
     // ���� �����Ѱ谡 �������𼭸��� ��ġ�� ���
     else if (fabs(LeftCheukDae.GetWidth() + LeftDrainage.GetWidth()
                  +LeftGuideStone.GetWidth()
                  -LeftSideMarginWidth.GetWidth())
               <1.0e-5) {
          N+=6;
     }
     // ���� �����Ѱ谡 ������ ���� ��ġ�� ���
     else if (LeftCheukDae.GetWidth() + LeftDrainage.GetWidth()
             +LeftGuideStone.GetWidth()+ LeftGongDongGu.GetWidth()
             > LeftSideMarginWidth.GetWidth()) {
          N+=7;
     }
     // ���� �����Ѱ谡 �ͳ� ������ ���� ��� : ���� �߻�.
     else throw;

     N+=Road.Number;
//     N++; // �ͳ� �߽ɼ�
     N++; // ���� �߽ɼ�

     // ���� �����Ѱ谡 ������ ��ġ�� ���
     if (RightCheukDae.GetWidth() > RightSideMarginWidth.GetWidth()) {
          N+=2;
     }

     // ���� �����Ѱ谡 ����� ���� ��ġ�� ���
     else if (RightCheukDae.GetWidth() + RightDrainage.GetWidth()
          > RightSideMarginWidth.GetWidth()) {
          N+=3;
     }
     // ���� �����Ѱ谡 ������ �𼭸��� ���
     else if (fabs(RightCheukDae.GetWidth() + RightDrainage.GetWidth()
          - RightSideMarginWidth.GetWidth()) < 1.0e-5) {
          N+=4;
     }
     // ���� �����Ѱ谡 �������� ��ġ�� ���
     else if (RightCheukDae.GetWidth() + RightDrainage.GetWidth()
          > RightSideMarginWidth.GetWidth()) {
          N+=5;
     }
     // ���� �����Ѱ谡 �������𼭸��� ��ġ�� ���
     else if (fabs(RightCheukDae.GetWidth() + RightDrainage.GetWidth()+RightGuideStone.GetWidth()
               - RightSideMarginWidth.GetWidth())<1.0e-5) {
          N+=6;
     }
     // ���� �����Ѱ谡 ������ ���� ��ġ�� ���
     else if (RightCheukDae.GetWidth() + RightDrainage.GetWidth()+RightGuideStone.GetWidth()
               > RightSideMarginWidth.GetWidth()) {
          N+=7;
     }
     // ���� �����Ѱ谡 �ͳ� ������ ���� ��� : ���� �߻�.
     else {
          ShowMessage("Error Occurred: Right Construction Limit ");
          return false;
     }

     N+=4;  // �����Ѱ� ��� 4���� ��
     if (InspectWay.isExist) N+=3;   // �˻�� ��ΰ� �ִ� ���
// ��� ����    if (!LeftGuideStone.isExist) N-=2;  // ���� ������ ���� ���
// ��� ����    if (!RightGuideStone.isExist) N-=2; // ���� ������ ���� ���
     Initialize(N); // +1�� �������� �ۼ��� ��

     N=0;

     // ���� �����Ѱ谡 ������ ��ġ�� ���, 2 point
     if (LeftCheukDae.GetWidth() > LeftSideMarginWidth.GetWidth()) {
         (*this)[N].X = LeftCheukDae[0].X
                        + LeftCheukDae.GetWidth()
                        - LeftSideMarginWidth.GetWidth();
         (*this)[N++].Y = LeftCheukDae[1].Y+LeftSideMarginWidth.GetWidth()*tan(LeftCheukDae.SlopeAng);
         (*this)[N].X = LeftCheukDae[1].X;
         (*this)[N++].Y = LeftCheukDae[1].Y;
     }
     // ���� �����Ѱ谡 ����� ���� ��ġ�� ���, 3 point
     else if (LeftCheukDae.GetWidth() + LeftDrainage.GetWidth()
          > LeftSideMarginWidth.GetWidth()) {
         (*this)[N++].X = LeftDrainage[0].X
                        + LeftDrainage.GetWidth()
                        + LeftCheukDae.GetWidth()
                        - LeftSideMarginWidth.GetWidth();
         (*this)[N++].Y = LeftDrainage[1].Y-(LeftSideMarginWidth.GetWidth()
                          +LeftCheukDae.GetWidth())*tan(LeftCheukDae.SlopeAng);
         (*this)[N].X = LeftDrainage[1].X;
         (*this)[N++].Y = LeftDrainage[1].Y;
         (*this)[N].X = LeftCheukDae[1].X;
         (*this)[N++].Y = LeftCheukDae[1].Y;
     }
     // ���� �����Ѱ谡 ������ �𼭸��� ���, 4 point
     else if (fabs(LeftCheukDae.GetWidth() + LeftDrainage.GetWidth()
                  - LeftSideMarginWidth.GetWidth())
               < 1.0e-5) {
         (*this)[N].X = LeftGuideStone[1].X;
         (*this)[N++].Y = LeftGuideStone[1].Y;
         (*this)[N].X = LeftGuideStone[2].X;
         (*this)[N++].Y = LeftGuideStone[2].Y;
         (*this)[N].X = LeftDrainage[1].X;
         (*this)[N++].Y = LeftDrainage[1].Y;
         (*this)[N].X = LeftCheukDae[1].X;
         (*this)[N++].Y = LeftCheukDae[1].Y;
     }
     // ���� �����Ѱ谡 �������� ��ġ�� ���, 5 point
     else if (LeftCheukDae.GetWidth() + LeftDrainage.GetWidth()
             +LeftGuideStone.GetWidth() > LeftSideMarginWidth.GetWidth()) {
         (*this)[N].X = LeftGuideStone[0].X+
                        + LeftGuideStone.GetWidth()
                        + LeftDrainage.GetWidth()
                        + LeftCheukDae.GetWidth()
                        - LeftSideMarginWidth.GetWidth();
         (*this)[N++].Y = LeftGuideStone[0].Y;
         (*this)[N].X = LeftGuideStone[1].X;
         (*this)[N++].Y = LeftGuideStone[1].Y;
         (*this)[N].X = LeftGuideStone[2].X;
         (*this)[N++].Y = LeftGuideStone[2].Y;
         (*this)[N].X = LeftDrainage[1].X;
         (*this)[N++].Y = LeftDrainage[1].Y;
         (*this)[N].X = LeftCheukDae[1].X;
         (*this)[N++].Y = LeftCheukDae[1].Y;
     }
     // ���� �����Ѱ谡 �������𼭸��� ��ġ�� ���, 6point
     else if (fabs(LeftCheukDae.GetWidth() + LeftDrainage.GetWidth()
                  +LeftGuideStone.GetWidth()
                  -LeftSideMarginWidth.GetWidth())
               <1.0e-5) {

         (*this)[N++] = LeftGongDongGu.Polygon[1];
         (*this)[N++] = LeftGongDongGu.Polygon[2];
         (*this)[N++] = LeftGuideStone.Polygon[1];
         (*this)[N++] = LeftGuideStone.Polygon[2];
         (*this)[N++] = LeftDrainage.Polygon[1];
         (*this)[N++] = LeftCheukDae.Polygon[1];
     }
     // ���� �����Ѱ谡 ������ ���� ��ġ�� ���, 7point
     else if (LeftCheukDae.GetWidth() + LeftDrainage.GetWidth()
             +LeftGuideStone.GetWidth()+ LeftGongDongGu.GetWidth()
             > LeftSideMarginWidth.GetWidth()) {
         (*this)[N].X = LeftGongDongGu[0].X
                        + LeftGongDongGu.GetWidth()
                        + LeftGuideStone.GetWidth()
                        + LeftDrainage.GetWidth()
                        + LeftCheukDae.GetWidth()
                        - LeftSideMarginWidth.GetWidth();
         (*this)[N++].Y = LeftGongDongGu[0].Y;
         (*this)[N].X = LeftGongDongGu[1].X;
         (*this)[N++].Y = LeftGongDongGu[1].Y;
         (*this)[N].X = LeftGuideStone[0].X;
         (*this)[N++].Y = LeftGuideStone[0].Y;
         (*this)[N].X = LeftGuideStone[1].X;
         (*this)[N++].Y = LeftGuideStone[1].Y;
         (*this)[N].X = LeftGuideStone[2].X;
         (*this)[N++].Y = LeftGuideStone[2].Y;
         (*this)[N].X = LeftDrainage[1].X;
         (*this)[N++].Y = LeftDrainage[1].Y;
         (*this)[N].X = LeftCheukDae[1].X;
         (*this)[N++].Y = LeftCheukDae[1].Y;
     }
     // ���� �����Ѱ谡 �ͳ� ������ ���� ��� : ���� �߻�.
     else {
          ShowMessage("Error Occurred: Left Construction Limit ");
          return false;
     }

     if (Road[pRoadCenter].X < Road[pTunnelCenter].X) {
        (*this)[N].X = Road[pRoadCenter].X;
        (*this)[N++].Y = Road[pRoadCenter].Y;
        (*this)[N].X = Road[pTunnelCenter].X;
        (*this)[N++].Y = Road[pTunnelCenter].Y;
     }
     else if (Road[pRoadCenter].X > Road[pTunnelCenter].X) {
        (*this)[N].X = Road[pTunnelCenter].X;
        (*this)[N++].Y = Road[pTunnelCenter].Y;
        (*this)[N].X = Road[pRoadCenter].X;
        (*this)[N++].Y = Road[pRoadCenter].Y;
     }
     (*this)[N].X = Road[pEndPoint].X;
     (*this)[N++].Y = Road[pEndPoint].Y;

     // ���� �����Ѱ谡 ������ ��ġ�� ���, 2point
     if (RightCheukDae.GetWidth() > RightSideMarginWidth.GetWidth()) {
         (*this)[N].X = RightCheukDae[0].X;
         (*this)[N++].Y = RightCheukDae[0].Y;
         (*this)[N].X = RightCheukDae[0].X
                        + RightSideMarginWidth.GetWidth();
         (*this)[N++].Y = RightCheukDae[0].Y + RightSideMarginWidth.GetWidth()*tan(RightCheukDae.SlopeAng);
     }

     // ���� �����Ѱ谡 ����� ���� ��ġ�� ���, 3point
     else if (RightCheukDae.GetWidth() + RightDrainage.GetWidth()
          > RightSideMarginWidth.GetWidth()) {
         (*this)[N].X = RightCheukDae[0].X;
         (*this)[N++].Y = RightCheukDae[0].Y;
         (*this)[N].X = RightDrainage[0].X;
         (*this)[N++].Y = RightDrainage[0].Y;
         (*this)[N].X = RightCheukDae[0].X
                        + RightSideMarginWidth.GetWidth();
         (*this)[N++].Y = RightDrainage[0].Y - (RightSideMarginWidth.GetWidth()
                        + RightCheukDae.GetWidth())*tan(RightCheukDae.SlopeAng);
     }
     // ���� �����Ѱ谡 ������ �𼭸��� ���, 4point
     else if (fabs(RightCheukDae.GetWidth() + RightDrainage.GetWidth()
          - RightSideMarginWidth.GetWidth()) < 1.0e-5) {
         (*this)[N].X = RightCheukDae[0].X;
         (*this)[N++].Y = RightCheukDae[0].Y;
         (*this)[N].X = RightDrainage[0].X;
         (*this)[N++].Y = RightDrainage[0].Y;
         (*this)[N].X = RightGuideStone[0].X;
         (*this)[N++].Y = RightGuideStone[0].Y;
         (*this)[N].X = RightGuideStone[1].X;
         (*this)[N++].Y = RightGuideStone[1].Y;
     }
     // ���� �����Ѱ谡 �������� ��ġ�� ���, 5point
     else if (RightCheukDae.GetWidth() + RightDrainage.GetWidth()
          > RightSideMarginWidth.GetWidth()) {
         (*this)[N].X = RightCheukDae[0].X;
         (*this)[N++].Y = RightCheukDae[0].Y;
         (*this)[N].X = RightDrainage[0].X;
         (*this)[N++].Y = RightDrainage[0].Y;
         (*this)[N].X = RightGuideStone[0].X;
         (*this)[N++].Y = RightGuideStone[0].Y;
         (*this)[N].X = RightGuideStone[1].X;
         (*this)[N++].Y = RightGuideStone[1].Y;
         (*this)[N].X = RightCheukDae[1].X
                        + RightSideMarginWidth.GetWidth();
         (*this)[N++].Y = RightGuideStone[1].Y;
     }
     // ���� �����Ѱ谡 �������𼭸��� ��ġ�� ���, 6point
     else if (fabs(RightCheukDae.GetWidth() + RightDrainage.GetWidth()+RightGuideStone.GetWidth()
               - RightSideMarginWidth.GetWidth())<1.0e-5) {
         (*this)[N++] = RightCheukDae.Polygon[0];
         (*this)[N++] = RightDrainage.Polygon[0];
         (*this)[N++] = RightGuideStone.Polygon[0];
         (*this)[N++] = RightGuideStone.Polygon[1];
         (*this)[N++] = RightGongDongGu.Polygon[0];
         (*this)[N++] = RightGongDongGu.Polygon[1];

     }
     // ���� �����Ѱ谡 ������ ���� ��ġ�� ���, 7point
     else if (RightCheukDae.GetWidth() + RightDrainage.GetWidth()+RightGuideStone.GetWidth()
               > RightSideMarginWidth.GetWidth()) {
         (*this)[N++] = RightCheukDae.Polygon[0];
         (*this)[N++] = RightDrainage.Polygon[0];
         (*this)[N++] = RightGuideStone.Polygon[0];
         (*this)[N++] = RightGuideStone.Polygon[1];
         (*this)[N++] = RightGongDongGu.Polygon[0];
         (*this)[N++] = RightGongDongGu.Polygon[1];
         (*this)[N++] = RightGongDongGu.Polygon[1];
     }
     // ���� �����Ѱ谡 �ͳ� ������ ���� ��� : ���� �߻�.
     else {
          ShowMessage("Error Occurred: Right Construction Limit 2nd phase.");
          return false;
     }

     // ���� �ڵ�� ���谡 2�� ���� ����� ������ 2�� �ƴ� ���±��踦 �����ؾ� �Ѵ�.
     // �����Ѱ� �𼭸��� ����� ��Ȯ�ϰ� �ԷµǴ� ����� �ڼ��� ����...

     if (Road.Slope == 2) {

        if (InspectWay.isExist)
           ConstMargin.Circles.Initialize(5);
        else
           ConstMargin.Circles.Initialize(4);
        if (InspectWay.isExist) {
           InsPoint[0].X = (*this)[N].X = (*this)[N-1].X + InspectWay.GetWidth();
           InsPoint[0].Y = (*this)[N].Y = (*this)[N-1].Y; N++;
           InsPoint[1].X = (*this)[N].X = (*this)[N-1].X;
           InsPoint[1].Y = (*this)[N].Y = (*this)[N-1].Y + InspectWay.GetHeight(); N++;
           (*this)[N].X = (*this)[N-1].X - InspectWay.GetWidth();
           (*this)[N].Y = (*this)[N-1].Y; N++;
           ConstMargin.Circles[4].SetCircle(InsPoint[1],ConstMargin.InspectWay,clRed);
        }
        CilPoint[0].X = (*this)[N].X = (*this)[N-1].X;
        CilPoint[0].Y = (*this)[N].Y = Height - Corner.Height ; N++;
        CilPoint[1].X = (*this)[N].X = (*this)[N-1].X-Corner.Width;
        CilPoint[1].Y = (*this)[N].Y = Height+(*this)[N].X*tan(Road.SlopeAng); N++;
        CilPoint[2].X = (*this)[N].X = 0;
        CilPoint[2].Y = (*this)[N].Y = Height; N++;
        CilPoint[3].X = (*this)[N].X = -Corner.Width;
        CilPoint[3].Y = (*this)[N].Y = Height - Corner.Height ; N++;
        for (int i=0;i<4;i++){
            ConstMargin.Circles[i].SetCircle(CilPoint[i],ConstMargin.ConstLimit,clRed);
        }

        RightControlPoint = RightGongDongGu.Polygon[2];
        LeftControlPoint = LeftGongDongGu.Polygon[0];
     }
     else {
        if (InspectWay.isExist)
           ConstMargin.Circles.Initialize(5);
        else
           ConstMargin.Circles.Initialize(4);

        if (InspectWay.isExist) {
           InsPoint[0].X = (*this)[N].X = (*this)[N-1].X + InspectWay.GetWidth();
           InsPoint[0].Y = (*this)[N].Y = (*this)[N-1].Y; N++;
           InsPoint[1].X = (*this)[N].X = (*this)[N-1].X;
           InsPoint[1].Y = (*this)[N].Y = (*this)[N-1].Y + InspectWay.GetHeight(); N++;
           (*this)[N].X = (*this)[N-1].X - InspectWay.GetWidth();
           (*this)[N].Y = (*this)[N-1].Y; N++;
           ConstMargin.Circles[4].SetCircle(InsPoint[0],ConstMargin.InspectWay,clRed);
        }
        CilPoint[0].X = (*this)[N].X = (*this)[N-1].X;
        CilPoint[0].Y = (*this)[N].Y = Height - Corner.Height ; N++;
        CilPoint[1].X = (*this)[N].X = (*this)[N-1].X-Corner.Width;
        CilPoint[1].Y = (*this)[N].Y = Height; N++;
        CilPoint[2].X = (*this)[N].X = 0;
        CilPoint[2].Y = (*this)[N].Y = Height; N++;
        CilPoint[3].X = (*this)[N].X = -Corner.Width;
        CilPoint[3].Y = (*this)[N].Y = Height - Corner.Height ; N++;

        for (int i=0;i<4;i++){
            ConstMargin.Circles[i].SetCircle(CilPoint[i],ConstMargin.ConstLimit,clRed);
        }

        RightControlPoint = RightGongDongGu.Polygon[2];
        LeftControlPoint = LeftGongDongGu.Polygon[0];
     }
     isMade = true;
     return true;
}

TRealPoint TConstLimit::GetCenter()
{
    TRealPoint rp;
    if (isMade) rp = TRealPoints::GetCenter();
    rp.Y = rp.Y / 2;
    return rp;
}

float TConstLimit::GetIniLen()
{
    float l=0,l2;
    float x1,y1,x2,y2;
    TRealPoint c;
    float cl,iw;
    cl = ConstMargin.ConstLimit;
    iw = ConstMargin.InspectWay;

    c = GetCenter();
    x1 = c.X;
    y1 = c.Y;

    if (isMade) {
       for (int i=0;i < 4;i++) {
          x2 = CilPoint[i].X;
          y2 = CilPoint[i].Y;
          l = l > (l2=sqrt(pow(x1-x2,2)+pow(y1-y2,2))+cl) ? l : l2;
       }
       for (int i=0;i < 2;i++) {
          x2 = InsPoint[i].X;
          y2 = InsPoint[i].Y;
          l = l > (l2=sqrt(pow(x1-x2,2)+pow(y1-y2,2))+iw) ? l : l2;
       }
       x2 = LeftControlPoint.X;
       y2 = LeftControlPoint.Y;
       l = l > (l2=sqrt(pow(x1-x2,2)+pow(y1-y2,2))+iw) ? l : l2;
       x2 = RightControlPoint.X;
       y2 = RightControlPoint.Y;
       l = l > (l2=sqrt(pow(x1-x2,2)+pow(y1-y2,2))+iw) ? l : l2;

       return l;
    }
    return 0;
}

float TConstLimit::GetIniLen(TRealPoint rp)
{
    float l=0,l2;
    float x1,y1,x2,y2;
    TRealPoint c;
    float cl,iw;
    cl = ConstMargin.ConstLimit;
    iw = ConstMargin.InspectWay;

    c = rp;
    x1 = c.X;
    y1 = c.Y;

    if (isMade) {
       for (int i=0;i < 4;i++) {
          x2 = CilPoint[i].X;
          y2 = CilPoint[i].Y;
          l = l > (l2=sqrt(pow(x1-x2,2)+pow(y1-y2,2))+cl) ? l : l2;
       }
       for (int i=0;i < 2;i++) {
          x2 = InsPoint[i].X;
          y2 = InsPoint[i].Y;
          l = l > (l2=sqrt(pow(x1-x2,2)+pow(y1-y2,2))+iw) ? l : l2;
       }
       x2 = LeftControlPoint.X;
       y2 = LeftControlPoint.Y;
       l = l > (l2=sqrt(pow(x1-x2,2)+pow(y1-y2,2))+iw) ? l : l2;
       x2 = RightControlPoint.X;
       y2 = RightControlPoint.Y;
       l = l > (l2=sqrt(pow(x1-x2,2)+pow(y1-y2,2))+iw) ? l : l2;

       return l;
    }
    return 0;
}
/*
TRealArc TConstLimit::GetLeftArc(TRealArc &ra)
{
  float x1,x2,y1,y2,x3,y3,x4,y4;
  float Len=0;
  TRealPoint CP,rp;
  TRealLine rl6,rl7;
  TRealLine EndLine,StartLine;
  bool flag=false;
 
  x1 = ra[0].X;
  y1 = ra[0].Y;
  x2 = ra[2].X;
  y2 = ra[2].Y;
  x3 = LeftControlPoint.X;   //�ϴ�, ������
  y3 = LeftControlPoint.Y;   //�ϴ�, ������

  TRealLine rl1(x1,y1,x2,y2);  // ����� ���ۼ�
  TRealLine rl2(x1,y1,x3,y3);  // ������ ����

  for (int i = 0; i < 4; i++ ) {
    x4 = CilPoint[i].X;
    y4 = CilPoint[i].Y;
    TRealLine rl3(x1,y1,x4,y4);     // �����Ѱ��� �Ϻ� ��
    if ( rl1 * rl3 > 0 && rl2 * rl3 < 0 ) {

       TRealPoint rp,EndPoint;
       TRealLine rl4(x2,y2,x4,y4); //  ����� �������� �����Ѱ���
       TRealLine rl5 = !rl4;       // �������� ������ ��
       rp = rl1 & rl5;             // ����� ���ۼ��� ������ ����(�ҿ��� �߽�)

       rl6.SetLine(rp.X,rp.Y,x2,y2);  // �ҿ��� ����
       float len = rl6.GetLength();           // �ҿ��� �ݰ�

       EndPoint.Y = y3;                // �ҿ��� ������
       if (len < fabs(y3-y1)) continue;
       EndPoint.X = rp.X + sqrt(len*len- (y3-y1)*(y3-y1) );
       rl7.SetLine(rp.X,rp.Y,EndPoint.X,EndPoint.Y); // �ҿ��� ���ۼ�

       if (Len < len) {
          Len = len;
          CP = rp;
          flag = true;
          EndLine = rl7;
          StartLine = rl6;
       }
    }
  }
  x4 = LeftControlPoint.X;
  y4 = LeftControlPoint.Y;
  TRealLine rl3(x1,y1,x4,y4);     // �����Ѱ��� �Ϻ� ��
  if ( rl1*rl2 > 0 ) {

     TRealPoint rp,EndPoint;
     TRealLine rl4(x2,y2,x4,y4); //  ����� �������� �����Ѱ���
     TRealLine rl5 = !rl4;       // �������� ������ ��
     rp = rl1 & rl5;             // ����� ���ۼ��� ������ ����(�ҿ��� �߽�)

     rl6.SetLine(rp.X,rp.Y,x2,y2);  // �ҿ��� ����
     float len = rl6.GetLength();           // �ҿ��� �ݰ�

     rl7.SetLine(rp.X,rp.Y,x4,y4); // �ҿ��� ���ۼ�
     if (Len < len) {
        Len = len;
        CP = rp;
        flag = true;
        EndLine = rl7;
        StartLine = rl6;
     }
  }
//  if (!flag) ShowMessage("Errrrrrrr~~~~~~~~~");
  if (flag) return TRealArc(CP.X, CP.Y, Len,
                            StartLine.GetTheta(),EndLine.GetTheta());
  else return TRealArc(x1,y1,Len,rl1.GetTheta(),rl1.GetTheta());

}
*/
TRealArc TConstLimit::GetLeftArc(TRealArc &ra)
{
     int i;
     TRealArc RealArc;
     TRealArc ra1(ra[2],LeftControlPoint,ra(1));
     RealArc = ra1;
     for (i=0;i<4;i++) {
         if (ra1.isWithInAng(CilPoint[i])) {
            TRealPoint Cen = CilPoint[i];
            float R = ConstMargin.ConstLimit;
            TRealCircle Circle(Cen,R);

            TRealPoints rps = Circle & ra[2];
            TRealPoint rp = rps[0].X < rps[1].X ? rps[0] : rps[1];
//            float len = TRealLine(Cen,rp).GetLength();
//            TRealArc ra2(ra[2],Cen,ra(1));
            TRealArc ra2(ra[2],rp,ra(1));
            if (RealArc.GetRadius() < ra2.GetRadius()) RealArc = ra2;
         }
     }
     for (i=0;i<2 && InspectWay.isExist;i++) {
         if (ra1.isWithInAng(InsPoint[i])) {
            TRealPoint Cen = InsPoint[i];
            float R = ConstMargin.ConstLimit;
            TRealCircle Circle(Cen,R);

            TRealPoints rps = Circle & ra[2];
            TRealPoint rp = rps[0].X < rps[1].X ? rps[0] : rps[1];
//            TRealArc ra2(ra[2],Cen,ra(1));
            TRealArc ra2(ra[2],rp,ra(1));

            if (RealArc.GetRadius() < ra2.GetRadius()) RealArc = ra2;
         }
     }

     float rr = pow(RealArc.GetRadius(),2)- pow(LeftControlPoint.Y-RealArc[0].Y,2);
     if ( rr <= 0) return NullArc;
     RealArc[2].Y = LeftControlPoint.Y;
     RealArc[2].X = RealArc[0].X - sqrt(rr);
     RealArc.ReCalcAng();

     if (RealArc.CrossProduct() > 0) return RealArc;
     else return NullArc;
}

TRealArc TConstLimit::GetRightArc(TRealArc &ra)
{
     int i;
     TRealPoints rps;
     TRealArc RealArc;
     TRealArc ra1(RightControlPoint,ra[1],ra(0));
     RealArc = ra1;
     for (i=0;i<4;i++) {
         if (ra1.isWithInAng(CilPoint[i])) {
            TRealPoint Cen = CilPoint[i];
            float R = ConstMargin.ConstLimit;
            TRealCircle Circle(Cen,R);

            rps = Circle & ra[1];

            TRealPoint rp;
            if( rps[0].X > rps[1].X ) rp = rps[0];
            else rp = rps[1];

            float len = TRealLine(Cen,rp).GetLength();
            if (rp==NullPoint) rp = Cen+TRealPoint(R,R);
            TRealArc ra2(rp,ra[1],ra(0));
            if (RealArc.GetRadius() < ra2.GetRadius()) RealArc = ra2;
         }
     }
     for (i=0;i<2 && InspectWay.isExist;i++) {
         if (ra1.isWithInAng(InsPoint[i])) {
            TRealPoint Cen = InsPoint[i];
            float R = ConstMargin.InspectWay;
            TRealCircle Circle(Cen,R);

            rps = Circle & ra[1];

            TRealPoint rp;
            if( rps[0].X > rps[1].X ) rp = rps[0];
            else rp = rps[1];
            if (rp==NullPoint) rp = Cen+TRealPoint(R,R);
            float len = TRealLine(Cen,rp).GetLength();
            TRealArc ra2(rp,ra[1],ra(0));
            if (RealArc.GetRadius() < ra2.GetRadius()) RealArc = ra2;
         }
     }

     float rr = pow(RealArc.GetRadius(),2)- pow(LeftControlPoint.Y-RealArc[0].Y,2);
     if ( rr <= 0) return NullArc;
     RealArc[1].Y = RightControlPoint.Y;
     RealArc[1].X = RealArc[0].X + sqrt(rr);
     RealArc.ReCalcAng();

     if (RealArc.CrossProduct() > 0) return RealArc;
     else return NullArc;
}

/*
TRealArc TConstLimit::GetRightArc(TRealArc &ra)
{
  float x1,x2,y1,y2,x3,y3,x4,y4,x5,y5;
  float Len=0,len=0,len1,len2;
  TRealPoint CP,rp;
  TRealLine rl6,rl7;
  TRealLine StartLine,EndLine;
  bool flag=false;
  int isAnyLonger=0,DoIPass = 0;
  int i;

  x1 = ra[0].X;             // ����� �߽��� - x
  y1 = ra[0].Y;             // ����� �߽��� - y
  x2 = ra[1].X;             // ����� ������ - x
  y2 = ra[1].Y;             // ����� ������ - y
  x3 = RightControlPoint.X;   //�ϴ�, ������
  y3 = RightControlPoint.Y;   //�ϴ�, ������

  TRealLine rl1(x1,y1,x2,y2);  // ����� ���ۼ�
  TRealLine rl2(x1,y1,x3,y3);  // ������ ����

  if ( rl2 * rl1 < 0 ) {
     return NullArc;
  }
  else {
     TRealPoint EndPoint;
     TRealLine rl4(x2,y2,x3,y3); //  ����� �������� �����Ѱ���
     TRealLine rl5 = !rl4;       // �������� ������ ��
     rp = rl1 & rl5;             // ����� ���ۼ��� ������ ����(�ҿ��� �߽�)

     rl6.SetLine(rp.X,rp.Y,x2,y2);  // �ҿ��� ����
     rl7.SetLine(rp.X,rp.Y,x3,y3); // �ҿ��� ���ۼ�

     len1 = rl6.GetLength();           // �ҿ��� �ݰ�
     len2 = rl7.GetLength();

     Len = len1;
     CP = rp;
     flag = true;
     StartLine = rl7;
     EndLine = rl6;
     if (CP == NullPoint) return TRealArc(CP.X, CP.Y, Len,
                                 StartLine.GetTheta(),EndLine.GetTheta());
  }

  x5 = rp.X;
  y5 = rp.Y;

  if (InspectWay.isExist) {
     for (i=0;i<2;i++) {
       x4 = InsPoint[i].X;
       y4 = InsPoint[i].Y;
       TRealLine rl3(x1,y1,x4,y4);     // �����Ѱ��� �Ϻ� ��
       if ( rl1 * rl3 < 0 && rl2 * rl3 > 0) {
         len = sqrt((x5-x4)*(x5-x4)+(y5-y4)*(y5-y4));
         if (len > Len) {
             isAnyLonger = i+1;
             Len = len;
         }
       }
     }
  }

  for (i = 0;i < 4;i++) {
    x4 = CilPoint[i].X;
    y4 = CilPoint[i].Y;
    TRealLine rl3(x1,y1,x4,y4);     // �����Ѱ��� �Ϻ� ��
    if ( rl1 * rl3 < 0 && rl2 * rl3 > 0) {
      len = sqrt((x5-x4)*(x5-x4)+(y5-y4)*(y5-y4));
      if (len > Len) {
         isAnyLonger = i+3;
         Len = len;
      }
    }
  }

  Len = len1; //Right Control point �� ������� �ҿ��� �ݰ�

  if (InspectWay.isExist) {
    for (i = 0; i < 2; i++ ) {
      x4 = InsPoint[i].X;
      y4 = InsPoint[i].Y;
      TRealLine rl3(x1,y1,x4,y4);     // �����Ѱ��� �Ϻ� ��
      bool isWithIn = rl1 * rl3 < 0 && rl2 * rl3 > 0;
      if ( isWithIn ) {
         TRealPoint EndPoint;
         TRealLine rl4(x2,y2,x4,y4); //  ����� �������� �����Ѱ���
         TRealLine rl5 = !rl4;       // �������� ������ ��
         rp = rl1 & rl5;             // ����� ���ۼ��� ������ ����(�ҿ��� �߽�)

         rl6.SetLine(rp.X,rp.Y,x2,y2);  // �ҿ��� ����
         len = rl6.GetLength();           // �ҿ��� �ݰ�

         EndPoint.Y = y3;                // �ҿ��� ������
         if (len < fabs(y3-y1)) continue;  // �ҿ��� right control point level�� ��ġ�� ���ϴ� ���
         if (len < fabs(rp.Y-y3)) continue;
         EndPoint.X = rp.X + sqrt(len*len - (y3-rp.Y)*(y3-rp.Y) );
         rl7.SetLine(rp.X,rp.Y,EndPoint.X,EndPoint.Y); // �ҿ��� ���ۼ�

         if (Len < len) {
            Len = len;
            CP = rp;
            flag = true;
            DoIPass = i+1;
            StartLine = rl7;
            EndLine = rl6;
         }
      }
    }
  }

  for (i = 0; i < 4; i++ ) {
    x4 = CilPoint[i].X;
    y4 = CilPoint[i].Y;
    TRealLine rl3(x1,y1,x4,y4);     // �����Ѱ��� �Ϻ� ��
    bool isWithIn = rl1 * rl3 < 0 && rl2 * rl3 > 0;
    if ( isWithIn ) {

       TRealPoint EndPoint;
       TRealLine rl4(x2,y2,x4,y4); //  ����� �������� �����Ѱ���
       TRealLine rl5 = !rl4;       // �������� ������ ��
       rp = rl1 & rl5;             // ����� ���ۼ��� ������ ����(�ҿ��� �߽�)

       rl6.SetLine(rp.X,rp.Y,x2,y2);  // �ҿ��� ����
       len = rl6.GetLength();           // �ҿ��� �ݰ�

       EndPoint.Y = y3;                // �ҿ��� ������
       if (len < fabs(y3-y1)) continue;
       if (len < fabs(rp.Y-y3)) continue;
       EndPoint.X = rp.X + sqrt(len*len - (y3-rp.Y)*(y3-rp.Y) );
       rl7.SetLine(rp.X,rp.Y,EndPoint.X,EndPoint.Y); // �ҿ��� ���ۼ�

       if (Len < len) {
          Len = len;
          CP = rp;
          flag = true;
          DoIPass = i+3;
          StartLine = rl7;
          EndLine = rl6;
       }
    }
  }
//  if (!flag) ShowMessage("Errrrrrrr~~~~~~~~~");
  if (isAnyLonger != DoIPass) {
     return NullArc;
  }
  if (isAnyLonger == DoIPass && isAnyLonger) {
     int d = 1;
     d = d;
  }

  if (flag) return TRealArc(CP.X, CP.Y, Len,
                            StartLine.GetTheta(),EndLine.GetTheta());
  else return TRealArc(x1,y1,Len,rl1.GetTheta(),rl1.GetTheta());
}
*/

void TConstLimit::GetInformation(TObject *Sender)
{
    if (String(Sender->ClassName()) == String("TMemo")) {
       TMemo *memo=(TMemo*)Sender;
       Road.GetInformation(Sender);
       LeftGuideStone.GetInformation(Sender);
       RightGuideStone.GetInformation(Sender);
       InspectWay.GetInformation(Sender);
       ConstMargin.GetInformation(Sender);
       LeftSideMarginWidth.GetInformation(Sender);
       RightSideMarginWidth.GetInformation(Sender);
       LeftDrainage.GetInformation(Sender);
       RightDrainage.GetInformation(Sender);
       LeftCheukDae.GetInformation(Sender);
       RightCheukDae.GetInformation(Sender);
       LeftGongDongGu.GetInformation(Sender);
       RightGongDongGu.GetInformation(Sender);
       LeftTHP.GetInformation(Sender);
       RightTHP.GetInformation(Sender);
       LeftSteelPipe.GetInformation(Sender);
       RightSteelPipe.GetInformation(Sender);
       PaveConc.GetInformation(Sender);
       MixConc.GetInformation(Sender);
       SelectLayer.GetInformation(Sender);
       Invert.GetInformation(Sender);
       Corner.GetInformation(Sender);
    }
}

void TConstLimit::Draw(TObject *Sender)
{
     ConstMargin.Draw(Sender);
     TRealPolygon::Draw(Sender);
}

TConstLimit & TConstLimit::operator=(TConstLimit & cl)
{
     (*this).TRealPoints::operator=(cl);
     this->isMade = cl.isMade;
     this->Road = cl.Road;
     this->LeftGuideStone = cl.LeftGuideStone;
     this->RightGuideStone = cl.RightGuideStone;
     this->InspectWay = cl.InspectWay;
     this->ConstMargin = cl.ConstMargin;
     this->LeftSideMarginWidth = cl.LeftSideMarginWidth;
     this->RightSideMarginWidth = cl.RightSideMarginWidth;
     this->LeftDrainage = cl.LeftDrainage;
     this->RightDrainage = cl.RightDrainage;
     this->LeftCheukDae = cl.LeftCheukDae;
     this->RightCheukDae = cl.RightCheukDae;
     this->LeftGongDongGu = cl.LeftGongDongGu;
     this->RightGongDongGu = cl.RightGongDongGu;
     this->LeftTHP = cl.LeftTHP;
     this->RightTHP = cl.RightTHP;
     this->LeftSteelPipe = cl.LeftSteelPipe;
     this->RightSteelPipe = cl.RightSteelPipe;
     this->PaveConc = cl.PaveConc;
     this->MixConc = cl.MixConc;
     this->SelectLayer = cl.SelectLayer;
     this->Invert = cl.Invert;
     this->Corner = cl.Corner;

     // �ͳ��� ���ΰ� �����Ѱ踦 �����ϴ��� �Ǵ��ϴµ�
     // �ʿ��� �ڷ� CilPoint�� 30cm, ConPoint�� 10cm.
     for (int i = 0;i< 4;i++) this->CilPoint[i] = cl.CilPoint[i];
     for (int i = 0;i< 2;i++) this->InsPoint[i] = cl.InsPoint[i];

     this->LeftControlPoint = cl.LeftControlPoint;
     this->RightControlPoint = cl.RightControlPoint;
     this->Center = cl.Center;

     this->ShotcreteThickness = cl.ShotcreteThickness; // ��ũ��Ʈ �β�
     this->Height = cl.Height;     // �����Ѱ� ����
}
//---------------------------------------------------------------------------
//  �ͳδܸ�����
//---------------------------------------------------------------------------
void TTunnelFace::SetInnerPerimeter(TTunPart &ip)
{
     InnerPerimeter = ip;
}

void  TTunnelFace::SetOuterPerimeter(TTunPart &op)
{
     OuterPerimeter = op;
}

void  TTunnelFace::SetPaveConc(TTunPart &pc)
{
     PaveConc = pc;
}

void  TTunnelFace::SetMixConc(TTunPart &mc)
{
     MixConc = mc;
}

void  TTunnelFace::SetSelectLayer(TTunPart &sl)
{
     SelectLayer = sl;
}

void  TTunnelFace::SetLowConc(TTunPart &lc)
{
     LowConcrete = lc;
}

void  TTunnelFace::SetTHP(TRealCircles &thp)
{
     THP = thp;
}

void  TTunnelFace::SetSteelPipe(TRealCircles &sp)
{
     SteelPipe = sp;
}

void  TTunnelFace::SetBenchHeight(float bh)
{
     BenchHeight = bh;
}

void TTunnelFace::Draw(TObject *Sender)
{
     InnerPerimeter.Draw(Sender);
     OuterPerimeter.Draw(Sender);
     PaveConc.Draw(Sender);
     MixConc.Draw(Sender);
     SelectLayer.Draw(Sender); // ������
     LowConcrete.Draw(Sender);
     THP.Draw(Sender);        // T.H.P.
     SteelPipe.Draw(Sender);  // �ƿ�������
}

float TTunnelFace::GetInnerArea()
{
    return InnerPerimeter.GetArea();
}

//---------------------------------------------------------------------------
#pragma package(smart_init)
