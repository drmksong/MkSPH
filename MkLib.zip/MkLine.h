//---------------------------------------------------------------------------
#ifndef MkLineH
#define MkLineH

#ifdef __BCPLUSPLUS__
#ifdef _MSC_VER
#undef _MSC_VER
#endif
#endif

#include "MkShape.h"
#include "MkPoint.h"
#include "math.h"

#if defined(_MSC_VER) && defined(_WINDOWS_)
class MkPaint;
#endif

class MkArc;
//---------------------------------------------------------------------------
class MkLine : public MkShape {
private:
    MkPoint StartPoint, EndPoint;
    float Theta, Length;
    float A,B,C;            // A*X + B*Y = C  (C = 0 or 1)
    float L,M,N;            // direction cosine
    bool isSelected;
    bool  isFinite;
    
    void  CalLength();
    void  CalTheta();
    void  CalCoeff();
    float Tol;
public:
     MkLine();
     MkLine(MkPoint sp,MkPoint ep);
     MkLine(float sx,float sy,float ex,float ey);

#ifdef __BCPLUSPLUS__
     MkLine(MkPoint sp,MkPoint ep,TColor C);
     MkLine(float sx,float sy,float ex,float ey,TColor C);
    void SetLine(MkPoint sp,MkPoint ep,TColor C);
    void SetLine(float sx,float sy,float ex,float ey,TColor C);
#endif

#ifdef __BCPLUSPLUS__
    AnsiString ClassName(){return AnsiString("MkLine");}
#else
    char * ClassName(){return "MkLine";}
#endif

    void SetLine(MkPoint sp,MkPoint ep);
    void SetLine(float sx,float sy,float ex,float ey);
    void SetTol(float tol){Tol = tol;}
    float GetLength();
    float GetTheta();
    bool GetFiniteness(){return isFinite;}
    void SetFiniteness(bool fin){isFinite = fin;} 
    void AdjustTheta(){if (Theta>360) Theta -= 360;
                       else if (Theta<0) Theta += 360;}
    MkPoint GetMiddlePoint()
           {return
             MkPoint(
              ((*this)[0].X+(*this)[1].X)/2,
              ((*this)[0].Y+(*this)[1].Y)/2,
              ((*this)[0].Z+(*this)[1].Z)/2);
           };
    MkPoint  GetDivision(float f);

    void Extend(float f);
    float DeltaX(){return EndPoint.X - StartPoint.X;};
    float DeltaY(){return EndPoint.Y - StartPoint.Y;};
    float DeltaZ(){return EndPoint.Z - StartPoint.Z;};
    float NormDeltaX(){return fabs(StartPoint.X)<1.0e-6?
                                  0:((EndPoint.X-StartPoint.X)/StartPoint.X);};
    float NormDeltaY(){return fabs(StartPoint.Y)<1.0e-6?
                                  0:((EndPoint.Y-StartPoint.Y)/StartPoint.Y);};
    bool IsIntersect(MkLine &realline);
    bool IsIn(MkPoint rp);
    bool IsIn(float x,float y);
    bool IsInLine(MkPoint rp);
    bool IsInLine(float x,float y);
    bool IsInSamePlane(MkLine rl);
    bool GetIntParam(MkLine &rl,float &t);
    bool GetIntParam(MkPoint p,float &t);
    MkPoint GetIntPoint(MkLine &rl);
    float GetArea(){return 0;};
    float GetA(){return A;}
    float GetB(){return B;}
    float GetC(){return C;}
    float GetL(){return L;}
    float GetM(){return M;}
    float GetN(){return N;}

    MkVector & GetVector()
      {
        static MkVector vec(3);
        vec[0] = EndPoint.X-StartPoint.X;
        vec[1] = EndPoint.Y-StartPoint.Y;
        vec[2] = EndPoint.Z-StartPoint.Z;
        vec.Normalize();
        return vec;
      }

    void Select(){isSelected=true;}
    void Unselect(){isSelected=false;}
    bool GetSelected(){return isSelected;}

    float CalDist(MkPoint rp){return fabs(A*rp.X+B*rp.Y-C)/sqrt(A*A+B*B);}
    float CalDist(float x,float y){return fabs(A*x+B*y-C)/sqrt(A*A+B*B);}
    float CalDist3D(MkPoint rp);
    float CalDist3D(float x,float y,float z);
    MkPoint GetNearestPnt(MkPoint rp);
    MkPoint GetNearestPnt(float x,float y,float z);

    MkLine Translate(MkPoint rp);
    MkLine Translate(float x,float y,float z);
    MkLine Rotate(float alpha, float beta, float gamma);
    MkLine RotateInX(float ang);
    MkLine RotateInY(float ang);
    MkLine RotateInZ(float ang);
    MkLine RotateInA(float ang,float l, float m, float n);

    MkLine Scale(float sx,float sy, float sz);

    void Out();
    void Clear();
    bool operator &&(MkLine rline1);
    bool operator ==(MkLine rline1);
    bool operator !=(MkLine rline1);
    MkPoint operator &(MkLine &);
    MkPoint & operator[](int);
    float operator +(MkLine); //dot product
    float operator *(MkLine);
    float operator *(MkPoint rp);  //cross product
    MkLine & operator*(MkMatrix4 &rm);
    float operator+=(MkPoint);
    float operator-=(MkPoint);

#if !defined(_MSC_VER) && !defined(_WINDOWS_) || defined(__BCPLUSPLUS__)
    MkLine & operator=(const MkLine &);
#endif
    MkLine & operator=(MkLine &);
    MkLine operator!();

#ifdef __BCPLUSPLUS__
    void Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif
};

class MkLines {
protected:
    MkLine *FRealLine;
    int FSize;
#ifdef __BCPLUSPLUS__
    TColor Color;
#endif
#if defined(_MSC_VER) && defined(_WINDOWS_)
    MkColor PColor,BColor;
#endif
public:
    MkLines(int size,MkLine *rl);
    MkLines(int FSize);
    MkLines(){FSize = 0;FRealLine = NULL;}
    ~MkLines();
    void Initialize(int size);
    void Initialize(int size,MkLine *rl);
    void Grow(int sz);
    void Add(MkLine &l){Grow(1);FRealLine[FSize-1] = l;}
    void DeleteSelected();
    int GetSize(){return FSize;};
    int GetNumber(){return FSize;};
    MkLine * GetLine(){return FRealLine;}
    bool Clear();
#ifdef __BCPLUSPLUS__
    TColor GetColor(){return Color;};
    void SetColor(TColor c){Color = c;}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
    MkColor GetColor(){return PColor;};
    void SetColor(MkColor c){PColor = c;}
#endif

    virtual MkLine & operator[](int);

    MkLines & RotateInX(float ang);
    MkLines & RotateInY(float ang);
    MkLines & RotateInZ(float ang);
    MkLines & RotateInA(float ang,float l, float m, float n);

    MkLines & operator*(MkMatrix4 &rm);
    MkLines & operator=(MkLines &);
    bool operator==(MkLines &);
#ifdef __BCPLUSPLUS__
    void Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif


};

extern MkLine NullLine;
extern MkLines NullLines;
//---------------------------------------------------------------------------
#endif
