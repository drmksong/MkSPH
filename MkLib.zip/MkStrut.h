//---------------------------------------------------------------------------
#ifndef MkStrutH
#define MkStrutH
#include "MkEntity.h"
#include "MkWale.h"
#include "MkMisc.h"
//---------------------------------------------------------------------------
class MkStrut : public MkEntity {
private:
#ifdef __BCPLUSPLUS__
  AnsiString MajorWale;
#else
  char MajorWale[255];
#endif
  MkWale Wale;
  int Tan, LeftTan, RightTan; // for Wale spec, support_L, and support_R
protected:
//HH,BB,tt1, tt2, AA, Aw,W,Zx,Ix,rx,ry for beam
  MkSteelType SteelType; 
  float Height;        // HH
  float Width;         // BB
  float T1,T2;         // tt1, tt2
  float Area, AreaWeb; // AA, Aw
  float Weight;        // W
  float SecCoeffY, SecCoeffZ;    // Section coefficient Zx, Zy
  float SecMomentY, SecMomentZ;  // second moment of inertial Ix, Iy
  float SecRadiusY, SecRadiusZ;  // second radius of inertia rx, ry

  float Spacing;
  float JackingForce;
  float IniDisp;
  float StressLoss;
  float RakerAng;
  float YoungMod;
  float ShearTor;
  MkLine StrutLine;
public:
  MkStrut();
  MkStrut(int n);
  ~MkStrut(){};
public: //setting function
#ifdef __BCPLUSPLUS__
  void SetMajorWale(AnsiString str){MajorWale = str;}
#else
  void SetMajorWale(char *str){strncpy(MajorWale,str,255);}
#endif
  void SetTan(int tan){Tan = tan;}
  void SetLeftTan(int tan){LeftTan = tan;}
  void SetRightTan(int tan){RightTan = tan;}

  void SetSteelType(MkSteelType st){SteelType = st;}
  void SetHeight(float h){Height=h;}
  void SetWidth(float w){Width=w;}
  void SetT1(float t){T1=t;}
  void SetT2(float t){T2=t;}
  void SetArea(float a){Area=a;}
  void SetAreaWeb(float a){AreaWeb=a;}
  void SetWeight(float w){Weight=w;}
  void SetSecCoeffY(float sm){SecCoeffY=sm;}
  void SetSecCoeffZ(float sm){SecCoeffZ=sm;}
  void SetSecMomentY(float sm){SecMomentY=sm;}
  void SetSecMomentZ(float sm){SecMomentZ=sm;}
  void SetSecRadiusY(float sm){SecRadiusY=sm;}
  void SetSecRadiusZ(float sm){SecRadiusZ=sm;}
  void SetBeam(MkBeam beam);

  void SetSpacing(float hs){Spacing=hs;}
  void SetJackingForce(float is){JackingForce=is;}
  void SetIniDisp(float id){IniDisp=id;}
  void SetStressLoss(float sl){StressLoss=sl;}
  void SetRakerAng(float ra){RakerAng=ra;}
  void SetYoungMod(float y){YoungMod = y;}
  void SetShearTor(float s){ShearTor = s;}
  void SetLine(MkLine &line)
    {
      StrutLine = line;
      StrutLine.SetFiniteness(true);
      Depth = -StrutLine[0].Y;
      Length = StrutLine.GetLength();
    };
  void SetWale(MkWale &wale){Wale=wale;}    

public: //getting function

#ifdef __BCPLUSPLUS__
  AnsiString GetMajorWale(){return MajorWale;}
#else
  char *GetMajorWale(){return MajorWale;}
#endif

  int GetTan(){return Tan;}
  int GetLeftTan(){return LeftTan;}
  int GetRightTan(){return RightTan;}

  MkSteelType GetSteelType(){return SteelType;}
  float GetHeight(){return Height;}
  float GetWidth(){return Width;}
  float GetT1(){return T1;}
  float GetT2(){return T2;}
  float GetArea(){return Area;}
  float GetAreaWeb(){return AreaWeb;}
  float GetWeight(){return Weight;}
  float GetSecCoeffY(){return SecCoeffY;}  // second coeff of inertial
  float GetSecCoeffZ(){return SecCoeffZ;}  // second coeff of inertial
  float GetSecMomentY(){return SecMomentY;}  // second moment of inertial
  float GetSecMomentZ(){return SecMomentZ;}  // second moment of inertial
  float GetSecRadiusY(){return SecRadiusY;}  // second radius of inertial
  float GetSecRadiusZ(){return SecRadiusZ;}  // second radius of inertial

  float GetSpacing(){return Spacing;}
  float GetJackingForce(){return JackingForce;}
  float GetIniDisp(){return IniDisp;}
  float GetStressLoss(){return StressLoss;}
  float GetRakerAng(){return RakerAng;}
  float GetYoungMod(){return YoungMod;}
  float GetShearTor(){return ShearTor;}
  MkLine &GetLine(){return StrutLine;}
  MkWale &GetWale(){return Wale;}

public:
#ifdef __BCPLUSPLUS__
  AnsiString ClassName(){return AnsiString("MkStrut");};
  bool UpdateFrom(TStringGrid *grid){Grid = grid;return UpdateFrom();};
  bool UpdateTo(TStringGrid *grid){Grid = grid;return UpdateTo();};
  bool UpdateFrom();
  bool UpdateTo();
  void Out(TObject *);
  void ExtractSpec(AnsiString &spec);
  void ComposeSpec(AnsiString &spec);
  void Import(MkGlobalVar &globalvar, int sec,MkSide side, int tan);
  void Export(MkGlobalVar &globalvar, int sec,MkSide side, int tan);
#else
  char* ClassName(){return "MkStrut";}
#endif

  void Out(char *);
  void Clear();
    
#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif
  bool operator==(MkStrut&);
  bool operator!=(MkStrut&);
  MkStrut&operator=(MkStrut&);
};

class MkStruts {
protected:
    MkStrut *FStrut;
    int FSize;//Actual size of entities
    int FSizeOfArray;
#ifdef __BCPLUSPLUS__
    TColor Color;
#endif
public:
  MkStruts(int size,MkStrut *ent);
  MkStruts(int size);
  MkStruts(){FSizeOfArray = FSize = 0;FStrut = NULL;}
   ~MkStruts();
  virtual void Initialize(int size);
  virtual void Initialize(int size,MkStrut *);
  int GetSize(){return FSize;};
  int GetNumber(){return FSize;};
  bool Add(MkStrut &strut);  // change of size of strut
  bool Add(int index,MkStrut &strut);
  bool Delete(MkStrut &strut);  // change of size of strut
  bool Delete(int index);
  int Grow(int Delta);            // change of size of array
  int Shrink(int Delta);          // change of size of array
  bool Clear();
#ifdef __BCPLUSPLUS__
  TColor GetColor(){return Color;};
  void SetColor(TColor c){Color = c;}
  void Out(TObject *);
  void Import(MkGlobalVar &globalvar, int sec);
  void Export(MkGlobalVar &globalvar, int sec);
#else
#endif

  void Out(char *fname);

#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif

  virtual MkStrut & operator[](int);
  MkStruts & operator=(MkStruts &struts);
  bool operator==(MkStruts &struts);
};
//---------------------------------------------------------------------------
extern MkStrut NullStrut;
//---------------------------------------------------------------------------
#endif
