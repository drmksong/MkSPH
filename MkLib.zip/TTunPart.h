//---------------------------------------------------------------------------
#ifndef TTunPartH
#define TTunPartH
#include "TMyShape.h"
#include "MyLine.h"
#include "MyCircle.h"
#include "MyPolygon.h"
//---------------------------------------------------------------------------
class TTunPart : public TMyShapeList {
private:
     bool Continuity;
     bool Crossing;
     bool Validity;
public:
     TTunPart() : TMyShapeList(){;};
     ~TTunPart();
     bool isContinuous();
     bool isCrossed();
     bool isValid(){return Validity = isContinuous() && !isCrossed();}
     float GetArea();
};

class TTunParts {
      int FI;
      TTunPart dmmy;
      TTunPart *F;
      TTunPart *FCur;
      long  Size;
public:
       TTunParts(int);
       TTunParts();
       ~TTunParts();
       void Initialize(int size);
       void SetSize(int);
       TTunPart & operator[](int i){FI = i; FCur = F+FI; return *(F+FI);};
       TTunParts & operator=(TTunParts &a);
//       operator TTunPart() {return *FCur;}
       long GetSize() { return Size; };
};

//---------------------------------------------------------------------------
#endif
