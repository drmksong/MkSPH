//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#pragma package(smart_init)
#endif

#pragma hdrstop
#include "stdafx.h"
#include "MkLoad.h"

#ifdef __BCPLUSPLUS__
#include <vcl.h>
#endif

MkLoad NullLoad(0);
//---------------------------------------------------------------------------
bool MkLoad::BuildRange(MkWall &wall)
{
  MkPoint sp,ep,p;
  MkRect r;
  MkRangeShape rs;

  sp = wall.GetLine()[0];
  ep = wall.GetLine()[1];

  if(sp==ep) return false;

  p = sp.Y<ep.Y?sp:ep;
  p.X = p.X-EPS*2;
  p.Y = p.Y-EPS*2;

  r.SetOrigin(p);
  r.SetWidth(EPS*4);
  r.SetHeight(wall.GetLine().GetLength()+EPS*4);

  rs.SetShape(&r);

  Range.Clear();
  Range.SetRoot(&rs);
  return true;
}

bool MkLoad::Out(char *fname) 
{
  FILE *fp;
  fp = fopen(fname,"a");
  if(!fp) {
    MkDebug(fname); MkDebug(" is not found, so fp is null and return false\n");
    return false;
  }

  fprintf(fp,"-------------------------begin of load info--------------\n");
  fprintf(fp,"LoadType      : MkLoad\n");
  fprintf(fp,"Dir vector    : (%10.3f,%10.3f,%10.3f) \n",Direction[0], Direction[1], Direction[2]);
  fprintf(fp,"Origin        : (%10.3f,%10.3f,%10.3f) \n",Origin.X, Origin.Y, Origin.Z);
  fprintf(fp,"Ground wat lev: %10.3f\n",GroundWaterLevel);
  fprintf(fp,"-------------------------end of load info----------------\n");
  fclose(fp);
}

bool MkLoad::operator==(MkLoad &load)
{
  bool flag;
  flag = LoadType == load.LoadType &&
         LoadApplyType == load.LoadApplyType && 
         Direction == load.Direction &&
         Origin == load.Origin &&
         Range == load.Range;
  return flag;
}

bool MkLoad::operator!=(MkLoad &load)
{
  return !operator==(load);
}

MkLoad & MkLoad::operator=(MkLoad &load)
{
  LoadType=load.LoadType;
  LoadApplyType = load.LoadApplyType;
  Direction=load.Direction;
  Origin=load.Origin;

  Range=load.Range;
#ifdef __BCPLUSPLUS__
  Color=load.Color;
#endif
  return *this;
}
//--------------------------------------------------------------------
MkEarthPress::MkEarthPress() : MkLoad()
{
  LoadType = ltEarthPress;
  K0 = 0;
  Ka = 0;
  Kp = 0;
  Gamma = 0;
  H = 0;

  HeightTop = 0;
  HeightMid = 0;
  HeightBot = 0;
}

float MkEarthPress::GetStaticPress(MkPoint pnt)
{
  MkLine l;  
  MkPoint p;
  if (!Range.Operate(pnt)) return 0;
  l.SetLine(MkPoint(-1000,pnt.Y),MkPoint(1000,pnt.Y));
  for (int i=0;i<Static.GetSize()-1;i++) {
    if(Static(i)&&l) {
      p = Static(i)&l;
      break;
    }
  }
  return p.X;
}

bool MkEarthPress::Build(MkWall &wall)
{
  int dir;
  float h;
  MkPoint *pnt;

  dir = Direction[0] > 0 ? -1 : 1;
  BuildRange(wall);

  if (HeightTop<0) HeightTop = 0;
  if (HeightMid<0) HeightMid = 0;
  if (HeightBot<0) HeightBot = 0;

  h = HeightTop+HeightMid+HeightBot;

  if (h < EPS) HeightMid = 1;
  else {
    HeightTop = HeightTop/h;
    HeightMid = HeightMid/h;
    HeightBot = HeightBot/h;
  }

  pnt = new MkPoint[4];
  pnt[0].SetPoint(0,0);
  pnt[1].SetPoint(dir*K0*Gamma*H,-H*HeightTop);
  pnt[2].SetPoint(dir*K0*Gamma*H,-H*(HeightTop+HeightMid));
  pnt[3].SetPoint(0,-H);
//  pnt[0] += Origin;
//  pnt[1] += Origin;
//  pnt[2] += Origin;
//  pnt[3] += Origin;

  Static.Initialize(4,pnt);
  delete[] pnt;
  return true;
}

bool MkEarthPress::Out(char *fname)
{
  FILE *fp;
  fp = fopen(fname,"a");
  if(!fp) {
    MkDebug(fname); MkDebug(" is not found, so fp is null and return false\n");
    return false;
  }

  fprintf(fp,"-------------------------begin of earth press info--------------\n");
  fprintf(fp,"LoadType      : MkEarthPress\n");
  fprintf(fp,"Dir vector    : (%10.3f,%10.3f,%10.3f) \n",Direction[0], Direction[1], Direction[2]);
  fprintf(fp,"Origin        : (%10.3f,%10.3f,%10.3f) \n",Origin.X, Origin.Y, Origin.Z);
  fprintf(fp,"Ground wat lev: %10.3f\n",GroundWaterLevel);
  fprintf(fp,"K0, Ka, Kp    : %10.3f, %10.3f, %10.3f\n",K0,Ka,Kp);
  fprintf(fp,"Gamma, H      : %10.3f, %10.3f\n",Gamma,H);
  fprintf(fp,"HeightTop     : %10.3f, %10.3f\n",HeightTop);
  fprintf(fp,"HeightMid     : %10.3f, %10.3f\n",HeightMid);
  fprintf(fp,"HeightBot     : %10.3f, %10.3f\n",HeightBot);
  fprintf(fp,"Static earth pressure\n");
  fclose(fp);
  Static.Out(fname);

  fp = fopen(fname,"a");
  if(!fp) {
    MkDebug(fname); MkDebug(" is not found, so fp is null and return false\n");
    return false;
  }
  fprintf(fp,"-------------------------end of earth press info----------------\n");
  fclose(fp);

}

bool MkEarthPress::operator==(MkEarthPress &ep)
{
  bool flag;
  flag = MkLoad::operator==((MkLoad&)ep);
  flag = flag && fabs(K0-ep.K0)<EPS && fabs(Gamma-ep.Gamma)<EPS &&
    fabs(H-ep.H)<EPS && fabs(HeightTop-ep.HeightTop)<EPS &&
    fabs(HeightMid-ep.HeightMid)<EPS && fabs(HeightBot-ep.HeightBot)<EPS &&
    Static == ep.Static;

  return flag;
}

bool MkEarthPress::operator!=(MkEarthPress &ep)
{
  return !operator==(ep);
}

MkEarthPress & MkEarthPress::operator=(MkEarthPress & ep)
{
  LoadType=ep.LoadType;
  LoadApplyType = ep.LoadApplyType;  
  Direction=ep.Direction;
  Origin=ep.Origin;

  Range=ep.Range;
#ifdef __BCPLUSPLUS__
  Color=ep.Color;
#endif

  K0 = ep.K0;
  Gamma = ep.Gamma;
  H = ep.H;

  HeightTop = ep.HeightTop;
  HeightMid = ep.HeightMid;
  HeightBot = ep.HeightBot;

  Static = ep.Static;
  return *this;
}

#ifdef __BCPLUSPLUS__
void MkEarthPress::Draw(TObject *pb)
{
  for(int i=0;i<Static.GetSize();i++) 
    Static[i]+= Origin;
  Static.Draw(pb);
  for(int i=0;i<Static.GetSize();i++)
    Static[i]-= Origin;
}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void MkEarthPress::Draw(MkPaint *pb)
{
  int i;
  for(i=0;i<Static.GetSize();i++) 
    Static[i]+= Origin;
  Static.Draw(pb);
  for(i=0;i<Static.GetSize();i++)
    Static[i]-= Origin;
}
#endif

//--------------------------------------------------------------------
MkRankine::MkRankine() : MkEarthPress()
{
  LoadType = ltRankine;
}

float MkRankine::GetVerticPress(MkPoint pnt)
{
  MkLine l;  
  MkPoint p;
  if (!Range.Operate(pnt)) return 0;
  l.SetLine(MkPoint(-1000,pnt.Y),MkPoint(1000,pnt.Y));
  for (int i=0;i<Vertic.GetSize()-1;i++) {
    if(Vertic(i)&&l) {
      p = Vertic(i)&l;
      break;
    }
  }
  return p.X;
}

float MkRankine::GetActivPress(MkPoint pnt)
{
  MkLine l;  
  MkPoint p;
  if (!Range.Operate(pnt)) return 0;
  l.SetLine(MkPoint(-1000,pnt.Y),MkPoint(1000,pnt.Y));
  for (int i=0;i<Activ.GetSize()-1;i++) {
    if(Activ(i)&&l) {
      p = Activ(i)&l;
      break;
    }
  }
  return p.X;
}

float MkRankine::GetPassivPress(MkPoint pnt)
{
  MkLine l;
  MkPoint p;
  if (!Range.Operate(pnt)) return 0;
  l.SetLine(MkPoint(-1000,pnt.Y),MkPoint(1000,pnt.Y));
  for (int i=0;i<Passiv.GetSize()-1;i++) {
    if(Passiv(i)&&l) {
      p = Passiv(i)&l;
      break;
    }
  }
  return p.X;
}

bool MkRankine::BuildActiv(MkLayers &lay,MkCuts &cuts,MkFills &fills,MkWall &wall)
{
  int i;
  float ka,c,phi,rad;
  MkPoint p;
  p.X = Direction[0];
  Activ = Vertic;

  for(i=0;i<Activ.GetSize();i++) {
    p.Y = Activ[i].Y+2*EPS;
    ka = lay.GetKa(p);
    c = lay.GetCohesion(p);
    phi = lay.GetFriction(p);
    rad = (45-phi/2)*3.141592/180.0;
    Activ[i].X = Vertic[i].X*ka;//-c*tan(rad);
  }
  return true;
}

bool MkRankine::BuildPassiv(MkLayers &lay,MkCuts &cuts,MkFills &fills,MkWall &wall)
{
  int i;
  float kp,c,phi,rad;
  MkPoint p;
  p.X = Direction[0];
  Passiv = Vertic;

  for(i=0;i<Passiv.GetSize();i++) {
    p.Y = Passiv[i].Y+2*EPS;
    kp = lay.GetKp(p);
    c = lay.GetCohesion(p);
    phi = lay.GetFriction(p);
    rad = (45+phi/2)*3.141592/180.0;
    Passiv[i].X = Vertic[i].X*kp;//+c*tan(rad);
  }
  return true;
}

bool MkRankine::BuildStatic(MkLayers &lay,MkCuts &cuts,MkFills &fills,MkWall &wall)
{
  int i;
  float k0;
  MkPoint p;
  p.X = Direction[0];
  Static = Vertic;

  for(i=0;i<Static.GetSize();i++) {
    p.Y = Static[i].Y+2*EPS;
    k0 = lay.GetK0(p);
    Static[i].X = k0*Static[i].X;
  }
  return true;
}

bool MkRankine::BuildVertic(MkLayers &lay,MkCuts &cuts,MkFills &fills,MkWall &wall)
{
  int i,j,k,cnt=0;
  float depth_c=10000,depth_f=-10000;
  float gamma = 1.8; // surcharge soil properties
  float cut_s=-1000, cut_e=1000;
  bool flag=true;
  float UnitConv = 1.0;//ori 10000;// need to update to consider the unit selection
  MkLine w,l;
  MkPoint sp,ep;
  MkPoints p,ip;

  w=wall.GetLine();
  if(w[0].Y<w[1].Y) {
    sp=w[0]; ep=w[1];
  }
  else {
    sp=w[1]; ep=w[0];
  }
  
  // need to update : if it is single wall, then how to know that it is single?
  if(cuts.GetSize()) {
    MkWall &lw = *cuts[0].GetWall(0);
    MkWall &rw = cuts[0].GetWall(1)?*cuts[0].GetWall(1):*cuts[0].GetWall(0);
    cut_s = lw.GetLine()[0].X;
    cut_e = rw.GetLine()[0].X;
    if(fabs(cut_s-cut_e)<EPS) cut_e = 1.0e3;
  }

  sp.Y += -EPS;
  ep.Y += EPS;
  sp.X += Direction[0]<0 ? 2*EPS:-2*EPS;
  ep.X += Direction[0]<0 ? 2*EPS:-2*EPS;
  l.SetLine(sp,ep);

  for (i=0;i<cuts.GetSize();i++) {
	if(cuts[i].GetDepth()<depth_c) 
	  depth_c = cuts[i].GetDepth();
  }

  for (i=0;i<fills.GetSize();i++) {
	if(fills[i].GetDepth()>depth_f) 
	  depth_f = fills[i].GetDepth();
  }

  if((sp.X-cut_s)<EPS || (sp.X-cut_e)>EPS) {
    float g = -10000;
    for(i=0;i<lay.GetSize();i++) 
      g = g>lay[i].GetRect().GetTop()?g:lay[i].GetRect().GetTop();
    depth_c = depth_f = g;
  }

  if(fabs(depth_f+10000)>EPS && depth_c < depth_f) {
    ep.SetPoint(0,depth_f);
    p.Add(ep);
  }
  if(fabs(depth_c-10000)>EPS) {
    sp.SetPoint(0,depth_c);
    p.Add(sp);
  }
  if((depth_f+10000)<EPS) depth_f = depth_c;

  for (i=0;i<lay.GetSize();i++) {
    ip.Clear();
    lay[i].GetRect().GetCross(l,ip);
    for (j=0;j<ip.GetSize();j++) {
      flag=true;
      for (k=0;k<p.GetSize();k++) {
	if(CalDist(p[k],ip[j])<EPS*10)
	  flag = false;
      }
      if (ip[j].Y < max(depth_c, depth_f) && flag)
	p.Add(ip[j]);
    }
  }
  ip.Clear();

  flag = true;
  for(k=0;k<p.GetSize();k++) {
    if(CalDist(p[k],l[0])<EPS)
      flag = false;
  }
  if(l[0].Y < depth_c && flag) 
    p.Add(l[0]);

  //bubble sort...? 
  for(i=0;i<p.GetSize()-1;i++) {
    for(j=i+1;j<p.GetSize();j++) {
      if(p[i].Y < p[j].Y) 
		Swap(p[i],p[j]);
    }
  }

  Vertic.Clear();
  Vertic.Initialize(p.GetSize(),p.GetPoints());
  p.Clear();

  for(i=0;i<Vertic.GetSize();i++) {
    float burden=0,h,g;
    ep = Vertic[i];

    if(fabs(depth_f-ep.Y) < EPS) continue;

    for (j=0;j<lay.GetSize();j++) {
      float min_z, max_z;
      min_z = max(ep.Y,lay[j].GetRect().GetBot());
      max_z = min(depth_c,lay[j].GetRect().GetTop());
      if(max_z-min_z<EPS) continue;

      l[0].Y = max_z-2*EPS;
      l[1].Y = min_z+2*EPS;

      h = max_z-min_z;
      g = lay[j].GetWetUnitWeight(l);
      burden+=h*g;
    }
    if (fabs(depth_c - ep.Y)<EPS && (depth_f - ep.Y)>EPS) { // if the point is cut between fill
      h = depth_f-ep.Y;
      g = gamma;
      burden += h*g;
    }
    Vertic[i].X = Direction[0]<0 ? burden*UnitConv : -burden*UnitConv; //Pa
  }
  return true;
}

bool MkRankine::BuildFrom(MkLayers &lay,MkCuts &cuts,MkFills &fills,MkWall &wall)
{
  bool flag;

  BuildRange(wall);

  flag = BuildVertic(lay,cuts,fills,wall);
  flag = BuildStatic(lay,cuts,fills,wall) && flag;
  flag = BuildActiv(lay,cuts,fills,wall) && flag;
  flag = BuildPassiv(lay,cuts,fills,wall) && flag;
  return flag;
}

bool MkRankine::BuildStatic(MkStratum &str,MkCuts &cuts,MkFills &fills,MkWall &wall)
{
  return false;  
}

bool MkRankine::BuildActiv(MkStratum &str,MkCuts &cuts,MkFills &fills,MkWall &wall)
{
  return false;  
}

bool MkRankine::BuildPassiv(MkStratum &str,MkCuts &cuts,MkFills &fills,MkWall &wall)
{
  return false;  
}

bool MkRankine::BuildVertic(MkStratum &str,MkCuts &cuts,MkFills &fills,MkWall &wall)
{
  return false;
}

bool MkRankine::BuildFrom(MkStratum &str,MkCuts &cuts,MkFills &fills,MkWall &wall)
{
  bool flag;

  BuildRange(wall);

  flag = BuildVertic(str,cuts,fills,wall);
  flag = BuildStatic(str,cuts,fills,wall) && flag;
  flag = BuildActiv(str,cuts,fills,wall) && flag;
  flag = BuildPassiv(str,cuts,fills,wall) && flag;
  return flag;
}

bool MkRankine::Out(char *fname)
{
  FILE *fp;
  fp = fopen(fname,"a");
  if(!fp) {
    MkDebug(fname); MkDebug(" is not found, so fp is null and return false\n");
    return false;
  }

  fprintf(fp,"-------------------------begin of rankine info--------------\n");
  fprintf(fp,"LoadType      : MkRankine\n");
  fprintf(fp,"Dir vector    : (%10.3f,%10.3f,%10.3f) \n",Direction[0], Direction[1], Direction[2]);
  fprintf(fp,"Origin        : (%10.3f,%10.3f,%10.3f) \n",Origin.X, Origin.Y, Origin.Z);
  fprintf(fp,"Ground wat lev: %10.3f\n",GroundWaterLevel);
  fprintf(fp,"Static, Activ, Passiv, Vertic earth pressure\n");
  fclose(fp);
  Static.Out(fname);
  Activ.Out(fname);
  Passiv.Out(fname);
  Vertic.Out(fname);
  fp = fopen(fname,"a");
  if(!fp) {
    MkDebug(fname); MkDebug(" is not found, so fp is null and return false\n");
    return false;
  }
  fprintf(fp,"-------------------------end of rankine info----------------\n");
  fclose(fp);
}

bool MkRankine::operator==(MkRankine &r)
{
  bool flag;
  flag = MkEarthPress::operator==((MkEarthPress&)r);
  return flag;
}

bool MkRankine::operator!=(MkRankine &r)
{
  return !operator==(r);
}

MkRankine & MkRankine::operator=(MkRankine &r)
{
  LoadType=r.LoadType;
  LoadApplyType = r.LoadApplyType;
  Direction=r.Direction;
  Origin=r.Origin;

  Range=r.Range;
#ifdef __BCPLUSPLUS__
  Color=r.Color;
#endif

  K0 = r.K0;
  Gamma = r.Gamma;
  H = r.H;

  HeightTop = r.HeightTop;
  HeightMid = r.HeightMid;
  HeightBot = r.HeightBot;

  Static = r.Static;
  Vertic = r.Vertic;
  Activ = r.Activ;
  Passiv = r.Passiv;
  return *this;
}

#ifdef __BCPLUSPLUS__
void MkRankine::Draw(TObject *pb)
{
  for(int i=0;i<Static.GetSize();i++) 
    Static[i]+= Origin;
  Static.Draw(pb);
  for(int i=0;i<Static.GetSize();i++)
    Static[i]-= Origin;
}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void MkRankine::Draw(MkPaint *pb)
{
  int i;
  for(i=0;i<Static.GetSize();i++) 
    Static[i]+= Origin;
  Static.Draw(pb);
  for(i=0;i<Static.GetSize();i++)
    Static[i]-= Origin;
}
#endif
//--------------------------------------------------------------------
MkStaticHydLoad::MkStaticHydLoad()
{
  GroundWaterLevel = 0;
  LoadType = ltStaticHydLoad;
}

bool MkStaticHydLoad::Build(MkWall &wall)
{
  int dir;
  float h;
  MkPoint *pnt;

  dir = Direction[0] > 0 ? -1 : 1;
  BuildRange(wall);

  if (HeightTop<0) HeightTop = 0;
  if (HeightBot<0) HeightBot = 0;
  if (fabs(HeightTop+HeightBot)<EPS) HeightTop = 1;
  h = GroundWaterLevel-ExcavDepth;

  pnt = new MkPoint[3];
  pnt[0].SetPoint(0,0);
  pnt[1].SetPoint(dir*h,-h*HeightTop);
  pnt[2].SetPoint(0,-h);
  pnt[0] += Origin;
  pnt[1] += Origin;
  pnt[2] += Origin;

  WatPress.Initialize(3,pnt);
  delete[] pnt;
  return true;
}

bool MkStaticHydLoad::operator==(MkStaticHydLoad &r)
{
  bool flag;
  flag = MkLoad::operator==((MkLoad&)r);
  flag = flag && (HeightTop==r.HeightTop);
  flag = flag && (HeightBot==r.HeightBot);
  flag = flag && (WatPress==r.WatPress);
  flag = flag && (ExcavDepth==r.ExcavDepth);
  return flag;
}

bool MkStaticHydLoad::operator!=(MkStaticHydLoad &r)
{
  return !operator==(r);
}

MkStaticHydLoad & MkStaticHydLoad::operator=(MkStaticHydLoad &r)
{
  MkStaticHydLoad::operator=((MkStaticHydLoad &)r);
  HeightTop=r.HeightTop;
  HeightBot=r.HeightBot;
  WatPress=r.WatPress;
  ExcavDepth=r.ExcavDepth;
  return *this;
}

#ifdef __BCPLUSPLUS__
void MkStaticHydLoad::Draw(TObject *pb)
{
  for(int i=0;i<WatPress.GetSize();i++) 
    WatPress[i]+= Origin;
  WatPress.Draw(pb);
  for(int i=0;i<WatPress.GetSize();i++)
    WatPress[i]-= Origin;
}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void MkStaticHydLoad::Draw(MkPaint *pb)
{
  int i;
  for(i=0;i<WatPress.GetSize();i++)
    WatPress[i]+= Origin;
  WatPress.Draw(pb);
  for(i=0;i<WatPress.GetSize();i++)
    WatPress[i]-= Origin;
}
#endif
//--------------------------------------------------------------------
MkArbtrHydLoad::MkArbtrHydLoad() : MkStaticHydLoad()
{
	LoadType = ltArbtrHydLoad;
}

bool MkArbtrHydLoad::Build(MkWall &wall)
{
  BuildRange(wall);
  return false;
}

bool MkArbtrHydLoad::operator==(MkArbtrHydLoad &r)
{
  bool flag;
  flag = MkStaticHydLoad::operator==((MkStaticHydLoad&)r);
  return flag;
}

bool MkArbtrHydLoad::operator!=(MkArbtrHydLoad &r)
{
  return !operator==(r);
}

MkArbtrHydLoad & MkArbtrHydLoad::operator=(MkArbtrHydLoad &r)
{
  MkStaticHydLoad::operator=((MkStaticHydLoad &)r);
  return *this;
}

#ifdef __BCPLUSPLUS__
void MkArbtrHydLoad::Draw(TObject *pb)
{
  MkStaticHydLoad::Draw(pb);
}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void MkArbtrHydLoad::Draw(MkPaint *pb)
{
  MkStaticHydLoad::Draw(pb);
}
#endif
//--------------------------------------------------------------------
MkPointBackLoad::MkPointBackLoad()
{
  Weight = 0;
  LoadType = ltPointBackLoad;
}

bool MkPointBackLoad::Build(MkWall &wall)
{
  int i;
  float sigma_h,H,m,n,dist;
  MkPoint p;
  MkLine l;
  BuildRange(wall);

  l = wall.GetLine();
  dist = fabs(LoadPoint.X - l[0].X);
  H = l.GetLength();
  p = l[0].Y > l[1].Y ? l[0] : l[1];

  if(H<EPS) return false;

  m = dist/H;
  BackLoad.Clear();

  for(i=0;i<20;i++) {
    BackLoad.Add(l.GetDivision(i/19.0));
  }

  for(i=0;BackLoad.GetSize();i++) {
    n = (p.Y-BackLoad[i].Y)/H;
    sigma_h = m>0.4? 1.77*Weight/H/H*m*m*n*n/(m*m+n*n)/(m*m+n*n)/(m*m+n*n) : 
                     0.28*Weight/H/H*n*n/(0.16+n*n)/(0.16+n*n)/(0.16+n*n);
    BackLoad[i].X = Direction[0]>0?-sigma_h:sigma_h;
  }
  return false;
}

bool MkPointBackLoad::BuildVert(MkLayers &lay)
{
  int i;
  float offset;
  MkPoint p;
  float ko;
  bool flag=true;
  offset = Direction[0]>0 ? -1:1;
  for (i=0;i<BackLoad.GetSize();i++) {
    p = BackLoad[i];
    p.X = Origin.X+offset;
    ko = lay.GetK0(p);
    if(ko>EPS) VertLoad[i] = MkPoint(BackLoad[i].X/ko,p.Y);
    else flag = false;
  }
  return flag;
}

bool MkPointBackLoad::BuildVert(MkStratum &str)
{
  return false;
}

bool MkPointBackLoad::operator==(MkPointBackLoad &r)
{
  bool flag;
  flag = MkLoad::operator==((MkLoad&)r);
  flag = flag && (Weight==r.Weight);
  flag = flag && (LoadPoint==r.LoadPoint);
  flag = flag && (BackLoad==r.BackLoad);
  flag = flag && (VertLoad==r.VertLoad);
  return flag;
}

bool MkPointBackLoad::operator!=(MkPointBackLoad &r)
{
  return !operator==(r);
}

MkPointBackLoad & MkPointBackLoad::operator=(MkPointBackLoad &r)
{
  MkLoad::operator=((MkLoad &)r);
  Weight=r.Weight;
  LoadPoint=r.LoadPoint;
  BackLoad=r.BackLoad;
  VertLoad=r.VertLoad;
  return *this;
}

#ifdef __BCPLUSPLUS__
void MkPointBackLoad::Draw(TObject *pb)
{
  for(int i=0;i<BackLoad.GetSize();i++)
    BackLoad[i]+= Origin;
  BackLoad.Draw(pb);
  for(int i=0;i<BackLoad.GetSize();i++)
    BackLoad[i]-= Origin;
}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void MkPointBackLoad::Draw(MkPaint *pb)
{
  int i;
  for(i=0;i<BackLoad.GetSize();i++)
    BackLoad[i]+= Origin;
  BackLoad.Draw(pb);
  for(i=0;i<BackLoad.GetSize();i++)
    BackLoad[i]-= Origin;
}
#endif
//--------------------------------------------------------------------
MkLineBackLoad::MkLineBackLoad() : MkPointBackLoad()
{
  LoadType = ltLineBackLoad;
}

bool MkLineBackLoad::Build(MkWall &wall)
{
  int i;
  float sigma_h,H,m,n,dist;
  MkPoint p;
  MkLine l;
  BuildRange(wall);

  l = wall.GetLine();
  dist = fabs(LoadPoint.X - l[0].X);
  H = l.GetLength();
  p = l[0].Y > l[1].Y ? l[0] : l[1];

  if(H<EPS) return false;

  m = dist/H;
  BackLoad.Clear();

  for(i=0;i<20;i++) {
    BackLoad.Add(l.GetDivision(i/19.0));
  }

  for(i=0;BackLoad.GetSize();i++) {
    n = (p.Y-BackLoad[i].Y)/H;
    sigma_h = m>0.4? 4*Weight/3.141592654/H*m*m*n/(m*m+n*n)/(m*m+n*n) : 
                     0.203*Weight/H*n/(0.16+n*n)/(0.16+n*n);
    BackLoad[i].X = Direction[0]>0?-sigma_h:sigma_h;
  }
  return false;
}

bool MkLineBackLoad::operator==(MkLineBackLoad &r)
{
  bool flag;
  flag = MkPointBackLoad::operator==((MkPointBackLoad&)r);
  return flag;
}

bool MkLineBackLoad::operator!=(MkLineBackLoad &r)
{
  return !operator==(r);
}

MkLineBackLoad & MkLineBackLoad::operator=(MkLineBackLoad &r)
{
  MkPointBackLoad::operator=((MkPointBackLoad &)r);
  return *this;
}

#ifdef __BCPLUSPLUS__
void MkLineBackLoad::Draw(TObject *pb)
{
  MkPointBackLoad::Draw(pb);
}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void MkLineBackLoad::Draw(MkPaint *pb)
{
  MkPointBackLoad::Draw(pb);
}
#endif
//--------------------------------------------------------------------
MkLoads::MkLoads(int size,MkLoad **loads)
{
    if (size < 0) {
      MkDebug("::MkLoads - MkLoads(int size)");;
      return;
    }

    FSize = size;
    if (FSize == 0) {
       FLoad = NULL;
       return;
    }

    FLoad = new MkLoad*[FSize];
    assert(FLoad);
    for (int i=0;i<FSize;i++) dyn_load_cp(FLoad[i],loads[i]);
}

MkLoads::~MkLoads()
{
  Clear();
}

void MkLoads::Initialize(int size,MkLoad **loads)
{
  int i;
  if (size < 0) {
    MkDebug("::MkLoads - MkLoads(int size)");
    return;
  }

  Clear();

  FSize = size;
  if (FSize == 0) {
     FLoad = NULL;
     return;
  }

  FLoad = new MkLoad*[FSize];
  assert(FLoad);

  for (i=0;i<FSize;i++)
    dyn_load_cp(FLoad[i],loads[i]);
}

bool MkLoads::Add(MkLoad *l)
{
  int i,j,k,size=FSize;
  bool flag=false;
  MkLoad **loads;
  MkLoad *load;

  if(FSize==0) {
    FLoad = new MkLoad*[1];
    if(!FLoad) return false;
    dyn_load_cp(FLoad[0],l);
    FSize = 1;
    return true;
  }

  dyn_load_cp(load,l);
  if(!load) return false;

  for (i=0;i<FSize;i++)
    if (*FLoad[i]==*load) flag = true;

  if(flag) return false;

  loads = new MkLoad*[FSize+1];
  assert(loads);

  for (j=0;j<FSize;j++)
    dyn_load_cp(loads[j],FLoad[j]);
  dyn_load_cp(loads[FSize],load);

  Clear();

  if(load->isRankine()) {
    MkRankine *l = (MkRankine *)load;
    delete l;
  }
  else if(load->isEarthPress()) {
    MkEarthPress *l = (MkEarthPress *)load;
    delete l;
  }
  else if(load->isArbtrHydLoad()) {
    MkArbtrHydLoad *l = (MkArbtrHydLoad*)load;
    delete l;
  }
  else if(load->isStaticHydLoad()) {
    MkStaticHydLoad *l = (MkStaticHydLoad *)load;
    delete l;
  }
  else if(load->isPointBackLoad()) {
    MkPointBackLoad *l = (MkPointBackLoad *)load;
    delete l;
  }
  else if(load->isLineBackLoad()) {
    MkLineBackLoad *l = (MkLineBackLoad *)load;
    delete l;
  }
  else delete load;
  load = NULL;

  FSize = size+1;
  FLoad = loads;

  return true;
}

bool MkLoads::Delete(MkLoad *load)
{
  int i,j,k,size=FSize;
  bool flag=false;
  MkLoad **loads;

  for (i=0;i<FSize;i++)
    if (*FLoad[i]==*load) {flag = true; break;}

  if(flag) {
    loads = new MkLoad*[FSize-1];
    assert(loads);

    for (j=0;j<i;j++) dyn_load_cp(loads[j],FLoad[j]);
    for (j=i+1;j<FSize;j++) dyn_load_cp(loads[j-1],FLoad[j]);

    Clear();
    Initialize(size-1,loads);
  }
  return true;
}

bool MkLoads::Clear()
{
 if (FLoad) {
   for(int i=0;i<FSize;i++) {
     if(FLoad[i]) {
       if(FLoad[i]->isLineBackLoad()){
         MkLineBackLoad *l = (MkLineBackLoad*)FLoad[i];
         delete l;
	   }
       else if(FLoad[i]->isPointBackLoad()){
		 MkPointBackLoad *p = (MkPointBackLoad*)FLoad[i];
		 delete p;
	   }
       else if(FLoad[i]->isArbtrHydLoad()){
		 MkArbtrHydLoad *h = (MkArbtrHydLoad*)FLoad[i];
         delete h;
	   }
       else if(FLoad[i]->isStaticHydLoad()){
		 MkStaticHydLoad *h = (MkStaticHydLoad*)FLoad[i];
		 delete h;
	   }
       else if(FLoad[i]->isRankine()){
		 MkRankine *r = (MkRankine*)FLoad[i];
		 delete r;
	   }
       else if(FLoad[i]->isEarthPress()) {
         MkEarthPress *e = (MkEarthPress*)FLoad[i];
		 delete e;
	   }
	   else {
		 delete FLoad[i];
	   }
     }
   }
   delete[] FLoad;
   FLoad = NULL;
   FSize = 0;
   return true;
 }
 else return false;
}

bool MkLoads::Out(char *fname)
{
  for(int i=0;i<FSize;i++) FLoad[i]->Out(fname);
  return true;
}

MkLoad & MkLoads::operator[](int i)
{
    if (FSize == 0) return NullLoad;
    else if (i >=0 && i < FSize) return *FLoad[i];
    else return NullLoad;
}

MkLoads & MkLoads::operator=(MkLoads &loads)
{
    int i;

    Clear();
    FSize = loads.FSize;
    if (FSize == 0) {
       FLoad = NULL;
       return *this;
    }
    FLoad = new MkLoad*[FSize];
    assert(FLoad);

    for (i=0;i<FSize;i++)
      dyn_load_cp(FLoad[i],&loads[i]);

    return *this;
}

bool MkLoads::operator==(MkLoads &loads)
{
    int i;

    if (FSize != loads.FSize) return false;
    for (i=0;i<FSize;i++)
      if (this->FLoad[i] != loads.FLoad[i]) return false;

    return true;
}

bool MkLoads::operator!=(MkLoads &loads)
{
  return !(*this==loads);
}

#ifdef __BCPLUSPLUS__
void MkLoads::Draw(TObject *Sender)
{
  for (int i=0;i<FSize;i++)
    (*FLoad)[i].Draw(Sender);
}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void MkLoads::Draw(MkPaint *pb)
{
  for (int i=0;i<FSize;i++)
    (*FLoad)[i].Draw(pb);
}
#endif
//---------------------------------------------------------------------------
