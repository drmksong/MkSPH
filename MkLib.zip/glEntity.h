//---------------------------------------------------------------------------
#ifndef glEntityH
#define glEntityH
#include "MkMesh.h"
#include "MkMisc.h"
#include "MkFloat.h"
#include "MkPoint.h"
#include "MkLine.h"
#include "MkCircle.h"
#include "MkPolygon.h"
#include "MkSection.h"
//#include "MkMatrix.h"
//#include "MkGrid.h"

//#include "GLColor.h"
#include "OpenGLPanel.h"
//---------------------------------------------------------------------------
// pine:�ҳ���, cryptomeria:�ﳪ��,oak:������, chestnut:�㳪��
enum GLBeamType {btHBeam,btIBeam,btLBeam,btCBeam, btSheet};
enum GLWallType {wtNone,wtWood, wtConc,wtWoodConc,wtSlurryWall};
enum GLWoodType {wtPine, wtCryptomeria, wtOak, wtChestnut};
//enum GLWallSide {wsLeft, wsRight};
//enum GLPileLoc  {gplLeft, gplMid, gplRight};
enum GLSide {gsLeft, gsMid, gsRight};
enum GLSuptType {stCIP, stSCW, stSIG, stJSP};
enum GLBracketType {btSteelRod, btSteelBeam};
enum GLAnchorHangerType {ahtOneWale, ahtTwoWale};
enum GLDeckType {dtOnGround, dtAboveGround};
enum GLDrawMode {dmModel, dmResult};
enum GLResultType {resXDis, resAngDis, resMoment, resShear, resPress, resAxial};
enum GLDimType {dtLine, dtArc, dtPolygon};

// Center, Up : +y, Face : +x
class GLObject {
protected:
  float RotX, RotY, RotZ;
  float LocX, LocY, LocZ;
  MkLine   Line;
  MkVector Up;
  GLDrawMode DrawMode;
  int Number;
public:
  GLObject();
  virtual void CalcRot();
  virtual void TranRot();

  void SetRotX(float f){RotX = f;}
  void SetRotY(float f){RotY = f;}
  void SetRotZ(float f){RotZ = f;}
  void SetLocX(float f){LocX = f;}
  void SetLocY(float f){LocY = f;}
  void SetLocZ(float f){LocZ = f;}
  void SetLine(MkLine &l){Line = l;CalcRot();}
  void SetVector(MkVector &v){Up = v;Up.Normalize();CalcRot();}
  void SetDir(MkLine &l, MkVector &v){Line=l;Up=v;Up.Normalize();CalcRot();}
  void SetDrawMode(GLDrawMode dm){DrawMode = dm;}
  void SetNumber(int n){Number = n;}

  float GetRotX(){return RotX;}
  float GetRotY(){return RotY;}
  float GetRotZ(){return RotZ;}
  float GetLocX(){return LocX;}
  float GetLocY(){return LocY;}
  float GetLocZ(){return LocZ;}
  MkLine & GetLine(){return Line;}
  MkVector & GetUpVector(){return Up;}
  GLDrawMode GetDrawMode(){return DrawMode;}
  int GetNumber(){return Number;}

  bool operator==(GLObject &obj);
  bool operator!=(GLObject &obj);
  GLObject &operator=(GLObject &obj);

  virtual void DrawGL();
  virtual void DrawModel();
  virtual void DrawResult();
};

class GLRect : public GLObject {
protected:
  float Width, Height;
public:
  GLRect();
  void SetWidth(float f){Width = f;}
  void SetHeight(float f){Height = f;}
  float GetWidth(){return Width;}
  float GetHeight(){return Height;}
  void DrawGL();
};

class GLCube : public GLRect {
protected:
  float Thick;
public:
  GLCube();
  void SetThick(float t){Thick = t;}
  float GetThick(){return Thick;}
  void DrawGL();
};

class GLCone : public GLObject {
protected:
  float TopRad,Height;
  MkPoint Cen;
  GLUquadricObj *QObj;
public:
  GLCone();
  ~GLCone(){if(QObj) {gluDeleteQuadric(QObj);QObj=NULL;}}
  void TranRot();
  void CalcRot();
  void SetTopRad(float r){TopRad = r;}
  void SetHeight(float h){Height = h;}
  float GetTopRad(){return TopRad;}
  float GetHeight(){return Height;}
  void DrawGL();
};

class GLCylinder : public GLCone {
protected:
  float BaseRad;
public:
  GLCylinder();
  GLCylinder(int );
  ~GLCylinder(){if(QObj) {gluDeleteQuadric(QObj);QObj=NULL;}}
  void SetBaseRad(float r){TopRad=BaseRad= r;}
  float GetBaseRad(){return BaseRad;}
  void DrawGL();
};

class GLCylinders {
protected:
  GLCylinder *FCylinder;
  int FSize;//Actual size of cylinders
  int FSizeOfArray;
public:
  GLCylinders(int size,GLCylinder *cylinder);
  GLCylinders(int size);
  GLCylinders(){FSizeOfArray = FSize = 0;FCylinder = NULL;}
  ~GLCylinders();

public:
  void Initialize(int size);
  void Initialize(int size,GLCylinder *);
  int  GetSize(){return FSize;};
  int  GetNumber(){return FSize;};
  bool Add(GLCylinder &cylinder);      // change of size of cylinder
  bool Delete(GLCylinder &cylinder);   // change of size of cylinder
  int  Grow(int Delta);            // change of size of array
  int  Shrink(int Delta);          // change of size of array
  bool Clear();

  void SetRotX(float f){for(int i=0;i<FSize;i++) FCylinder[i].SetRotX(f);}
  void SetRotY(float f){for(int i=0;i<FSize;i++) FCylinder[i].SetRotY(f);}
  void SetRotZ(float f){for(int i=0;i<FSize;i++) FCylinder[i].SetRotZ(f);}
  void SetLocX(float f){for(int i=0;i<FSize;i++) FCylinder[i].SetLocX(f);}
  void SetLocY(float f){for(int i=0;i<FSize;i++) FCylinder[i].SetLocY(f);}
  void SetLocZ(float f){for(int i=0;i<FSize;i++) FCylinder[i].SetLocZ(f);}

  float GetRotX(){return FSize>0?FCylinder[0].GetRotX():0;}
  float GetRotY(){return FSize>0?FCylinder[0].GetRotY():0;}
  float GetRotZ(){return FSize>0?FCylinder[0].GetRotZ():0;}
  float GetLocX(){return FSize>0?FCylinder[0].GetLocX():0;}
  float GetLocY(){return FSize>0?FCylinder[0].GetLocY():0;}
  float GetLocZ(){return FSize>0?FCylinder[0].GetLocZ():0;}

  virtual GLCylinder & operator[](int);
  GLCylinders & operator=(GLCylinders &cylinders);
  bool operator==(GLCylinders &cylinders);
};

class GLSphere : public GLObject {
protected:
  float Rad;
  GLUquadricObj *QObj;
public:
  GLSphere();
  ~GLSphere(){if(QObj) {gluDeleteQuadric(QObj);QObj=NULL;}}
  void SetRad(float r){Rad = r;}
  void DrawGL();
};

class GLText : public GLObject {
protected:
  OpenGLFont3D *Font;
  OpenGLFont2D *Font2D;
  AnsiString Text;

public:
  GLText();
  ~GLText();

  void SetText(AnsiString &text){Text = text;}
  void SetFont(OpenGLFont3D *font){Font = font;}
  void SetFont2D(OpenGLFont2D *font){Font2D = font;}

  AnsiString &GetText(){return Text;}
  OpenGLFont3D *GetFont(){return Font;}
  OpenGLFont2D *GetFont2D(){return Font2D;}

  bool operator==(GLText &text){return Text==text.Text && Font == text.Font;}
  bool operator!=(GLText &text){return Text!=text.Text || Font != text.Font;}
  GLText &operator=(GLText &text){Font = text.Font;Text = text.Text;return *this;}

  void DrawGL();
  void DrawGL2D();
};

class GLColors {
protected:
  TColor *FColor;
  int FSize;//Actual size of colors
  int FSizeOfArray;
public:
  GLColors(int size,TColor *color);
  GLColors(int size);
  GLColors(){FSizeOfArray = FSize = 0;FColor = NULL;}
  ~GLColors();

public:
  void Initialize(int size);
  void Initialize(int size,TColor *);
  int  GetSize(){return FSize;};
  int  GetNumber(){return FSize;};
  bool Add(TColor &color);      // change of size of color
  bool Delete(TColor &color);   // change of size of color
  int  Grow(int Delta);            // change of size of array
  int  Shrink(int Delta);          // change of size of array
  bool Clear();

  virtual TColor & operator[](int);
  GLColors & operator=(GLColors &colors);
  bool operator==(GLColors &colors);
};

class GLColorLegend {
protected:
  int NumberOfColor;
  GLColors Color;
  MkFloat  Value;
  float MinValue, MaxValue;
  GLText Label;
  AnsiString Title, Unit;

protected:
  void MinMax();
  void Sort();
  bool Check();

public:
  GLColorLegend();

  void AddColorValue(TColor c, float t);
  void DelColorValue(TColor c, float t);

  void SetFont2D(OpenGLFont2D *font){Label.SetFont2D(font);}
  void SetTitle(AnsiString tit){Title = tit;}
  void SetUnit(AnsiString unit){Unit = unit;}

  TColor GetColor(float t);
  float GetRed(TColor c);
  float GetGreen(TColor c);
  float GetBlue(TColor c);
  OpenGLFont2D *GetFont(){return Label.GetFont2D();}
  AnsiString GetTitle(){return Title;}
  AnsiString GetUnit(){return Unit;}

  bool operator==(GLColorLegend &);
  bool operator!=(GLColorLegend &);
  GLColorLegend &operator=(GLColorLegend &);

  void DrawGL();
};

class GLDim : public GLObject {
protected:
  GLDimType DimType;
  MkLine DimLine;
  MkArc DimArc;
  MkPolygon DimPoly;
  float ArrowHead;
  float TextSize;
  GLText DimText;
  GLCone StartArrow, EndArrow;
public:
  GLDim();
  GLDim(int );
  ~GLDim(){}

  void SetDimType(GLDimType dt){DimType = dt;}
  void SetDimLine(MkLine &line){DimLine = line;DimText.SetLine(line);}
  void SetDimArc(MkArc &arc){DimArc = arc;}
  void SetDimPoly(MkPolygon &poly){DimPoly = poly;}
  void SetArrowHead(float ah);
  void SetTextSize(float size){TextSize = size;}
  void SetDimText(AnsiString &str){DimText.SetText(str);}
  void SetDimFont(OpenGLFont3D *font){DimText.SetFont(font);}
  void SetDimFont2D(OpenGLFont2D *font){DimText.SetFont2D(font);}

  GLDimType GetDimType(){return DimType;}
  MkLine &GetDimLine(){return DimLine;}
  MkArc &GetDimArc(){return DimArc;}
  MkPolygon &GetDimPoly(){return DimPoly;}
  float GetArrowHead(){return ArrowHead;}
  float GetTextSize(){return TextSize;}
  AnsiString &GetText(){return DimText.GetText();}
  OpenGLFont3D *GetFont(){return DimText.GetFont();}
  OpenGLFont2D *GetFont2D(){return DimText.GetFont2D();}

  bool operator==(GLDim &s);
  bool operator!=(GLDim &s);
  GLDim &operator=(GLDim &s);

  void DrawGL();
  void DrawLine();
  void DrawArc();
  void DrawPoly();
};

class GLDims : public GLObject {
protected:
  GLDim *FDim;
  int FSize;//Actual size of stratum
  int FSizeOfArray;
public:
  GLDims(int size,GLDim *strata);
  GLDims(int size);
  GLDims(){FSizeOfArray = FSize = 0;FDim = NULL;}
  ~GLDims();

  void SetDimLine(MkPolygon &line){for(int i=0;i<FSize;i++) FDim[i].SetDimPoly(line);}
  void SetDimArc(MkPolygon &arc){for(int i=0;i<FSize;i++) FDim[i].SetDimPoly(arc);}
  void SetDimPoly(MkPolygon &poly){for(int i=0;i<FSize;i++) FDim[i].SetDimPoly(poly);}

public:
  void Initialize(int size);
  void Initialize(int size,GLDim *);
  int  GetSize(){return FSize;};
  int  GetNumber(){return FSize;};
  bool Add(GLDim &strata);      // change of size of strata
  bool Delete(GLDim &strata);   // change of size of strata
  int  Grow(int Delta);            // change of size of array
  int  Shrink(int Delta);          // change of size of array
  bool Clear();

  virtual GLDim & operator[](int);
  GLDims & operator=(GLDims &stratum);
  bool operator==(GLDims &stratum);
  void DrawGL(){for(int i=0;i<FSize;i++) FDim[i].DrawGL();}
  void DrawModel();
  void DrawResult();
};

class GLBeam : public GLObject {
protected:
  GLBeamType BeamType;
  AnsiString Spec;
  float H, B, L, T1, T2;

public:
  GLBeam();
  GLBeam(int );

public:
  void SetBeamType(GLBeamType bt){BeamType = bt;}
  void SetBeamSpec(AnsiString str);
  void SetHeight(float f){H=f;}
  void SetWidth(float f){B=f;}
  void SetLength(float f){L=f;}
  void SetT1(float f){T1=f;}
  void SetT2(float f){T2=f;}

  GLBeamType GetBeamType(){return BeamType;}
  AnsiString GetBeamSpec(){return BeamType;}
  float GetHeight(){return H;}
  float GetWidth(){return B;}
  float GetLength(){return L;}
  float GetT1(){return T1;}
  float GetT2(){return T2;}

  bool operator==(GLBeam &beam);
  bool operator!=(GLBeam &beam);
  GLBeam &operator=(GLBeam &beam);

  void DrawGL();
  void DrawHBeam();
  void DrawIBeam();
  void DrawLBeam();
  void DrawCBeam();
  void DrawSheet();
};

class GLColorBeam : public GLBeam {
protected:
  int Division;
  float Scale;
  OpenGLFont3D *Font;
  OpenGLFont2D *Font2D;
  GLfloat matShi[1],matAmb[4],
          matDif[4],matSpc[4];

public:
  GLColorBeam();

  void SetDivision(int div){Division = div;}
  void SetScale(float scale){Scale = scale;}
  void SetFont(OpenGLFont3D *font){Font = font;}
  void SetFont2D(OpenGLFont2D *font){Font2D = font;}

  int  GetDivision(){return Division;}
  float GetScale(){return Scale;}

  void Mat(float r, float g, float b);
  void DrawGL(MkFloat &res, GLColorLegend &legend);
};

class GLBeams : public GLObject {
protected:
  GLBeam *FBeam;
  int FSize;//Actual size of stratum
  int FSizeOfArray;
public:
  GLBeams(int size,GLBeam *beam);
  GLBeams(int size);
  GLBeams(){FSizeOfArray = FSize = 0;FBeam = NULL;}
  ~GLBeams();

public:
  void Initialize(int size);
  void Initialize(int size,GLBeam *);
  int  GetSize(){return FSize;};
  int  GetNumber(){return FSize;};
  bool Add(GLBeam &beam);      // change of size of beam
  bool Delete(GLBeam &beam);   // change of size of beam
  int  Grow(int Delta);            // change of size of array
  int  Shrink(int Delta);          // change of size of array
  bool Clear();

  virtual GLBeam & operator[](int);
  GLBeams & operator=(GLBeams &beams);
  bool operator==(GLBeams &beams);
  void DrawGL(){for(int i=0;i<FSize;i++) FBeam[i].DrawGL();}
};

class GLPiles;
class GLCut : public GLObject {
protected:
//  GLSidePiles *LeftPiles;
//  GLSidePiles *RightPiles;
  GLPiles *Piles;
  MkPolygon CutLine;
  GLDim Dim;

public:
  GLCut(){Piles = NULL;}
  GLCut(int ){Piles = NULL;}

  void SetPiles(GLPiles &pile){Piles = &pile;}
  void SetCutLine(MkPolygon &poly){CutLine = poly;}

  GLPiles *GetPiles(){return Piles;}
  MkPolygon &GetCutLine(){return CutLine;}

  bool operator==(GLCut &s);
  bool operator!=(GLCut &s);
  GLCut &operator=(GLCut &s);

  void DrawGL(){}
  bool ImportStep(MkSection &sec);
};

class GLCuts : public GLObject {
protected:
  GLCut *FCut;
  int FSize;//Actual size of stratum
  int FSizeOfArray;
public:
  GLCuts(int size,GLCut *strata);
  GLCuts(int size);
  GLCuts(){FSizeOfArray = FSize = 0;FCut = NULL;}
  ~GLCuts();

  void SetCutLine(MkPolygon &poly){for(int i=0;i<FSize;i++) FCut[i].SetCutLine(poly);}

public:
  void Initialize(int size);
  void Initialize(int size,GLCut *);
  int  GetSize(){return FSize;};
  int  GetNumber(){return FSize;};
  bool Add(GLCut &strata);      // change of size of strata
  bool Delete(GLCut &strata);   // change of size of strata
  int  Grow(int Delta);            // change of size of array
  int  Shrink(int Delta);          // change of size of array
  bool Clear();

  virtual GLCut & operator[](int);
  GLCuts & operator=(GLCuts &cuts);
  bool operator==(GLCuts &cuts);
  void DrawGL(){for(int i=0;i<FSize;i++) FCut[i].DrawGL();}
};

class GLFill : public GLObject {
protected:
  GLPiles *Piles;
//  GLSidePiles *LeftPiles;
//  GLSidePiles *RightPiles;
  MkPolygon FillLine;
  GLDim Dim;

public:
  GLFill(){Piles = NULL;}
  GLFill(int ){Piles = NULL;}

  void SetPiles(GLPiles &pile){Piles = &pile;}
  void SetFillLine(MkPolygon &poly){FillLine = poly;}

  GLPiles *GetPiles(){return Piles;}
  MkPolygon &GetFillLine(){return FillLine;}

  bool operator==(GLFill &s);
  bool operator!=(GLFill &s);
  GLFill &operator=(GLFill &s);

  void DrawGL(){}
  bool ImportStep(MkSection &sec);  
};

class GLFills : public GLObject {
protected:
  GLFill *FFill;
  int FSize;//Actual size of stratum
  int FSizeOfArray;
public:
  GLFills(int size,GLFill *strata);
  GLFills(int size);
  GLFills(){FSizeOfArray = FSize = 0;FFill = NULL;}
  ~GLFills();

  void SetFillLine(MkPolygon &poly){for(int i=0;i<FSize;i++) FFill[i].SetFillLine(poly);}

public:
  void Initialize(int size);
  void Initialize(int size,GLFill *);
  int  GetSize(){return FSize;};
  int  GetNumber(){return FSize;};
  bool Add(GLFill &strata);      // change of size of strata
  bool Delete(GLFill &strata);   // change of size of strata
  int  Grow(int Delta);            // change of size of array
  int  Shrink(int Delta);          // change of size of array
  bool Clear();

  virtual GLFill & operator[](int);
  GLFills & operator=(GLFills &fills);
  bool operator==(GLFills &fills);
  void DrawGL(){for(int i=0;i<FSize;i++) FFill[i].DrawGL();}
};

class GLStrata : public GLObject {
protected:
  AnsiString Name;
  int Number;
  float Length;
  MkPolygon TopProf;
  MkPolygon BotProf;
  MkMesh FrontFace, BackFace;
  GLDim Dim;
  bool drawStrata, isBuilt;

protected:
  GLCut Cut;
  GLFill Fill;
  MkPolygons Polys;

public:
  GLStrata();
  GLStrata(int );
  ~GLStrata(){}

public:
  void SetTopProf(MkPolygon &p){TopProf=p; isBuilt = false;}
  void SetBotProf(MkPolygon &p){BotProf=p; isBuilt = false;}
  void SetLength(float l){Length = l; isBuilt = false;}
  void SetCut(GLCut &cut){Cut = cut; isBuilt = false;}
  void SetFill(GLFill &fill){Fill = fill; isBuilt = false;}
  void SetName(AnsiString &name){Name=name;}
  void SetDraw(bool f){drawStrata = f;}
  void SetBuilt(bool f){isBuilt = f;}
  void SetBaseFrom(MkLayers &lay);
  void SetNumber(int i){Number = i;}

  MkPolygon &GetTopProf(){return TopProf;}
  MkPolygon &GetBotProf(){return BotProf;}
  float GetLength(){return Length;}
  GLCut &GetCut(){return Cut;}
  GLFill &GetFill(){return Fill;}
  AnsiString &GetName(){return Name;}
  bool GetDraw(){return drawStrata;}
  bool GetBuilt(){return isBuilt;}
  int  GetNumber(){return Number;}

  bool operator==(GLStrata &s);
  bool operator!=(GLStrata &s);
  bool operator=(GLStrata &s);
  void DrawGL();
  void BuildGL();
  bool Import(MkSection &sec);
};

class GLStratum : public GLObject {
protected:
  GLStrata *FStrata;
  int FSize;//Actual size of stratum
  int FSizeOfArray;

protected:
  GLCut Cut;
  GLFill Fill;
  int Base;

public:
  GLStratum(int size,GLStrata *strata);
  GLStratum(int size);
  GLStratum(){FSizeOfArray = FSize = 0;FStrata = NULL;}
  ~GLStratum();

  void SetCut(GLCut &cut){Cut = cut;for(int i=0;i<FSize;i++) FStrata[i].SetCut(cut);}
  void SetFill(GLFill &fill){Fill = fill;for(int i=0;i<FSize;i++) FStrata[i].SetFill(fill);}
  void SetBase(int i){Base = 0<=i && i<FSize?i:FSize-1;}
  void SetLength(float l){for(int i=0;i<FSize;i++) FStrata[i].SetLength(l);}

  GLCut &GetCut(){return Cut;}
  GLFill &GetFill(){return Fill;}
  int GetBase(){return Base;}
  GLStrata &GetBaseStrata(){return FStrata[Base];}

public:
  void Initialize(int size);
  void Initialize(int size,GLStrata *);
  int  GetSize(){return FSize;};
  int  GetNumber(){return FSize;};
  bool Add(GLStrata &strata);      // change of size of strata
  bool Delete(GLStrata &strata);   // change of size of strata
  int  Grow(int Delta);            // change of size of array
  int  Shrink(int Delta);          // change of size of array
  bool Clear();

  virtual GLStrata & operator[](int);
  GLStratum & operator=(GLStratum &stratum);
  bool operator==(GLStratum &stratum);
  void DrawGL();
  bool Import(MkSection &sec);
  bool ClearMember();
};

class GLPile : public GLObject {
protected:
  GLSide Side;
//  MkFloat BaseDepth; // (0-1 , 0-no. of data)
  float RootDepth; // insert depth
  bool isBuilt;
  bool useDir;
  bool isClosed;
  MkFloat XDis;
  MkFloat AngDis;
  MkFloat Moment;
  MkFloat Shear;
  MkFloat Press;

  MkVector GlobalUp;
  MkPolygon Loc; // it doesn't have to be sequential(center-top of pile)
  MkLines Lines;

  GLStrata BaseStrata;
  GLResultType ResultType;
  GLBeam Beam;
  GLDim Dim;
public:
  GLPile();
  GLPile(int );  
  ~GLPile(){}
  float CalcDepth(float x);
  void CalcDir(int i, MkVector &dir);

public:
  void SetBeam(GLBeam &beam){Beam = beam; isBuilt = false;}
//  void SetBaseDepth(MkFloat &depth){BaseDepth = depth; isBuilt = false;}
  void SetRootDepth(float f){RootDepth = f; isBuilt = false;}
  void SetLoc(MkPolygon &loc){Loc=loc; isBuilt = false;}
  void SetGlobalUp(MkVector &up){GlobalUp = up;}
  void SetBuilt(bool b){isBuilt = b;}
  void SetBase(GLStrata &base){BaseStrata = base;}
  void SetSide(GLSide ws){Side = ws;}
  void SetClose(bool b){isClosed = b;}
  void SetUseDir(bool b){useDir = b;}
  void SetXDis(MkFloat &a){XDis.CopyFrom(a);}
  void SetAngDis(MkFloat &a){AngDis.CopyFrom(a);}
  void SetMoment(MkFloat &a){Moment.CopyFrom(a);}
  void SetShear(MkFloat &a){Shear.CopyFrom(a);}
  void SetPress(MkFloat &a){Press.CopyFrom(a);}
  void SetResultType(GLResultType rt){ResultType = rt;}
  void SetDim(GLDim &dim){Dim = dim;}

  bool operator==(GLPile &obj);
  bool operator!=(GLPile &obj);
  GLPile &operator=(GLPile &obj);

  GLBeam    &GetBeam(){return Beam;}
  float     GetRootDepth(){return RootDepth;}
  MkPolygon &GetLoc(){return Loc;}
  MkVector  &GetGlobalUp(){return GlobalUp;}
  GLStrata  &GetBase(){return BaseStrata;}
  GLSide GetSide(){return Side;}
  bool GetClosed(){return isClosed;}
  bool GetUseDir(){return useDir;}
  MkFloat &GetXDis(){return XDis;}
  MkFloat &GetAngDis(){return AngDis;}
  MkFloat &GetMoment(){return Moment;}
  MkFloat &GetShear(){return Shear;}
  MkFloat &GetPress(){return Press;}
  GLResultType GetResultType(){return ResultType;}
  GLDim &GetDim(){return Dim;}

  void DrawGL();
  void DrawModel();
  void DrawResult();
  bool Import(MkSection &sec);
  bool ImportStep(MkSection &sec);
  bool ClearMember();
};

class GLPiles : public GLObject {
protected:
  GLPile *FPile;
  int FSize;//Actual size of entities
  int FSizeOfArray;
#ifdef __BCPLUSPLUS__
  TColor Color;
#endif
public:
  GLPiles(int size,GLPile *ent);
  GLPiles(int size);
  GLPiles(){FSizeOfArray = FSize = 0;FPile = NULL;}
   ~GLPiles();
  virtual void Initialize(int size);
  virtual void Initialize(int size,GLPile *);

  bool Add(GLPile &pile);  // change of size of ground
  bool Add(int index,GLPile &pile);
  bool Delete(GLPile &pile);  // change of size of ground
  bool Delete(int index);
  int Grow(int Delta);            // change of size of array
  int Shrink(int Delta);          // change of size of array
  bool Clear();


  int GetSize(){return FSize;}
  int GetNumber(){return FSize;}

  virtual GLPile & operator[](int);
  GLPiles & operator=(GLPiles &piles);
  bool operator==(GLPiles &piles);
#ifdef __BCPLUSPLUS__
  void Import(MkGlobalVar &globalvar, int sec);
#else
#endif

  void DrawGL() {
    for(int i=0;i<FSize;i++)
      FPile[i].DrawGL();
  }
  void Out(char *fname);
  bool Import(MkSection &sec);
  bool ImportStep(MkSection &sec);
  bool ClearMember();
};

/*
class GLMidPiles : public GLObject {
protected:
  GLBeam Beam;
//  MkFloat BaseDepth; // (0-1 , 0-no. of data)
  float RootDepth;
  MkVector GlobalUp;
  MkPolygon Loc; // it doesn't have to be sequential(center-top of pile)
  MkLines Lines;
  bool isBuilt;
  GLDim Dim;
  GLStrata BaseStrata;

public:
  GLMidPiles();
  ~GLMidPiles(){}
  float CalcDepth(float x);

public:
  void SetBeam(GLBeam &beam){Beam = beam; isBuilt = false;}
//  void SetBaseDepth(MkFloat &depth){BaseDepth = depth; isBuilt = false;}
  void SetRootDepth(float f){RootDepth = f; isBuilt = false;}
  void SetLoc(MkPolygon &loc){Loc=loc; isBuilt = false;}
  void SetGlobalUp(MkVector &up){GlobalUp = up;}
  void SetBuilt(bool b){isBuilt = b;}
  void SetBase(GLStrata &base){BaseStrata = base;}

  bool operator==(GLMidPiles &obj);
  bool operator!=(GLMidPiles &obj);
  GLMidPiles &operator=(GLMidPiles &obj);

  GLBeam    &GetBeam(){return Beam;}
  float     GetRootDepth(){return RootDepth;}
  MkPolygon &GetLoc(){return Loc;}
  MkVector  &GetGlobalUp(){return GlobalUp;}
  GLStrata  &GetBase(){return BaseStrata;}

  void DrawGL();
  bool Import(MkSection &sec);
};

class GLSidePiles : public GLMidPiles { // Loc should be sequential(center-top of pile)
protected:
  GLSide Side;
  GLResultType ResultType;
  bool useDir;
  bool isClosed;
  MkFloat XDis;
  MkFloat AngDis;
  MkFloat Moment;
  MkFloat Shear;
  MkFloat Press;
  GLDim Dim;

public:
  GLSidePiles();
  ~GLSidePiles(){}
  void CalcDir(int i, MkVector &dir);

public:
  void SetSide(GLSide ws){Side = ws;}
  void SetClose(bool b){isClosed = b;}
  void SetUseDir(bool b){useDir = b;}
  void SetXDis(MkFloat &a){XDis.CopyFrom(a);}
  void SetAngDis(MkFloat &a){AngDis.CopyFrom(a);}
  void SetMoment(MkFloat &a){Moment.CopyFrom(a);}
  void SetShear(MkFloat &a){Shear.CopyFrom(a);}
  void SetPress(MkFloat &a){Press.CopyFrom(a);}
  void SetResultType(GLResultType rt){ResultType = rt;}
  void SetDim(GLDim &dim){Dim = dim;}

  GLSide GetSide(){return Side;}
  bool GetClosed(){return isClosed;}
  bool GetUseDir(){return useDir;}
  MkFloat &GetXDis(){return XDis;}
  MkFloat &GetAngDis(){return AngDis;}
  MkFloat &GetMoment(){return Moment;}
  MkFloat &GetShear(){return Shear;}
  MkFloat &GetPress(){return Press;}
  GLResultType GetResultType(){return ResultType;}
  GLDim &GetDim(){return Dim;}

  bool operator==(GLSidePiles &obj);
  bool operator!=(GLSidePiles &obj);
  GLSidePiles &operator=(GLSidePiles &obj);

  void DrawGL();
  void DrawModel();
  void DrawResult();
  bool Import(MkSection &sec);
};
*/
class GLWale : public GLObject {
protected:
  GLSide Side;
  GLBeams Beam;
  MkFloat InstallDepth;
  MkPolygon Loc;
  GLPile *Pile;
  GLDim Dim;
public:
  GLWale();
  GLWale(int );

  void SetBeam(GLBeams &beam){Beam = beam;}
  void SetInstallDepth(MkFloat &depth){InstallDepth.CopyFrom(depth);}
  void SetLoc(MkPolygon &poly)
    {
      Loc = poly;
    }
  void SetPile(GLPile &piles){Pile = &piles;}
  void SetSide(GLSide side){Side = side;}

  GLBeams &GetBeam(){return Beam;}
  MkFloat & GetInstallDepth(){return InstallDepth;}
  MkPolygon & GetLoc()
    {
      return Loc;
    }
  GLPile * GetPile(){return Pile;}
  GLSide GetSide(){return Side;}

  bool operator==(GLWale&);
  bool operator!=(GLWale&);
  GLWale & operator=(GLWale&);

  void DrawGL();
  void DrawModel();
  void DrawResult();
  bool Import(MkSection &sec);
  bool ImportStep(MkSection &sec);
  bool ClearMember();
};

class GLWales : public GLObject {
protected:
  GLWale *FWale;
  int FSize;//Actual size of entities
  int FSizeOfArray;
#ifdef __BCPLUSPLUS__
  TColor Color;
#endif
public:
  GLWales(int size,GLWale *ent);
  GLWales(int size);
  GLWales(){FSizeOfArray = FSize = 0;FWale = NULL;}
   ~GLWales();
  virtual void Initialize(int size);
  virtual void Initialize(int size,GLWale *);

  bool Add(GLWale &wale);  // change of size of ground
  bool Add(int index,GLWale &wale);
  bool Delete(GLWale &wale);  // change of size of ground
  bool Delete(int index);
  int Grow(int Delta);            // change of size of array
  int Shrink(int Delta);          // change of size of array
  bool Clear();

  void SetPile(GLPile &pile){for(int i=0;i<FSize;i++) FWale[i].SetPile(pile);}
  int GetSize(){return FSize;}
  int GetNumber(){return FSize;}

  virtual GLWale & operator[](int);
  GLWales & operator=(GLWales &wales);
  bool operator==(GLWales &wales);
#ifdef __BCPLUSPLUS__
  void Import(MkGlobalVar &globalvar, int sec);
#else
#endif
  void Out(char *fname);
  bool Import(MkSection &sec);
  bool ImportStep(MkSection &sec);
  void DrawGL();
  bool ClearMember();
};

class GLStruts : public GLObject {
protected:
  GLBeam Beam;
  MkFloat InstallDepth, Spacing;
  float Start, Length;
  GLWales *Wales;
  bool isBuilt;
  MkFloat AxialForce;
  GLDim Dim;

public:
  GLStruts();
  void SetBeam(GLBeam &bt){Beam = bt; isBuilt = false;}
  void SetInstallDepth(MkFloat &is){InstallDepth.CopyFrom(is); isBuilt = false;}
  void SetStart(float start){Start = start; isBuilt = false;}
  void SetLength(float len){Length = len; isBuilt = false;}
  void SetSpacing(MkFloat &spacing){Spacing.CopyFrom(spacing); isBuilt = false;}
  void SetAxialForce(MkFloat &axf){AxialForce.CopyFrom(axf); isBuilt = false;}
  void SetWales(GLWales &wale){Wales = &wale; isBuilt = false;}
  void SetBuilt(bool flag){isBuilt = flag;}

  GLBeam &GetBeam(){return Beam;}
  MkFloat &GetInstallDepth(){return InstallDepth;}
  float GetStart(){return Start;}
  float GetLength(){return Length;}
  MkFloat &GetSpacing(){return Spacing;}
  MkFloat &GetAxialForce(){return AxialForce;}
  GLWales *GetWales(){return Wales;}
  bool GetBuilt(){return isBuilt;}

  void DrawGL();
  void DrawModel();
  void DrawResult();
  bool Import(MkSection &sec);
  bool ImportStep(MkSection &sec);
  bool ClearMember();
};

class GLWoodWall : public GLObject {  // wooden board
protected:
  GLWoodType WoodType;
  float Height, Thick, InstallDepth;
  GLPile *Pile;
public:
  GLWoodWall();

  void SetWoodType(GLWoodType wt){WoodType=wt;}
  void SetHeight(float h){Height=h;}
  void SetThick(float t){Thick=t;}
  void SetInstallDepth(float d){InstallDepth = d;}
  void SetPile(GLPile &pile){Pile = &pile;}

  GLWoodType GetWoodType(){return WoodType;}
  float GetHeight(){return Height;}
  float GetThick(){return Thick;}
  float GetInstallDepth(){return InstallDepth;}
  GLPile *GetPile(){return Pile;}

  void DrawGL();
  bool Import(MkSection &sec);
  bool ClearMember();
};

class GLConcWall : public GLObject {
protected:
  GLPile *Pile;
public:
  GLConcWall();
  void SetPile(GLPile &pile){Pile = &pile;}

  GLPile *GetPile(){return Pile;}

  void DrawGL();
  bool Import(MkSection &sec);
  bool ClearMember();
};

class GLReinforce : public GLObject {
protected:
  GLSuptType SuptType;

public:
  GLReinforce();
  ~GLReinforce(){}

  void SetSuptType(GLSuptType st){SuptType = st;}
  GLSuptType GetSuptType(){return SuptType;}

  void DrawGL();
  bool Import(MkSection &sec);
  bool ClearMember();
};

class GLWall : public GLObject {
protected:
  GLWallType WallType;
  GLSide Side;
  GLConcWall ConcWall;
  GLWoodWall WoodWall;
  GLReinforce Reinforce;
  GLPile *Pile;
public:
  GLWall();
  GLWall(int);

public:
  void SetWallType(GLWallType wt){WallType=wt;}
  void SetSide(GLSide ws){Side=ws;}
  void SetConcWall(GLConcWall cw){ConcWall=cw;}
  void SetWoodWall(GLWoodWall ww){WoodWall=ww;}
  void SetReinforce(GLReinforce &rf){Reinforce=rf;}
  void SetPile(GLPile &pile)
    {Pile = &pile; WoodWall.SetPile(pile); ConcWall.SetPile(pile);}

  GLWallType GetWallType(){return WallType;}
  GLSide GetSide(){return Side;}
  GLConcWall &GetConcWall(){return ConcWall;}
  GLWoodWall &GetWoodWall(){return WoodWall;}
  GLReinforce &GetReinforce(){return Reinforce;}
  GLPile *GetPile(){return Pile;}

  bool operator==(GLWall&);
  bool operator!=(GLWall&);
  GLWall & operator=(GLWall&);

  void DrawGL();
  bool Import(MkSection &sec);
  bool ClearMember();
};

class GLWalls :public GLObject {
protected:
  GLWall *FWall;
  int FSize;//Actual size of entities
  int FSizeOfArray;
#ifdef __BCPLUSPLUS__
  TColor Color;
#endif
public:
  GLWalls(int size,GLWall *ent);
  GLWalls(int size);
  GLWalls(){FSizeOfArray = FSize = 0;FWall = NULL;}
   ~GLWalls();
  virtual void Initialize(int size);
  virtual void Initialize(int size,GLWall *);

  bool Add(GLWall &wall);  // change of size of ground
  bool Add(int index,GLWall &wall);
  bool Delete(GLWall &wall);  // change of size of ground
  bool Delete(int index);
  int Grow(int Delta);            // change of size of array
  int Shrink(int Delta);          // change of size of array
  bool Clear();

  int GetSize(){return FSize;}
  int GetNumber(){return FSize;}

  virtual GLWall & operator[](int);
  GLWalls & operator=(GLWalls &walls);
  bool operator==(GLWalls &walls);
#ifdef __BCPLUSPLUS__
  void Import(MkGlobalVar &globalvar, int sec);
#else
#endif
  void Out(char *fname);
  bool Import(MkSection &sec);
  bool ClearMember();
};

class GLAnchor : public GLObject {
protected:
  GLSide Side;
  GLAnchorHangerType HangerType;
  float Diameter,Start;
  MkFloat FreeLen, StickLen, Angle;
  MkFloat InstallDepth;
  GLWale *Wale;
  GLCylinder Anchor,Grout;
  MkFloat AxialForce;
  GLDim Dim;

public:
  GLAnchor();
  GLAnchor(int);

  void SetHangerType(GLAnchorHangerType aht){HangerType = aht;}
  void SetDiameter(float dia){Diameter = dia;Anchor.SetBaseRad(dia/2);
                              Anchor.SetTopRad(dia/2);Grout.SetBaseRad(dia);
                              Grout.SetTopRad(dia); }
  void SetFreeLen(MkFloat &freelen){FreeLen.CopyFrom(freelen);}
  void SetStickLen(MkFloat &sticklen){StickLen.CopyFrom(sticklen);}
  void SetAngle(MkFloat &angle){Angle.CopyFrom(angle);}
  void SetInstallDepth(MkFloat &depth){InstallDepth.CopyFrom(depth);}
  void SetWale(GLWale &wale){Wale = &wale;}
  void SetStart(float start){Start = start;}
  void SetSide(GLSide side){Side = side;}

  GLAnchorHangerType GetHangerType(){return HangerType;}
  float GetDiameter(){return Diameter;}
  MkFloat &GetFreeLen(){return FreeLen;}
  MkFloat &GetStickLen(){return StickLen;}
  MkFloat &GetAngle(){return Angle;}
  MkFloat &GetInstallDepth(){return InstallDepth;}
  GLWale *GetWale(){return Wale;}
  float GetStart(){return Start;}
  GLSide GetSide(){return Side;}

  bool operator==(GLAnchor&);
  bool operator!=(GLAnchor&);
  GLAnchor & operator=(GLAnchor&);

  void DrawGL();
  void DrawModel();
  void DrawResult();
  bool Import(MkSection &sec);
  bool ImportStep(MkSection &sec);
  bool ClearMember();
};

class GLAnchors : public GLObject {
protected:
  GLAnchor *FAnchor;
  int FSize;//Actual size of entities
  int FSizeOfArray;
#ifdef __BCPLUSPLUS__
  TColor Color;
#endif
public:
  GLAnchors(int size,GLAnchor *ent);
  GLAnchors(int size);
  GLAnchors(){FSizeOfArray = FSize = 0;FAnchor = NULL;}
   ~GLAnchors();
  virtual void Initialize(int size);
  virtual void Initialize(int size,GLAnchor *);

  bool Add(GLAnchor &anchor);  // change of size of ground
  bool Add(int index,GLAnchor &anchor);
  bool Delete(GLAnchor &anchor);  // change of size of ground
  bool Delete(int index);
  int Grow(int Delta);            // change of size of array
  int Shrink(int Delta);          // change of size of array
  bool Clear();

  int GetSize(){return FSize;}
  int GetNumber(){return FSize;}

  virtual GLAnchor & operator[](int);
  GLAnchors & operator=(GLAnchors &anchors);
  bool operator==(GLAnchors &anchors);
#ifdef __BCPLUSPLUS__
  void Import(MkGlobalVar &globalvar, int sec);
#else
#endif
  void Out(char *fname);
  void DrawGL()
  {
    int i;
    for (i=0;i<FSize;i++)
      FAnchor[i].DrawGL();
  }
  bool Import(MkSection &sec);
  bool ImportStep(MkSection &sec);
  bool ClearMember();
};

class GLRockBolt : public GLObject {
protected:
  GLSide Side;
  float Diameter;
  float Start;
  MkFloat InstallDepth,Length;
  GLCylinder Bolt;
  GLPile *Pile;
  MkFloat AxialForce;
  GLDim Dim;

public:
  GLRockBolt();
  GLRockBolt(int);

  void SetDiameter(float dia){Diameter = dia;Bolt.SetBaseRad(dia/2);
                                             Bolt.SetTopRad(dia/2);}
  void SetLength(MkFloat &len){Length.CopyFrom(len);}
  void SetInstallDepth(MkFloat &depth){InstallDepth.CopyFrom(depth);}
  void SetPile(GLPile &pile){Pile = &pile;}
  void SetStart(float start){Start = start;}
  void SetSide(GLSide side){Side=side;}

  float GetDiameter(){return Diameter;}
  MkFloat &GetLength(){return Length;}
  MkFloat &GetInstallDepth(){return InstallDepth;}
  GLPile *GetPile(){return Pile;}
  float GetStart(){return Start;}
  GLSide GetSide(){return Side;}

  bool operator==(GLRockBolt&);
  bool operator!=(GLRockBolt&);
  GLRockBolt & operator=(GLRockBolt&);

  void DrawGL();
  void DrawModel();
  void DrawResult();
  bool Import(MkSection &sec);
  bool ImportStep(MkSection &sec);
  bool ClearMember();
};

class GLRockBolts : public GLObject {
protected:
  GLRockBolt *FRockBolt;
  int FSize;//Actual size of entities
  int FSizeOfArray;
#ifdef __BCPLUSPLUS__
  TColor Color;
#endif
public:
  GLRockBolts(int size,GLRockBolt *ent);
  GLRockBolts(int size);
  GLRockBolts(){FSizeOfArray = FSize = 0;FRockBolt = NULL;}
   ~GLRockBolts();
  virtual void Initialize(int size);
  virtual void Initialize(int size,GLRockBolt *);

  bool Add(GLRockBolt &rockbolt);  // change of size of ground
  bool Add(int index,GLRockBolt &rockbolt);
  bool Delete(GLRockBolt &rockbolt);  // change of size of ground
  bool Delete(int index);
  int Grow(int Delta);            // change of size of array
  int Shrink(int Delta);          // change of size of array
  bool Clear();

  int GetSize(){return FSize;}
  int GetNumber(){return FSize;}

  virtual GLRockBolt & operator[](int);
  GLRockBolts & operator=(GLRockBolts &rockbolts);
  bool operator==(GLRockBolts &rockbolts);
#ifdef __BCPLUSPLUS__
  void Import(MkGlobalVar &globalvar, int sec);
#else
#endif
  void Out(char *fname);
  void DrawGL()
  {
    int i;
    for(i=0;i<FSize;i++)
      FRockBolt[i].DrawGL();
  }
  bool Import(MkSection &sec);
  bool ImportStep(MkSection &sec);
  bool ClearMember();
};

class GLMainBeam;
class GLMainBeamProp : public GLObject {
protected:
  GLSide Side;
  GLBeam Beam;
  float Depth;
  GLWale *Wale;
  GLMainBeam *MainBeam;
  GLDim Dim;

public:
  GLMainBeamProp();
  GLMainBeamProp(int);

  void SetBeam(GLBeam bt){Beam = bt;}
  void SetWale(GLWale &wale){Wale = &wale;}
  void SetMainBeam(GLMainBeam &mbeam){MainBeam = &mbeam;}
  void SetDepth(float depth){Depth = depth;}
  void SetSide(GLSide side){Side = side;}

  GLBeam &GetBeam(){return Beam;}
  GLWale *GetWale(){return Wale;}
  GLMainBeam *GetMainBeam(){return MainBeam;}
  float GetDepth(){return Depth;}
  GLSide GetSide(){return Side;}

  bool operator==(GLMainBeamProp&);
  bool operator!=(GLMainBeamProp&);
  GLMainBeamProp & operator=(GLMainBeamProp&);

  void DrawGL();
  bool Import(MkSection &sec);
  bool ClearMember();
};

class GLMainBeamProps : public GLObject {
protected:
  GLMainBeamProp *FMainBeamProp;
  int FSize;//Actual size of entities
  int FSizeOfArray;
#ifdef __BCPLUSPLUS__
  TColor Color;
#endif
public:
  GLMainBeamProps(int size,GLMainBeamProp *ent);
  GLMainBeamProps(int size);
  GLMainBeamProps(){FSizeOfArray = FSize = 0;FMainBeamProp = NULL;}
   ~GLMainBeamProps();
  virtual void Initialize(int size);
  virtual void Initialize(int size,GLMainBeamProp *);

  bool Add(GLMainBeamProp &mainbeamprop);  // change of size of ground
  bool Add(int index,GLMainBeamProp &mainbeamprop);
  bool Delete(GLMainBeamProp &mainbeamprop);  // change of size of ground
  bool Delete(int index);
  int Grow(int Delta);            // change of size of array
  int Shrink(int Delta);          // change of size of array
  bool Clear();


  int GetSize(){return FSize;}
  int GetNumber(){return FSize;}

  virtual GLMainBeamProp & operator[](int);
  GLMainBeamProps & operator=(GLMainBeamProps &mainbeamprops);
  bool operator==(GLMainBeamProps &mainbeamprops);
#ifdef __BCPLUSPLUS__
  void Import(MkGlobalVar &globalvar, int sec);
#else
#endif
  void Out(char *fname);
  bool Import(MkSection &sec);
  bool ClearMember();
};

class GLDeck;
class GLMainBeam : public GLObject {
protected:
  GLBeam Beam;
  float Start, Spacing, Depth,Length;
  GLMainBeamProps *Props;
  GLDeck *Deck;
  MkLines Lines;
  bool isBuilt;
  GLDim Dim;

public:
  GLMainBeam();

  void SetBeam(GLBeam bt){Beam = bt;  isBuilt = false;}
  void SetStart(float s){Start = s; isBuilt = false;}
  void SetSpacing(float s){Spacing = s; isBuilt = false;}
  void SetDepth(float d){Depth = d; isBuilt = false;}
  void SetProps(GLMainBeamProps &props){Props = &props; isBuilt = false;}
  void SetDeck(GLDeck &deck){Deck = &deck;}
  void SetBuilt(bool b){isBuilt = b;}

  GLBeam &GetBeam(){return Beam;}
  float GetStart(){return Start;}
  float GetSpacing(){return Spacing;}
  float GetDepth(){return Depth;}
  GLMainBeamProps *GetProp(){return Props;}
  GLDeck *GetDeck(){return Deck;}
  MkLines &GetLines(){return Lines;}

  void DrawGL();
  bool Import(MkSection &sec);
  bool ClearMember();
};

class GLDeck : public GLObject {
protected:
  GLDeckType DeckType;
  float Height, Width, Thick;
  GLMainBeam *MainBeam;
  GLCube Deck;
  MkLines Lines;
  GLDim Dim;

public:
  GLDeck();

  void SetDeckType(GLDeckType dt){DeckType = dt;}
  void SetHeight(float h){Deck.SetHeight(h);Height=h;}
  void SetWidth(float w){Deck.SetWidth(w);Width=w;}
  void SetThick(float t){Deck.SetThick(t);Thick=t;}
  void SetMainBeam(GLMainBeam &mb){MainBeam=&mb;}

  GLDeckType GetDeckType(){return DeckType;}
  float GetHeight(){return Deck.GetHeight();}
  float GetWidth(){return Deck.GetWidth();}
  float GetThick(){return Deck.GetThick();}
  GLMainBeam *GetMainBeam(){return MainBeam;}

  void DrawGL();
  bool Import(MkSection &sec);
  bool ClearMember();
};

class GLBracket : public GLObject {  // ������
protected:
  GLBracketType BracketType;
  float Diameter; // for steel rod
  float Height, Width, Thick; // for steel beam
  GLStruts *RefStrut;
public:
  GLBracket();
  void SetStruts(GLStruts &strut){RefStrut = &strut;}

  GLStruts *GetStruts(){return RefStrut;}

  void DrawGL();
  bool Import(MkSection &sec);
  bool ClearMember();
};

class GLPieceBracket : public GLObject {
protected:
  GLSide Side;
  GLBeam Beam;
  GLMainBeamProp *Prop;
  MkLines Lines;
  bool isBuilt;
public:
  GLPieceBracket();
  GLPieceBracket(int);

  void SetBeam(GLBeam bt){Beam = bt;}
  void SetProp(GLMainBeamProp &prop){Prop = &prop;}
  void SetBuilt(bool b){isBuilt = b;}
  void SetSide(GLSide side){Side = side;}

  GLBeam &GetBeam(){return Beam;}
  GLMainBeamProp *GetProp(){return Prop;}
  bool GetBuilt(){return isBuilt;}
  GLSide GetSide(){return Side;}

  bool operator==(GLPieceBracket &obj);
  bool operator!=(GLPieceBracket &obj);
  GLPieceBracket &operator=(GLPieceBracket &obj);

  void DrawGL();
  bool Import(MkSection &sec);
  bool ClearMember();
};

class GLPieceBrackets : public GLObject {
protected:
  GLPieceBracket *FPieceBracket;
  int FSize;//Actual size of entities
  int FSizeOfArray;
#ifdef __BCPLUSPLUS__
  TColor Color;
#endif
public:
  GLPieceBrackets(int size,GLPieceBracket *ent);
  GLPieceBrackets(int size);
  GLPieceBrackets(){FSizeOfArray = FSize = 0;FPieceBracket = NULL;}
   ~GLPieceBrackets();
  virtual void Initialize(int size);
  virtual void Initialize(int size,GLPieceBracket *);

  bool Add(GLPieceBracket &piecebracket);  // change of size of ground
  bool Add(int index,GLPieceBracket &piecebracket);
  bool Delete(GLPieceBracket &piecebracket);  // change of size of ground
  bool Delete(int index);
  int Grow(int Delta);            // change of size of array
  int Shrink(int Delta);          // change of size of array
  bool Clear();

  int GetSize(){return FSize;}
  int GetNumber(){return FSize;}

  virtual GLPieceBracket & operator[](int);
  GLPieceBrackets & operator=(GLPieceBrackets &piecebrackets);
  bool operator==(GLPieceBrackets &piecebrackets);
#ifdef __BCPLUSPLUS__
  void Import(MkGlobalVar &globalvar, int sec);
#else
#endif
  void Out(char *fname);
  bool Import(MkSection &sec);
  bool ClearMember();

};

class GLSlab : public GLObject {
protected:
  MkPolygon Prof;
  GLDim Dim;

public:
  GLSlab();

  void SetProf(MkPolygon &poly) {Prof = poly;}

  MkPolygon &GetProf(){return Prof;}

  void DrawGL();
  bool Import(MkSection &sec);
};

class GLWater : public GLObject {
protected:
  MkPolygon WaterTable;
  GLDim Dim;

public:
  GLWater();

  void SetWaterTable(MkPolygon &poly){WaterTable = poly;}

  MkPolygon &GetWaterTable(){return WaterTable;}

  void DrawGL();
  bool Import(MkSection &sec);
  bool ClearMember();
};

class GLLoad : public GLObject {
protected:
  MkPolygon Load;
  GLDim Dim;
public:
  GLLoad();

  void SetLoad(MkPolygon &poly){Load = poly;}

  void DrawGL();
  bool ClearMember();
};

class GLLoads : public GLObject {

public:
  GLLoads();
  void DrawGL();
  bool Import(MkSection &sec);
  bool ClearMember();
};

class GLEarthWall {
protected:
  GLStratum Stratum;
//  GLSidePiles LeftPiles,RightPiles;
//  GLMidPiles MidPiles;
  GLPiles Piles;
  GLWales Wales;
  GLStruts Struts;
  GLAnchors Anchors;
  GLRockBolts Bolts;
  GLWalls Walls;
  GLDeck Deck;
  GLMainBeam MainBeam;
  GLMainBeamProps Props;
  GLPieceBrackets PieceBracket;
  GLWater Water;
  GLLoads Loads;
  GLDims  Dims;
  GLDrawMode DrawMode;
  GLResultType ResultType;
  GLColorLegend LegendXDis,LegendAngDis, LegendMoment, LegendShear,
                LegendAxial, LegendPress;

  bool drawStratum;
  bool drawPiles;
  bool drawWales;
  bool drawStruts;
  bool drawAnchors;
  bool drawBolts;
  bool drawWalls;
  bool drawDeck;
  bool drawMainBeam;
  bool drawProps;
  bool drawPieceBracket;
  bool drawWater;
  bool drawLoads;
  bool drawDims;
  bool drawLegendXDis,drawLegendAngDis, drawLegendMoment, drawLegendShear,
       drawLegendAxial, drawLegendPress;

  bool isStratumDefined;
  bool isPilesDefined;
  bool isWalesDefined;
  bool isStrutsDefined;
  bool isAnchorsDefined;
  bool isBoltsDefined;
  bool isWallDefined;
  bool isDeckDefined;
  bool isMainBeamDefined;
  bool isPropsDefined;
  bool isPieceBracketDefined;
  bool isWaterDefined;
  bool isLoadsDefined;
  bool isDimsDefined;
  bool isLegendXDisDefined, isLegendAngDisDefined, isLegendMomentDefined,
       isLegendShearDefined, isLegendAxialDefined, isLegendPressDefined;
  float Dis, RotX, RotY;
public:
  GLEarthWall();
  GLEarthWall(int );
  ~GLEarthWall(){}

  bool Initialize();
  void SetStratum(GLStratum &a){Stratum = a;}
  void SetPiles(GLPiles &a){Piles = a;}
//  void SetLeftPiles(GLSidePiles &a){LeftPiles = a;}
//  void SetRightPiles(GLSidePiles &a){RightPiles = a;}
//  void SetMidPiles(GLMidPiles &a){MidPiles = a;}
  void SetWales(GLWales &a){Wales = a;}
  void SetStruts(GLStruts &a){Struts = a;}
  void SetAnchors(GLAnchors &a){Anchors = a;}
  void SetBolts(GLRockBolts &a){Bolts = a;}
  void SetWalls(GLWalls &a){Walls = a;}
  void SetDeck(GLDeck &a){Deck = a;}
  void SetMainBeam(GLMainBeam &a){MainBeam = a;}
  void SetProps(GLMainBeamProps &a){Props = a;}
  void SetPieceBrackets(GLPieceBrackets &a){PieceBracket = a;}
  void SetWater(GLWater &a){Water = a;}
  void SetLoads(GLLoads &a){Loads = a;}
  void SetDims(GLDims &a){Dims = a;}
  void SetDrawMode(GLDrawMode &a);
  void SetLegendXDis(GLColorLegend &cl){LegendXDis = cl;}
  void SetLegendAngDis(GLColorLegend &cl){LegendAngDis = cl;}
  void SetLegendMoment(GLColorLegend &cl){LegendMoment = cl;}
  void SetLegendShear(GLColorLegend &cl){LegendShear = cl;}
  void SetLegendAxial(GLColorLegend &cl){LegendAxial = cl;}
  void SetLegendPress(GLColorLegend &cl){LegendPress = cl;}
  void SetDis(float dis){Dis = dis;}
  void SetRotX(float rot){RotX = rot;}
  void SetRotY(float rot){RotY = rot;}

  void EnableStratum(bool a){drawStratum = a;}
  void EnablePiles(bool a){drawPiles = a;}
  void EnableWales(bool a){drawWales = a;}
  void EnableStruts(bool a){drawStruts = a;}
  void EnableAnchors(bool a){drawAnchors = a;}
  void EnableBolts(bool a){drawBolts = a;}
  void EnableWalls(bool a){drawWalls = a;}
  void EnableDeck(bool a){drawDeck = a;}
  void EnableMainBeam(bool a){drawMainBeam = a;}
  void EnableProps(bool a){drawProps = a;}
  void EnablePieceBrackets(bool a){drawPieceBracket = a;}
  void EnableWater(bool a){drawWater = a;}
  void EnableLoads(bool a){drawLoads = a;}
  void EnableDims(bool a){drawDims = a;}
  void EnableLegendXDis(bool a){drawLegendXDis = a;}
  void EnableLegendAngDis(bool a){drawLegendAngDis = a;}
  void EnableLegendMoment(bool a){drawLegendMoment = a;}
  void EnableLegendShear(bool a){drawLegendShear = a;}
  void EnableLegendAxial(bool a){drawLegendAxial = a;}
  void EnableLegendPress(bool a){drawLegendPress = a;}

  void DefineStratum(bool a){isStratumDefined = a;}
  void DefinePiles(bool a){isPilesDefined = a;}
  void DefineWales(bool a){isWalesDefined = a;}
  void DefineStruts(bool a){isStrutsDefined = a;}
  void DefineAnchors(bool a){isAnchorsDefined = a;}
  void DefineBolts(bool a){isBoltsDefined = a;}
  void DefineWall(bool a){isWallDefined = a;}
  void DefineDeck(bool a){isDeckDefined = a;}
  void DefineMainBeam(bool a){isMainBeamDefined = a;}
  void DefineProps(bool a){isPropsDefined = a;}
  void DefinePieceBrackets(bool a){isPieceBracketDefined = a;}
  void DefineWater(bool a){isWaterDefined = a;}
  void DefineLoads(bool a){isLoadsDefined = a;}
  void DefineDims(bool a){isDimsDefined = a;}
  void DefineLegendXDis(bool a){isLegendXDisDefined = a;}
  void DefineLegendAngDis(bool a){isLegendAngDisDefined = a;}
  void DefineLegendMoment(bool a){isLegendMomentDefined = a;}
  void DefineLegendShear(bool a){isLegendShearDefined = a;}
  void DefineLegendAxial(bool a){isLegendAxialDefined = a;}
  void DefineLegendPress(bool a){isLegendPressDefined = a;}

  GLStratum &GetStratum(){return Stratum;}
  GLPiles &GetPiles(){return Piles;}
//  GLSidePiles &GetLeftPiles(){return LeftPiles;}
//  GLSidePiles &GetRightPiles(){return RightPiles;}
//  GLMidPiles &GetMidPiles(){return MidPiles;}
  GLWales &GetWales(){return Wales;}
  GLStruts &GetStruts(){return Struts;}
  GLAnchors &GetAnchors(){return Anchors;}
  GLRockBolts &GetBolts(){return Bolts;}
  GLWalls &GetWalls(){return Walls;}
  GLDeck &GetDeck(){return Deck;}
  GLMainBeam &GetMainBeam(){return MainBeam;}
  GLMainBeamProps &GetProps(){return Props;}
  GLPieceBrackets &GetPieceBrackets(){return PieceBracket;}
  GLWater &GetWater(){return Water;}
  GLLoads &GetLoads(){return Loads;}
  GLDims  &GetDims(){return Dims;}
  GLColorLegend &GetLegendXDis(){return LegendXDis;}
  GLColorLegend &GetLegendAngDis(){return LegendAngDis;}
  GLColorLegend &GetLegendMoment(){return LegendMoment;}
  GLColorLegend &GetLegendShear(){return LegendShear;}
  GLColorLegend &GetLegendAxial(){return LegendAxial;}
  GLColorLegend &GetLegendPress(){return LegendPress;}
  float &GetDis(){return Dis;}
  float &GetRotX(){return RotX;}
  float &GetRotY(){return RotY;}

  bool operator==(GLEarthWall &earthwall);
  bool operator!=(GLEarthWall &earthwall);
  GLEarthWall &operator=(GLEarthWall &earthwall);

  void DrawGL();
  void DrawLegend();
  bool Import(MkGlobalVar &var,int sec);
  bool Import(MkSection &sec);
  bool ClearMember();
};
//---------------------------------------------------------------------------
class GLEarthWalls : public GLObject {
protected:
  GLEarthWall *FEarthWall;
  int FSize;//Actual size of stratum
  int FSizeOfArray;
public:
  GLEarthWalls(int size,GLEarthWall *earthwall);
  GLEarthWalls(int size);
  GLEarthWalls(){FSizeOfArray = FSize = 0;FEarthWall = NULL;}
  ~GLEarthWalls();
public:
  void Initialize(int size);
  void Initialize(int size,GLEarthWall *);
  int  GetSize(){return FSize;};
  int  GetNumber(){return FSize;};
  bool Add(GLEarthWall &earthwall);      // change of size of earthwall
  bool Delete(GLEarthWall &earthwall);   // change of size of earthwall
  int  Grow(int Delta);            // change of size of array
  int  Shrink(int Delta);          // change of size of array
  bool Clear();
  bool ClearMember();

  virtual GLEarthWall & operator[](int);
  GLEarthWalls & operator=(GLEarthWalls &earthwalls);
  bool operator==(GLEarthWalls &earthwalls);
  void DrawGL(){for(int i=0;i<FSize;i++) FEarthWall[i].DrawGL();}
  bool Import(MkGlobalVar &var);
  bool Import(MkSections &sec);
};
//---------------------------------------------------------------------------
extern TColor NullGLColor;
extern GLDim NullGLDim;
extern GLCylinder NullGLCylinder;
extern GLCut NullGLCut;
extern GLBeam NullGLBeam;
extern GLFill NullGLFill;
extern GLPile NullGLPile;
extern GLWall NullGLWall;
extern GLWale NullGLWale;
extern GLAnchor NullGLAnchor;
extern GLRockBolt NullGLRockBolt;
extern GLPieceBracket NullGLPieceBracket;
extern GLMainBeamProp NullGLMainBeamProp;
extern GLStrata NullGLStrata;
extern GLEarthWall NullGLEarthWall;
#endif

