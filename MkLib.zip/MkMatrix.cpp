//---------------------------------------------------------------------------
#include "stdafx.h"
#include "MkMatrix.h"

//---------------------------------------------------------------------------
// index
//  [0][0] [0][1] [0][2] [0][3]
//  [1][0] [1][1] [1][2] [1][3]
//  [2][0] [2][1] [2][2] [2][3]
//  [3][0] [3][1] [3][2] [3][3]
//---------------------------------------------------------------------------
MkMatrix NullMatrix;
MkVector NullVector;
float Zero=0;

MkMatrix4::MkMatrix4()
{
   for (int i=0;i<4;i++)
       for (int j=0;j<4;j++)
           FMatrix[i][j] = 0;
}

void MkMatrix4::Identity()
{
   int i;
   for (i=0;i<4;i++)
       for (int j=0;j<4;j++)
           FMatrix[i][j] = 0;

   for (i=0;i<4;i++)
       FMatrix[i][i] = 1;
}

void MkMatrix4::Clear()
{
   for (int i=0;i<4;i++)
       for (int j=0;j<4;j++)
           FMatrix[i][j] = 0;
}

void MkMatrix4::Translate(float x,float y,float z)
{
   MkMatrix4 rm;
   rm.Identity();
   rm.FMatrix[0][3] = x;
   rm.FMatrix[1][3] = y;
   rm.FMatrix[2][3] = z;
   *this=*this*rm;
}

void MkMatrix4::Rotate(float alpha,float beta,float gamma)
// x,y,z axis each , don't use this. it is obsolete
// use RotateInX, RotateInY, RotateInZ and RotateInA
// alpha is ang for rotation in x
// beta  is ang for rotation in y
// gamma is ang for rotation in z
// the order is x->y->z
// This routine is changed at 2001.10.3
// So, you must check it...
{
   MkMatrix4 rm1,rm2;

   alpha = alpha*M_PI/180;
   beta = beta*M_PI/180;
   gamma = gamma*M_PI/180;

   if(fabs(alpha-int(alpha))<0.001) alpha = int(alpha);
   if(fabs(beta-int(beta))<0.001) beta = int(beta);
   if(fabs(gamma-int(gamma))<0.001) gamma = int(gamma);
   rm2.Identity();
   rm1.Identity();

   rm1.FMatrix[0][0] =  cos(gamma);
   rm1.FMatrix[0][1] = -sin(gamma);
   rm1.FMatrix[1][0] =  sin(gamma);
   rm1.FMatrix[1][1] =  cos(gamma);

   rm2 *= rm1;

   rm1.Identity();

   rm1.FMatrix[0][0] =  cos(beta);
   rm1.FMatrix[0][2] =  sin(beta);
   rm1.FMatrix[2][0] = -sin(beta);
   rm1.FMatrix[2][2] =  cos(beta);

   rm2 *= rm1;

   rm1.Identity();

   rm1.FMatrix[1][1] =  cos(alpha);
   rm1.FMatrix[1][2] = -sin(alpha);
   rm1.FMatrix[2][1] =  sin(alpha);
   rm1.FMatrix[2][2] =  cos(alpha);

   rm2 *= rm1;

   *this *= rm2;
}

void MkMatrix4::RotateInX(float ang)
{
   MkMatrix4 rm1;

   ang = ang*M_PI/180;
   if(fabs(ang-int(ang))<0.001) ang = int(ang);

   rm1.Identity();

   rm1.FMatrix[1][1] =  cos(ang);
   rm1.FMatrix[1][2] = -sin(ang);
   rm1.FMatrix[2][1] =  sin(ang);
   rm1.FMatrix[2][2] =  cos(ang);

   *this *= rm1;
}

void MkMatrix4::RotateInY(float ang)
{
   MkMatrix4 rm1;

   ang = ang*M_PI/180;
   if(fabs(ang-int(ang))<0.001) ang = int(ang);

   rm1.Identity();

   rm1.FMatrix[0][0] =  cos(ang);
   rm1.FMatrix[0][2] =  sin(ang);
   rm1.FMatrix[2][0] = -sin(ang);
   rm1.FMatrix[2][2] =  cos(ang);

   *this *= rm1;
}

void MkMatrix4::RotateInZ(float ang)
{
   MkMatrix4 rm1,rm2;

   ang = ang*M_PI/180;
   if(fabs(ang-int(ang))<0.001) ang = int(ang);

   rm1.Identity();

   rm1.FMatrix[0][0] =  cos(ang);
   rm1.FMatrix[0][1] = -sin(ang);
   rm1.FMatrix[1][0] =  sin(ang);
   rm1.FMatrix[1][1] =  cos(ang);

   *this *= rm1;
}

void MkMatrix4::RotateInA(float theta, float l, float m, float n)
{
   float len;
   float beta, gamma;
   len = sqrt(l*l+m*m+n*n);
   l/=len;m/=len;n/=len;
   beta = acos(n);

   if (fabs(l)>0.0001) {
      gamma = acos(sin(beta)/l);
      if (l != sin(beta)*cos(gamma)) gamma = -gamma;
      beta = beta*180/M_PI;
      gamma = gamma*180/M_PI;

      RotateInZ(-gamma);
      RotateInY(-beta);
      RotateInZ(theta);
      RotateInY(beta);
      RotateInZ(gamma);
   }
   else if (fabs(m)>0.0001) {
      gamma = asin(sin(beta)/m);
      if (l != sin(beta)*sin(gamma)) gamma = M_PI-gamma;
      beta = beta*180/M_PI;
      gamma = gamma*180/M_PI;

      RotateInZ(-gamma);
      RotateInY(-beta);
      RotateInZ(theta);
      RotateInY(beta);
      RotateInZ(gamma);
   }
   else RotateInZ(theta);
}

void MkMatrix4::Scale(float sx,float sy,float sz)
{
   MkMatrix4 rm;
   rm.Identity();
   rm.FMatrix[0][0] = sx;
   rm.FMatrix[1][1] = sy;
   rm.FMatrix[2][2] = sz;
   *this*=rm;
}

MkMatrix4 & MkMatrix4::operator=(MkMatrix4 &rm)
{
    for (int i= 0;i<4;i++)
        for (int j=0;j<4;j++)
            FMatrix[i][j] = rm.FMatrix[i][j];
    FI = rm.FI;
    FJ = rm.FJ;
    return *this;
}

MkMatrix4 & MkMatrix4::operator*=(float f)
{
    for (int i= 0;i<4;i++)
        for (int j=0;j<4;j++)
            FMatrix[i][j] *= f;

    return *this;
}

MkMatrix4 & MkMatrix4::operator*=(MkMatrix4 &rm)
{
    static MkMatrix4 rm_t;
    rm_t.Clear();

    for (int i=0;i<4;i++)
        for (int j =0;j<4;j++)
            for (int k=0;k<4;k++) {
                rm_t.FMatrix[i][j] += FMatrix[i][k]*rm.FMatrix[k][j];
            }

    return *this = rm_t;

}

MkMatrix4 & MkMatrix4::operator += (float f)
{
   for (int i=0;i<4;i++)
        for (int j =0;j<4;j++)
          FMatrix[i][j] += f;

    return *this;
}

MkMatrix4 & MkMatrix4::operator += (MkMatrix4 &rm)
{
   for (int i=0;i<4;i++)
        for (int j =0;j<4;j++)
          FMatrix[i][j] += rm.FMatrix[i][j];

    return *this;
}

MkMatrix4 & MkMatrix4::operator -= (float f)
{
   for (int i=0;i<4;i++)
        for (int j =0;j<4;j++)
          FMatrix[i][j] -= f;

    return *this;
}

MkMatrix4 & MkMatrix4::operator -= (MkMatrix4 &rm)
{
   for (int i=0;i<4;i++)
        for (int j =0;j<4;j++)
          FMatrix[i][j] -= rm.FMatrix[i][j];

    return *this;
}

MkMatrix4 & operator*(MkMatrix4 &rm, float f)
{
    static MkMatrix4 rm_t;
    rm_t.Clear();

    for (int i= 0;i<4;i++)
        for (int j=0;j<4;j++)
            rm_t.FMatrix[i][j] = rm.FMatrix[i][j]*f;

    return rm_t;
}

MkMatrix4 & operator*(MkMatrix4 &rm, MkMatrix4 &rm2)
{
    static MkMatrix4 rm_t;
    rm_t.Clear();

    for (int i=0;i<4;i++)
        for (int j =0;j<4;j++)
            for (int k=0;k<4;k++) {
                rm_t.FMatrix[i][j] += rm.FMatrix[i][k]*rm2.FMatrix[k][j];
            }

    return rm_t;
}

MkMatrix4 & operator+(MkMatrix4 &rm, float f)
{
    static MkMatrix4 rm_t;
    rm_t.Clear();

   for (int i=0;i<4;i++)
        for (int j =0;j<4;j++)
          rm_t.FMatrix[i][j] = rm.FMatrix[i][j]+f;

    return rm_t;
}

MkMatrix4 & operator+(MkMatrix4 &rm, MkMatrix4 &rm2)
{
    static MkMatrix4 rm_t;
    rm_t.Clear();

   for (int i=0;i<4;i++)
        for (int j =0;j<4;j++)
          rm_t.FMatrix[i][j] = rm.FMatrix[i][j]+rm2.FMatrix[i][j];

    return rm_t;
}

MkMatrix4 & operator-(MkMatrix4 &rm, float f)
{
    static MkMatrix4 rm_t;
    rm_t.Clear();

   for (int i=0;i<4;i++)
        for (int j =0;j<4;j++)
          rm_t.FMatrix[i][j] = rm.FMatrix[i][j]-f;

    return rm_t;
}

MkMatrix4 & operator-(MkMatrix4 &rm, MkMatrix4 &rm2)
{
    static MkMatrix4 rm_t;
    rm_t.Clear();

   for (int i=0;i<4;i++)
        for (int j =0;j<4;j++)
          rm_t.FMatrix[i][j] = rm.FMatrix[i][j]-rm2.FMatrix[i][j];

    return rm_t;
}

#ifdef __BCPLUSPLUS__
void MkMatrix4::Out(TMemo *memo)
{
  char str[256],s[256];
  memo->Lines->Add("Output of Matrix ");
  sprintf(str,"A-th row [%10.3f %10.3f %10.3f %10.3f ]",0.0,1.0,2.0,3.0);
  memo->Lines->Add(str);
  for (int i=0;i<4;i++) {
    sprintf(str,"%d-th row [",i);
    for (int j=0;j<4;j++) {
      sprintf(s,"%10.3f ",FMatrix[i][j]);
      strcat(str,s);
    }
    sprintf(s,"]");
    strcat(str,s);
    memo->Lines->Add(str);
  }
}
#endif
void MkMatrix4::Out(char *fname)
{
  FILE *fp;
  char str[256],s[256];

  fp = fopen(fname,"a");
  fprintf(fp,"Output of Matrix ");
  sprintf(str,"A-th row [%10.3f %10.3f %10.3f %10.3f ]",0.0,1.0,2.0,3.0);
  fprintf(fp,str);
  for (int i=0;i<4;i++) {
    sprintf(str,"%d-th row [",i);
    for (int j=0;j<4;j++) {
      sprintf(s,"%10.3f ",FMatrix[i][j]);
      strcat(str,s);
    }
    sprintf(s,"]");
    strcat(str,s);
    fprintf(fp,str);
  }
  fclose(fp);
}


//---------------------------------------------------------------------------
MkVector::MkVector()
{
    FSize = 0;
    FVector.Clear();
    FVectType = vtNone;
}

MkVector::MkVector(int sz)
{
    char str[256];
    FSize = sz;
    try{ FVector.Initialize(sz);}
    catch(MkFloat::Size s) {
      sprintf(str,"Vector::Constructor Size error of MkFloat size(%d)\n",s.X);
      MkDebug(str);
      throw;
    }
    FVectType = vtNone;
}

MkVector::MkVector(int sz,VectType vt)
{
    char str[256];
    FSize = sz;
    try{ FVector.Initialize(sz);}
    catch(MkFloat::Size s) {
      sprintf(str,"Vector::Constructor Size error of MkFloat size(%d)\n",s.X);
      MkDebug(str);
      throw;
    }
    FVectType = vt;
}

MkVector::MkVector(MkFloat &b)
{
    FSize = b.getSzX();
    FVector.CopyFrom(b);
    FVectType = vtNone;
}

MkVector::MkVector(float l, float m, float n)
{
   FVector.Initialize(3);
   FSize = 3;
   FVector(0) = l;
   FVector(1) = m;
   FVector(2) = n;
   FVectType = vtNone;
}

MkVector::~MkVector()
{

}

void MkVector::SetVector(int sz)
{
   FSize = sz;
   FVector.Initialize(sz);
//   FMatrix.Clear();
}

void MkVector::SetVector(float l, float m, float n)
{
   FVector.Initialize(3);
   FSize = 3;
   FVector(0) = l;
   FVector(1) = m;
   FVector(2) = n;
   FVectType = vtNone;
}


void MkVector::Clear()
{
    FSize = 0;
    FVector.Clear();
//    FMatrix.Clear();
    FVectType = vtNone;
}

void MkVector::Unify()
{
    float sum =0;
    for (int i = 0 ; i < FSize ; i ++)
        sum += FVector(i)*FVector(i);
    sum = sqrt(sum);
    if(sum > 0.0001)
       for (int i = 0 ; i < FSize ; i ++)
          FVector(i)=FVector(i)/sum;

}

float MkVector::Dot(MkVector &vect)
{
    float dot=0;
//    if (FSize <= 0 || FSize != vect.FSize || FVectType != vtRow || vect.FVectType != vtCol) return 0;
    if (FSize <= 0 || FSize != vect.FSize) return 0;
    for (int i=0;i < FSize;i++)
      dot += FVector(i)*vect(i);
    return dot;
}

void MkVector::Cross(MkVector &vect,MkVector &target) // not yet finished, because I do not find general cross product
{
    char str[256];
    try{ if(FSize!=target.GetSize()) target.Initialize(FSize);}
    catch(MkFloat::Size s) {
      sprintf(str,"Vector::Cross Size error of MkFloat size(%d)\n",s.X);
      MkDebug(str);
      throw;
    }

//    l3 = m1*n2 - m2*n1;
//    m3 = n1*l2 - n2*l1;
//    n3 = l1*m2 - l2*m1;  �̰ź��� �����ϱ� �ٶ�...-.-;

    for (int i=0 ; i < FSize ; i++) {
        target.FVector(i) = FVector(i+1 >= FSize ? i+1 - FSize : i+1)*vect(i+2 >= FSize ? i+2-FSize : i+2)
                - vect(i+1 >= FSize ? i+1-FSize : i+1)*FVector(i+2 >= FSize ? i+2 - FSize : i+2);  //�򰥸�...^^
    }
}

float & MkVector::operator()(int i)
{
    return FVector(i);
}

float & MkVector::operator[](int i)
{
    return FVector(i);
}

MkVector & MkVector::operator=(MkVector &vect)
{
    FVector.CopyFrom(vect.FVector);
    FSize = vect.FSize;
    FVectType = vect.FVectType;
    return *this;
}

bool MkVector::operator==(MkVector &v)
{
  return FSize==v.FSize && FVectType == v.FVectType && FVector == v.FVector;
}

bool MkVector::operator!=(MkVector &v)
{
  return !operator==(v);
}

MkVector & MkVector::operator+=(MkVector &vect)
{
    if (FSize != vect.FSize) return NullVector;
    for (int i = 0 ; i < FSize;i++) FVector(i) += vect.FVector(i);
    return *this;
}

MkVector & MkVector::operator-=(MkVector &vect)
{
    if (FSize != vect.FSize) return NullVector;
    for (int i = 0 ; i < FSize;i++) FVector(i) -= vect.FVector(i);
    return *this;
}

MkVector & MkVector::operator*=(float a)
{
    for (int i=0;i < FSize;i++)
      FVector(i) *= a;
    return *this;
}

MkVector & MkVector::operator/=(float a)
{
    if (fabs(a) > EPS)
       for (int i=0;i < FSize;i++)
           FVector(i) /= a;

    return *this;
}

MkVector & MkVector::operator+=(float a)
{
    for (int i=0;i < FSize;i++)
      FVector(i) += a;
    return *this;
}

MkVector & MkVector::operator-=(float a)
{
    for (int i=0;i < FSize;i++)
      FVector(i) -= a;
    return *this;
}

MkVector & operator+(MkVector &v,MkVector &v2)
{
    static MkVector v_t;
    if (v.FSize != v2.FSize) return NullVector;
    v_t.Initialize(v.FSize);
    for (int i = 0 ; i < v.FSize;i++)
      v_t.FVector(i)=v.FVector(i)+v2.FVector(i);
    return v_t;
}

MkVector & operator-(MkVector &v,MkVector &v2)
{
    static MkVector v_t;
    if (v.FSize != v2.FSize) return NullVector;
    v_t.Initialize(v.FSize);
    for (int i = 0 ; i < v.FSize;i++)
      v_t.FVector(i)=v.FVector(i)+v2.FVector(i);
    return v_t;
}

MkVector & operator*(MkVector &v,float a)
{
    static MkVector v_t;

    v_t = v;
    for (int i = 0 ; i < v.FSize;i++)
      v_t.FVector(i)*=a;
    return v_t;
}

MkVector & operator/(MkVector &v,float a)
{
    static MkVector v_t;

    v_t = v;
    for (int i = 0 ; i < v.FSize;i++)
      v_t.FVector(i)/=a;
    return v_t;
}

MkVector & operator+(MkVector &v,float a)
{
    static MkVector v_t;
    v_t.Initialize(v.FSize);
    for (int i = 0 ; i < v.FSize;i++)
      v_t.FVector(i)=v.FVector(i)+a;
    return v_t;
}

MkVector & operator-(MkVector &v,float a)
{
    static MkVector v_t;
    v_t.Initialize(v.FSize);
    for (int i = 0 ; i < v.FSize;i++)
      v_t.FVector(i)=v.FVector(i)-a;
    return v_t;
}

#ifdef __BCPLUSPLUS__
void MkVector::Out(TMemo *memo)
{
  char str[256],s[256];
  memo->Lines->Add("Output of Vector ");
  sprintf(str,"vector [");
  for (int i=0;i<FSize;i++) {
    sprintf(s,"%10.6f ",FVector(i));
    strcat(str,s);
  }
  sprintf(s,"]");
  strcat(str,s);
  memo->Lines->Add(str);
}
#endif
void MkVector::Out(char *fname)
{
  FILE *fp;
  char str[256],s[256];

  fp=fopen(fname,"a");
  fprintf(fp,"Output of Vector ");
  sprintf(str,"vector [");
  for (int i=0;i<FSize;i++) {
    sprintf(s,"%10.6f ",FVector(i));
    strcat(str,s);
  }
  sprintf(s,"]");
  strcat(str,s);
  fprintf(fp,str);
  fclose(fp);
}

//---------------------------------------------------------------------------
MkMatrix::MkMatrix()
{
    FMatrix.Clear();
    FIndex.Clear();
    FD = 0;
    FI = FJ = 0;
    FMatType = mtNormal;
}

MkMatrix::MkMatrix(int sz_x,int sz_y)
{
    char str[256];
    try {FMatrix.Initialize(sz_x,sz_y);}
    catch(MkFloat::Size s) {
      sprintf(str,"Matrix::Constructor Size error of MkFloat size(%d,%d)\n",s.X,s.Y);
      MkDebug(str);
      throw;
    }

    try {if (sz_x == sz_y) FIndex.Initialize(sz_x);}
    catch(MkFloat::Size s) {
      sprintf(str,"Matrix::Constructor Size error of MkFloat size(%d)\n",s.X);
      MkDebug(str);
      throw;
    }

    FD = 0;
    FI = sz_x;
    FJ = sz_y;
    FMatType = mtNormal;
}

MkMatrix::MkMatrix(MkMatrix &tm)
{
    *this = tm;
}

MkMatrix::MkMatrix(MkFloat &fm)
{
    if (fm.getSzZ() != 1) {
       FMatrix.Clear();
       FIndex.Clear();
       FD = 0;
       FI = FJ = 0;
       FMatType = mtNormal;
    }
    else {
       FI = fm.getSzX();
       FJ = fm.getSzY();
       FMatrix.CopyFrom(fm);
       FIndex.Initialize(FI);
       FD = 0;
       FMatType = mtNormal;
    }
}

MkMatrix::~MkMatrix()
{

}

void MkMatrix::SetMatrix(int sz_x,int sz_y)
{
    FMatrix.Initialize(sz_x,sz_y);
    if (sz_x == sz_y) FIndex.Initialize(sz_x);
    FI = sz_x;
    FJ = sz_y;
    FMatType = mtNormal;
}

void MkMatrix::Identify()
{
    if (FI != FJ) return;
    for (int i=0;i<FI;i++)
        for (int j=0;j<FJ;j++) {
            if (i == j) FMatrix(i,j) = 1;
            else FMatrix(i,j) = 0;
        }
    FMatType = mtNormal;
}

void MkMatrix::Clear()
{
    FMatrix.Clear();
    FIndex.Clear();
    FI = FJ = 0;
    FMatType = mtNormal;
}

bool MkMatrix::Transpose()
{
    MkFloat A(FJ,FI);
    for (int i=0;i < FI;i++)
        for (int j=0;j< FJ;j++)
            A(j,i) = FMatrix(i,j);

    FMatrix.CopyFrom(A);

    int tmp;
    tmp = FI;
    FI = FJ;
    FJ = tmp;
    
    FMatType = FMatType == mtNormal ? mtTransposed : mtNormal;
    return true;
}

bool MkMatrix::Invert()
{
    int i,j,n;
    if (FI != FJ) return false;
    n = FI;

    MkFloat y(n,n);
    MkVector TempVect(n);
    LUDecompose();

    for (j=0;j<n;j++) {
        for (i=0;i<n;i++) TempVect(i) = 0;
        TempVect(j) = 1.0;
        LUBackSubstitute(TempVect);
        for (i=0;i<n;i++) y(i,j) = TempVect(i);
    }

    for (i=0;i < n;i++)
        for (j=0; j < n;j++)
            FMatrix(i,j) = y(i,j);

    FMatType = mtInverted;
    return true;
}

//  float **a, int n, int *indx, float FD

bool MkMatrix::LUDecompose()
{
    int i,imax,j,k;
    float big,dum,sum,temp;
    MkFloat vv;

    if(FMatType == mtLUDecomposed) return true;
    if (FI != FJ) return false;
    int n = FI;

    vv.Initialize(n);
    FD=1;

    for (i=0;i<n;i++) {
        big=0.0;
        for (j=0;j<n;j++)
            if ((temp=fabs(FMatrix(i,j))) > big) big=temp;
        if (fabs(big) < EPS) MkDebug("Singular matrix in routine MkMatrix::LUDecompose");
        vv(i)=1.0/big;
    }

    for (j=0;j<n;j++) {
        for (i=0;i<j;i++) {
            sum=FMatrix(i,j);
            for (k=0;k<i;k++) sum -= FMatrix(i,k)*FMatrix(k,j);
                FMatrix(i,j)=sum;
        }
        big=0.0;
        for (i=j;i<n;i++) {
            sum=FMatrix(i,j);
            for (k=0;k<j;k++)
                sum -= FMatrix(i,k)*FMatrix(k,j);
            FMatrix(i,j)=sum;
            if ( (dum=vv(i)*fabs(sum)) >= big) {
               big=dum;
               imax=i;
            }
        }
        if (j != imax) {
           for (k=0;k<n;k++) {
               dum=FMatrix(imax,k);
               FMatrix(imax,k)=FMatrix(j,k);
               FMatrix(j,k)=dum;
           }
           FD = -(FD);
           vv(imax)=vv(j);
        }
        FIndex(j)=imax;
        if (FMatrix(j,j) == 0.0) FMatrix(j,j)=TINY;
        if (j != n) {
           dum=1.0/(FMatrix(j,j));
           for (i=j+1;i<n;i++) FMatrix(i,j) *= dum;
        }
    }
    FMatType = mtLUDecomposed;
    return true;
}

//  b is input and output. Solving equations AX = B.
//  b as input B
//  b as output X

bool MkMatrix::LUBackSubstitute(MkVector &b)
{
    int i,ii=-1,ip,j;
    float sum;
    int n;

    if (FI != FJ) return false;
    n = FI;
    if (FMatType != mtLUDecomposed) return false;

    for (i=0;i<n;i++) {
        ip=FIndex(i);
        sum=b(ip);
        b(ip)=b(i);
        if (ii>=0)
           for (j=ii;j<=i-1;j++) sum -= FMatrix(i,j)*b(j);
        else if (sum) ii=i;
           b(i)=sum;
    }

    for (i=n-1;i>=0;i--) {
        sum=b(i);
        for (j=i+1;j<n;j++) sum -= FMatrix(i,j)*b(j);
            b(i)=sum/FMatrix(i,i);
    }
    return true;
}

bool MkMatrix::GaussSeidel(MkVector &X0,MkVector &B) // X0 is initial and return X
{
    int m=0;
    int NN = FI;
    //    float max_x,x,x0;
    //    bool flag;
    MkFloat U(NN);
    MkFloat X(NN);
    MkFloat A;
	
    if(FMatType == mtLUDecomposed) return false;
    if (FI != FJ) return false;

    A.CopyFrom(FMatrix);

    for (int i=0;i<NN;i++) {
        U(i) = X0(i);
        B(i) /= A(i,i);
        for (int j=0;j<NN;j++)
            A(i,j) = (i==j) ? A(i,j) : A(i,j)/A(i,i);
        A(i,i) = 0;
    }

    while( m < NN) {
        for (int i=0;i<NN;i++) {
            X(i) = 0;
            for (int j=0;j<NN;j++) {
                X(i) = X(i) - A(i,j)*U(j);
            }
            X(i) += B(i);
            U(i) = X(i);
        }
        m = 0;
	//in case x and x0 is too small to compare, then normalize the value to its bigger one.
/*	
	x = X(m);
	x0 = X0(m);
	max_x = (fabs(x)>fabs(x0))?fabs(x):fabs(x0);

	if(EPS*EPS<max_x&&max_x<EPS) flag = flag && (fabs(x-x0)/max_x < EPS*10);
	else if(max_x>EPS) flag = flag && (fabs(x-x0) < EPS);
	else flag = flag && true;
*/
        while ((m < NN) && fabs(X(m)-X0(m)) < EPS*10)
              m++;
        if (m < NN)
            for (int i=0;i<NN;i++){
                X0(i) = X(i);
            }
    }
    return true;
}

bool MkMatrix::isSingular()
{
    int i,j;
    float big,temp;

    if (FI != FJ) return true;

    FD=1;

    for (i=0;i<FI;i++) {
        big=0.0;
        for (j=0;j<FI;j++)
            if ((temp=fabs(FMatrix(i,j))) > big) big=temp;
        if (fabs(big) <= EPS) return true;
    }
    return false;
}

bool MkMatrix::Solve(MkVector &B)
{
    if (isSingular()) return false;
    MkVector X;
    MkMatrix A(FMatrix);
    X = B;
    A.LUDecompose();
    A.LUBackSubstitute(X);
    MkMatrix A1(FMatrix);
    A1.GaussSeidel(X,B);
    B = X;
    return true;
}

bool MkMatrix::Solve(MkVector &B,SolveType solve_type)
{
    if (isSingular()) return false;

    if (solve_type == stLUD) {
       MkVector X;
       MkMatrix A(FMatrix);
       X = B;
       A.LUDecompose();
       A.LUBackSubstitute(X);
       B = X;
       return true;
    }
    else if (solve_type == stGauss) {
       MkVector X;
       MkMatrix A(FMatrix);
       X = B;
       A.GaussSeidel(X,B);
       B = X;
       return true;
    }
    else if (solve_type == stHybrid)
       return Solve(B);
    else return false;
}

MkMatrix & MkMatrix::GetTranspose()
{
   if (Transpose()) return *this;
   else return NullMatrix;

}

MkMatrix & MkMatrix::GetInvert()
{
   if (Invert()) return *this;
   else return NullMatrix;
}

MkMatrix & MkMatrix::operator!() // matrix inversion
{
   return GetInvert();
}

MkMatrix & MkMatrix::operator~() // matrix tranpose
{
   return GetTranspose();
}

MkMatrix & operator!(MkMatrix &m) // matrix inversion
{
   static MkMatrix m_t;
   m_t = m;
   return m_t.GetInvert();
}

MkMatrix & operator~(MkMatrix &m) // matrix tranpose
{
   static MkMatrix m_t;
   m_t = m;
   return m_t.GetTranspose();
}

MkMatrix & MkMatrix::operator*=(MkMatrix &m)
{
   if (FJ != m.FI) return NullMatrix;
   static MkMatrix m_t(FI,m.FJ);
   float sum;
   for (int i=0;i<FI;i++) {
       for (int j=0;j<m.FJ;j++) {
           sum = 0;
           for (int k=0;k < FJ;k++) sum += FMatrix(i,k)*m(k,j);
           m_t(i,j) = sum;
       }
   }
   return *this=m_t;
}

MkVector & MkMatrix::operator*=(MkVector &v)
{
   static MkVector FVector;
   if (FJ != v.GetFI()) return NullVector;
   FVector.Initialize(FI);
   float sum;
   for (int i=0;i < FI;i++) {
       sum = 0;
       for (int j=0;j < FJ;j++) sum += FMatrix(i,j)*v(j);
       FVector(i) = sum;
   }
   return FVector;
}
MkMatrix & operator*(MkMatrix &m,MkMatrix &m2)
{
   static MkMatrix m_t;
   if (m.FJ != m2.FI) return NullMatrix;
   m_t.Initialize(m.FI,m2.FJ);
   float sum;
   for (int i=0;i<m.FI;i++) {
       for (int j=0;j<m2.FJ;j++) {
           sum = 0;
           for (int k=0;k < m.FJ;k++) sum += m.FMatrix(i,k)*m2.FMatrix(k,j);
           m_t(i,j) = sum;
       }
   }
   return m_t;
}

MkVector & operator*(MkMatrix &m,MkVector &v)
{
   static MkVector v_t;
   if (m.FJ != v.GetFI()) return NullVector;
   v_t.Initialize(m.FI);
   float sum;
   for (int i=0;i < m.FI;i++) {
       sum = 0;
       for (int j=0;j < m.FJ;j++) sum += m.FMatrix(i,j)*v(j);
       v_t(i) = sum;
   }
   return v_t;
}

MkMatrix & MkMatrix::operator=(MkMatrix &m)
{
    FMatrix.CopyFrom(m.FMatrix);
    FIndex.CopyFrom(m.FIndex);
    FD=m.FD;
    FI=m.FI;
    FJ=m.FJ;
    FMatType=m.FMatType;
    return *this;
}

float & MkMatrix::operator()(int i,int j)
{
   return FMatrix(i,j);
}

#ifdef __BCPLUSPLUS__
void MkMatrix::Out(TMemo *memo)
{
  char str[256],s[256];
  memo->Lines->Add("Output of Matrix ");
  sprintf(str,"A-th row [%10.3f %10.3f %10.3f %10.3f %10.3f %10.3f %10.3f %10.3f %10.3f %10.3f]",
                           0.0,1.0,2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0);
  memo->Lines->Add(str);
  for (int i=0;i<GetFI();i++) {
    sprintf(str,"%d-th row [",i);
    for (int j=0;j<GetFJ();j++) {
      sprintf(s,"%10.3f ",FMatrix(i,j));
      strcat(str,s);
    }
    sprintf(s,"]");
    strcat(str,s);
    memo->Lines->Add(str);
  }
}
#endif
void MkMatrix::Out(char *fname)
{
  FILE *fp;
  char str[256],s[256];

  fp=fopen(fname,"a");
  fprintf(fp,"Output of Matrix ");
  sprintf(str,"A-th row [%10.3f %10.3f %10.3f %10.3f %10.3f %10.3f %10.3f %10.3f %10.3f %10.3f]",
                           0.0,1.0,2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0);
  fprintf(fp,str);
  for (int i=0;i<GetFI();i++) {
    sprintf(str,"%d-th row [",i);
    for (int j=0;j<GetFJ();j++) {
      sprintf(s,"%10.3f ",FMatrix(i,j));
      strcat(str,s);
    }
    sprintf(s,"]");
    strcat(str,s);
    fprintf(fp,str);
  }
}
//---------------------------------------------------------------------------
