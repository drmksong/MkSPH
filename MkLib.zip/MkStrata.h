//---------------------------------------------------------------------------
#ifndef MkStrataH
#define MkStrataH
#ifdef __BCPLUSPLUS__
#include "GlobalVarUnit.h"
#endif
#include "MkEntity.h"
//---------------------------------------------------------------------------
class MkStrata : public MkEntity {
protected:
  MkPolygon Strata;
  float WetUnitWeight[2];
  float SubUnitWeight[2];
  float Cohesion[2];
  float Friction[2];
  float HorSubReact[2]; // ���� ���ݹݷ°��(modulus of subgrade reaction
  float VerSubReact[2]; // ���� ���ݹݷ°��(modulus of subgrade reaction
  float Burden;
  float K0;
  float Ka;
  float Kp;
public:
  MkStrata();
  MkStrata(int n);
  ~MkStrata(){};
public: //setting function
  void SetStrata(MkPolygon &strata){Strata=strata;}
  void SetK0(float k0){K0 = k0;}
  void SetKa(float ka){Ka = ka;}
  void SetKp(float kp){Kp = kp;}
  void SetBurden(float burden){Burden=burden;}
  void SetWetUnitWeight(int n,float w){if(n>=0&&n<2) WetUnitWeight[n] = w;}
  void SetSubUnitWeight(int n,float w){if(n>=0&&n<2) SubUnitWeight[n] = w;}
  void SetCohesion(int n,float w){if(n>=0&&n<2) Cohesion[n] = w;}
  void SetFriction(int n,float w){if(n>=0&&n<2) Friction[n] = w;}
  void SetHorSubReact(int n,float w){if(n>=0&&n<2) HorSubReact[n] = w;}
  void SetVerSubReact(int n,float w){if(n>=0&&n<2) VerSubReact[n] = w;}
public:// getting function
  float GetWetUnitWeight(MkPoint &pnt);
  float GetCohesion(MkPoint &pnt);
  float GetFriction(MkPoint &pnt);
  float GetHorSubReact(MkPoint &pnt);
  float GetVerSubReact(MkPoint &pnt);
  float GetWetUnitWeight(MkLine &line);
  float GetCohesion(MkLine &line);
  float GetFriction(MkLine &line);
  float GetHorSubReact(MkLine &line);
  float GetVerSubReact(MkLine &line);
public: //key function
  MkPolygon &GetStrata(){return Strata;}
//  float GetWeight(){return (WetUnitWeight[0]+WetUnitWeight[1])/2.0*Rect.GetHeight();}
  bool IsIn(MkPoint &pnt){return Strata.IsIn(pnt);}
  bool IsIn(MkLine &line){return Strata.IsIn(line[0]) || Strata.IsIn(line[1]);}
  float InLen(MkLine &line);
  MkLine InLine(MkLine &line);

#ifdef __BCPLUSPLUS__
  AnsiString ClassName(){return AnsiString("MkStrata");}
  bool UpdateFrom(TStringGrid *grid){Grid = grid;return UpdateFrom();};
  bool UpdateTo(TStringGrid *grid){Grid = grid;return UpdateTo();};
  bool UpdateFrom();
  bool UpdateTo();
#else
  char* ClassName(){return "MkStrata";}
#endif

public: // operator function
  bool operator==(MkStrata&);
  bool operator!=(MkStrata&);

#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif
};

class MkStratum {
protected:
    MkStrata *FStrata;
    int FSize;//Actual size of entities
    int FSizeOfArray;
#ifdef __BCPLUSPLUS__
    TColor Color;
#endif
public:
    MkStratum(int size,MkStrata *ent);
    MkStratum(int size);
    MkStratum(){FSizeOfArray = FSize = 0;FStrata = NULL;}
     ~MkStratum();
    virtual void Initialize(int size);
    virtual void Initialize(int size,MkStrata *);
    bool Add(MkStrata &strata);  // change of size of ground
    bool Add(int index,MkStrata &strata);
    bool Delete(MkStrata &strata);  // change of size of ground
    bool Delete(int index);
    int Grow(int Delta);            // change of size of array
    int Shrink(int Delta);          // change of size of array

    int GetSize(){return FSize;};
    int GetNumber(){return FSize;};
    bool Clear();
#ifdef __BCPLUSPLUS__
    TColor GetColor(){return Color;};
    void SetColor(TColor c){Color = c;}
#endif

#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif

    virtual MkStrata & operator[](int);
    MkStratum & operator=(MkStratum &stratum);
    bool operator==(MkStratum &stratum);

    float GetWetUnitWeight(MkPoint &pnt)
      {
        for (int i=0;i<FSize;i++)
          if(FStrata[i].IsIn(pnt))
            return FStrata[i].GetWetUnitWeight(pnt);
        return 0;
      }
    float GetCohesion(MkPoint &pnt)
      {
        for (int i=0;i<FSize;i++)
          if(FStrata[i].IsIn(pnt))
            return FStrata[i].GetCohesion(pnt);
        return 0;
      }
    float GetFriction(MkPoint &pnt)
      {
        for (int i=0;i<FSize;i++)
          if(FStrata[i].IsIn(pnt))
            return FStrata[i].GetFriction(pnt);
        return 0;
      }
    float GetHorSubReact(MkPoint &pnt)
      {
        for (int i=0;i<FSize;i++)
          if(FStrata[i].IsIn(pnt))
            return FStrata[i].GetHorSubReact(pnt);
        return 0;
      }
    float GetVerSubReact(MkPoint &pnt)
      {
        for (int i=0;i<FSize;i++)
          if(FStrata[i].IsIn(pnt))
            return FStrata[i].GetVerSubReact(pnt);
        return 0;
      }
    float GetWetUnitWeight(MkLine &line)
      {
        float w=0,l;
        if(line.GetLength()<0.001) return GetWetUnitWeight(line[0]);
        for (int i=0;i<FSize;i++)
          if(FStrata[i].IsIn(line)) {
            l = FStrata[i].InLen(line);
            w+=FStrata[i].GetWetUnitWeight(line)*l;
          }
        return w/line.GetLength();
      }
    float GetCohesion(MkLine &line)
      {
        float c=0,l;
        if(line.GetLength()<0.001) return GetCohesion(line[0]);
        for (int i=0;i<FSize;i++)
          if(FStrata[i].IsIn(line)) {
            l = FStrata[i].InLen(line);
            c+= FStrata[i].GetCohesion(line)*l;
          }
         return c/line.GetLength();
      }
    float GetFriction(MkLine &line)
      {
        float f=0,l;
        if(line.GetLength()<0.001) return GetFriction(line[0]);
        for (int i=0;i<FSize;i++)
          if(FStrata[i].IsIn(line)) {
            l = FStrata[i].InLen(line);
            f+=FStrata[i].GetCohesion(line)*l;
          }
        return f/line.GetLength();
      }
    float GetHorSubReact(MkLine &line)
      {
        float h=0,l;
        if(line.GetLength()<0.001) return GetHorSubReact(line[0]);
        for (int i=0;i<FSize;i++)
          if(FStrata[i].IsIn(line)) {
            l = FStrata[i].InLen(line);
            h += FStrata[i].GetHorSubReact(line)*l;
          }
        return h/line.GetLength();
      }
    float GetVerSubReact(MkLine &line)
      {
        float v=0,l;
        if(line.GetLength()<0.001) return GetVerSubReact(line[0]);
        for (int i=0;i<FSize;i++)
          if(FStrata[i].IsIn(line)) {
            l = FStrata[i].InLen(line);
            v += FStrata[i].GetHorSubReact(line)*l;
          }
        return v/line.GetLength();
      }
};
//---------------------------------------------------------------------------
extern MkStrata NullStrata;
extern MkStratum NullStratum;
#endif
