//---------------------------------------------------------------------------
#ifndef MkOpenGLH
#define MkOpenGLH
#include "OpenGLPanel.h"
#include "MkPoint.h"
//---------------------------------------------------------------------------
void accFrustum(GLdouble left, GLdouble right, GLdouble bottom,
                GLdouble top, GLdouble near, GLdouble far, GLdouble pixdx,
                GLdouble pixdy, GLdouble eyedx, GLdouble eyedy, GLdouble focus);
void accPerspective(GLdouble fovy, GLdouble aspect, GLdouble near, GLdouble far,
                GLdouble pixdx, GLdouble pixdy, GLdouble eyedx, GLdouble eyedy,
                GLdouble focus);

#endif
