//---------------------------------------------------------------------------
#ifndef MkGroundImprovH
#define MkGroundImprovH

#ifdef __BCPLUSPLUS__
#include "GlobalVarUnit.h"
#endif
#include <string.h>
#include "MkObject.h"
#include "MkMisc.h"
//---------------------------------------------------------------------------
class MkGroundImprov : public MkObject {
public:
  int width, ctc,rctc,row;
  int layer; //??
#ifdef __BCPLUSPLUS__
  AnsiString kind;
#else
  char kind[256];
#endif
public:
  MkGroundImprov();
  MkGroundImprov(int);
  ~MkGroundImprov(){}
  void Clear();
#ifdef __BCPLUSPLUS__
  void Import(MkGlobalVar &globalvar, int tan);
  void Export(MkGlobalVar &globalvar, int tan);
#endif
};

class MkGroundImprovs {
protected:
  MkGroundImprov *FGroundImprov;
  int FSize;//Actual size of nodes
  int FSizeOfArray;
public:
  MkGroundImprovs(int size,MkGroundImprov *jibanbogang);
  MkGroundImprovs(int size);
  MkGroundImprovs(){FSizeOfArray = FSize = 0;FGroundImprov = NULL;}
  ~MkGroundImprovs();
  virtual void Initialize(int size);
  virtual void Initialize(int size,MkGroundImprov *);
  int GetSize(){return FSize;};
  int GetNumber(){return FSize;};
  bool Add(MkGroundImprov &jibanbogang);  // change of size of jibanbogang
  bool Add(int index,MkGroundImprov &jibanbogang);
  bool Delete(MkGroundImprov &jibanbogang);  // change of size of jibanbogang
  bool Delete(int index);
  int Grow(int Delta);            // change of size of array
  int Shrink(int Delta);          // change of size of array
  bool Clear();
  virtual MkGroundImprov & operator[](int);
  MkGroundImprovs & operator=(MkGroundImprovs &jibanbogangs);
  bool operator==(MkGroundImprovs &jibanbogangs);
#ifdef __BCPLUSPLUS__
  void Import(MkGlobalVar &globalvar);
  void Export(MkGlobalVar &globalvar);
#endif
};
extern MkGroundImprov NullMkGroundImprov;
#endif
