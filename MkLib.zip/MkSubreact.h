#ifndef MkSubreactH
#define MkSubreactH
#include "MkEntity.h"
#include "MkPolygon.h"
#include "MkMatrix.h"
#include "MkRange.h"
#include "MkLayer.h"
#include "MkCut.h"
#include "MkFill.h"
#include "MkWall.h"

class MkSubreact {
 protected:
  MkVector Direction;
  MkPoint Origin;
  MkRangeTree Range;
  MkPolygon Subreact;
#ifdef __BCPLUSPLUS__
  TColor Color;
#endif

 public:
  MkSubreact(){Direction.SetVector(1,0,0); Origin.SetPoint(0,0,0);}
  MkSubreact(int){Direction.SetVector(1,0,0); Origin.SetPoint(0,0,0);}
  MkSubreact(MkVector &dir, MkPoint &ori, MkRangeTree &range){Direction=dir;Origin=ori;Range=range;}
  ~MkSubreact(){}
#ifdef __BCPLUSPLUS__
  AnsiString ClassName(){return AnsiString("MkSubreact");}
#else
  char *ClassName(){return "MkSubreact";}
#endif

 public:
  void SetDirection(MkVector &dir){Direction = dir;}
  void SetOrigin(MkPoint &ori){Origin = ori;}
  void SetRangeTree(MkRangeTree &range){Range = range;}
 public:
  MkVector &GetDirection(){return Direction;}
  MkPoint &GetOrigin(){return Origin;}
  MkRangeTree &GetRangeTree(){return Range;}
  bool isIn(MkPoint p){return Range.Operate(p);}
  MkPolygon &GetSubreact(){return Subreact;}
 public:
  bool Build(MkLayers &lay, MkCuts &cuts, MkFills &fills, MkWall &wall);
  bool BuildRange(MkWall &wall);
  bool Out(char *fname);
 public: 
  virtual bool operator==(MkSubreact &subreact);
  virtual bool operator!=(MkSubreact &subreact);
  virtual MkSubreact & operator=(MkSubreact &subreact);
#ifdef __BCPLUSPLUS__
  void Draw(TObject *){}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *){}
#endif
  
};

class MkSubreacts {
protected:
  MkSubreact *FSubreact;
  int FSize;//Actual size of subreacts
#ifdef __BCPLUSPLUS__
  TColor Color;
#endif
public:
  MkSubreacts(int size,MkSubreact *subreact);
  MkSubreacts(){FSize = 0;FSubreact = NULL;}
  ~MkSubreacts();
  void Initialize(int size);
  void Initialize(int size,MkSubreact *);
  int GetSize(){return FSize;};
  int GetNumber(){return FSize;};
  bool Add(MkSubreact &subreact);  // change of size of subreact
  bool Delete(MkSubreact &subreact);  // change of size of subreact
  bool Clear();
  virtual MkSubreact & operator[](int);

  MkSubreacts & operator=(MkSubreacts &subreacts);
  bool operator==(MkSubreacts &subreacts);
  bool operator!=(MkSubreacts &subreacts);

  bool Out(char *fname);
#ifdef __BCPLUSPLUS__
  void Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif
};

#endif


