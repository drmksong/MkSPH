//---------------------------------------------------------------------------
#include "MkStrut.h"
#ifdef __BCPLUSPLUS__
#include <vcl.h>
#endif
#pragma hdrstop
//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#pragma package(smart_init)
#endif
//---------------------------------------------------------------------------
MkStrut NullStrut(0);
MkStrut::MkStrut()
{
  Clear();
}
MkStrut::MkStrut(int n)
{
  Clear();
}
#ifdef __BCPLUSPLUS__
bool MkStrut::UpdateFrom()
{
  if(!Grid) return false;

  Number          = Grid->Cells[1][0].ToInt();
  Depth           = Grid->Cells[1][1].ToDouble();
  Area            = Grid->Cells[1][2].ToDouble();
  Length          = Grid->Cells[1][3].ToDouble();
  Spacing      = Grid->Cells[1][4].ToDouble();
  JackingForce       = Grid->Cells[1][5].ToDouble();
  IniDisp         = Grid->Cells[1][6].ToDouble();
  StressLoss      = Grid->Cells[1][7].ToDouble();
  RakerAng        = Grid->Cells[1][8].ToDouble();

  return true;
}

bool MkStrut::UpdateTo()
{
  if(!Grid) return false;

  for(int i=0;i<20;i++) {Grid->Cells[0][i] = "";Grid->Cells[1][i]="";}

  Grid->Cells[0][0] = "Number";
  Grid->Cells[0][1] = "Depth";
  Grid->Cells[0][2] = "Area";
  Grid->Cells[0][3] = "Length";
  Grid->Cells[0][4] = "Spacing";
  Grid->Cells[0][5] = "JackingForce";
  Grid->Cells[0][6] = "IniDisp";
  Grid->Cells[0][7] = "StressLoss";
  Grid->Cells[0][8] = "RakerAng";
  Grid->Cells[1][0] = Number;
  Grid->Cells[1][1] = Depth;
  Grid->Cells[1][2] = Area;
  Grid->Cells[1][3] = Length;
  Grid->Cells[1][4] = Spacing;
  Grid->Cells[1][5] = JackingForce;
  Grid->Cells[1][6] = IniDisp;
  Grid->Cells[1][7] = StressLoss;
  Grid->Cells[1][8] = RakerAng;

  return true;
}


void MkStrut::Out(TObject *Sender)
{

}
#endif


void MkStrut::Out(char *fname)
{
  FILE *fp;
  fp = fopen(fname,"a");
  if(!fp) {
    MkDebug(fname); MkDebug(" is not found, so fp is null and return false\n");
    return;
  }
            //12345678901234567890123456789012345678901234567890123456789012345678901234567890
//fprintf(fp," Strut Depth   Length  Area     I       E    Spacing  \n");
//fprintf(fp,"   No.   (m)    (m)    (m2)    (m4)   (t/m2)   (m)  \n");
  fprintf(fp,"  %3d   %5.2f   %5.2f  %5.2f   %5.2f   %5.2f  %5.2f\n",Number,Depth,Length,Area,SecMomentZ,YoungMod*MPa2Tonf,Spacing);
  fprintf(fp,"                      (%5.2f) (%5.2f) \n",Area/(Spacing>EPS?Spacing:1),SecMomentZ/(Spacing>EPS?Spacing:1));
  fprintf(fp,"\n");
  fclose(fp);
}

void MkStrut::Clear()
{
  MkEntity::Clear();

#ifdef __BCPLUSPLUS__
  MajorWale="";
#else
  memset(MajorWale,'\0',255);
#endif

  Height=0;        // HH
  Width=0;         // BB
  T1=0;
  T2=0;         // tt1, tt2
  Area=0;
  AreaWeb=0;
  Weight=0;
  SecCoeffY=0;
  SecCoeffZ=0;    // Section coefficient Zx, Zy
  SecMomentY=0;
  SecMomentZ=0;  // second moment of inertial Ix, Iy
  SecRadiusY=0;
  SecRadiusZ=0;  // second radius of inertia rx, ry

  Spacing=0;
  JackingForce=0;
  IniDisp=0;
  StressLoss=0;
  RakerAng=0;
  YoungMod=0;
  ShearTor=0;

  StrutLine.Clear();
}

#ifdef __BCPLUSPLUS__
void MkStrut::ExtractSpec(AnsiString &steel)
{
  AnsiString sub;
  bool found = false;
  int i,j,spos,epos,len;

  for(i=0;i<75 && !found;i++)
    if(AnsiString(HBEAM[i][0])==steel) {
      found = true;
      SteelType = stHBEAM;

      sub = AnsiString(HBEAM[i][0]);
      len = sub.Length();
      epos = sub.Pos("��");
      spos = sub.Pos("-");
      AnsiString s1,s2;
      s1 = sub.SubString(spos+1,epos-spos-1);
      s2 = sub.SubString(epos+2,len-epos);

      Height = sub.SubString(spos+1,epos-spos-1).ToDouble();    //H   0
      Width= sub.SubString(epos+2,len-epos).ToDouble();       //B   1
      T1= AnsiString(HBEAM[i][1]).ToDouble();             //t1  2
      T2= AnsiString(HBEAM[i][2]).ToDouble();             //t2  3
      Area=  AnsiString(HBEAM[i][3]).ToDouble();             //A   4
      Weight=   AnsiString(HBEAM[i][4]).ToDouble();             //W   5
      SecMomentY=  AnsiString(HBEAM[i][5]).ToDouble();             //Ix  6
                                                           //Iy  7
      SecRadiusY=  AnsiString(HBEAM[i][7]).ToDouble();             //fx  8
      SecRadiusZ=  AnsiString(HBEAM[i][8]).ToDouble();             //fy  9
      SecCoeffY=  AnsiString(HBEAM[i][9]).ToDouble();             //Zx  10
                                                           //Zy  11
      AreaWeb= T1*(Height-2*T2);
      break;
    }

  for(i=0;i<15 && !found;i++)
    if(AnsiString(IBEAM[i][0])==steel) {
      found = true;
      SteelType = stIBEAM;

      sub = AnsiString(IBEAM[i][0]);
      len = sub.Length();
      epos = sub.Pos("��");
      spos = sub.Pos("-");
      AnsiString s1,s2;
      s1 = sub.SubString(spos+1,epos-spos-1);
      s2 = sub.SubString(epos+2,len-epos);

      Height= sub.SubString(spos+1,epos-spos-1).ToDouble();    //H   0
      Width= sub.SubString(epos+2,len-epos).ToDouble();       //B   1
      T1= AnsiString(IBEAM[i][1]).ToDouble();             //t1  2
      T2= AnsiString(IBEAM[i][2]).ToDouble();             //t2  3
      Area=  AnsiString(IBEAM[i][3]).ToDouble();             //A   4
      Weight=   AnsiString(IBEAM[i][4]).ToDouble();             //W   5
      SecMomentY=  AnsiString(IBEAM[i][5]).ToDouble();             //Ix  6
                                                           //Iy  7
      SecRadiusY=  AnsiString(IBEAM[i][7]).ToDouble();             //fx  8
      SecRadiusZ=  AnsiString(IBEAM[i][8]).ToDouble();             //fy  9
      SecCoeffY=  AnsiString(IBEAM[i][9]).ToDouble();             //Zx  10
                                                           //Zy  11
      AreaWeb= T1*(Height-2*T2);

      break;
    }

  for(i=0;i<9 && !found;i++)
    if(AnsiString(CHAN[i][0])==steel) {
      found = true;
      SteelType = stCHANNEL;

      sub = AnsiString(CHAN[i][0]);
      len = sub.Length();
      epos = sub.Pos("��");
      spos = sub.Pos("-");
      AnsiString s1,s2;
      s1 = sub.SubString(spos+1,epos-spos-1);
      s2 = sub.SubString(epos+2,len-epos);

      Height= sub.SubString(spos+1,epos-spos-1).ToDouble();    //H   0
      Width= sub.SubString(epos+2,len-epos).ToDouble();       //B   1
      T1= AnsiString(CHAN[i][1]).ToDouble();             //t1  2
      T2= AnsiString(CHAN[i][2]).ToDouble();             //t2  3
      Area=  AnsiString(CHAN[i][3]).ToDouble();             //A   4
      Weight=   AnsiString(CHAN[i][4]).ToDouble();             //W   5
      SecMomentY=  AnsiString(CHAN[i][5]).ToDouble();             //Ix  6
                                                          //Iy  7
      SecRadiusY=  AnsiString(CHAN[i][7]).ToDouble();             //fx  8
      SecRadiusZ=  AnsiString(CHAN[i][8]).ToDouble();             //fy  9
      SecCoeffY=  AnsiString(CHAN[i][9]).ToDouble();             //Zx  10
                                                           //Zy  11
      AreaWeb= T1*(Height-2*T2);

      break;
    }

  for(i=0;i<46 && !found;i++)
    if(AnsiString(ANG[i][0])==steel) {
      found = true;
      SteelType = stANGLE;

      sub = AnsiString(ANG[i][0]);
      len = sub.Length();
      epos = sub.Pos("��");
      spos = sub.Pos("-");
      AnsiString s1,s2;
      s1 = sub.SubString(spos+1,epos-spos-1);
      s2 = sub.SubString(epos+2,len-epos);

      Height = sub.SubString(spos+1,epos-spos-1).ToDouble();   //H
      Width = sub.SubString(epos+2,len-epos).ToDouble();      //B
      T1 = T2 = AnsiString(ANG[i][1]).ToDouble();       //t
      Area = AnsiString(ANG[i][2]).ToDouble();              //A
      Weight = AnsiString(ANG[i][3]).ToDouble();               //W
      SecMomentY = AnsiString(ANG[i][4]).ToDouble();         //Ix=Iy
      SecRadiusY = SecRadiusZ = AnsiString(ANG[i][5]).ToDouble();         //fx=fy
      SecCoeffY = AnsiString(ANG[i][6]).ToDouble();         //Zx=Zy
      break;
    }

  for(i=0;i<9 && !found;i++)
    if(AnsiString(S_P[i][0])==steel) {
      found = true;
      SteelType = stSHEETPILE;

      sub = AnsiString(S_P[i][0]);
      len = sub.Length();
      epos = sub.Pos("��");
      spos = sub.Pos("-");
      AnsiString s1,s2;
      s1 = sub.SubString(spos+1,epos-spos-1);
      s2 = sub.SubString(epos+2,len-epos);

      Width = sub.SubString(spos+1,epos-spos-1).ToDouble();   // B
      Height = sub.SubString(epos+2,len-epos).ToDouble();      // H
      T1 = AnsiString(ANG[i][1]).ToDouble();              // t
      Area = AnsiString(ANG[i][2]).ToDouble();               // A/ea
      AreaWeb = AnsiString(ANG[i][3]).ToDouble();               // A/m
      Weight = AnsiString(ANG[i][4]).ToDouble();                // W/ea
      T2 = AnsiString(ANG[i][5]).ToDouble();              // W/m
      SecMomentY = AnsiString(ANG[i][6]).ToDouble();               // I/ea
      SecRadiusY = AnsiString(ANG[i][7]).ToDouble();               // I/m
      SecCoeffY = AnsiString(ANG[i][8]).ToDouble();               // Z/ea
      SecRadiusZ = AnsiString(ANG[i][9]).ToDouble();               // Z/m
      break;
    }
}

void MkStrut::ComposeSpec(AnsiString &steel)
{
  steel="";
  switch(SteelType) {
    case stHBEAM: steel=AnsiString("H-")+Height+"��"+Width; break;
    case stIBEAM: steel=AnsiString("I-")+Height+"��"+Width; break;
    case stCHANNEL: steel=AnsiString("C-")+Height+"��"+Width; break;
    case stANGLE: steel=AnsiString("A-")+Height+"��"+Width; break;
    case stSHEETPILE: steel=AnsiString("SP-")+Width+"��"+Height; break;
  }
}

void MkStrut::Import(MkGlobalVar &globalvar, int sec, MkSide, int tan)
{

  Width=globalvar.strut_BB[sec+1];
  Height=globalvar.strut_HH[sec+1];
  T1=globalvar.strut_tt1[sec+1];
  T2=globalvar.strut_tt2[sec+1];
  Area=globalvar.strut_AA[sec+1];
  AreaWeb=globalvar.strut_Aw[sec+1];
  Weight=globalvar.strut_W[sec+1];
  SecCoeffY=globalvar.strut_Zx[sec+1];
  SecMomentY=globalvar.strut_Ix[sec+1];
  SecRadiusY=globalvar.strut_rx[sec+1];
  SecRadiusZ=globalvar.strut_ry[sec+1];
/*
  Tan = globalvar.support_tan_L[sec+1][LeftTan+1];
      //globalvar.support_tan_R[sec+1][RightTan+1]);

  JackingForce = globalvar.support_jackingforce_L[sec+1][LeftTan+1];
               //globalvar.support_jackingforce_R[sec+1][RightTan+1]);

  Depth = globalvar.support_depth_L[sec+1][LeftTan+1];
        //globalvar.support_depth_R[sec+1][RightTan+1]);

  Spacing = globalvar.support_var_L[sec+1][LeftTan+1];
          //globalvar.support_var_R[sec+1][RightTan+1]);

  Wale.SetMajorWale(MajorWale);
  Wale.Import(globalvar,sec,Tan);
*/
//  IniDisp;
//  StressLoss;
//  RakerAng;
//  YoungMod;
//  ShearTor;
}

void MkStrut::Export(MkGlobalVar &globalvar, int sec, MkSide side, int tan)
{
  globalvar.strut_BB[sec+1]=Width;
  globalvar.strut_HH[sec+1]=Height;
  globalvar.strut_tt1[sec+1]=T1;
  globalvar.strut_tt2[sec+1]=T2;
  globalvar.strut_AA[sec+1]=Area;
  globalvar.strut_Aw[sec+1]=AreaWeb;
  globalvar.strut_W[sec+1]=Weight;
  globalvar.strut_Zx[sec+1]=SecCoeffY;
  globalvar.strut_Ix[sec+1]=SecMomentY;
  globalvar.strut_rx[sec+1]=SecRadiusY;
  globalvar.strut_ry[sec+1]=SecRadiusZ;
/*
  globalvar.support_tan_L[sec+1][tan+1]=globalvar.support_tan_R[sec+1][tan+1]=Tan;
  globalvar.support_type_L[sec+1][tan+1]=globalvar.support_type_R[sec+1][tan+1]="������";
  globalvar.support_depth_L[sec+1][tan+1]=globalvar.support_depth_R[sec+1][tan+1]=Depth;
  globalvar.support_var_L[sec+1][tan+1]=globalvar.support_var_R[sec+1][tan+1]=Spacing;
  globalvar.support_jackingforce_L[sec+1][tan+1]=globalvar.support_jackingforce_R[sec+1][tan+1]=JackingForce;
  Wale.Export(globalvar, sec, Tan);
*/
}
#endif

void MkStrut::SetBeam(MkBeam beam)
{
  SetSteelType(beam.SteelType);
  SetHeight(beam.HH);
  SetWidth(beam.BB);
  SetT1(beam.tt1);
  SetT2(beam.tt2);
  SetArea(beam.AA);
  SetAreaWeb(beam.Aw);
  SetWeight(beam.W);
  SetSecCoeffY(beam.Zx);
  SetSecCoeffZ(beam.Zx);
  SetSecMomentY(beam.Ix);
  SetSecMomentZ(beam.Ix);
  SetSecRadiusY(beam.rx);
  SetSecRadiusZ(beam.ry);
}

bool MkStrut::operator==(MkStrut &strut)
{
  bool flag = true;
  flag = flag && MkEntity::operator==((MkEntity&)strut);
  flag = flag && MajorWale==strut.MajorWale;
  flag = flag && Height==strut.Height; // H
  flag = flag && Width==strut.Width;  // B
  flag = flag && T1==strut.T1;
  flag = flag && T2==strut.T2;
  flag = flag && Area==strut.Area;
  flag = flag && AreaWeb==strut.AreaWeb;
  flag = flag && Weight==strut.Weight;
  flag = flag && SecCoeffY==strut.SecCoeffY;
  flag = flag && SecCoeffZ==strut.SecCoeffZ;
  flag = flag && SecMomentY==strut.SecMomentY;
  flag = flag && SecMomentZ==strut.SecMomentZ;
  flag = flag && SecRadiusY==strut.SecRadiusY;
  flag = flag && SecRadiusZ==strut.SecRadiusZ;

  flag = flag && Spacing==strut.Spacing;
  flag = flag && JackingForce==strut.JackingForce;
  flag = flag && IniDisp==strut.IniDisp;
  flag = flag && StressLoss==strut.StressLoss;
  flag = flag && RakerAng==strut.RakerAng;
  flag = flag && YoungMod==strut.YoungMod;
  flag = flag && ShearTor==strut.ShearTor;
  flag = flag && StrutLine==strut.StrutLine;

  return flag;
}

bool MkStrut::operator!=(MkStrut &strut)
{
  return !operator==(strut);
}

MkStrut& MkStrut::operator=(MkStrut& strut)
{
  MkEntity::operator=((MkEntity&)strut);
  Height=strut.Height; // H
  Width=strut.Width;  // B
  T1=strut.T1;
  T2=strut.T2;
  Area=strut.Area;
  AreaWeb=strut.AreaWeb;
  Weight=strut.Weight;
  SecCoeffY=strut.SecCoeffY;
  SecCoeffZ=strut.SecCoeffZ;
  SecMomentY=strut.SecMomentY;
  SecMomentZ=strut.SecMomentZ;
  SecRadiusY=strut.SecRadiusY;
  SecRadiusZ=strut.SecRadiusZ;

  Spacing=strut.Spacing;
  JackingForce=strut.JackingForce;
  IniDisp=strut.IniDisp;
  StressLoss=strut.StressLoss;
  RakerAng=strut.RakerAng;
  YoungMod=strut.YoungMod;
  ShearTor=strut.ShearTor;
  StrutLine=strut.StrutLine;

  return *this;
}

#ifdef __BCPLUSPLUS__
void MkStrut::Draw(TObject *Sender)
{
  StrutLine.Draw(Sender);
}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void MkStrut::Draw(MkPaint *pb)
{

}
#endif
//---------------------------------------------------------------------------
MkStruts::MkStruts(int size,MkStrut *struts)
{
    if (size < 0) {
      MkDebug("::MkStruts - MkStruts(int size)");;
      return;
    }

    FSizeOfArray = FSize = size;
    if (FSize == 0) {
       FStrut = NULL;
       return;
    }

    FStrut = new MkStrut[FSize];
    for (int i=0;i<FSize;i++) (*this)[i] = struts[i];
}

MkStruts::MkStruts(int size)
{
    if (size < 0) {
      MkDebug("::MkStruts - MkStruts(int size)");;
      return;
    }

    FSizeOfArray = size;
    FSize = 0;
    if (FSizeOfArray == 0) {
       FStrut = NULL;
       return;
    }

    FStrut = new MkStrut[FSizeOfArray];
}

MkStruts::~MkStruts()
{
   FSizeOfArray = FSize = 0;
   if (FStrut) {
      delete[] FStrut;
      FStrut = NULL;
   }
}

void MkStruts::Initialize(int size)
{
    int i;
    if (size < 0) {
      MkDebug("::MkStruts - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;

    FSizeOfArray = FSize = size;

    if (FSizeOfArray == 0) {
       if (FStrut!=NULL) delete[] (MkStrut*)FStrut;
       FStrut = NULL;
       return;
    }

    if (FStrut!=NULL) delete[] (MkStrut*)FStrut;
    FStrut = new MkStrut[FSizeOfArray];
    for (i=0;i<FSize;i++) FStrut[i].Number = i;
}

void MkStruts::Initialize(int size,MkStrut *struts)
{
    int i;
    if (size < 0 || struts == NULL) {
      MkDebug("::MkStruts - Initialize(int size)");;
      return;
    }
    if (FSizeOfArray == size) return;
    FSize = FSizeOfArray = size;
    if (FSizeOfArray == 0) {
       if (FStrut!=NULL) delete[] (MkStrut*)FStrut;
       FStrut = NULL;
       return;
    }

    if (FStrut!=NULL) delete[] (MkStrut*)FStrut;
    FStrut = new MkStrut[FSizeOfArray];
    for (i=0;i<FSizeOfArray;i++) FStrut[i] = struts[i];
    for (i=0;i<FSize;i++) FStrut[i].Number = i;
}

int MkStruts::Grow(int delta)
{
    int i;
    MkStrut *strut=NULL;

    if (!(strut = new MkStrut[FSizeOfArray+delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        strut[i] = FStrut[i];
    for (i=FSize; i<FSizeOfArray+delta;i++)
        strut[i] = NullStrut;
    if (FStrut) {
       delete[] (MkStrut*)FStrut;
       FStrut = NULL;
    }
    FStrut = strut;
    FSizeOfArray = FSizeOfArray+delta;
    return FSizeOfArray;
}

int MkStruts::Shrink(int delta)
{
    int i;
    MkStrut *strut=NULL;

    if (!(strut = new MkStrut[FSizeOfArray-delta])) return FSizeOfArray;

    for (i = 0; i < FSize;i++)
        strut[i] = FStrut[i];
    for (i=FSize; i<FSizeOfArray-delta;i++)
        strut[i] = NullStrut;
    if (FStrut) {
       delete[] (MkStrut*)FStrut;
       FStrut = NULL;
    }
    FStrut = strut;
    FSizeOfArray = FSizeOfArray-delta;
    return FSizeOfArray;
}

bool MkStruts::Add(MkStrut &strut)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    FSize++;
    FStrut[FSize-1] = strut;
    return true;
}

bool MkStruts::Add(int index, MkStrut &strut)
{
    int tmp=FSizeOfArray;

    if(FSize>=FSizeOfArray) {
      Grow(FSize-FSizeOfArray+1);
      if(tmp==FSizeOfArray) return false;
    }

    for (int i=FSize-1;i>=index;i--)
      FStrut[i+1] = FStrut[i];
    FSize++;
    FStrut[index] = strut;
    return true;
}

bool MkStruts::Delete(MkStrut &strut)
{
    int i;
    for (i=0;i<FSize;i++) {
      if(FStrut[i] == strut) break;
    }
    if(i==FSize) return false;
    if(FStrut[i] == strut) {
      for (int j=i;j<FSize-1;j++)
        FStrut[j] = FStrut[j+1];
    }
    FSize--;
    FStrut[FSize] = NullStrut;
    return true;
}

bool MkStruts::Delete(int index)
{
    for (int j=index;j<FSize-1;j++)
        FStrut[j] = FStrut[j+1];

    FSize--;
    FStrut[FSize] = NullStrut;
    return true;
}

bool MkStruts::Clear()
{
   FSizeOfArray = FSize = 0;
   if (FStrut) {
      delete[] FStrut;
      FStrut = NULL;
   }
   return true;
}

MkStrut & MkStruts::operator[](int i)
{
    if (0<=i && i<FSize) return FStrut[i];
    else if(FSize<=i && i<FSizeOfArray) {
      FSize=i+1;
      return FStrut[i];
    }
    else if (FSizeOfArray <= i) {
      Grow(i-FSizeOfArray+5);
      return NullStrut;
    }
    else return NullStrut;
}

MkStruts & MkStruts::operator=(MkStruts &struts)
{
    int i;

    Clear();
    FSize = struts.FSize;
    FSizeOfArray = struts.FSizeOfArray;
    if (FSizeOfArray == 0) {
       FStrut = NULL;
       return *this;
    }
    this->FStrut = new MkStrut[FSizeOfArray];

    for (i=0;i<FSize;i++)
      FStrut[i] = struts.FStrut[i];
    for (i=FSize;i<FSizeOfArray;i++)
      FStrut[i] = NullStrut;

    return *this;
}

bool MkStruts::operator==(MkStruts &struts)
{
    int i;

    if (FSize != struts.FSize) return false;
    for (i=0;i<FSize;i++)
      if (this->FStrut[i] != struts.FStrut[i]) return false;

    return true;
}

#ifdef __BCPLUSPLUS__
void MkStruts::Out(TObject *)
{

}
#endif

void MkStruts::Out(char *fname)
{
  FILE *fp;
  fp = fopen(fname,"a");
  if(!fp) {
    return;
  }

  if(FSize==0) return;
    
            //12345678901234567890123456789012345678901234567890123456789012345678901234567890
  fprintf(fp,"\n");
  fprintf(fp,"                           <Information of Struts>\n");
  fprintf(fp,"\n");
  fprintf(fp," Strut Depth   Length  Area     I       E    Spacing  \n");
  fprintf(fp,"   No.   (m)    (m)    (m2)    (m4)   (t/m2)   (m)  \n");
  fclose(fp);

  for(int i=0;i<FSize;i++) 
    FStrut[i].Out(fname);
}

#ifdef __BCPLUSPLUS__
void MkStruts::Import(MkGlobalVar &globalvar, int sec)
{
  int i;
  for(i=0;i<FSize;i++)
    FStrut[i].Import(globalvar,sec,mkLeft,i);
}

void MkStruts::Export(MkGlobalVar &globalvar, int sec)
{
  int i;
  for(i=0;i<FSize;i++)
    FStrut[i].Export(globalvar,sec,mkLeft,i);
}
#endif

#ifdef __BCPLUSPLUS__
void MkStruts::Draw(TObject *Sender)
{
    TColor C;
    float Offset;
    if (FSize == 0) return;
    if (String(Sender->ClassName()) == String("MkPaintBox")) {
       MkPaintBox *pb=(MkPaintBox*)Sender;
       C = pb->Canvas->Pen->Color;
       pb->Canvas->Pen->Color = Color;
       for (int i = 0; i < FSize;i++) {
           Offset = pb->Offset(3);
           FStrut[i].Draw(pb);
       }
       pb->Canvas->Pen->Color = C;
    }
}
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
void MkStruts::Draw(MkPaint *pb)
{

}
#endif


