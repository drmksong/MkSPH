//---------------------------------------------------------------------------
#ifndef MkSupportH
#define MkSupportH
#include "MkObject.h"
#include "MkEntity.h"
#include "MkWale.h"
//---------------------------------------------------------------------------
class MkSupport : public MkObject {
private:
#ifdef __BCPLUSPLUS__
  AnsiString MajorWale;
#else 
  char MajorWale[256];
#endif
public:
#ifdef __BCPLUSPLUS__
  AnsiString type;
  AnsiString info;
#else
  char type[256];
  char info[256];
#endif
  int Tan;
  MkSide side;
  int tendonEA;
  double depth,R_depth;
  double var;
  double freelen;  // Diameter spec for rockbolt, free length for anchor
  double sticklen;
  double jackingforce;
  double inidis; // newly made 2005.5
  double strloss; // newly made 2005.5
  MkWale Wale; // if type is rockbolt then wale is diameter, else then wale.
public:
  MkSupport();
  MkSupport(int);
  ~MkSupport(){}

  void Clear();
#ifdef __BCPLUSPLUS__
  void Import(MkGlobalVar &globalvar, int sec, MkSide side, int tan);
  void Export(MkGlobalVar &globalvar, int sec, MkSide side, int tan);

  void SetMajorWale(AnsiString str){MajorWale = str;}
  AnsiString GetMajorWale(){return MajorWale;}
  AnsiString GetInfo();
#else 
  void SetMajorWale(char *str){strcpy(MajorWale,str);}
  char *GetMajorWale(){return MajorWale;}
  char* GetInfo();
#endif

  bool operator==(MkSupport &spt);
  bool operator!=(MkSupport &spt);
  MkSupport &operator=(MkSupport &spt);
};

class MkSupports {
private:
#ifdef __BCPLUSPLUS__
  AnsiString MajorWale;
#else 
  char MajorWale[256];
#endif

protected:
  MkSupport *FSupport;
  int FSize;//Actual size of nodes
  int FSizeOfArray;
public:
  MkSupports(int size,MkSupport *support);
  MkSupports(int size);
  MkSupports(){FSizeOfArray = FSize = 0;FSupport = NULL;}
  ~MkSupports();

  virtual void Initialize(int size);
  virtual void Initialize(int size,MkSupport *);
  int GetSize(){return FSize;};
  int GetNumber(){return FSize;};
  bool Add(MkSupport &support);  // change of size of support
  bool Add(int index,MkSupport &support);
  bool Delete(MkSupport &support);  // change of size of support
  bool Delete(int index);
  int Grow(int Delta);            // change of size of array
  int Shrink(int Delta);          // change of size of array
  bool Clear();
  virtual MkSupport & operator[](int);
  MkSupports & operator=(MkSupports &supports);
  bool operator==(MkSupports &supports);

#ifdef __BCPLUSPLUS__
  void Import(MkGlobalVar &globalvar, int sec, MkSide side);
  void Export(MkGlobalVar &globalvar, int sec, MkSide side);

  void SetMajorWale(AnsiString str){MajorWale = str;}
  AnsiString GetMajorWale(){return MajorWale;}
#else 
  void SetMajorWale(char *str){strcpy(MajorWale,str);}
  char *GetMajorWale(){return MajorWale;}
#endif

};
extern MkSupport NullSupport;
void Swap(MkSupports &Supports, int i, int j);
#endif
