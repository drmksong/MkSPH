//---------------------------------------------------------------------------
// It is part of OPTIFACE program which is to be designed to get
// the best parameter using Genetic alogrithm which is one of optimization
// algorithm.
// The work of this project was started by T.H. Ahn, and handed to M.K. Song.
// Copyright (c) 1999 ESCO Consultant Co., Ltd.#include <vcl.h>
#pragma hdrstop

#include "TTunPart.h"

//TTunPart::TTunPart(){}

TTunPart::~TTunPart()
{
//   *this.~TMyShapeList();
}

bool TTunPart::isContinuous()
{
    bool flag = true;
    TRealLine rl;
    TRealArc ra;
    TRealPoint p1,p2;
    for (int i = 0 ; i < GetNumberOfShape()-1; i++ ) {
        if ((*this)[i].ClassName() == "TRealArc") {
           ra = (TRealArc &)(*this)[i];
           p1 = ra[2];
        }
        else if ((*this)[i].ClassName() == "TRealLine") {
           rl = (TRealLine &)(*this)[i];
           p1 = rl[1];
        }
        if ((*this)[i+1].ClassName() == "TRealArc") {
           ra = (TRealArc &)(*this)[i+1];
           p2 = ra[1];
        }
        else if ((*this)[i+1].ClassName() == "TRealLine") {
           rl = (TRealLine &)(*this)[i+1];
           p2 = rl[0];
        }
        if (p1 != p2) flag = false;
    }
    if ((*this)[GetNumberOfShape()-1].ClassName() == "TRealArc") {
       ra = (TRealArc &)(*this)[GetNumberOfShape()-1];
       p1 = ra[2];
    }
    else if ((*this)[GetNumberOfShape()-1].ClassName() == "TRealLine") {
       rl = (TRealLine &)(*this)[GetNumberOfShape()-1];
       p1 = rl[1];
    }
    if ((*this)[0].ClassName() == "TRealArc") {
       ra = (TRealArc &)(*this)[0];
       p2 = ra[1];
    }
    else if ((*this)[0].ClassName() == "TRealLine") {
       rl = (TRealLine &)(*this)[0];
       p2 = rl[0];
    }
    if (p1 != p2) flag = false;
    Continuity = flag;
    return Continuity;
}

bool TTunPart::isCrossed()
{
    if (!GetNumberOfShape()) return Crossing = false;
    Crossing = true;
    return Crossing;
}

float TTunPart::GetArea()
{
    float NumberOfPoint = 0;
    float Area=0;
    TRealLine rl;
    TRealArc ra;

//    if (isContinuous()) {
       NumberOfPoint = GetNumberOfShape();
       TRealPolygon InnerSpace(NumberOfPoint+1);
       for (int i = 0;i < NumberOfPoint; i+=2 ) {
           if ((*this)[i].ClassName() == "TRealArc") {
              ra = (TRealArc &)(*this)[i];
              InnerSpace[i] = ra[1];
              InnerSpace[i+1] = ra[2];
           }
           else if ((*this)[i].ClassName() == "TRealLine") {
              rl = (TRealLine &)(*this)[i];
              InnerSpace[i] = rl[0];
              InnerSpace[i+1] = rl[1];
           }
       }
       Area = InnerSpace.GetArea();
       for (int i = 0;i<(*this).GetNumberOfShape();i++) {
           if ((*this)[i].ClassName() == "TRealArc") {
              ra = (TRealArc &)(*this)[i];
              Area += ra.GetCrownArea();
           }
       }
//    }
    return Area;
}

TTunParts::TTunParts(int size)
{
    if (size<=0) {
       ShowMessage( "bad TTunParts size");
       return;
    }

    FI = 0;

    Size = long(size);

    try {
        F = new TTunPart[Size];
    }
    catch (std::bad_alloc){
       ShowMessage( "Not Enough Memory");
       F = NULL;
       return;
    }
}

TTunParts::TTunParts()
{
     FI = 0;
     F=NULL;
     FCur=NULL;
     Size=0;
}

TTunParts::~TTunParts()
{
     for (int i = 0 ; i < Size ; i++)
         F[i].~TTunPart();

     if (F!=NULL) delete[] F;
}

void TTunParts::Initialize(int size)
{
    if (size<=0) {
       ShowMessage( "bad TTunParts size");
       return;
    }

    if (F!=NULL) {
       delete[] F;
       F = NULL;
    }

    FI = 0;

    Size = long(size);

    try {
        F = new TTunPart[Size];
    }
    catch (std::bad_alloc){
       ShowMessage( "Not Enough Memory");
       return;
    }
}

void TTunParts::SetSize(int)
{

}

TTunParts & TTunParts::operator=(TTunParts &a)
{
     Initialize(a.Size);
     for (int i = 0 ; i<Size ;i++ )
         (*this)[i] = a[i];
     return *this;
}

//---------------------------------------------------------------------------
#pragma package(smart_init)

