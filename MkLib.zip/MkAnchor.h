//---------------------------------------------------------------------------
#ifndef MkAnchorH
#define MkAnchorH
#include "MkEntity.h"
#include "MkWale.h"
//---------------------------------------------------------------------------
class MkAnchor : public MkEntity {
private:
  MkSide Side;
  MkWale Wale;
#ifdef __BCPLUSPLUS__
  AnsiString MajorWale;
#else
  char MajorWale[256];
#endif
  int Tan, SupportTan;
protected:
  float Area;
  float Angle;
  float Spacing;
  float JackingForce;
  float TenLoss;
  float IniDis;
  float WireNum;
  float FreeLength;
  float StickLength;
  float YoungMod;
  float ShearTor;
  float SecMomentY, SecMomentZ;  // second moment of inertial
  MkLine AnchorLine;
public:
  MkAnchor();
  MkAnchor(int n);
  ~MkAnchor(){};
public: // setting function
  void SetSide(MkSide side){Side = side;}
  void SetWale(MkWale &wale){Wale = wale;}
#ifdef __BCPLUSPLUS__
  void SetMajorWale(AnsiString wale){MajorWale = wale;}
#else
  void SetMajorWale(char* wale){strcpy(MajorWale,wale);}
#endif

  void SetTan(int tan){Tan = tan;}
  void SetSupportTan(int tan){SupportTan = tan;}

  void SetArea(float a){Area=a;}
  void SetAngle(float a){Angle=a;}
  void SetSpacing(float s){Spacing=s;}
  void SetJackingForce(float f){JackingForce=f;}
  void SetTenLoss(float tl){TenLoss=tl;}
  void SetIniDis(float id){IniDis=id;}
  void SetWireNum(float wn){WireNum=wn;}
  void SetFreeLength(float fl){FreeLength=fl;}
  void SetStickLength(float sl){StickLength=sl;}

  void SetYoungMod(float y){YoungMod = y;}
  void SetShearTor(float s){ShearTor = s;}
  void SetSecMomentY(float m){SecMomentY = m;}
  void SetSecMomentZ(float m){SecMomentZ = m;}
  void SetLine(MkLine &line)
    {
      AnchorLine = line;
      AnchorLine.SetFiniteness(true);
      Depth = -AnchorLine[0].Y;
      Length = AnchorLine.GetLength();
    };

public:
  MkSide GetSide(){return Side;}
  MkWale &GetWale(){return Wale;}
#ifdef __BCPLUSPLUS__
  AnsiString GetMajorWale(){return MajorWale;}
#else

#endif
  int GetTan(){return Tan;}
  int GetSupportTan(){return SupportTan;}

  float GetArea(){return Area;}
  float GetAngle(){return Angle;}
  float GetSpacing(){return Spacing;}
  float GetJackingForce(){return JackingForce;}
  float GetTenLoss(){return TenLoss;}
  float GetIniDis(){return IniDis;}
  float GetWireNum(){return WireNum;}
  float GetFreeLength(){return FreeLength;}
  float GetStickLength(){return StickLength;}

  float GetYoungMod(){return YoungMod;}
  float GetShearTor(){return ShearTor;}
  float GetSecMomentY(){return SecMomentY;}  // second moment of inertial
  float GetSecMomentZ(){return SecMomentZ;}  // second moment of inertial
  MkLine &GetLine(){return AnchorLine;}

public:
#ifdef __BCPLUSPLUS__
  AnsiString ClassName(){return AnsiString("MkAnchor");};
  bool UpdateFrom(TStringGrid *grid){Grid = grid;return UpdateFrom();};
  bool UpdateTo(TStringGrid *grid){Grid = grid;return UpdateTo();};
  bool UpdateFrom();
  bool UpdateTo();
  void Out(TObject *);
  void Import(MkGlobalVar &globalvar, int sec, MkSide side, int tan);
  void Export(MkGlobalVar &globalvar, int sec, MkSide side, int tan);
#else
  char* ClassName(){return "MkAnchor";}
#endif

  void Out(char *fname);
  void Clear();

#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif
  bool operator==(MkAnchor&);
  bool operator!=(MkAnchor&);
  MkAnchor &operator=(MkAnchor&);
};

class MkAnchors {
protected:
  MkAnchor *FAnchor;
  int FSize;//Actual size of entities
  int FSizeOfArray;
#ifdef __BCPLUSPLUS__
  TColor Color;
#endif
public:
  MkAnchors(int size,MkAnchor *ent);
  MkAnchors(int size);
  MkAnchors(){FSizeOfArray = FSize = 0;FAnchor = NULL;}
  ~MkAnchors();
  virtual void Initialize(int size);
  virtual void Initialize(int size,MkAnchor *);
  int GetSize(){return FSize;};
  int GetNumber(){return FSize;};
  bool Add(MkAnchor &anchor);  // change of size of anchor
  bool Add(int index,MkAnchor &anchor);
  bool Delete(MkAnchor &anchor);  // change of size of anchor
  bool Delete(int index);
  int Grow(int Delta);            // change of size of array
  int Shrink(int Delta);          // change of size of array
  bool Clear();
#ifdef __BCPLUSPLUS__
  TColor GetColor(){return Color;};
  void SetColor(TColor c){Color = c;}
  void Out(TObject *);
  void Import(MkGlobalVar &globalvar, int sec);
  void Export(MkGlobalVar &globalvar, int sec);
#else
#endif
  void Out(char *fname);

#ifdef __BCPLUSPLUS__
  void  Draw(TObject *);
#endif

#if defined(_MSC_VER) && defined(_WINDOWS_)
  void Draw(MkPaint *);
#endif

  virtual MkAnchor & operator[](int);
  MkAnchors & operator=(MkAnchors &anchors);
  bool operator==(MkAnchors &anchors);
};
//---------------------------------------------------------------------------
extern MkAnchor NullAnchor;
//---------------------------------------------------------------------------
#endif
