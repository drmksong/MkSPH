//---------------------------------------------------------------------------
#include "MkWater.h"
#ifdef __BCPLUSPLUS__
#include <vcl.h>
#endif
#pragma hdrstop
//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#pragma package(smart_init)
#endif
//---------------------------------------------------------------------------
MkWater::MkWater()
{
  Clear();
}

MkWater::MkWater(int)
{
  Clear();
}

void MkWater::Clear()
{
  first_water_level=0;
  water_level_type=0;
  reductionrate=0;
  reductiondepth=0;
  W_GL_minus=0;
  level_l.Clear();
  level_r.Clear();
}

#ifdef __BCPLUSPLUS__
void MkWater::Import(MkGlobalVar &globalvar,int sec)
{
  int i;

  first_water_level= ::first_water_level;
  water_level_type= water_level_type;
  reductionrate= globalvar.reductionrate;
  reductiondepth= globalvar.reductiondepth;
  W_GL_minus= ::W_GL_minus;

  for (i=0;i<level_l.getSzX() && i<10;i++) {
    level_l(i) = ::waterlevel_l[sec+1][i+1];
  }

  for (i=0;i<level_r.getSzX() && i<10;i++) {
    level_r(i) = ::waterlevel_r[sec+1][i+1];
  }
}

void MkWater::Export(MkGlobalVar &globalvar, int sec)
{
  int i;
  ::first_water_level= first_water_level;
  globalvar.water_level_type= water_level_type;
  globalvar.reductionrate= reductionrate;
  globalvar.reductiondepth= reductiondepth;
  ::W_GL_minus= W_GL_minus;

  for (i=0;i<level_l.getSzX() && i<10;i++) {
    ::waterlevel_l[sec+1][i+1] = level_l(i);
  }

  for (i=0;i<level_r.getSzX() && i<10;i++) {
    ::waterlevel_r[sec+1][i+1] = level_r(i);
  }
}
#endif
//---------------------------------------------------------------------------
