//---------------------------------------------------------------------------
#include "MkAnalyticSection.h"

#ifdef __BCPLUSPLUS__
#include <vcl.h>
#endif

#pragma hdrstop
#include "stdafx.h"
//---------------------------------------------------------------------------
#ifdef __BCPLUSPLUS__
#pragma package(smart_init)
#endif
//---------------------------------------------------------------------------
MkAnalyticSection::MkAnalyticSection()
{
  char str[256];

  Ana.Clear();
//  sprintf(str,"FSize of Piles is %d, FSizeOFArray is %d\n",Piles.GetSize(),Piles.GetSizeOfArray());
//  MkDebug(str);
  Piles.Clear();
//  sprintf(str,"FSize of Piles is %d, FSizeOFArray is %d\n",Piles.GetSize(),Piles.GetSizeOfArray());
//  MkDebug(str);

  Struts.Clear();
  Bolts.Clear();
  Anchors.Clear();
  Wales.Clear();
  Panels.Clear();
  Layers.Clear();
  Cuts.Clear();
  Fills.Clear();
  Subreacts.Clear();

  memset(FileName,'\0',255);
}

MkAnalyticSection::~MkAnalyticSection()
{
  int i=0;//delete it if you saw this line!!!
  i = i+1;
}

bool MkAnalyticSection::Initialize(MkLayers &lay)
{
  Layers = lay;
  return false;
}

void MkAnalyticSection::AddAnalysis(MkAnalysisType at)
{
  int i;
  for(i=0;i<Ana.GetSize();i++)
    if(at==Ana[i]->GetAnalysisType()) return;

  switch(at) {
    case atMori: {
      MkMori *m = new MkMori();
      Ana.Add(m);
      delete m;
      break;
    }
    case atBeamSpring: {
      MkBeamSpring *b = new MkBeamSpring();
      Ana.Add(b);
      delete b;
      break;
    }
    case atContBeam: {
      MkContBeam *cb = new MkContBeam();
      Ana.Add(cb);
      delete cb;
      break;
    }
  }
  Ana[Ana.GetSize()-1]->SetNodes(*NodeRef);
}

void MkAnalyticSection::DelAnalysis(MkAnalysisType at)
{
  int i;
  for(i=0;i<Ana.GetSize();i++)
    if(at==Ana[i]->GetAnalysisType()) Ana.Del(Ana[i]);
}
/*
void MkAnalyticSection::SetupDivision()
{
  int i;
  float len,s;
  int div;
  s = Spacing;

  if (fabs(s) < EPS) return;

  for (i=0;i<Piles.GetSize();i++) {
    len = Piles[i].GetLine().GetLength();
    div = int(len/s);
    Piles[i].SetDivision(div);
  }
  for (i=0;i<Struts.GetSize();i++) {
    len = Struts[i].GetLine().GetLength();
    div = int(len/s);
    Struts[i].SetDivision(div);
  }
  for (i=0;i<Bolts.GetSize();i++) {
    len = Bolts[i].GetLine().GetLength();
    div = int(len/s);
    Bolts[i].SetDivision(div);
  }
  for (i=0;i<Anchors.GetSize();i++) {
    len = Anchors[i].GetLine().GetLength();
    div = int(len/s);
    Anchors[i].SetDivision(div);
  }
}
*/
void MkAnalyticSection::SetupLoad()
{
  MkVector dir;
  MkPoint p[2],ori;
  Loads.Clear();

  for (int i=0;i<Piles.GetSize();i++) {
    p[0] = Piles[i].GetLine()[0];
    p[1] = Piles[i].GetLine()[1];

    MkRankine *rankine;

    dir.SetVector(1,0,0);
    ori = p[0].Y > p[1].Y ? p[0] : p[1];

    rankine = new MkRankine();
    rankine->SetOrigin(ori);
    rankine->SetDirection(dir);
    rankine->BuildFrom(Layers,Cuts,Fills,Piles[i]);
    Loads.Add(rankine);
    delete rankine;

    dir.SetVector(-1,0,0);
    ori = p[0].Y > p[1].Y ? p[0] : p[1];

    rankine = new MkRankine();
    rankine->SetOrigin(ori);
    rankine->SetDirection(dir);
    rankine->BuildFrom(Layers,Cuts,Fills,Piles[i]);
    Loads.Add(rankine);
    delete rankine;
  }
  OutLoad("loadpoly.chk");
}

void MkAnalyticSection::SetupSubreact()
{
  FILE *fp;
  int i,j;
  MkVector dir;
  MkPoint p[2],ori;
  Subreacts.Initialize(Piles.GetSize()*2);

  fp = fopen("subreact.chk","a");

  for (int i=0;i<Piles.GetSize();i++) {
    p[0] = Piles[i].GetLine()[0];
    p[1] = Piles[i].GetLine()[1];

    MkDebug("Before left of wall 0\n");
    dir.SetVector(1,0,0);
    ori = p[0].Y > p[1].Y ? p[0] : p[1];
    Subreacts[2*i].SetDirection(dir);
    Subreacts[2*i].SetOrigin(ori);
    Subreacts[2*i].Build(Layers,Cuts,Fills,Piles[i]);

    fprintf(fp,"%d-th left subreact\n",i/2);
    MkPolygon &lp = Subreacts[2*i].GetSubreact();
    for(j=0;j<lp.GetSize();j++) {
      fprintf(fp,"%d %f %f\n",j,lp[j].X,lp[j].Y);
    }
    fputs("\n\n",fp);

    MkDebug("Before right of wall 0\n");
    dir.SetVector(-1,0,0);
    ori = p[0].Y > p[1].Y ? p[0] : p[1];
    Subreacts[2*i+1].SetDirection(dir);
    Subreacts[2*i+1].SetOrigin(ori);
    Subreacts[2*i+1].Build(Layers,Cuts,Fills,Piles[i]);

    fprintf(fp,"%d-th right subreact\n",(i+1)/2);
    MkPolygon &rp = Subreacts[2*i+1].GetSubreact();
    for(j=0;j<rp.GetSize();j++) {
      fprintf(fp,"%d %f %f\n",j,rp[j].X,rp[j].Y);
    }
    fputs("\n\n",fp);
  }
  fclose(fp);
}

bool MkAnalyticSection::Install(MkStrut &strut)
{
  int i,div=strut.GetDivision();
  MkLine &line=strut.GetLine();

  MkNodes node(div+1);
  MkInt elemnode(2);
  MkElements elem;
  MkElement **truss;
  MkFloat prop(5);

  MkDOFs dof(6);
  dof[0].SetType(doftXDis,bndtFree);
  dof[1].SetType(doftYDis,bndtFix);
  dof[2].SetType(doftZDis,bndtFix);
  dof[3].SetType(doftXAng,bndtFix);
  dof[4].SetType(doftYAng,bndtFix);
  dof[5].SetType(doftZAng,bndtFix);

  for (i=0;i<div+1;i++) {
    MkPoint pnt;
    pnt=line.GetDivision(float(i)/float(div));
    node[i].SetPoint(pnt);
    node[i].SetDOF(dof);
  }

  truss = new MkElement*[div];
  for (i=0;i<div;i++) truss[i] = new MkTrussElement();

  prop(0) = strut.GetYoungMod();
  prop(1) = strut.GetArea();
  prop(2) = strut.GetShearTor();
  prop(3) = strut.GetSecMomentY();
  prop(4) = strut.GetSecMomentZ();

  for (i=0;i<div;i++) {
    elemnode[0] = i;
    elemnode[1] = i+1;
    truss[i]->SetElemNode(elemnode);
    truss[i]->SetNodes(node);
    truss[i]->SetupProp(prop);
    truss[i]->SetAxialLoad(0);
  }

  elem.Initialize(div,truss);

  truss[0]->SetupStiff();
  elem[0].SetupStiff();

  for (i=0;i<div;i++) delete truss[i];
  delete[] truss;

  for (i=0;i<Ana.GetSize();i++) {
    Ana[i]->Add(elem);
  }
  return true;
}

bool MkAnalyticSection::Install(MkAnchor &anchor)
{
  int i,div=anchor.GetDivision();
  MkLine &line=anchor.GetLine();

  MkNodes node(div+1);
  MkInt elemnode(2);
  MkElements elem;
  MkElement **truss;
  MkFloat prop(5);

  MkDOFs dof(6);
  dof[0].SetType(doftXDis,bndtFree);
  dof[1].SetType(doftYDis,bndtFix);
  dof[2].SetType(doftZDis,bndtFix);
  dof[3].SetType(doftXAng,bndtFix);
  dof[4].SetType(doftYAng,bndtFix);
  dof[5].SetType(doftZAng,bndtFix);

  for (i=0;i<div+1;i++) {
    MkPoint pnt=line.GetDivision(float(i)/float(div));
    node[i].SetPoint(pnt);
    node[i].SetDOF(dof);
  }

  dof[0].SetType(doftXDis,bndtFix);
  if(anchor.GetSide() == mkLeft) node[0].SetDOF(dof);
  else if(anchor.GetSide() == mkRight) node[div].SetDOF(dof);
  else MkDebug("InstallSide is wrong in intall anchor\n");

  truss = new MkElement*[div];
  for (i=0;i<div;i++) truss[i] = new MkTrussElement();

  prop(0) = anchor.GetYoungMod();
  prop(1) = anchor.GetArea();
  prop(2) = anchor.GetShearTor();
  prop(3) = anchor.GetSecMomentY();
  prop(4) = anchor.GetSecMomentZ();

  for (i=0;i<div;i++) {
    elemnode[0] = i;
    elemnode[1] = i+1;
    truss[i]->SetElemNode(elemnode);
    truss[i]->SetNodes(node);
    truss[i]->SetupProp(prop);
    truss[i]->SetAxialLoad(0);
  }

  elem.Initialize(div,truss);

  for (i=0;i<div;i++) delete truss[i];
  delete[] truss;

  for (i=0;i<Ana.GetSize();i++)
    Ana[i]->Add(elem);

  return true;
}

bool MkAnalyticSection::Install(MkBolt &bolt)
{
  int i,div=bolt.GetDivision();
  MkLine &line=bolt.GetLine();

  MkNodes node(div+1);
  MkInt elemnode(2);
  MkElements elem;
  MkElement **truss;
  MkFloat prop(5);

  MkDOFs dof(6);
  dof[0].SetType(doftXDis,bndtFree);
  dof[1].SetType(doftYDis,bndtFix);
  dof[2].SetType(doftZDis,bndtFix);
  dof[3].SetType(doftXAng,bndtFix);
  dof[4].SetType(doftYAng,bndtFix);
  dof[5].SetType(doftZAng,bndtFix);

  for (i=0;i<div+1;i++) {
    MkPoint pnt=line.GetDivision(float(i)/float(div));
    node[i].SetPoint(pnt);
    node[i].SetDOF(dof);
  }

  dof[0].SetType(doftXDis,bndtFix);
  if(bolt.GetSide() == mkLeft) node[0].SetDOF(dof);
  else if(bolt.GetSide() == mkRight) node[div].SetDOF(dof);
  else MkDebug("InstallSide is wrong in intall bolt\n");

  truss = new MkElement*[div];
  for (i=0;i<div;i++) truss[i] = new MkTrussElement();

  prop(0) = bolt.GetYoungMod();
  prop(1) = bolt.GetArea();
  prop(2) = 0;//bolt.GetShearTor();
  prop(3) = 0;//bolt.GetSecMomentY();
  prop(4) = 0;//bolt.GetSecMomentZ();

  for (i=0;i<div;i++) {
    elemnode[0] = i;
    elemnode[1] = i+1;
    truss[i]->SetElemNode(elemnode);
    truss[i]->SetNodes(node);
    truss[i]->SetupProp(prop);
    truss[i]->SetAxialLoad(0);
  }

  elem.Initialize(div,truss);

  for (i=0;i<div;i++) delete truss[i];
  delete[] truss;

  for (i=0;i<Ana.GetSize();i++) {
    Ana[i]->Add(elem);
  }
  return true;
}

bool MkAnalyticSection::Install(MkPile &pile)
{
  int i,div=pile.GetDivision();
  MkLine &line=pile.GetLine();

  MkDebug("Install pile to Analytic Section\n");

  MkNodes node(div+1);
  MkInt elemnode(2);
  MkElements elem;
  MkElement **beam;
  MkFloat prop(5);

  MkDOFs dof(6);
  dof[0].SetType(doftXDis,bndtFree);
  dof[1].SetType(doftYDis,bndtFix);
  dof[2].SetType(doftZDis,bndtFix);
  dof[3].SetType(doftXAng,bndtFix);
  dof[4].SetType(doftYAng,bndtFix);
  dof[5].SetType(doftZAng,bndtFree);

  for (i=0;i<div+1;i++) {
    MkPoint pnt=line.GetDivision(float(i)/float(div));
    node[i].SetPoint(pnt);
    node[i].SetDOF(dof);
  }

  beam = new MkElement*[div];
  for (i=0;i<div;i++) beam[i] = new MkBeamElement();

  prop(0) = pile.GetYoungMod();
  prop(1) = pile.GetArea();
  prop(2) = pile.GetShearTor();
  prop(3) = pile.GetSecMomentY();
  prop(4) = pile.GetSecMomentZ();

  for (i=0;i<div;i++) {
    elemnode[0] = i;
    elemnode[1] = i+1;
    beam[i]->SetElemNode(elemnode);
    beam[i]->SetNodes(node);
    beam[i]->SetupProp(prop);
    beam[i]->SetAxialLoad(0);
  }

  elem.Initialize(div,beam);

  for (i=0;i<div;i++) delete beam[i];
  delete[] beam;

  for (i=0;i<Ana.GetSize();i++) {
//    MkDebug("Add node for pile\n");
//    Ana[i]->Add(node);
//    MkDebug("Add element for pile\n");
    Ana[i]->Add(elem);
  }
  return true;
}

bool MkAnalyticSection::Install(MkStrut &strut,int div)
{
  strut.SetDivision(div);
  return Install(strut);
}

bool MkAnalyticSection::Install(MkAnchor &anchor,int div)
{
  int i;
  anchor.SetDivision(div);
  return Install(anchor);
}

bool MkAnalyticSection::Install(MkBolt &bolt,int div)
{
  bolt.SetDivision(div);
  return Install(bolt);
}

bool MkAnalyticSection::Install(MkPile &pile,int div)
{
  pile.SetDivision(div);
  return Install(pile);
}

bool MkAnalyticSection::Uninstall(MkStrut &strut)
{
  int i,div=strut.GetDivision();
  MkLine &line=strut.GetLine();

  MkNodes node(div+1);
  MkInt elemnode(2);
  MkElements elem;
  MkElement **truss;
  MkFloat prop(5);

  MkDOFs dof(6);
  dof[0].SetType(doftXDis,bndtFree);
  dof[1].SetType(doftYDis,bndtFix);
  dof[2].SetType(doftZDis,bndtFix);
  dof[3].SetType(doftXAng,bndtFix);
  dof[4].SetType(doftYAng,bndtFix);
  dof[5].SetType(doftZAng,bndtFix);

  for (i=0;i<div+1;i++) {
    MkPoint pnt=line.GetDivision(float(i)/float(div));
    node[i].SetPoint(pnt);
    node[i].SetDOF(dof);
  }

  truss = new MkElement*[div];
  for (i=0;i<div;i++) truss[i] = new MkTrussElement();

  prop(0) = strut.GetYoungMod();
  prop(1) = strut.GetArea();
  prop(2) = strut.GetShearTor();
  prop(3) = strut.GetSecMomentY();
  prop(4) = strut.GetSecMomentZ();

  for (i=0;i<div;i++) {
    elemnode[0] = i;
    elemnode[1] = i+1;
    truss[i]->SetElemNode(elemnode);
    truss[i]->SetNodes(node);
    truss[i]->SetupProp(prop);
    truss[i]->SetAxialLoad(0);
  }

  elem.Initialize(div,truss);

  for (i=0;i<div;i++) delete truss[i];
  delete[] truss;

  for (i=0;i<Ana.GetSize();i++) {
    Ana[i]->Delete(elem);
  }
  return true;
}

bool MkAnalyticSection::Uninstall(MkAnchor &anchor)
{
  int i,div=anchor.GetDivision();
  MkLine &line=anchor.GetLine();

  MkNodes node(div+1);
  MkInt elemnode(2);
  MkElements elem;
  MkElement **beam;
  MkFloat prop(5);

  MkDOFs dof(6);
  dof[0].SetType(doftXDis,bndtFree);
  dof[1].SetType(doftYDis,bndtFix);
  dof[2].SetType(doftZDis,bndtFix);
  dof[3].SetType(doftXAng,bndtFix);
  dof[4].SetType(doftYAng,bndtFix);
  dof[5].SetType(doftZAng,bndtFix);

  for (i=0;i<div+1;i++) {
    MkPoint pnt=line.GetDivision(float(i)/float(div));
    node[i].SetPoint(pnt);
    node[i].SetDOF(dof);
  }

  beam = new MkElement*[div];
  for (i=0;i<div;i++) beam[i] = new MkBeamElement();

  prop(0) = anchor.GetYoungMod();
  prop(1) = anchor.GetArea();
  prop(2) = anchor.GetShearTor();
  prop(3) = anchor.GetSecMomentY();
  prop(4) = anchor.GetSecMomentZ();

  for (i=0;i<div;i++) {
    elemnode[0] = i;
    elemnode[1] = i+1;
    beam[i]->SetElemNode(elemnode);
    beam[i]->SetNodes(node);
    beam[i]->SetupProp(prop);
    beam[i]->SetAxialLoad(0);
  }

  elem.Initialize(div,beam);

  for (i=0;i<div;i++) delete beam[i];
  delete[] beam;

  for (i=0;i<Ana.GetSize();i++) {
    Ana[i]->Delete(elem);
  }
  return true;
}

bool MkAnalyticSection::Uninstall(MkBolt &bolt)
{
  int i,div=bolt.GetDivision();
  MkLine &line=bolt.GetLine();

  MkNodes node(div+1);
  MkInt elemnode(2);
  MkElements elem;
  MkElement **beam;
  MkFloat prop(5);

  MkDOFs dof(6);
  dof[0].SetType(doftXDis,bndtFree);
  dof[1].SetType(doftYDis,bndtFix);
  dof[2].SetType(doftZDis,bndtFix);
  dof[3].SetType(doftXAng,bndtFix);
  dof[4].SetType(doftYAng,bndtFix);
  dof[5].SetType(doftZAng,bndtFix);

  for (i=0;i<div+1;i++) {
    MkPoint pnt=line.GetDivision(float(i)/float(div));
    node[i].SetPoint(pnt);
    node[i].SetDOF(dof);
  }

  beam = new MkElement*[div];
  for (i=0;i<div;i++) beam[i] = new MkBeamElement();

  prop(0) = bolt.GetYoungMod();
  prop(1) = bolt.GetArea();
  prop(2) = 0;//bolt.GetShearTor();
  prop(3) = 0;//bolt.GetSecMomentY();
  prop(4) = 0;//bolt.GetSecMomentZ();

  for (i=0;i<div;i++) {
    elemnode[0] = i;
    elemnode[1] = i+1;
    beam[i]->SetElemNode(elemnode);
    beam[i]->SetNodes(node);
    beam[i]->SetupProp(prop);
    beam[i]->SetAxialLoad(0);
  }

  elem.Initialize(div,beam);

  for (i=0;i<div;i++) delete beam[i];
  delete[] beam;

  for (i=0;i<Ana.GetSize();i++) {
    Ana[i]->Delete(elem);
  }
  return true;
}

bool MkAnalyticSection::Uninstall(MkPile &pile)
{
  int i,div=pile.GetDivision();
  MkLine &line=pile.GetLine();

  MkNodes node(div+1);
  MkInt elemnode(2);
  MkElements elem;
  MkElement **beam;
  MkFloat prop(5);

  MkDOFs dof(6);
  dof[0].SetType(doftXDis,bndtFree);
  dof[1].SetType(doftYDis,bndtFix);
  dof[2].SetType(doftZDis,bndtFix);
  dof[3].SetType(doftXAng,bndtFix);
  dof[4].SetType(doftYAng,bndtFix);
  dof[5].SetType(doftZAng,bndtFree);

  for (i=0;i<div+1;i++) {
    MkPoint pnt=line.GetDivision(float(i)/float(div));
    node[i].SetPoint(pnt);
    node[i].SetDOF(dof);
  }

  beam = new MkElement*[div];
  for (i=0;i<div;i++) beam[i] = new MkBeamElement();

  prop(0) = pile.GetYoungMod();
  prop(1) = pile.GetArea();
  prop(2) = pile.GetShearTor();
  prop(3) = pile.GetSecMomentY();
  prop(4) = pile.GetSecMomentZ();

  for (i=0;i<div;i++) {
    elemnode[0] = i;
    elemnode[1] = i+1;
    beam[i]->SetElemNode(elemnode);
    beam[i]->SetNodes(node);
    beam[i]->SetupProp(prop);
    beam[i]->SetAxialLoad(0);
  }

  elem.Initialize(div,beam);

  for (i=0;i<div;i++) delete beam[i];
  delete[] beam;

  for (i=0;i<Ana.GetSize();i++) {
    Ana[i]->Delete(elem);
  }
  return true;
}


void MkAnalyticSection::Out()
{
  for(int i=0;i<Ana.GetSize();i++) {
    MkDebug("Ana[i]->Out()\n");
    Ana[i]->Out();
  }
}

void MkAnalyticSection::Out(char *fname)
{
  SetFileName(fname);

  FILE *fp;
  if(strlen(FileName)==0) return;
  fp = fopen(FileName,"a");
  if(!fp) return;
  fprintf(fp,"---------------Info Begin of Analytic Section --------------------------\n");
  fclose(fp);

  Layers.Out(FileName);
  Cuts.Out(FileName);
  Fills.Out(FileName);
  Piles.Out(FileName);
  Struts.Out(FileName);
  Anchors.Out(FileName);
  Bolts.Out(FileName);
  Loads.Out(FileName);
  Subreacts.Out(FileName);

  for(int i=0;i<Ana.GetSize();i++) {
    Ana[i]->Out(FileName);
  }

  fp = fopen(FileName,"a");
  if(!fp) return;
  fprintf(fp,"---------------Info End of Analytic Section ----------------------------\n");
  fclose(fp);
}

void MkAnalyticSection::OutLoad(char *fname)
{
  int i;
  FILE *fp;
  if(strlen(fname)==0) return;
  fp = fopen(fname,"w");
  fclose(fp);

  for(i=0;i<Loads.GetSize();i++) {
    Loads[i].Out(fname);
  }
}

bool MkAnalyticSection::Apply(MkLoads &load)
{
  MkBeamSpring *beam;
  MkMori *mori;
  MkContBeam *cbeam;
  char str[256];

  for (int i=0;i<Ana.GetSize();i++) {
    if(Ana[i]->GetAnalysisType() == atBeamSpring) {
      beam = dynamic_cast<MkBeamSpring*>(Ana[i]);      
      assert(beam);
      beam->Apply(load);
    }
    else if(Ana[i]->GetAnalysisType() == atMori) {
      mori = dynamic_cast<MkMori*>(Ana[i]);
      assert(mori);
      mori->Apply(load,Layers);
    }
    else if(Ana[i]->GetAnalysisType() == atContBeam) {
      cbeam = dynamic_cast<MkContBeam*>(Ana[i]);
      assert(cbeam);
      cbeam->Apply(load,Layers);
    }
  }
  return true;
}

bool MkAnalyticSection::operator==(MkAnalyticSection &ans)
{
  bool flag=true;

  flag = flag && Ana == ans.Ana;
  flag = flag && Piles == ans.Piles;
  flag = flag && Struts == ans.Struts;
  flag = flag && Bolts == ans.Bolts;
  flag = flag && Anchors == ans.Anchors;
  flag = flag && Wales == ans.Wales;
  flag = flag && Panels == ans.Panels;
  flag = flag && Layers == ans.Layers;
  flag = flag && !strcmp(FileName,ans.FileName);
  
  return flag;
}

bool MkAnalyticSection::operator!=(MkAnalyticSection &ans)
{
  return !(*this==ans);
}

MkAnalyticSection& MkAnalyticSection::operator=(MkAnalyticSection &ans)
{
  Ana = ans.Ana;
  Piles = ans.Piles;
  Struts = ans.Struts;
  Bolts = ans.Bolts;
  Anchors = ans.Anchors;
  Wales = ans.Wales;
  Panels = ans.Panels;
  Layers = ans.Layers;
  strcpy(FileName,ans.FileName);
  return *this;
}
//------------------------------------------------ New functions
// Based on the Nodes contains all the nodes previously
// to improve the speed of analysis, because the installation
// of new structure into support system takes too much time
bool MkAnalyticSection::InstallNew(MkStrut &strut)
{
  //MkDebug("InstallNew strut to Analytic Section\n");
  int i,j,cnt;
  float delta[2]={0,0};
  float iniforcecorrect=0;
  int ndi[2];   // index of edge node;
  MkNode nd[2]; // edge node
  MkLine &line=strut.GetLine();
  MkNodes &node=*NodeRef;
  MkFloat nodeorder;
  MkInt elemnode(2);
  MkElements elem;
  MkElement **truss;
  MkFloat prop(5);

  if(line[0].X>line[1].X) Swap(line[0],line[1]);
  //count how many nodes are located in strut
  cnt = 0;
  for(i=0;i<node.GetSize();i++) {
    if(line.IsInLine(node[i].GetPoint())) {
      MkDOFs &dof = node[i].GetDOFs();
      for (j=0;j<dof.GetSize();j++) {
        if(dof[j].GetDOFType()==doftXDis) dof[j].SetBNDType(bndtFree);
      }
      cnt++;
    }
  }

  nodeorder.Initialize(cnt,2);
  cnt = 0;
  for(i=0;i<node.GetSize();i++) {
    if(line.IsInLine(node[i].GetPoint())) {
      nodeorder(cnt,0) = i;
      cnt++;
    }
  }

  // find the location of node in the line
  for(i=0;i<cnt;i++) {
    float t;
    if(line.GetIntParam(node[(int)nodeorder(i,0)].GetPoint(),t)&& t<1.0+EPS && t>-EPS){
      nodeorder(i,1) = t;
    }
  }

  //bubble sort with respect to the order of node in strut
  for(i=0;i<cnt-1;i++) {
    for(j=i+1;j<cnt;j++) {
      if(nodeorder(i,1) > nodeorder(j,1)) {
	swap(nodeorder(i,0),nodeorder(j,0));
	swap(nodeorder(i,1),nodeorder(j,1));
      }
    }
  }

  prop(0) = strut.GetYoungMod();
  prop(1) = strut.GetArea()/(strut.GetSpacing()>EPS?strut.GetSpacing():1);
  prop(2) = strut.GetShearTor();
  prop(3) = strut.GetSecMomentY()/(strut.GetSpacing()>EPS?strut.GetSpacing():1);
  prop(4) = strut.GetSecMomentZ()/(strut.GetSpacing()>EPS?strut.GetSpacing():1);

  ndi[0] = int(nodeorder(0,0)+0.5);
  ndi[1] = int(nodeorder(cnt-1,0)+0.5);
  nd[0] = node[ndi[0]];
  nd[1] = node[ndi[1]];

  if(nd[0].GetPoint().X > nd[1].GetPoint().X) {
    Swap(nd[0],nd[1]);
    swap(ndi[0],ndi[1]);
  }

//  delta[0] = nd[0].GetXDis();
//  delta[1] = nd[1].GetXDis();

  if(line.GetLength()>EPS) {
    iniforcecorrect = prop(0)*prop(1)*(delta[0]-delta[1])/line.GetLength();
    IniForceCorrection.Add(ndi[0],prop(0)*prop(1)*delta[0]/line.GetLength());
    IniForceCorrection.Add(ndi[1],prop(0)*prop(1)*delta[1]/line.GetLength());
  }
  JackingForce.Add(ndi[0],strut.GetJackingForce()/(strut.GetSpacing()>EPS?strut.GetSpacing():1));
  JackingForce.Add(ndi[1],-strut.GetJackingForce()/(strut.GetSpacing()>EPS?strut.GetSpacing():1));

  truss = new MkElement*[cnt-1];
  for (i=0;i<cnt-1;i++) truss[i] = new MkTrussElement();

  for (i=0;i<cnt-1;i++) {
    elemnode[0] = (int)nodeorder(i,0);
    elemnode[1] = (int)nodeorder(i+1,0);
    truss[i]->SetElemNode(elemnode);
    truss[i]->SetNodes(node);
    truss[i]->SetupProp(prop);
    truss[i]->SetAxialLoad(0);
    truss[i]->SetIniForceCorrection(iniforcecorrect);
    truss[i]->SetJackingForce(strut.GetJackingForce()/(strut.GetSpacing()>EPS?strut.GetSpacing():1));
  }

  elem.Initialize(cnt-1,truss);

  //  elem.Out();

  for (i=0;i<cnt-1;i++) delete truss[i];
  delete[] truss;

  for (i=0;i<Ana.GetSize();i++) {
    //MkDebug("Add element for strut\n");
    Ana[i]->AddNew(elem);
  }
  return true;
}

bool MkAnalyticSection::InstallNew(MkAnchor &anchor)
{
//MkDebug("InstallNew strut to Analytic Section\n");
  int i,j,cnt;
  float delta[2];
  float iniforcecorrect=0;
  int ndi[2];   // index of edge node;
  MkNode nd[2]; // edge node
  MkLine &line=anchor.GetLine();
  MkNodes &node=*NodeRef;
  MkFloat nodeorder;
  MkInt elemnode(2);
  MkElements elem;
  MkElement **truss;
  MkFloat prop(5);
  MkPoint bp;

  if(line[0].X>line[1].X) Swap(line[0],line[1]);
  //bp is boundary point
  bp = (anchor.GetSide() == mkLeft)?(line[0].X < line[1].X ? line[0] : line[1]):
                                    (line[0].X < line[1].X ? line[1] : line[0]);
  //count how many nodes are located in anchor
  cnt = 0;
  for(i=0;i<node.GetSize();i++) {
    if(line.IsInLine(node[i].GetPoint())) {
      MkDOFs &dof = node[i].GetDOFs();
      for (j=0;j<dof.GetSize();j++) {
        if(dof[j].GetDOFType()==doftXDis) dof[j].SetBNDType(bndtFree);
      }
      if(node[i].GetPoint()==bp) {
        for (j=0;j<dof.GetSize();j++) {
          if(dof[j].GetBNDType()==bndtFree)
            dof[j].SetBNDType(bndtFix);
        }
      }
      cnt++;
    }
  }

  nodeorder.Initialize(cnt,2);
  cnt = 0;
  for(i=0;i<node.GetSize();i++) {
    if(line.IsInLine(node[i].GetPoint())) {
      nodeorder(cnt,0) = i;
      cnt++;
    }
  }

  // find the location of node in the line
  for(i=0;i<cnt;i++) {
    float t;
    if(line.GetIntParam(node[(int)nodeorder(i,0)].GetPoint(),t)&& t<1.0+EPS && t>-EPS){
      nodeorder(i,1) = t;
    }
  }

  //bubble sort with respect to the order of node in anchor
  for(i=0;i<cnt-1;i++) {
    for(j=i+1;j<cnt;j++) {
      if(nodeorder(i,1) > nodeorder(j,1)) {
	swap(nodeorder(i,0),nodeorder(j,0));
	swap(nodeorder(i,1),nodeorder(j,1));
      }
    }
  }

  truss = new MkElement*[cnt-1];
  for (i=0;i<cnt-1;i++) truss[i] = new MkTrussElement();

  prop(0) = anchor.GetYoungMod();
  prop(1) = anchor.GetArea()/(anchor.GetSpacing()>EPS?anchor.GetSpacing():1);
  prop(2) = anchor.GetShearTor();
  prop(3) = anchor.GetSecMomentY()/(anchor.GetSpacing()>EPS?anchor.GetSpacing():1);
  prop(4) = anchor.GetSecMomentZ()/(anchor.GetSpacing()>EPS?anchor.GetSpacing():1);

  ndi[0] = int(nodeorder(0,0)+0.5);
  ndi[1] = int(nodeorder(cnt-1,0)+0.5);
  nd[0] = node[ndi[0]];
  nd[1] = node[ndi[1]];

  if(nd[0].GetPoint().X > nd[1].GetPoint().X) {
    Swap(nd[0],nd[1]);
    swap(ndi[0],ndi[1]);
  }

  delta[0] = nd[0].GetXDis();
  delta[1] = nd[1].GetXDis();

  if(line.GetLength()>EPS) {
    iniforcecorrect = prop(0)*prop(1)*(delta[0]-delta[1])/line.GetLength();
    IniForceCorrection.Add(ndi[0],prop(0)*prop(1)*delta[0]/line.GetLength());
    IniForceCorrection.Add(ndi[1],prop(0)*prop(1)*delta[1]/line.GetLength());
  }
  JackingForce.Add(ndi[0],anchor.GetJackingForce()/(anchor.GetSpacing()>EPS?anchor.GetSpacing():1));
  JackingForce.Add(ndi[1],-anchor.GetJackingForce()/(anchor.GetSpacing()>EPS?anchor.GetSpacing():1));

  for (i=0;i<cnt-1;i++) {
    elemnode[0] = (int)nodeorder(i,0);
    elemnode[1] = (int)nodeorder(i+1,0);
    truss[i]->SetElemNode(elemnode);
    truss[i]->SetNodes(node);
    truss[i]->SetupProp(prop);
    truss[i]->SetAxialLoad(0);
    truss[i]->SetIniForceCorrection(iniforcecorrect);
    truss[i]->SetJackingForce(anchor.GetJackingForce()/(anchor.GetSpacing()>EPS?anchor.GetSpacing():1));
  }

  elem.Initialize(cnt-1,truss);

  //  elem.Out();

  for (i=0;i<cnt-1;i++) delete truss[i];
  delete[] truss;

  for (i=0;i<Ana.GetSize();i++) {
    //MkDebug("Add element for anchor\n");
    Ana[i]->AddNew(elem);
  }
  return true;
}

bool MkAnalyticSection::InstallNew(MkBolt &bolt)
{
  int i,j,cnt;
  //MkDebug("InstallNew bolt to Analytic Section\n");
  float delta[2];
  float iniforcecorrect=0;
  int ndi[2];   // index of edge node;
  MkNode nd[2]; // edge node
  MkLine &line=bolt.GetLine();
  MkNodes &node=*NodeRef;

  MkFloat nodeorder;
  MkInt elemnode(2);
  MkElements elem;
  MkElement **truss;
  MkFloat prop(5);
  MkPoint bp;

  if(line[0].X>line[1].X) Swap(line[0],line[1]);
  //bp is boundary point
  //"side of bolt is left" mean bolt is installed left side of wall
  bp = (bolt.GetSide() == mkLeft)?(line[0].X < line[1].X ? line[0] : line[1]):
                                    (line[0].X < line[1].X ? line[1] : line[0]);

  //count how many nodes are located in bolt
  cnt = 0;
  for(i=0;i<node.GetSize();i++) {
    if(line.IsInLine(node[i].GetPoint())) {
      MkDOFs &dof = node[i].GetDOFs();
      for (j=0;j<dof.GetSize();j++) {
        if(dof[j].GetDOFType()==doftXDis) dof[j].SetBNDType(bndtFree);
      }
      if(node[i].GetPoint()==bp) {
        for (j=0;j<dof.GetSize();j++) {
          if(dof[j].GetBNDType()==bndtFree)
            dof[j].SetBNDType(bndtFix);
        }
      }
      cnt++;
    }
  }

  nodeorder.Initialize(cnt,2);
  cnt = 0;
  for(i=0;i<node.GetSize();i++) {
    if(line.IsInLine(node[i].GetPoint())) {
      nodeorder(cnt,0) = i;
      cnt++;
    }
  }

  // find the location of node in the line
  for(i=0;i<cnt;i++) {
    float t;
    if(line.GetIntParam(node[(int)nodeorder(i,0)].GetPoint(),t)&& t<1.0+EPS && t>-EPS){
      nodeorder(i,1) = t;
    }
  }

  //bubble sort with respect to the order of node in bolt
  for(i=0;i<cnt-1;i++) {
    for(j=i+1;j<cnt;j++) {
      if(nodeorder(i,1) > nodeorder(j,1)) {
	swap(nodeorder(i,0),nodeorder(j,0));
	swap(nodeorder(i,1),nodeorder(j,1));
      }
    }
  }

  truss = new MkElement*[cnt-1];
  for (i=0;i<cnt-1;i++) truss[i] = new MkTrussElement();

  prop(0) = bolt.GetYoungMod();
  prop(1) = bolt.GetArea()/(bolt.GetSpacing()>EPS?bolt.GetSpacing():1);
  prop(2) = 0;//bolt.GetShearTor();
  prop(3) = 0;//bolt.GetSecMomentY()/(bolt.GetSpacing()>EPS?bolt.GetSpacing():1);
  prop(4) = 0;//bolt.GetSecMomentZ()/(bolt.GetSpacing()>EPS?bolt.GetSpacing():1);

  ndi[0] = int(nodeorder(0,0)+0.5);
  ndi[1] = int(nodeorder(cnt-1,0)+0.5);
  nd[0] = node[ndi[0]];
  nd[1] = node[ndi[1]];

  if(nd[0].GetPoint().X > nd[1].GetPoint().X) {
    Swap(nd[0],nd[1]);
    swap(ndi[0],ndi[1]);
  }

  delta[0] = nd[0].GetXDis();
  delta[1] = nd[1].GetXDis();

  if(line.GetLength()>EPS) {
    iniforcecorrect = prop(0)*prop(1)*(delta[0]-delta[1])/line.GetLength();
    IniForceCorrection.Add(ndi[0],prop(0)*prop(1)*delta[0]/line.GetLength());
    IniForceCorrection.Add(ndi[1],prop(0)*prop(1)*delta[1]/line.GetLength());
  }

  for (i=0;i<cnt-1;i++) {
    elemnode[0] = (int)nodeorder(i,0);
    elemnode[1] = (int)nodeorder(i+1,0);
    truss[i]->SetElemNode(elemnode);
    truss[i]->SetNodes(node);
    truss[i]->SetupProp(prop);
    truss[i]->SetAxialLoad(0);
    truss[i]->SetIniForceCorrection(iniforcecorrect);
  }

  elem.Initialize(cnt-1,truss);

  //  elem.Out();

  for (i=0;i<cnt-1;i++) delete truss[i];
  delete[] truss;

  for (i=0;i<Ana.GetSize();i++) {
    //MkDebug("Add element for bolt\n");
    Ana[i]->AddNew(elem);
  }
  return true;
}

bool MkAnalyticSection::InstallNew(MkPile &pile)
{
  int i,j,cnt;

  MkLine &line=pile.GetLine();

  MkNodes &node=*NodeRef;

  MkFloat nodeorder;
  MkInt elemnode(2);
  MkElements elem;
  MkElement **beam;
  MkFloat prop(5);

  //count how many nodes are located in pile
  cnt = 0;
  for(i=0;i<node.GetSize();i++) {
    if(line.IsInLine(node[i].GetPoint())) {
      MkDOFs &dof = node[i].GetDOFs();
      for (j=0;j<dof.GetSize();j++) {
        if(dof[j].GetDOFType()==doftXDis) dof[j].SetBNDType(bndtFree);
        else if(dof[j].GetDOFType()==doftZAng) dof[j].SetBNDType(bndtFree);
      }
      cnt++;
    }
  }

  nodeorder.Initialize(cnt,2);
  cnt = 0;
  for(i=0;i<node.GetSize();i++) {
    if(line.IsInLine(node[i].GetPoint())) {
      nodeorder(cnt,0) = i;
      cnt++;
    }
  }

  // find the location of node in the line
  for(i=0;i<cnt;i++) {
    float t;
    if(line.GetIntParam(node[(int)nodeorder(i,0)].GetPoint(),t)&& t<1.0+EPS && t>-EPS){
      nodeorder(i,1) = t;
    }
  }

  //bubble sort with respect to the order of node in pile
  for(i=0;i<cnt-1;i++) {
    for(j=i+1;j<cnt;j++) {
      if(nodeorder(i,1) > nodeorder(j,1)) {
	swap(nodeorder(i,0),nodeorder(j,0));
	swap(nodeorder(i,1),nodeorder(j,1));
      }
    }
  }

  beam = new MkElement*[cnt-1];
  for (i=0;i<cnt-1;i++) beam[i] = new MkBeamElement();

  prop(0) = pile.GetYoungMod();
  prop(1) = pile.GetArea();
  prop(2) = pile.GetShearTor();
  prop(3) = pile.GetSecMomentY();
  prop(4) = pile.GetSecMomentZ();

  for (i=0;i<cnt-1;i++) {
    elemnode[0] = (int)nodeorder(i,0);
    elemnode[1] = (int)nodeorder(i+1,0);
    beam[i]->SetElemNode(elemnode);
    beam[i]->SetNodes(node);
    beam[i]->SetupProp(prop);
    beam[i]->SetAxialLoad(0);
  }

  elem.Initialize(cnt-1,beam);

  for (i=0;i<cnt-1;i++) delete beam[i];
  delete[] beam;

  for (i=0;i<Ana.GetSize();i++) {
    Ana[i]->AddNew(elem);
  }
  return true;
}

bool MkAnalyticSection::UninstallNew(MkStrut &strut)
{
  int i,j,k,cnt;

  //MkDebug("InstallNew pile to Analytic Section\n");
  MkLine &line=strut.GetLine();

  MkNodes &node=*NodeRef;

  MkFloat nodeorder;
  MkInt elemnode(2);

  //count how many nodes are located in pile
  cnt = 0;
  for(i=0;i<node.GetSize();i++) {
    if(line.IsInLine(node[i].GetPoint())) {
      cnt++;
    }
  }

  nodeorder.Initialize(cnt,2);
  cnt = 0;
  for(i=0;i<node.GetSize();i++) {
    if(line.IsInLine(node[i].GetPoint())) {
      nodeorder(cnt,0) = i;
      cnt++;
    }
  }

  // find the location of node in the line
  for(i=0;i<cnt;i++) {
    float t;
    if(line.GetIntParam(node[(int)nodeorder(i,0)].GetPoint(),t)&& t<1.0+EPS && t>-EPS){
      nodeorder(i,1) = t;
    }
  }

  //bubble sort with respect to the order of node in pile
  for(i=0;i<cnt-1;i++) {
    for(j=1;j<cnt;j++) {
      if(nodeorder(i,1) > nodeorder(j,1)) {
	swap(nodeorder(i,0),nodeorder(j,0));
	swap(nodeorder(i,1),nodeorder(j,1));
      }
    }
  }

  for (i=0;i<cnt-1;i++) {
    elemnode[0] = (int)nodeorder(i,0);
    elemnode[1] = (int)nodeorder(i+1,0);
    for (j=0;j<Ana.GetSize();j++) {
      MkElements &elems=Ana[j]->GetElements();
      for(k=0;k<elems.GetSize();k++) {
	if(elems[k].GetNodeNumber(0)==elemnode[0] && elems[k].GetNodeNumber(1)==elemnode[1]) {
	  Ana[i]->Delete(elems[k]);
	  break;
	}
      }
      //MkDebug("Delete element for pile\n");
    }
  }
  return true;
}

bool MkAnalyticSection::UninstallNew(MkAnchor &anchor)
{
  int i,j,k,cnt;

  //MkDebug("InstallNew pile to Analytic Section\n");
  MkLine &line=anchor.GetLine();

  MkNodes &node=*NodeRef;

  MkFloat nodeorder;
  MkInt elemnode(2);

  //count how many nodes are located in pile
  cnt = 0;
  for(i=0;i<node.GetSize();i++) {
    if(line.IsInLine(node[i].GetPoint())) {
      cnt++;
    }
  }

  nodeorder.Initialize(cnt,2);
  cnt = 0;
  for(i=0;i<node.GetSize();i++) {
    if(line.IsInLine(node[i].GetPoint())) {
      nodeorder(cnt,0) = i;
      cnt++;
    }
  }

  // find the location of node in the line
  for(i=0;i<cnt;i++) {
    float t;
    if(line.GetIntParam(node[(int)nodeorder(i,0)].GetPoint(),t)&& t<1.0+EPS && t>-EPS){
      nodeorder(i,1) = t;
    }
  }

  //bubble sort with respect to the order of node in pile
  for(i=0;i<cnt-1;i++) {
    for(j=1;j<cnt;j++) {
      if(nodeorder(i,1) > nodeorder(j,1)) {
	swap(nodeorder(i,0),nodeorder(j,0));
	swap(nodeorder(i,1),nodeorder(j,1));
      }
    }
  }

  for (i=0;i<cnt-1;i++) {
    elemnode[0] = (int)nodeorder(i,0);
    elemnode[1] = (int)nodeorder(i+1,0);
    for (j=0;j<Ana.GetSize();j++) {
      MkElements &elems=Ana[j]->GetElements();
      for(k=0;k<elems.GetSize();k++) {
	if(elems[k].GetNodeNumber(0)==elemnode[0] && elems[k].GetNodeNumber(1)==elemnode[1]) {
	  Ana[i]->Delete(elems[k]);
	  break;
	}
      }
      //MkDebug("Delete element for pile\n");
    }
  }
  return true;
}

bool MkAnalyticSection::UninstallNew(MkBolt &bolt)
{
  int i,j,k,cnt;

  //MkDebug("InstallNew pile to Analytic Section\n");
  MkLine &line=bolt.GetLine();

  MkNodes &node=*NodeRef;

  MkFloat nodeorder;
  MkInt elemnode(2);

  //count how many nodes are located in pile
  cnt = 0;
  for(i=0;i<node.GetSize();i++) {
    if(line.IsInLine(node[i].GetPoint())) {
      cnt++;
    }
  }

  nodeorder.Initialize(cnt,2);
  cnt = 0;
  for(i=0;i<node.GetSize();i++) {
    if(line.IsInLine(node[i].GetPoint())) {
      nodeorder(cnt,0) = i;
      cnt++;
    }
  }

  // find the location of node in the line
  for(i=0;i<cnt;i++) {
    float t;
    if(line.GetIntParam(node[(int)nodeorder(i,0)].GetPoint(),t)&& t<1.0+EPS && t>-EPS){
      nodeorder(i,1) = t;
    }
  }

  //bubble sort with respect to the order of node in pile
  for(i=0;i<cnt-1;i++) {
    for(j=1;j<cnt;j++) {
      if(nodeorder(i,1) > nodeorder(j,1)) {
	swap(nodeorder(i,0),nodeorder(j,0));
	swap(nodeorder(i,1),nodeorder(j,1));
      }
    }
  }

  for (i=0;i<cnt-1;i++) {
    elemnode[0] = (int)nodeorder(i,0);
    elemnode[1] = (int)nodeorder(i+1,0);
    for (j=0;j<Ana.GetSize();j++) {
      MkElements &elems=Ana[j]->GetElements();
      for(k=0;k<elems.GetSize();k++) {
	if(elems[k].GetNodeNumber(0)==elemnode[0] && elems[k].GetNodeNumber(1)==elemnode[1]) {
	  Ana[i]->Delete(elems[k]);
	  break;
	}
      }
      //MkDebug("Delete element for pile\n");
    }
  }
  return true;
}

bool MkAnalyticSection::UninstallNew(MkPile &pile)
{
  int i,j,k,cnt;

  //MkDebug("InstallNew pile to Analytic Section\n");
  MkLine &line=pile.GetLine();

  MkNodes &node=*NodeRef;

  MkFloat nodeorder;
  MkInt elemnode(2);

  //count how many nodes are located in pile
  cnt = 0;
  for(i=0;i<node.GetSize();i++) {
    if(line.IsInLine(node[i].GetPoint())) {
      cnt++;
    }
  }

  nodeorder.Initialize(cnt,2);
  cnt = 0;
  for(i=0;i<node.GetSize();i++) {
    if(line.IsInLine(node[i].GetPoint())) {
      nodeorder(cnt,0) = i;
      cnt++;
    }
  }

  // find the location of node in the line
  for(i=0;i<cnt;i++) {
    float t;
    if(line.GetIntParam(node[(int)nodeorder(i,0)].GetPoint(),t)&& t<1.0+EPS && t>-EPS){
      nodeorder(i,1) = t;
    }
  }

  //bubble sort with respect to the order of node in pile
  for(i=0;i<cnt-1;i++) {
    for(j=1;j<cnt;j++) {
      if(nodeorder(i,1) > nodeorder(j,1)) {
	swap(nodeorder(i,0),nodeorder(j,0));
	swap(nodeorder(i,1),nodeorder(j,1));
      }
    }
  }

  for (i=0;i<cnt-1;i++) {
    elemnode[0] = (int)nodeorder(i,0);
    elemnode[1] = (int)nodeorder(i+1,0);
    for (j=0;j<Ana.GetSize();j++) {
      MkElements &elems=Ana[j]->GetElements();
      for(k=0;k<elems.GetSize();k++) {
	if(elems[k].GetNodeNumber(0)==elemnode[0] && elems[k].GetNodeNumber(1)==elemnode[1]) {
	  Ana[i]->Delete(elems[k]);
	  break;
	}
      }
      //MkDebug("Delete element for pile\n");
    }
  }
  return true;
}
//------------------------------------------------ New functions

bool MkAnalyticSection::Initialize()
{
  int i;
// This function assumes the method is beam-spring so
// it is not apporoprietate for continuous beam
//  MkDebug("Before AnalyticSection::SetupLoad\n");
  if(Ana[0]->GetAnalysisType()==atMori || Ana[0]->GetAnalysisType()==atBeamSpring) 
    SetupLoad();  // temporary, make general code to apply load for each analysis
  MkDebug("Before AnalyticSection::Setup Subreact \n");
  SetupSubreact();
  MkDebug("Before Ana[i]->Initialize...\n");
  for (i=0;i<Ana.GetSize();i++) {
    Ana[i]->Initialize(); // needs backup of old data
    if(Ana[i]->GetAnalysisType()==atMori) Ana[i]->Apply(Loads,Layers);
    else {
      Ana[i]->Apply(Loads);
      Ana[i]->Apply(Layers);
    }

    Ana[i]->OutLoad("load.chk");
    Ana[i]->Apply(Subreacts);
    Ana[i]->ApplyIniForceCorrect(IniForceCorrection);
    Ana[i]->ApplyJackingForce(JackingForce);
    Ana[i]->SetPrintStep(1);
    Ana[i]->SetMaxStep(10);
  }
  return true;
}

bool MkAnalyticSection::Solve(MkAnalysisType at)
{
  int i;
  bool flag;
  MkDebug("Before AnalyticSection::Initialize\n");
  Initialize();
  MkDebug("After AnalyticSection::Initialize\n");

  for(i=0;i<Ana.GetSize();i++)
    if(Ana[i]->GetAnalysisType()==at) {
      flag = Ana[i]->Solve();
      return true;
    }
  return false;
}

