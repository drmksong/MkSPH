//---------------------------------------------------------------------------
#ifndef TTunShapeH
#define TTunShapeH
#include "TMyShape.h"
//---------------------------------------------------------------------------
class TTunShape : public TMyShapeList {
private:
     bool Continuity;
     bool Crossing;
public:
     TTunShape();
     bool isContinuous();
     bool isCrossed();
     void Draw(TObject *);
};

//---------------------------------------------------------------------------
#endif
