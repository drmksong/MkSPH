#include "stdafx.h"
#include "MkHeav.h"

MkHeav::MkHeav()
{
  FS = 0;
  Cu = 0;
  D = 0;
  L = 0;
  H = 0;
  Gamma = 0;
}

float MkHeav::GetFS()
{
  float a,b;
  if (fabs(L*D)<EPS) return 0;
  if(L<D) {
    b = H*(Gamma-2*Cu*(1/2/D+1/L));
    if(fabs(b)<EPS) return 0;
    a = 5.14*Cu*(1+0.44*D/L);
    return a/b;
  }
  else if(D<L && L < 2*D) {
    b = H*(Gamma-2*Cu*(1/2/D+(2*D-L)/L/D));
    if(fabs(b)<EPS) return 0;
    a = 5.14*Cu*(1+0.44*(2*D-L)/L);
    return a/b;
  }
  else if(2*D < L) {
    b = H*(Gamma-Cu/D);
    if(fabs(b)<EPS) return 0;
    a = 5.14*Cu;
    return a/b;
  }
  return 0;
}
